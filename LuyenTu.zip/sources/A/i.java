package A;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.FontVariationAxis;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class i extends g {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final Class f18i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Constructor f19j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final Method f20k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final Method f21l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final Method f22m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Method f23n;
    public final Method o;

    public i() throws NoSuchMethodException {
        Method methodA0;
        Constructor<?> constructor;
        Method methodZ;
        Method method;
        Method method2;
        Method method3;
        Class<?> cls = null;
        try {
            Class<?> cls2 = Class.forName("android.graphics.FontFamily");
            constructor = cls2.getConstructor(null);
            methodZ = Z(cls2);
            Class cls3 = Integer.TYPE;
            method = cls2.getMethod("addFontFromBuffer", ByteBuffer.class, cls3, FontVariationAxis[].class, cls3, cls3);
            method2 = cls2.getMethod("freeze", null);
            method3 = cls2.getMethod("abortCreation", null);
            methodA0 = a0(cls2);
            cls = cls2;
        } catch (ClassNotFoundException | NoSuchMethodException e6) {
            Log.e("TypefaceCompatApi26Impl", "Unable to collect necessary methods for class ".concat(e6.getClass().getName()), e6);
            methodA0 = null;
            constructor = null;
            methodZ = null;
            method = null;
            method2 = null;
            method3 = null;
        }
        this.f18i = cls;
        this.f19j = constructor;
        this.f20k = methodZ;
        this.f21l = method;
        this.f22m = method2;
        this.f23n = method3;
        this.o = methodA0;
    }

    public static Method Z(Class cls) {
        Class cls2 = Boolean.TYPE;
        Class cls3 = Integer.TYPE;
        return cls.getMethod("addFontFromAssetManager", AssetManager.class, String.class, cls3, cls2, cls3, cls3, cls3, FontVariationAxis[].class);
    }

    public final boolean W(Context context, Object obj, String str, int i6, int i7, int i8, FontVariationAxis[] fontVariationAxisArr) {
        try {
            return ((Boolean) this.f20k.invoke(obj, context.getAssets(), str, 0, Boolean.FALSE, Integer.valueOf(i6), Integer.valueOf(i7), Integer.valueOf(i8), fontVariationAxisArr)).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    public Typeface X(Object obj) {
        try {
            Object objNewInstance = Array.newInstance((Class<?>) this.f18i, 1);
            Array.set(objNewInstance, 0, obj);
            return (Typeface) this.o.invoke(null, objNewInstance, -1, -1);
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return null;
        }
    }

    public final boolean Y(Object obj) {
        try {
            return ((Boolean) this.f22m.invoke(obj, null)).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    public Method a0(Class cls) throws NoSuchMethodException {
        Class<?> cls2 = Array.newInstance((Class<?>) cls, 1).getClass();
        Class cls3 = Integer.TYPE;
        Method declaredMethod = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", cls2, cls3, cls3);
        declaredMethod.setAccessible(true);
        return declaredMethod;
    }

    @Override // A.g, X2.a
    public final Typeface n(Context context, p149z.b bVar, Resources resources, int i6) throws IllegalAccessException, InstantiationException, InvocationTargetException {
        Object objNewInstance;
        Method method = this.f20k;
        if (method == null) {
            Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
        }
        if (method == null) {
            return super.n(context, bVar, resources, i6);
        }
        try {
            objNewInstance = this.f19j.newInstance(null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            objNewInstance = null;
        }
        if (objNewInstance != null) {
            p149z.c[] cVarArr = bVar.f10558a;
            int length = cVarArr.length;
            int i7 = 0;
            while (i7 < length) {
                p149z.c cVar = cVarArr[i7];
                Context context2 = context;
                if (W(context2, objNewInstance, cVar.f10559a, cVar.f10563e, cVar.f10560b, cVar.f10561c ? 1 : 0, FontVariationAxis.fromFontVariationSettings(cVar.f10562d))) {
                    i7++;
                    context = context2;
                } else {
                    try {
                        this.f23n.invoke(objNewInstance, null);
                    } catch (IllegalAccessException | InvocationTargetException unused2) {
                    }
                }
            }
            if (Y(objNewInstance)) {
                return X(objNewInstance);
            }
        }
        return null;
    }

    @Override // A.g, X2.a
    public final Typeface o(Context context, E.k[] kVarArr, int i6) throws IOException {
        Object objNewInstance;
        Typeface typefaceX;
        boolean zBooleanValue;
        if (kVarArr.length >= 1) {
            Method method = this.f20k;
            if (method == null) {
                Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
            }
            try {
                if (method != null) {
                    HashMap map = new HashMap();
                    for (E.k kVar : kVarArr) {
                        if (kVar.f898f == 0) {
                            Uri uri = kVar.f893a;
                            if (!map.containsKey(uri)) {
                                map.put(uri, p000a.a.y(context, uri));
                            }
                        }
                    }
                    Map mapUnmodifiableMap = Collections.unmodifiableMap(map);
                    try {
                        objNewInstance = this.f19j.newInstance(null);
                    } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
                        objNewInstance = null;
                    }
                    if (objNewInstance != null) {
                        int length = kVarArr.length;
                        int i7 = 0;
                        boolean z6 = false;
                        while (true) {
                            Method method2 = this.f23n;
                            if (i7 >= length) {
                                if (!z6) {
                                    method2.invoke(objNewInstance, null);
                                    break;
                                }
                                if (!Y(objNewInstance) || (typefaceX = X(objNewInstance)) == null) {
                                    break;
                                    break;
                                }
                                return Typeface.create(typefaceX, i6);
                            }
                            E.k kVar2 = kVarArr[i7];
                            ByteBuffer byteBuffer = (ByteBuffer) mapUnmodifiableMap.get(kVar2.f893a);
                            if (byteBuffer != null) {
                                try {
                                    zBooleanValue = ((Boolean) this.f21l.invoke(objNewInstance, byteBuffer, Integer.valueOf(kVar2.f894b), null, Integer.valueOf(kVar2.f895c), Integer.valueOf(kVar2.f896d ? 1 : 0))).booleanValue();
                                } catch (IllegalAccessException | InvocationTargetException unused2) {
                                    zBooleanValue = false;
                                }
                                if (!zBooleanValue) {
                                    method2.invoke(objNewInstance, null);
                                    break;
                                }
                                z6 = true;
                            }
                            i7++;
                            z6 = z6;
                        }
                    }
                } else {
                    E.k kVarU = X2.a.u(kVarArr, i6);
                    ParcelFileDescriptor parcelFileDescriptorOpenFileDescriptor = context.getContentResolver().openFileDescriptor(kVarU.f893a, "r", null);
                    if (parcelFileDescriptorOpenFileDescriptor != null) {
                        try {
                            Typeface typefaceBuild = new Typeface.Builder(parcelFileDescriptorOpenFileDescriptor.getFileDescriptor()).setWeight(kVarU.f895c).setItalic(kVarU.f896d).build();
                            parcelFileDescriptorOpenFileDescriptor.close();
                            return typefaceBuild;
                        } catch (Throwable th) {
                            try {
                                parcelFileDescriptorOpenFileDescriptor.close();
                            } catch (Throwable th2) {
                                th.addSuppressed(th2);
                            }
                            throw th;
                        }
                    }
                    if (parcelFileDescriptorOpenFileDescriptor != null) {
                        parcelFileDescriptorOpenFileDescriptor.close();
                        return null;
                    }
                }
            } catch (IOException | IllegalAccessException | InvocationTargetException unused3) {
            }
        }
        return null;
    }

    @Override // X2.a
    public final Typeface q(Context context, Resources resources, int i6, String str, int i7) throws IllegalAccessException, InstantiationException, InvocationTargetException {
        Object objNewInstance;
        Method method = this.f20k;
        if (method == null) {
            Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation.");
        }
        if (method == null) {
            return super.q(context, resources, i6, str, i7);
        }
        try {
            objNewInstance = this.f19j.newInstance(null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            objNewInstance = null;
        }
        if (objNewInstance != null) {
            if (!W(context, objNewInstance, str, 0, -1, -1, null)) {
                try {
                    this.f23n.invoke(objNewInstance, null);
                } catch (IllegalAccessException | InvocationTargetException unused2) {
                }
            } else if (Y(objNewInstance)) {
                return X(objNewInstance);
            }
        }
        return null;
    }
}
