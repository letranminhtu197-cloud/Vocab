package A;

import android.graphics.Insets;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final d f1e = new d(0, 0, 0, 0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f2a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f3b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f4c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f5d;

    public d(int i6, int i7, int i8, int i9) {
        this.f2a = i6;
        this.f3b = i7;
        this.f4c = i8;
        this.f5d = i9;
    }

    public static d a(int i6, int i7, int i8, int i9) {
        return (i6 == 0 && i7 == 0 && i8 == 0 && i9 == 0) ? f1e : new d(i6, i7, i8, i9);
    }

    public static d b(Insets insets) {
        return a(insets.left, insets.top, insets.right, insets.bottom);
    }

    public final Insets c() {
        return c.a(this.f2a, this.f3b, this.f4c, this.f5d);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || d.class != obj.getClass()) {
            return false;
        }
        d dVar = (d) obj;
        return this.f5d == dVar.f5d && this.f2a == dVar.f2a && this.f4c == dVar.f4c && this.f3b == dVar.f3b;
    }

    public final int hashCode() {
        return (((((this.f2a * 31) + this.f3b) * 31) + this.f4c) * 31) + this.f5d;
    }

    public final String toString() {
        return "Insets{left=" + this.f2a + ", top=" + this.f3b + ", right=" + this.f4c + ", bottom=" + this.f5d + '}';
    }
}
