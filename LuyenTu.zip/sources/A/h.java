package A;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.net.Uri;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class h extends X2.a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final Class f14d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final Constructor f15e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final Method f16f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final Method f17g;

    static {
        Class<?> cls;
        Method method;
        Method method2;
        Constructor<?> constructor = null;
        try {
            cls = Class.forName("android.graphics.FontFamily");
            Constructor<?> constructor2 = cls.getConstructor(null);
            Class cls2 = Integer.TYPE;
            method2 = cls.getMethod("addFontWeightStyle", ByteBuffer.class, cls2, List.class, cls2, Boolean.TYPE);
            method = Typeface.class.getMethod("createFromFamiliesWithDefault", Array.newInstance(cls, 1).getClass());
            constructor = constructor2;
        } catch (ClassNotFoundException | NoSuchMethodException e6) {
            Log.e("TypefaceCompatApi24Impl", e6.getClass().getName(), e6);
            cls = null;
            method = null;
            method2 = null;
        }
        f15e = constructor;
        f14d = cls;
        f16f = method2;
        f17g = method;
    }

    public static boolean U(Object obj, ByteBuffer byteBuffer, int i6, int i7, boolean z6) {
        try {
            return ((Boolean) f16f.invoke(obj, byteBuffer, Integer.valueOf(i6), null, Integer.valueOf(i7), Boolean.valueOf(z6))).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    public static Typeface V(Object obj) {
        try {
            Object objNewInstance = Array.newInstance((Class<?>) f14d, 1);
            Array.set(objNewInstance, 0, obj);
            return (Typeface) f17g.invoke(null, objNewInstance);
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return null;
        }
    }

    @Override // X2.a
    public final Typeface n(Context context, p149z.b bVar, Resources resources, int i6) throws IllegalAccessException, InstantiationException, InvocationTargetException {
        Object objNewInstance;
        MappedByteBuffer map;
        try {
            objNewInstance = f15e.newInstance(null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            objNewInstance = null;
        }
        if (objNewInstance != null) {
            for (p149z.c cVar : bVar.f10558a) {
                int i7 = cVar.f10564f;
                File fileS = p000a.a.s(context);
                if (fileS != null) {
                    try {
                        if (p000a.a.i(fileS, resources, i7)) {
                            try {
                                FileInputStream fileInputStream = new FileInputStream(fileS);
                                try {
                                    FileChannel channel = fileInputStream.getChannel();
                                    map = channel.map(FileChannel.MapMode.READ_ONLY, 0L, channel.size());
                                    fileInputStream.close();
                                } catch (Throwable th) {
                                    try {
                                        fileInputStream.close();
                                    } catch (Throwable th2) {
                                        th.addSuppressed(th2);
                                    }
                                    throw th;
                                }
                            } catch (IOException unused2) {
                                map = null;
                            }
                            fileS.delete();
                        } else {
                            fileS.delete();
                        }
                        if (map != null && U(objNewInstance, map, cVar.f10563e, cVar.f10560b, cVar.f10561c)) {
                        }
                    } catch (Throwable th3) {
                        fileS.delete();
                        throw th3;
                    }
                }
                map = null;
                if (map != null) {
                }
            }
            return V(objNewInstance);
        }
        return null;
    }

    @Override // X2.a
    public final Typeface o(Context context, E.k[] kVarArr, int i6) {
        Object objNewInstance;
        try {
            objNewInstance = f15e.newInstance(null);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            objNewInstance = null;
        }
        if (objNewInstance != null) {
            p093p.j jVar = new p093p.j(0);
            for (E.k kVar : kVarArr) {
                Uri uri = kVar.f893a;
                ByteBuffer byteBufferY = (ByteBuffer) jVar.get(uri);
                if (byteBufferY == null) {
                    byteBufferY = p000a.a.y(context, uri);
                    jVar.put(uri, byteBufferY);
                }
                if (byteBufferY != null && U(objNewInstance, byteBufferY, kVar.f894b, kVar.f895c, kVar.f896d)) {
                }
            }
            Typeface typefaceV = V(objNewInstance);
            if (typefaceV != null) {
                return Typeface.create(typefaceV, i6);
            }
        }
        return null;
    }
}
