package A;

import android.app.ForegroundServiceStartNotAllowedException;
import android.app.Notification;
import android.app.RemoteInput;
import android.graphics.Insets;
import android.util.Log;
import androidx.work.impl.foreground.SystemForegroundService;
import p018d2.y;

/* JADX INFO: loaded from: classes.dex */
public abstract class c {
    public static Insets a(int i6, int i7, int i8, int i9) {
        return Insets.of(i6, i7, i8, i9);
    }

    public static void b(Notification.Builder builder, boolean z6) {
        builder.setAllowSystemGeneratedContextualActions(z6);
    }

    public static void c(Notification.Builder builder) {
        builder.setBubbleMetadata(null);
    }

    public static void d(Notification.Action.Builder builder, boolean z6) {
        builder.setContextual(z6);
    }

    public static void e(RemoteInput.Builder builder) {
        builder.setEditChoicesBeforeSending(0);
    }

    public static void f(SystemForegroundService systemForegroundService, int i6, Notification notification, int i7) {
        systemForegroundService.startForeground(i6, notification, i7);
    }

    public static void g(SystemForegroundService systemForegroundService, int i6, Notification notification, int i7) {
        try {
            systemForegroundService.startForeground(i6, notification, i7);
        } catch (ForegroundServiceStartNotAllowedException e6) {
            y yVarE = y.e();
            String str = SystemForegroundService.f4533v;
            if (yVarE.f5302a <= 5) {
                Log.w(str, "Unable to start foreground service", e6);
            }
        } catch (SecurityException e7) {
            y yVarE2 = y.e();
            String str2 = SystemForegroundService.f4533v;
            if (yVarE2.f5302a <= 5) {
                Log.w(str2, "Unable to start foreground service", e7);
            }
        }
    }
}
