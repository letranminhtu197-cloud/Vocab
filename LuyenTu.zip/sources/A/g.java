package A;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.ParcelFileDescriptor;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: classes.dex */
public class g extends X2.a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static Class f9d = null;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static Constructor f10e = null;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static Method f11f = null;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static Method f12g = null;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static boolean f13h = false;

    public static boolean U(Object obj, String str, int i6, boolean z6) throws NoSuchMethodException {
        V();
        try {
            return ((Boolean) f11f.invoke(obj, str, Integer.valueOf(i6), Boolean.valueOf(z6))).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException e6) {
            throw new RuntimeException(e6);
        }
    }

    public static void V() throws NoSuchMethodException {
        Method method;
        Class<?> cls;
        Method method2;
        if (f13h) {
            return;
        }
        f13h = true;
        Constructor<?> constructor = null;
        try {
            cls = Class.forName("android.graphics.FontFamily");
            Constructor<?> constructor2 = cls.getConstructor(null);
            method2 = cls.getMethod("addFontWeightStyle", String.class, Integer.TYPE, Boolean.TYPE);
            method = Typeface.class.getMethod("createFromFamiliesWithDefault", Array.newInstance(cls, 1).getClass());
            constructor = constructor2;
        } catch (ClassNotFoundException | NoSuchMethodException e6) {
            Log.e("TypefaceCompatApi21Impl", e6.getClass().getName(), e6);
            method = null;
            cls = null;
            method2 = null;
        }
        f10e = constructor;
        f9d = cls;
        f11f = method2;
        f12g = method;
    }

    @Override // X2.a
    public Typeface n(Context context, p149z.b bVar, Resources resources, int i6) throws NoSuchMethodException {
        V();
        try {
            Object objNewInstance = f10e.newInstance(null);
            for (p149z.c cVar : bVar.f10558a) {
                File fileS = p000a.a.s(context);
                if (fileS == null) {
                    return null;
                }
                try {
                    if (!p000a.a.i(fileS, resources, cVar.f10564f)) {
                        return null;
                    }
                    if (!U(objNewInstance, fileS.getPath(), cVar.f10560b, cVar.f10561c)) {
                        return null;
                    }
                    fileS.delete();
                } catch (RuntimeException unused) {
                    return null;
                } finally {
                    fileS.delete();
                }
            }
            V();
            try {
                Object objNewInstance2 = Array.newInstance((Class<?>) f9d, 1);
                Array.set(objNewInstance2, 0, objNewInstance);
                return (Typeface) f12g.invoke(null, objNewInstance2);
            } catch (IllegalAccessException | InvocationTargetException e6) {
                throw new RuntimeException(e6);
            }
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException e7) {
            throw new RuntimeException(e7);
        }
    }

    @Override // X2.a
    public Typeface o(Context context, E.k[] kVarArr, int i6) {
        File file;
        Typeface typefaceCreateFromFile;
        if (kVarArr.length >= 1) {
            try {
                ParcelFileDescriptor parcelFileDescriptorOpenFileDescriptor = context.getContentResolver().openFileDescriptor(X2.a.u(kVarArr, i6).f893a, "r", null);
                if (parcelFileDescriptorOpenFileDescriptor != null) {
                    try {
                        try {
                            String str = Os.readlink("/proc/self/fd/" + parcelFileDescriptorOpenFileDescriptor.getFd());
                            file = OsConstants.S_ISREG(Os.stat(str).st_mode) ? new File(str) : null;
                        } catch (ErrnoException unused) {
                        }
                        if (file != null && file.canRead()) {
                            Typeface typefaceCreateFromFile2 = Typeface.createFromFile(file);
                            parcelFileDescriptorOpenFileDescriptor.close();
                            return typefaceCreateFromFile2;
                        }
                        FileInputStream fileInputStream = new FileInputStream(parcelFileDescriptorOpenFileDescriptor.getFileDescriptor());
                        try {
                            File fileS = p000a.a.s(context);
                            if (fileS == null) {
                                typefaceCreateFromFile = null;
                            } else {
                                try {
                                    if (p000a.a.j(fileS, fileInputStream)) {
                                        typefaceCreateFromFile = Typeface.createFromFile(fileS.getPath());
                                        fileS.delete();
                                    } else {
                                        fileS.delete();
                                        typefaceCreateFromFile = null;
                                    }
                                } catch (RuntimeException unused2) {
                                } catch (Throwable th) {
                                    fileS.delete();
                                    throw th;
                                }
                            }
                            fileInputStream.close();
                            parcelFileDescriptorOpenFileDescriptor.close();
                            return typefaceCreateFromFile;
                        } catch (Throwable th2) {
                            try {
                                fileInputStream.close();
                            } catch (Throwable th3) {
                                th2.addSuppressed(th3);
                            }
                            throw th2;
                        }
                    } catch (Throwable th4) {
                        try {
                            parcelFileDescriptorOpenFileDescriptor.close();
                        } catch (Throwable th5) {
                            th4.addSuppressed(th5);
                        }
                        throw th4;
                    }
                }
                if (parcelFileDescriptorOpenFileDescriptor != null) {
                    parcelFileDescriptorOpenFileDescriptor.close();
                    return null;
                }
            } catch (IOException unused3) {
            }
        }
        return null;
    }
}
