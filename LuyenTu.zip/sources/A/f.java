package A;

import E.n;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.fonts.Font;
import android.graphics.fonts.FontFamily;
import android.graphics.text.PositionedGlyphs;
import android.graphics.text.TextRunShaper;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Trace;
import android.text.TextUtils;
import android.util.Log;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.apache.tika.utils.StringUtils;
import p025e2.v;
import p068l.C0405s;

/* JADX INFO: loaded from: classes.dex */
public abstract class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final X2.a f6a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p093p.i f7b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static Paint f8c;

    static {
        Trace.beginSection(v.I("TypefaceCompat static init"));
        int i6 = Build.VERSION.SDK_INT;
        if (i6 >= 31) {
            f6a = new l();
        } else if (i6 >= 29) {
            f6a = new k();
        } else if (i6 >= 28) {
            f6a = new j();
        } else if (i6 >= 26) {
            f6a = new i();
        } else {
            Method method = h.f16f;
            if (method == null) {
                Log.w("TypefaceCompatApi24Impl", "Unable to collect necessary private methods.Fallback to legacy implementation.");
            }
            if (method != null) {
                f6a = new h();
            } else {
                f6a = new g();
            }
        }
        f7b = new p093p.i(16);
        f8c = null;
        Trace.endSection();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static Typeface a(Context context, p149z.a aVar, Resources resources, int i6, String str, int i7, int i8, C0405s c0405s) {
        Typeface typefaceN;
        Typeface typefaceBuild;
        FontFamily fontFamilyBuild;
        int i9 = 12;
        if (aVar instanceof p149z.d) {
            p149z.d dVar = (p149z.d) aVar;
            String str2 = dVar.f10568d;
            typefaceN = null;
            int i10 = 1;
            boolean z6 = false;
            byte b6 = 0;
            byte b7 = 0;
            byte b8 = 0;
            if (TextUtils.isEmpty(str2) || (typefaceBuild = c(str2)) == null) {
                ArrayList arrayList = dVar.f10565a;
                if (arrayList.size() != 1) {
                    if (Build.VERSION.SDK_INT >= 31) {
                        int i11 = 0;
                        while (true) {
                            if (i11 >= arrayList.size()) {
                                Typeface.CustomFallbackBuilder customFallbackBuilderC = null;
                                int i12 = 0;
                                while (true) {
                                    if (i12 < arrayList.size()) {
                                        E.e eVar = (E.e) arrayList.get(i12);
                                        if (i12 == arrayList.size() - 1 && TextUtils.isEmpty(eVar.f878f)) {
                                            customFallbackBuilderC.setSystemFallback(eVar.f877e);
                                        } else {
                                            String str3 = eVar.f877e;
                                            String str4 = eVar.f878f;
                                            Font fontD = d(c(str3));
                                            if (fontD == null) {
                                                Log.w("TypefaceCompat", "Unable identify the primary font for " + eVar.f877e + ". Falling back to provider font.");
                                            } else {
                                                if (TextUtils.isEmpty(str4)) {
                                                    fontFamilyBuild = b.g(fontD).build();
                                                } else {
                                                    try {
                                                        b.n();
                                                        b.w();
                                                        fontFamilyBuild = b.g(e.e(fontD).setFontVariationSettings(str4).build()).build();
                                                    } catch (IOException unused) {
                                                        Log.e("TypefaceCompat", "Failed to clone Font instance. Fall back to provider font.");
                                                    }
                                                }
                                                if (customFallbackBuilderC == null) {
                                                    customFallbackBuilderC = b.c(fontFamilyBuild);
                                                } else {
                                                    customFallbackBuilderC.addCustomFallback(fontFamilyBuild);
                                                }
                                                i12++;
                                            }
                                        }
                                    }
                                    typefaceBuild = customFallbackBuilderC.build();
                                    break;
                                }
                            }
                            if (c(((E.e) arrayList.get(i11)).f877e) != null) {
                                i11++;
                            }
                            typefaceBuild = null;
                            break;
                        }
                    }
                    typefaceBuild = null;
                    break;
                }
                typefaceBuild = c(((E.e) arrayList.get(0)).f877e);
            }
            if (typefaceBuild != null) {
                new Handler(Looper.getMainLooper()).post(new p015d.b(c0405s, typefaceBuild, i9));
                f7b.b(b(resources, i6, str, i7, i8), typefaceBuild);
                return typefaceBuild;
            }
            byte b9 = dVar.f10567c == 0;
            int i13 = dVar.f10566b;
            Handler handler = new Handler(Looper.getMainLooper());
            K2.i iVar = new K2.i(i10, z6);
            iVar.f2080s = c0405s;
            ArrayList arrayList2 = dVar.f10565a;
            D.c cVar = new D.c(handler, 1);
            A4.b bVar = new A4.b(iVar, cVar, 6);
            if (b9 != true) {
                String strA = E.i.a(i8, arrayList2);
                Typeface typeface = (Typeface) E.i.f887a.a(strA);
                if (typeface != null) {
                    cVar.execute(new E.a(iVar, typeface, b7 == true ? 1 : 0));
                    typefaceN = typeface;
                } else {
                    E.g gVar = new E.g(bVar, b6 == true ? 1 : 0);
                    synchronized (E.i.f889c) {
                        try {
                            p093p.j jVar = E.i.f890d;
                            ArrayList arrayList3 = (ArrayList) jVar.get(strA);
                            if (arrayList3 != null) {
                                arrayList3.add(gVar);
                            } else {
                                ArrayList arrayList4 = new ArrayList();
                                arrayList4.add(gVar);
                                jVar.put(strA, arrayList4);
                                E.f fVar = new E.f(strA, context, arrayList2, i8, 1);
                                ThreadPoolExecutor threadPoolExecutor = E.i.f888b;
                                E.g gVar2 = new E.g(strA, i10);
                                Handler handler2 = Looper.myLooper() == null ? new Handler(Looper.getMainLooper()) : new Handler();
                                n nVar = new n();
                                nVar.f899s = fVar;
                                nVar.t = gVar2;
                                nVar.f900u = handler2;
                                threadPoolExecutor.execute(nVar);
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                }
            } else {
                if (arrayList2.size() > 1) {
                    throw new IllegalArgumentException("Fallbacks with blocking fetches are not supported for performance reasons");
                }
                E.e eVar2 = (E.e) arrayList2.get(0);
                p093p.i iVar2 = E.i.f887a;
                ArrayList arrayList5 = new ArrayList(1);
                Object obj = new Object[]{eVar2}[0];
                Objects.requireNonNull(obj);
                arrayList5.add(obj);
                String strA2 = E.i.a(i8, Collections.unmodifiableList(arrayList5));
                Typeface typeface2 = (Typeface) E.i.f887a.a(strA2);
                if (typeface2 != null) {
                    cVar.execute(new E.a(iVar, typeface2, b8 == true ? 1 : 0));
                    typefaceN = typeface2;
                } else if (i13 == -1) {
                    ArrayList arrayList6 = new ArrayList(1);
                    Object obj2 = new Object[]{eVar2}[0];
                    Objects.requireNonNull(obj2);
                    arrayList6.add(obj2);
                    E.h hVarB = E.i.b(strA2, context, Collections.unmodifiableList(arrayList6), i8);
                    bVar.t(hVarB);
                    typefaceN = hVarB.f885a;
                } else {
                    try {
                        try {
                            try {
                                try {
                                    E.h hVar = (E.h) E.i.f888b.submit(new E.f(strA2, context, eVar2, i8, 0)).get(i13, TimeUnit.MILLISECONDS);
                                    bVar.t(hVar);
                                    typefaceN = hVar.f885a;
                                } catch (InterruptedException e6) {
                                    throw e6;
                                }
                            } catch (TimeoutException unused2) {
                                throw new InterruptedException("timeout");
                            }
                        } catch (ExecutionException e7) {
                            throw new RuntimeException(e7);
                        }
                    } catch (InterruptedException unused3) {
                        ((D.c) bVar.t).execute(new E.b((K2.i) bVar.f174s, -3));
                    }
                }
            }
        } else {
            typefaceN = f6a.n(context, (p149z.b) aVar, resources, i8);
            if (typefaceN != null) {
                new Handler(Looper.getMainLooper()).post(new p015d.b(c0405s, typefaceN, i9));
            } else {
                c0405s.b();
            }
        }
        if (typefaceN != null) {
            f7b.b(b(resources, i6, str, i7, i8), typefaceN);
        }
        return typefaceN;
    }

    public static String b(Resources resources, int i6, String str, int i7, int i8) {
        return resources.getResourcePackageName(i6) + '-' + str + '-' + i7 + '-' + i6 + '-' + i8;
    }

    public static Typeface c(String str) {
        if (str != null && !str.isEmpty()) {
            Typeface typefaceCreate = Typeface.create(str, 0);
            Typeface typefaceCreate2 = Typeface.create(Typeface.DEFAULT, 0);
            if (typefaceCreate != null && !typefaceCreate.equals(typefaceCreate2)) {
                return typefaceCreate;
            }
        }
        return null;
    }

    public static Font d(Typeface typeface) {
        if (f8c == null) {
            f8c = new Paint();
        }
        f8c.setTextSize(10.0f);
        f8c.setTypeface(typeface);
        PositionedGlyphs positionedGlyphsShapeTextRun = TextRunShaper.shapeTextRun((CharSequence) StringUtils.SPACE, 0, 1, 0, 1, 0.0f, 0.0f, false, f8c);
        if (positionedGlyphsShapeTextRun.glyphCount() == 0) {
            return null;
        }
        return positionedGlyphsShapeTextRun.getFont(0);
    }
}
