package C4;

import android.net.Uri;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f586a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f587b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Uri f588c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f589d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final byte[] f590e;

    public a(String str, String str2, Uri uri, long j6, byte[] bArr) {
        this.f586a = str;
        this.f587b = str2;
        this.f588c = uri;
        this.f589d = j6;
        this.f590e = bArr;
    }
}
