package C4;

import K5.InterfaceC0117v;
import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.DocumentsContract;
import java.util.ArrayList;
import p074l5.l;

/* JADX INFO: loaded from: classes.dex */
public final class f extends p116s5.h implements p154z5.e {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final /* synthetic */ String f605A;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ Intent f606v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ b f607w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final /* synthetic */ Activity f608x;
    public final /* synthetic */ int y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final /* synthetic */ boolean f609z;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f(Intent intent, b bVar, Activity activity, int i6, boolean z6, String str, q5.c cVar) {
        super(2, cVar);
        this.f606v = intent;
        this.f607w = bVar;
        this.f608x = activity;
        this.y = i6;
        this.f609z = z6;
        this.f605A = str;
    }

    @Override // p154z5.e
    public final Object g(Object obj, Object obj2) throws Throwable {
        f fVar = (f) j((InterfaceC0117v) obj, (q5.c) obj2);
        l lVar = l.f7746a;
        fVar.l(lVar);
        return lVar;
    }

    @Override // p116s5.a
    public final q5.c j(Object obj, q5.c cVar) {
        return new f(this.f606v, this.f607w, this.f608x, this.y, this.f609z, this.f605A, cVar);
    }

    @Override // p116s5.a
    public final Object l(Object obj) throws Throwable {
        X2.a.O(obj);
        l lVar = l.f7746a;
        b bVar = this.f607w;
        Intent intent = this.f606v;
        if (intent == null) {
            bVar.b("unknown_activity", "Unknown activity error, please fill an issue.");
            return lVar;
        }
        ArrayList arrayList = new ArrayList();
        try {
            ClipData clipData = intent.getClipData();
            int i6 = this.y;
            boolean z6 = this.f609z;
            int i7 = 0;
            Activity activity = this.f608x;
            if (clipData != null) {
                ClipData clipData2 = intent.getClipData();
                A5.h.b(clipData2);
                int itemCount = clipData2.getItemCount();
                while (i7 < itemCount) {
                    ClipData clipData3 = intent.getClipData();
                    A5.h.b(clipData3);
                    Uri uri = clipData3.getItemAt(i7).getUri();
                    A5.h.b(uri);
                    g.a(activity, g.b(activity, uri, i6), z6, arrayList);
                    i7++;
                }
                bVar.c(arrayList);
                return lVar;
            }
            if (intent.getData() != null) {
                Uri data = intent.getData();
                A5.h.b(data);
                Uri uriB = g.b(activity, data, i6);
                if (!this.f605A.equals("dir")) {
                    g.a(activity, uriB, z6, arrayList);
                    if (arrayList.isEmpty()) {
                        bVar.b("unknown_path", "Failed to retrieve path.");
                        return lVar;
                    }
                    bVar.c(arrayList);
                    return lVar;
                }
                Uri uriBuildDocumentUriUsingTree = DocumentsContract.buildDocumentUriUsingTree(uriB, DocumentsContract.getTreeDocumentId(uriB));
                A5.h.d(uriBuildDocumentUriUsingTree, "buildDocumentUriUsingTree(...)");
                String strG = g.g(activity, uriBuildDocumentUriUsingTree);
                if (strG != null) {
                    bVar.c(strG);
                    return lVar;
                }
                bVar.b("unknown_path", "Failed to retrieve directory path.");
                return lVar;
            }
            Bundle extras = intent.getExtras();
            if (extras == null || !extras.containsKey("selectedItems")) {
                bVar.b("unknown_activity", "Unknown activity error, please fill an issue.");
                return lVar;
            }
            Bundle extras2 = intent.getExtras();
            A5.h.b(extras2);
            ArrayList parcelableArrayList = Build.VERSION.SDK_INT >= 33 ? extras2.getParcelableArrayList("selectedItems", Parcelable.class) : extras2.getParcelableArrayList("selectedItems");
            if (parcelableArrayList != null) {
                ArrayList arrayList2 = new ArrayList();
                int size = parcelableArrayList.size();
                int i8 = 0;
                while (i8 < size) {
                    Object obj2 = parcelableArrayList.get(i8);
                    i8++;
                    if (obj2 instanceof Uri) {
                        arrayList2.add(obj2);
                    }
                }
                int size2 = arrayList2.size();
                while (i7 < size2) {
                    Object obj3 = arrayList2.get(i7);
                    i7++;
                    g.a(activity, (Uri) obj3, z6, arrayList);
                }
            }
            bVar.c(arrayList);
            return lVar;
        } catch (Exception e6) {
            String message = e6.getMessage();
            if (message == null) {
                message = "Unknown error";
            }
            bVar.b("file_picker_error", message);
            return lVar;
        }
    }
}
