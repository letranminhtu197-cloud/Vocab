package C4;

import I5.l;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.util.Log;
import android.webkit.MimeTypeMap;
import com.google.crypto.tink.shaded.protobuf.T;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.tika.metadata.TikaCoreProperties;
import p018d2.G;
import p081m5.m;

/* JADX INFO: loaded from: classes.dex */
public final class g {
    /* JADX WARN: Code duplicated, block: B:108:? A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:49:0x011c A[Catch: IOException -> 0x0117, TryCatch #0 {IOException -> 0x0117, blocks: (B:43:0x010d, B:45:0x0113, B:49:0x011c, B:51:0x0121), top: B:90:0x010d }] */
    /* JADX WARN: Code duplicated, block: B:51:0x0121 A[Catch: IOException -> 0x0117, TRY_LEAVE, TryCatch #0 {IOException -> 0x0117, blocks: (B:43:0x010d, B:45:0x0113, B:49:0x011c, B:51:0x0121), top: B:90:0x010d }] */
    /* JADX WARN: Code duplicated, block: B:59:0x0147 A[Catch: IOException -> 0x014b, TryCatch #6 {IOException -> 0x014b, blocks: (B:57:0x0141, B:59:0x0147, B:63:0x0150, B:65:0x0155), top: B:93:0x0141 }] */
    /* JADX WARN: Code duplicated, block: B:63:0x0150 A[Catch: IOException -> 0x014b, TryCatch #6 {IOException -> 0x014b, blocks: (B:57:0x0141, B:59:0x0147, B:63:0x0150, B:65:0x0155), top: B:93:0x0141 }] */
    /* JADX WARN: Code duplicated, block: B:65:0x0155 A[Catch: IOException -> 0x014b, TRY_LEAVE, TryCatch #6 {IOException -> 0x014b, blocks: (B:57:0x0141, B:59:0x0147, B:63:0x0150, B:65:0x0155), top: B:93:0x0141 }] */
    /* JADX WARN: Code duplicated, block: B:93:0x0141 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    public static final void a(Activity activity, Uri uri, boolean z6, ArrayList arrayList) throws Throwable {
        Throwable th;
        InputStream inputStream;
        Exception exc;
        FileOutputStream fileOutputStream;
        FileDescriptor fd;
        A5.h.e(activity, "context");
        A5.h.e(uri, "uri");
        String strF = f(activity, uri);
        String str = activity.getCacheDir().getAbsolutePath() + "/file_picker/" + System.currentTimeMillis() + "/" + (strF == null ? "unamed" : strF);
        File file = new File(str);
        String canonicalPath = new File(T.i(activity.getCacheDir().getAbsolutePath(), "/file_picker/")).getCanonicalPath();
        String canonicalPath2 = file.getCanonicalPath();
        A5.h.d(canonicalPath2, "getCanonicalPath(...)");
        A5.h.b(canonicalPath);
        if (!canonicalPath2.startsWith(canonicalPath)) {
            throw new SecurityException("Path traversal detected. Escaping the intended cache directory is not allowed.");
        }
        FileOutputStream fileOutputStream2 = null;
        bArr = null;
        byte[] bArr = null;
        fileOutputStream2 = null;
        aVar = null;
        aVar = null;
        a aVar = null;
        if (!file.exists()) {
            try {
                File parentFile = file.getParentFile();
                if (parentFile != null) {
                    parentFile.mkdirs();
                }
                InputStream inputStreamOpenInputStream = activity.getContentResolver().openInputStream(uri);
                try {
                    fileOutputStream = new FileOutputStream(file);
                    try {
                        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
                        byte[] bArr2 = new byte[8192];
                        while (true) {
                            A5.h.b(inputStreamOpenInputStream);
                            int i6 = inputStreamOpenInputStream.read(bArr2);
                            if (i6 < 0) {
                                break;
                            } else {
                                bufferedOutputStream.write(bArr2, 0, i6);
                            }
                        }
                        bufferedOutputStream.flush();
                        try {
                            FileDescriptor fd2 = fileOutputStream.getFD();
                            if (fd2 != null) {
                                fd2.sync();
                            }
                            fileOutputStream.close();
                            inputStreamOpenInputStream.close();
                        } catch (IOException e6) {
                            Log.e("FilePickerUtils", "Failed to close file streams: " + e6.getMessage(), e6);
                        }
                    } catch (Exception e7) {
                        inputStream = inputStreamOpenInputStream;
                        exc = e7;
                        try {
                            Log.e("FilePickerUtils", "Failed to retrieve and cache file: " + exc.getMessage(), exc);
                            if (fileOutputStream != null) {
                                try {
                                    FileDescriptor fd3 = fileOutputStream.getFD();
                                    if (fd3 != null) {
                                        fd3.sync();
                                    }
                                    if (fileOutputStream != null) {
                                        fileOutputStream.close();
                                    }
                                    if (inputStream != null) {
                                        inputStream.close();
                                    }
                                } catch (IOException e8) {
                                    Log.e("FilePickerUtils", "Failed to close file streams: " + e8.getMessage(), e8);
                                }
                            } else {
                                if (fileOutputStream != null) {
                                    fileOutputStream.close();
                                }
                                if (inputStream != null) {
                                    inputStream.close();
                                }
                            }
                        } catch (Throwable th2) {
                            th = th2;
                            fileOutputStream2 = fileOutputStream;
                            if (fileOutputStream2 != null) {
                                try {
                                    fd = fileOutputStream2.getFD();
                                    if (fd != null) {
                                        fd.sync();
                                    }
                                } catch (IOException e9) {
                                    Log.e("FilePickerUtils", "Failed to close file streams: " + e9.getMessage(), e9);
                                    throw th;
                                }
                            }
                            if (fileOutputStream2 != null) {
                                fileOutputStream2.close();
                            }
                            if (inputStream == null) {
                                throw th;
                            }
                            inputStream.close();
                            throw th;
                        }
                    } catch (Throwable th3) {
                        inputStream = inputStreamOpenInputStream;
                        th = th3;
                        fileOutputStream2 = fileOutputStream;
                        if (fileOutputStream2 != null) {
                            fd = fileOutputStream2.getFD();
                            if (fd != null) {
                                fd.sync();
                            }
                        }
                        if (fileOutputStream2 != null) {
                            fileOutputStream2.close();
                        }
                        if (inputStream == null) {
                            throw th;
                        }
                        inputStream.close();
                        throw th;
                    }
                } catch (Exception e10) {
                    inputStream = inputStreamOpenInputStream;
                    exc = e10;
                    fileOutputStream = null;
                } catch (Throwable th4) {
                    inputStream = inputStreamOpenInputStream;
                    th = th4;
                    if (fileOutputStream2 != null) {
                        fd = fileOutputStream2.getFD();
                        if (fd != null) {
                            fd.sync();
                        }
                    }
                    if (fileOutputStream2 != null) {
                        fileOutputStream2.close();
                    }
                    if (inputStream == null) {
                        throw th;
                    }
                    inputStream.close();
                    throw th;
                }
            } catch (Exception e11) {
                exc = e11;
                inputStream = null;
                fileOutputStream = null;
            } catch (Throwable th5) {
                th = th5;
                inputStream = null;
            }
        }
        if (z6) {
            try {
                int length = (int) file.length();
                byte[] bArr3 = new byte[length];
                try {
                    try {
                        BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(file));
                        bufferedInputStream.read(bArr3, 0, length);
                        bufferedInputStream.close();
                    } catch (FileNotFoundException e12) {
                        Log.e("FilePickerUtils", "File not found: " + e12.getMessage(), null);
                    }
                } catch (IOException e13) {
                    Log.e("FilePickerUtils", "Failed to close file streams: " + e13.getMessage(), null);
                }
                bArr = bArr3;
            } catch (Exception e14) {
                Log.e("FilePickerUtils", "Failed to load bytes into memory with error " + e14 + ". Probably the file is too big to fit device memory. Bytes won't be added to the file this time.");
            }
        }
        aVar = new a(str, strF, uri, file.length(), bArr);
        if (aVar != null) {
            arrayList.add(aVar);
        }
    }

    public static final Uri b(Activity activity, Uri uri, int i6) {
        if (i6 > 0) {
            Context applicationContext = activity.getApplicationContext();
            A5.h.d(applicationContext, "getApplicationContext(...)");
            String extensionFromMimeType = MimeTypeMap.getSingleton().getExtensionFromMimeType(applicationContext.getContentResolver().getType(uri));
            if (extensionFromMimeType != null && (extensionFromMimeType.contentEquals("jpg") || extensionFromMimeType.contentEquals("jpeg") || extensionFromMimeType.contentEquals("png") || extensionFromMimeType.contentEquals("webp") || extensionFromMimeType.contentEquals("heic") || extensionFromMimeType.contentEquals("heif"))) {
                Context applicationContext2 = activity.getApplicationContext();
                A5.h.d(applicationContext2, "getApplicationContext(...)");
                try {
                    InputStream inputStreamOpenInputStream = applicationContext2.getContentResolver().openInputStream(uri);
                    try {
                        Bitmap.CompressFormat compressFormatE = e(applicationContext2, uri);
                        File fileD = d(applicationContext2, compressFormatE);
                        Bitmap bitmapDecodeStream = BitmapFactory.decodeStream(inputStreamOpenInputStream);
                        FileOutputStream fileOutputStream = new FileOutputStream(fileD);
                        bitmapDecodeStream.compress(compressFormatE, i6, fileOutputStream);
                        fileOutputStream.flush();
                        fileOutputStream.close();
                        Uri uriFromFile = Uri.fromFile(fileD);
                        A5.h.d(uriFromFile, "fromFile(...)");
                        p000a.a.e(inputStreamOpenInputStream, null);
                        return uriFromFile;
                    } catch (Throwable th) {
                        try {
                            throw th;
                        } catch (Throwable th2) {
                            p000a.a.e(inputStreamOpenInputStream, th);
                            throw th2;
                        }
                    }
                } catch (IOException e6) {
                    throw new RuntimeException(e6);
                }
            }
        }
        return uri;
    }

    public static final String c(String str) {
        switch (str) {
            case "custom":
                return "*/*";
            case "any":
                return "*/*";
            case "dir":
                return "dir";
            case "audio":
                return "audio/*";
            case "image":
                return "image/*";
            case "media":
                return "media";
            case "video":
                return "video/*";
            default:
                return null;
        }
    }

    public static File d(Context context, Bitmap.CompressFormat compressFormat) throws IOException {
        String str;
        String strJ = T.j("IMAGE_", new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date()), "_");
        File cacheDir = context.getCacheDir();
        int i6 = e.f604a[compressFormat.ordinal()];
        if (i6 != 1) {
            str = i6 != 2 ? "jpeg" : "webp";
        } else {
            str = "png";
        }
        File fileCreateTempFile = File.createTempFile(strJ, ".".concat(str), cacheDir);
        A5.h.d(fileCreateTempFile, "createTempFile(...)");
        return fileCreateTempFile;
    }

    public static Bitmap.CompressFormat e(Context context, Uri uri) {
        String extensionFromMimeType = MimeTypeMap.getSingleton().getExtensionFromMimeType(context.getContentResolver().getType(uri));
        A5.h.b(extensionFromMimeType);
        Locale locale = Locale.getDefault();
        A5.h.d(locale, "getDefault(...)");
        String upperCase = extensionFromMimeType.toUpperCase(locale);
        A5.h.d(upperCase, "toUpperCase(...)");
        if (upperCase.equals("PNG")) {
            return Bitmap.CompressFormat.PNG;
        }
        return upperCase.equals("WEBP") ? Bitmap.CompressFormat.WEBP : Bitmap.CompressFormat.JPEG;
    }

    /* JADX WARN: Code duplicated, block: B:19:0x0045  */
    public static final String f(Context context, Uri uri) {
        Exception exc;
        Uri uri2;
        String string;
        A5.h.e(uri, "uri");
        A5.h.e(context, "context");
        String str = null;
        try {
            if (A5.h.a(uri.getScheme(), "content")) {
                uri2 = uri;
                Cursor cursorQuery = context.getContentResolver().query(uri2, new String[]{"_display_name"}, null, null, null);
                if (cursorQuery != null) {
                    try {
                        if (cursorQuery.moveToFirst()) {
                            string = cursorQuery.getString(cursorQuery.getColumnIndexOrThrow("_display_name"));
                        } else {
                            string = null;
                        }
                    } catch (Throwable th) {
                        try {
                            throw th;
                        } catch (Throwable th2) {
                            p000a.a.e(cursorQuery, th);
                            throw th2;
                        }
                    }
                } else {
                    string = null;
                }
                try {
                    p000a.a.e(cursorQuery, null);
                } catch (Exception e6) {
                    exc = e6;
                    str = string;
                    Log.e("FilePickerUtils", "Failed to handle file name: " + exc);
                    return str;
                }
            } else {
                uri2 = uri;
                string = null;
            }
            if (string != null) {
                return string;
            }
            String path = uri2.getPath();
            if (path != null) {
                return I5.d.F0(path, '/', path);
            }
            return null;
        } catch (Exception e7) {
            exc = e7;
            Log.e("FilePickerUtils", "Failed to handle file name: " + exc);
            return str;
        }
    }

    public static final String g(Context context, Uri uri) {
        String strX0;
        List listG;
        String strX1;
        List listG2;
        A5.h.e(context, "context");
        int i6 = Build.VERSION.SDK_INT;
        Collection collectionI0 = m.r;
        if (i6 < 30 && A5.h.a(uri.getAuthority(), "com.android.providers.downloads.documents")) {
            String documentId = DocumentsContract.getDocumentId(uri);
            String path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getPath();
            if (A5.h.a(documentId, "downloads")) {
                return path;
            }
            A5.h.b(documentId);
            Pattern patternCompile = Pattern.compile("^ms[df]:.*");
            A5.h.d(patternCompile, "compile(...)");
            if (patternCompile.matcher(documentId).matches()) {
                return T.y(path, "/", f(context, uri));
            }
            if (!documentId.startsWith("raw:")) {
                return null;
            }
            Pattern patternCompile2 = Pattern.compile(TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER);
            A5.h.d(patternCompile2, "compile(...)");
            Matcher matcher = patternCompile2.matcher(documentId);
            if (matcher.find()) {
                ArrayList arrayList = new ArrayList(10);
                int iEnd = 0;
                do {
                    arrayList.add(documentId.subSequence(iEnd, matcher.start()).toString());
                    iEnd = matcher.end();
                } while (matcher.find());
                arrayList.add(documentId.subSequence(iEnd, documentId.length()).toString());
                listG2 = arrayList;
            } else {
                listG2 = G.G(documentId.toString());
            }
            if (!listG2.isEmpty()) {
                ListIterator listIterator = listG2.listIterator(listG2.size());
                while (listIterator.hasPrevious()) {
                    if (((String) listIterator.previous()).length() != 0) {
                        collectionI0 = p081m5.f.I0(listIterator.nextIndex() + 1, listG2);
                        break;
                    }
                }
            }
            return ((String[]) collectionI0.toArray(new String[0]))[1];
        }
        String treeDocumentId = DocumentsContract.getTreeDocumentId(uri);
        A5.h.b(treeDocumentId);
        List listD0 = I5.d.D0(treeDocumentId, new String[]{TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER});
        if (listD0.size() > 1) {
            String str = (String) listD0.get(0);
            String str2 = (String) listD0.get(1);
            if ("primary".equalsIgnoreCase(str)) {
                strX0 = Environment.getExternalStorageDirectory() + "/" + str2;
            } else {
                strX0 = A3.a.l("/storage/", str, "/", str2);
            }
        } else {
            strX0 = Environment.getExternalStorageDirectory() + "/" + p081m5.f.F0(listD0);
        }
        String str3 = File.separator;
        A5.h.d(str3, "separator");
        if (l.s0(strX0, str3)) {
            strX0 = I5.d.x0(strX0);
        }
        String treeDocumentId2 = DocumentsContract.getTreeDocumentId(uri);
        A5.h.b(treeDocumentId2);
        Pattern patternCompile3 = Pattern.compile(TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER);
        A5.h.d(patternCompile3, "compile(...)");
        Matcher matcher2 = patternCompile3.matcher(treeDocumentId2);
        if (matcher2.find()) {
            ArrayList arrayList2 = new ArrayList(10);
            int iEnd2 = 0;
            do {
                arrayList2.add(treeDocumentId2.subSequence(iEnd2, matcher2.start()).toString());
                iEnd2 = matcher2.end();
            } while (matcher2.find());
            arrayList2.add(treeDocumentId2.subSequence(iEnd2, treeDocumentId2.length()).toString());
            listG = arrayList2;
        } else {
            listG = G.G(treeDocumentId2.toString());
        }
        if (!listG.isEmpty()) {
            ListIterator listIterator2 = listG.listIterator(listG.size());
            while (listIterator2.hasPrevious()) {
                if (((String) listIterator2.previous()).length() != 0) {
                    collectionI0 = p081m5.f.I0(listIterator2.nextIndex() + 1, listG);
                    break;
                }
            }
        }
        String[] strArr = (String[]) collectionI0.toArray(new String[0]);
        if (strArr.length >= 2) {
            strX1 = strArr[1];
        } else {
            strX1 = File.separator;
            A5.h.d(strX1, "separator");
        }
        String str4 = File.separator;
        A5.h.d(str4, "separator");
        if (l.s0(strX1, str4)) {
            strX1 = I5.d.x0(strX1);
        }
        if (strX1.length() <= 0 || l.s0(strX0, strX1)) {
            return strX0;
        }
        return strX1.startsWith(str4) ? strX0.concat(strX1) : T.y(strX0, str4, strX1);
    }

    public static ArrayList h(ArrayList arrayList) {
        if (arrayList == null || arrayList.isEmpty()) {
            return new ArrayList(G.G("*/*"));
        }
        ArrayList arrayList2 = new ArrayList();
        int size = arrayList.size();
        for (int i6 = 0; i6 < size; i6++) {
            String mimeTypeFromExtension = MimeTypeMap.getSingleton().getMimeTypeFromExtension((String) arrayList.get(i6));
            if (mimeTypeFromExtension == null) {
                Log.w("FilePickerUtils", "Custom file type '" + arrayList.get(i6) + "' is unsupported and will not be filtered.");
                return new ArrayList(G.G("*/*"));
            }
            arrayList2.add(mimeTypeFromExtension);
            if (A5.h.a(arrayList.get(i6), "csv")) {
                arrayList2.add("text/csv");
            }
        }
        Log.d("FilePickerUtils", "Custom file types are " + arrayList + ". The mime types were detected as " + arrayList2 + ".");
        return arrayList2;
    }

    public static void i(File file) {
        if (file == null || !file.exists()) {
            return;
        }
        if (file.listFiles() != null && file.isDirectory()) {
            File[] fileArrListFiles = file.listFiles();
            if (fileArrListFiles == null) {
                fileArrListFiles = new File[0];
            }
            for (File file2 : fileArrListFiles) {
                i(file2);
            }
        }
        file.delete();
    }

    public static void j(b bVar, String str, Boolean bool, Boolean bool2, ArrayList arrayList, Integer num, i iVar) {
        Intent intent;
        if (bVar != null) {
            if (bVar.f593s != null) {
                int i6 = b.f591A;
                iVar.c("already_active", "File picker is already active", null);
                return;
            }
            bVar.f593s = iVar;
        }
        if (bVar != null) {
            bVar.f595v = str;
        }
        if (bool != null && bVar != null) {
            bVar.t = bool.booleanValue();
        }
        if (bool2 != null && bVar != null) {
            bVar.f594u = bool2.booleanValue();
        }
        if (bVar != null) {
            bVar.f597x = arrayList;
        }
        if (num != null && bVar != null) {
            bVar.f596w = num.intValue();
        }
        if (bVar != null) {
            Activity activity = bVar.r;
            String str2 = bVar.f595v;
            if (str2 == null) {
                return;
            }
            if (str2.equals("dir")) {
                intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
            } else if (A5.h.a(bVar.f595v, "image/*")) {
                intent = new Intent("android.intent.action.GET_CONTENT");
                intent.setDataAndType(Uri.parse(Environment.getExternalStorageDirectory().getPath() + File.separator), bVar.f595v);
                intent.setType(bVar.f595v);
                intent.putExtra("android.intent.extra.ALLOW_MULTIPLE", bVar.t);
                intent.putExtra("multi-pick", bVar.t);
                String str3 = bVar.f595v;
                if (str3 != null) {
                    String str4 = I5.d.w0(str3, ",") ? str3 : null;
                    if (str4 != null) {
                        List listD0 = I5.d.D0(str4, new String[]{","});
                        ArrayList arrayList2 = new ArrayList();
                        for (Object obj : listD0) {
                            if (((String) obj).length() > 0) {
                                arrayList2.add(obj);
                            }
                        }
                        bVar.f597x = new ArrayList(arrayList2);
                    }
                }
                ArrayList arrayList3 = bVar.f597x;
                if (arrayList3 != null) {
                    intent.putExtra("android.intent.extra.MIME_TYPES", arrayList3);
                }
            } else if (A5.h.a(bVar.f595v, "audio/*")) {
                intent = new Intent("android.intent.action.GET_CONTENT");
                intent.setType(bVar.f595v);
                intent.addCategory("android.intent.category.OPENABLE");
                intent.putExtra("android.intent.extra.ALLOW_MULTIPLE", bVar.t);
                intent.putExtra("multi-pick", bVar.t);
                if (Build.VERSION.SDK_INT >= 26) {
                    intent.putExtra("android.provider.extra.INITIAL_URI", DocumentsContract.buildRootUri("com.android.providers.media.documents", "audio_root"));
                }
            } else if (A5.h.a(bVar.f595v, "video/*")) {
                intent = new Intent("android.intent.action.GET_CONTENT");
                intent.setType(bVar.f595v);
                intent.addCategory("android.intent.category.OPENABLE");
                intent.putExtra("android.intent.extra.ALLOW_MULTIPLE", bVar.t);
                intent.putExtra("multi-pick", bVar.t);
            } else if (A5.h.a(bVar.f595v, "media")) {
                intent = new Intent("android.intent.action.GET_CONTENT");
                intent.setType("*/*");
                intent.putExtra("android.intent.extra.MIME_TYPES", new String[]{"image/*", "video/*", "audio/*"});
                intent.addCategory("android.intent.category.OPENABLE");
                A5.h.b(intent.putExtra("android.intent.extra.ALLOW_MULTIPLE", bVar.t));
            } else {
                intent = new Intent("android.intent.action.OPEN_DOCUMENT");
                intent.addCategory("android.intent.category.OPENABLE");
                intent.setType(bVar.f595v);
                ArrayList arrayList4 = bVar.f597x;
                if (arrayList4 == null || arrayList4.isEmpty()) {
                    intent.putExtra("android.intent.extra.MIME_TYPES", intent.getType());
                } else {
                    ArrayList arrayList5 = bVar.f597x;
                    A5.h.b(arrayList5);
                    intent.putExtra("android.intent.extra.MIME_TYPES", (String[]) arrayList5.toArray(new String[0]));
                }
                intent.putExtra("android.intent.extra.ALLOW_MULTIPLE", bVar.t);
                intent.putExtra("multi-pick", bVar.t);
            }
            if (intent.resolveActivity(activity.getPackageManager()) != null) {
                activity.startActivityForResult(intent, b.f591A);
            } else {
                Log.e("FilePickerDelegate", "Can't find a valid activity to handle the request. Make sure you've a file explorer installed.");
                bVar.b("invalid_format_type", "Can't handle the provided file type.");
            }
        }
    }
}
