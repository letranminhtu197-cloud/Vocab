package C4;

import C1.B;
import W4.p;
import android.os.Handler;
import android.os.Looper;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public final class i implements p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f613a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final V4.h f614b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Handler f615c;

    public i(V4.h hVar, int i6) {
        this.f613a = i6;
        switch (i6) {
            case 1:
                this.f615c = new Handler(Looper.getMainLooper());
                this.f614b = hVar;
                break;
            default:
                this.f614b = hVar;
                this.f615c = new Handler(Looper.getMainLooper());
                break;
        }
    }

    @Override // W4.p
    public final void a(Object obj) {
        switch (this.f613a) {
            case 0:
                this.f615c.post(new B(this, obj, 2));
                break;
            default:
                this.f615c.post(new p015d.b(this, obj, 15));
                break;
        }
    }

    @Override // W4.p
    public final void b() {
        switch (this.f613a) {
            case 0:
                this.f615c.post(new B4.f(this, 2));
                break;
            default:
                V4.h hVar = this.f614b;
                Objects.requireNonNull(hVar);
                this.f615c.post(new B4.f(hVar, 26));
                break;
        }
    }

    @Override // W4.p
    public final void c(String str, String str2, Object obj) {
        switch (this.f613a) {
            case 0:
                A5.h.e(str, "errorCode");
                this.f615c.post(new h(this, str, str2, obj, 0));
                break;
            default:
                this.f615c.post(new h(this, str, str2, obj, 4));
                break;
        }
    }
}
