package C4;

import K5.AbstractC0120y;
import K5.G;
import W4.s;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import org.apache.tika.utils.StringUtils;
import p081m5.r;

/* JADX INFO: loaded from: classes.dex */
public final class b implements s {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public static final int f591A = (d.class.hashCode() + 43) & 65535;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public static final int f592B = (d.class.hashCode() + 83) & 65535;
    public final Activity r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public i f593s;
    public boolean t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f594u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public String f595v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f596w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public ArrayList f597x;
    public W4.h y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public byte[] f598z;

    public b(Activity activity) {
        A5.h.e(activity, "activity");
        this.r = activity;
        this.f593s = null;
    }

    public final void a(boolean z6) {
        if (this.y == null || A5.h.a(this.f595v, "dir")) {
            return;
        }
        new Handler(Looper.getMainLooper()).post(new B4.d(this, z6, 1));
    }

    public final void b(String str, String str2) {
        a(false);
        i iVar = this.f593s;
        if (iVar != null) {
            iVar.c(str, str2, null);
        }
        this.f593s = null;
    }

    /* JADX WARN: Code duplicated, block: B:11:0x0014  */
    /* JADX WARN: Code duplicated, block: B:13:0x0018  */
    /* JADX WARN: Code duplicated, block: B:14:0x001b  */
    /* JADX WARN: Code duplicated, block: B:16:0x001e  */
    /* JADX WARN: Code duplicated, block: B:18:0x0029  */
    /* JADX WARN: Code duplicated, block: B:20:0x0033  */
    /* JADX WARN: Code duplicated, block: B:21:0x0036  */
    /* JADX WARN: Code duplicated, block: B:23:0x0039  */
    /* JADX WARN: Code duplicated, block: B:24:0x0080  */
    /* JADX WARN: Code duplicated, block: B:27:0x0087  */
    /* JADX WARN: Code duplicated, block: B:31:0x0083 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:33:0x0027 A[SYNTHETIC] */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v0, types: [C4.i] */
    /* JADX WARN: Type inference failed for: r3v1 */
    /* JADX WARN: Type inference failed for: r3v2, types: [java.util.ArrayList] */
    /* JADX WARN: Type inference failed for: r3v3, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r3v5 */
    /* JADX WARN: Type inference failed for: r3v6 */
    /* JADX WARN: Type inference failed for: r3v7 */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final void c(Serializable serializable) {
        ArrayList arrayList;
        ?? arrayList2;
        int size;
        Object obj;
        a aVar;
        HashMap map;
        int i6 = 0;
        a(false);
        ?? r6 = this.f593s;
        if (r6 != 0) {
            if (serializable == null) {
                if (serializable instanceof ArrayList) {
                    arrayList = (ArrayList) serializable;
                } else {
                    arrayList = null;
                }
                if (arrayList != null) {
                    arrayList2 = new ArrayList();
                    size = arrayList.size();
                    while (i6 < size) {
                        obj = arrayList.get(i6);
                        i6++;
                        if (obj instanceof a) {
                            aVar = (a) obj;
                        } else {
                            aVar = null;
                        }
                        if (aVar != null) {
                            p074l5.g[] gVarArr = {new p074l5.g("path", aVar.f586a), new p074l5.g("name", aVar.f587b), new p074l5.g("size", Long.valueOf(aVar.f589d)), new p074l5.g("bytes", aVar.f590e), new p074l5.g("identifier", String.valueOf(aVar.f588c))};
                            map = new HashMap(r.Y(5));
                            r.a0(map, gVarArr);
                        } else {
                            map = null;
                        }
                        if (map != null) {
                            arrayList2.add(map);
                        }
                    }
                } else {
                    arrayList2 = 0;
                }
            } else {
                arrayList2 = serializable instanceof String ? serializable : 0;
                if (arrayList2 == 0) {
                    if (serializable instanceof ArrayList) {
                        arrayList = (ArrayList) serializable;
                    } else {
                        arrayList = null;
                    }
                    if (arrayList != null) {
                        arrayList2 = new ArrayList();
                        size = arrayList.size();
                        while (i6 < size) {
                            obj = arrayList.get(i6);
                            i6++;
                            if (obj instanceof a) {
                                aVar = (a) obj;
                            } else {
                                aVar = null;
                            }
                            if (aVar != null) {
                                p074l5.g[] gVarArr2 = {new p074l5.g("path", aVar.f586a), new p074l5.g("name", aVar.f587b), new p074l5.g("size", Long.valueOf(aVar.f589d)), new p074l5.g("bytes", aVar.f590e), new p074l5.g("identifier", String.valueOf(aVar.f588c))};
                                map = new HashMap(r.Y(5));
                                r.a0(map, gVarArr2);
                            } else {
                                map = null;
                            }
                            if (map != null) {
                                arrayList2.add(map);
                            }
                        }
                    } else {
                        arrayList2 = 0;
                    }
                }
            }
            r6.a(arrayList2);
            this.f593s = null;
        }
    }

    @Override // W4.s
    public final boolean onActivityResult(int i6, int i7, Intent intent) {
        int i8 = f592B;
        Activity activity = this.r;
        if (i6 == i8) {
            if (i7 == -1) {
                Uri data = intent != null ? intent.getData() : null;
                if (data != null) {
                    a(true);
                    try {
                        byte[] bArr = this.f598z;
                        A5.h.e(activity, "context");
                        OutputStream outputStreamOpenOutputStream = activity.getContentResolver().openOutputStream(data);
                        if (outputStreamOpenOutputStream != null) {
                            if (bArr != null) {
                                try {
                                    outputStreamOpenOutputStream.write(bArr);
                                } catch (Throwable th) {
                                    try {
                                        throw th;
                                    } catch (Throwable th2) {
                                        p000a.a.e(outputStreamOpenOutputStream, th);
                                        throw th2;
                                    }
                                }
                            }
                            outputStreamOpenOutputStream.close();
                        }
                        c(data.getPath());
                        return true;
                    } catch (IOException e6) {
                        Log.e("FilePickerDelegate", "Error while saving file", e6);
                        b("Error while saving file", e6.getMessage());
                    }
                }
                return false;
            }
            if (i7 == 0) {
                c(null);
                return false;
            }
        } else {
            if (i6 != f591A) {
                b("unknown_activity", "Unknown activity error, please file an issue.");
                return false;
            }
            if (i7 == -1) {
                a(true);
                int i9 = this.f596w;
                boolean z6 = this.f594u;
                String str = this.f595v;
                if (str == null) {
                    str = StringUtils.EMPTY;
                }
                String str2 = str;
                A5.h.e(activity, "activity");
                R5.e eVar = G.f2085a;
                AbstractC0120y.p(AbstractC0120y.b(R5.d.t), null, null, new f(intent, this, activity, i9, z6, str2, null), 3);
                return true;
            }
            if (i7 == 0) {
                c(null);
                return true;
            }
        }
        return false;
    }
}
