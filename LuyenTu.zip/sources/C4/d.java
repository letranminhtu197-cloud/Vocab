package C4;

import W4.n;
import W4.o;
import W4.p;
import W4.q;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import androidx.lifecycle.AbstractC0192n;
import com.google.crypto.tink.shaded.protobuf.T;
import io.flutter.embedding.engine.plugins.lifecycle.HiddenLifecycleReference;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import org.apache.tika.Tika;
import org.apache.tika.detect.Detector;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.metadata.TikaCoreProperties;
import org.apache.tika.mime.MimeTypes;
import p068l.v0;

/* JADX INFO: loaded from: classes.dex */
public final class d implements o, S4.b, T4.a {
    public T4.b r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public b f599s;
    public Application t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public S4.a f600u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public AbstractC0192n f601v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public c f602w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public Activity f603x;
    public q y;

    @Override // T4.a
    public final void onAttachedToActivity(T4.b bVar) {
        A5.h.e(bVar, "binding");
        this.r = bVar;
        S4.a aVar = this.f600u;
        if (aVar != null) {
            W4.f fVar = aVar.f3498c;
            A5.h.d(fVar, "getBinaryMessenger(...)");
            Context context = aVar.f3496a;
            A5.h.c(context, "null cannot be cast to non-null type android.app.Application");
            T4.b bVar2 = this.r;
            A5.h.b(bVar2);
            Activity activity = (Activity) ((v0) bVar2).r;
            A5.h.d(activity, "getActivity(...)");
            T4.b bVar3 = this.r;
            A5.h.b(bVar3);
            this.f603x = activity;
            this.t = (Application) context;
            this.f599s = new b(activity);
            q qVar = new q(fVar, "miguelruivo.flutter.plugins.filepicker");
            this.y = qVar;
            qVar.b(this);
            b bVar4 = this.f599s;
            if (bVar4 != null) {
                new A4.d(fVar, "miguelruivo.flutter.plugins.filepickerevent").R(new K2.i(bVar4, 4));
                this.f602w = new c(activity);
                v0 v0Var = (v0) bVar3;
                v0Var.a(bVar4);
                AbstractC0192n lifecycle = ((HiddenLifecycleReference) v0Var.f7490s).getLifecycle();
                this.f601v = lifecycle;
                c cVar = this.f602w;
                if (cVar == null || lifecycle == null) {
                    return;
                }
                lifecycle.a(cVar);
            }
        }
    }

    @Override // S4.b
    public final void onAttachedToEngine(S4.a aVar) {
        A5.h.e(aVar, "binding");
        this.f600u = aVar;
    }

    @Override // T4.a
    public final void onDetachedFromActivity() {
        T4.b bVar;
        b bVar2 = this.f599s;
        if (bVar2 != null && (bVar = this.r) != null) {
            ((v0) bVar).i(bVar2);
        }
        this.r = null;
        c cVar = this.f602w;
        if (cVar != null) {
            AbstractC0192n abstractC0192n = this.f601v;
            if (abstractC0192n != null) {
                abstractC0192n.b(cVar);
            }
            Application application = this.t;
            if (application != null) {
                application.unregisterActivityLifecycleCallbacks(cVar);
            }
        }
        this.f601v = null;
        b bVar3 = this.f599s;
        if (bVar3 != null) {
            bVar3.y = null;
        }
        this.f599s = null;
        q qVar = this.y;
        if (qVar != null) {
            qVar.b(null);
        }
        this.y = null;
        this.t = null;
    }

    @Override // T4.a
    public final void onDetachedFromActivityForConfigChanges() {
        onDetachedFromActivity();
    }

    @Override // S4.b
    public final void onDetachedFromEngine(S4.a aVar) {
        A5.h.e(aVar, "binding");
        this.f600u = null;
    }

    @Override // W4.o
    public final void onMethodCall(n nVar, p pVar) {
        String strDetect;
        Context applicationContext;
        A5.h.e(nVar, "call");
        Object objValueOf = null;
        if (this.f603x == null) {
            ((V4.h) pVar).c("no_activity", "file picker plugin requires a foreground activity", null);
            return;
        }
        boolean z6 = false;
        i iVar = new i((V4.h) pVar, 0);
        Object obj = nVar.f3730b;
        HashMap map = obj instanceof HashMap ? (HashMap) obj : null;
        String str = nVar.f3729a;
        if (str != null) {
            int iHashCode = str.hashCode();
            if (iHashCode != -1349088399) {
                if (iHashCode != 3522941) {
                    if (iHashCode == 94746189 && str.equals("clear")) {
                        Activity activity = this.f603x;
                        if (activity != null && (applicationContext = activity.getApplicationContext()) != null) {
                            try {
                                g.i(new File(applicationContext.getCacheDir().toString() + "/file_picker/"));
                                z6 = true;
                            } catch (Exception e6) {
                                Log.e("FilePickerUtils", "There was an error while clearing cached files: " + e6);
                            }
                            objValueOf = Boolean.valueOf(z6);
                        }
                        iVar.a(objValueOf);
                        return;
                    }
                } else if (str.equals("save")) {
                    Object obj2 = map != null ? map.get("fileType") : null;
                    A5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                    String strC = g.c((String) obj2);
                    String str2 = (String) (map != null ? map.get("initialDirectory") : null);
                    byte[] bArr = (byte[]) (map != null ? map.get("bytes") : null);
                    String strValueOf = String.valueOf(map != null ? map.get("fileName") : null);
                    if (strValueOf.length() > 0 && !I5.d.w0(strValueOf, ".")) {
                        String strDetect2 = new Tika().detect(bArr);
                        A5.h.b(strDetect2);
                        strValueOf = T.y(strValueOf, ".", I5.d.E0(strDetect2, "/"));
                    }
                    b bVar = this.f599s;
                    if (bVar != null) {
                        Activity activity2 = bVar.r;
                        if (bVar.f593s != null) {
                            int i6 = b.f591A;
                            iVar.c("already_active", "File picker is already active", null);
                            return;
                        }
                        bVar.f593s = iVar;
                        Intent intent = new Intent("android.intent.action.CREATE_DOCUMENT");
                        intent.addCategory("android.intent.category.OPENABLE");
                        if (strValueOf != null && strValueOf.length() != 0) {
                            intent.putExtra("android.intent.extra.TITLE", strValueOf);
                        }
                        bVar.f598z = bArr;
                        if (!"dir".equals(strC)) {
                            try {
                                Tika tika = new Tika();
                                if (strValueOf == null || strValueOf.length() == 0) {
                                    strDetect = tika.detect(bArr);
                                } else {
                                    Detector detector = tika.getDetector();
                                    TikaInputStream tikaInputStream = TikaInputStream.get(bArr);
                                    Metadata metadata = new Metadata();
                                    metadata.set(TikaCoreProperties.RESOURCE_NAME_KEY, strValueOf);
                                    strDetect = detector.detect(tikaInputStream, metadata).toString();
                                }
                                if (A5.h.a(strDetect, MimeTypes.PLAIN_TEXT)) {
                                    strDetect = "*/*";
                                } else {
                                    A5.h.b(strDetect);
                                }
                                intent.setType(strDetect);
                            } catch (Throwable th) {
                                intent.setType("*/*");
                                Log.e("FilePickerDelegate", "Failed to detect mime type. " + th);
                            }
                        }
                        if (str2 != null && str2.length() != 0 && Build.VERSION.SDK_INT >= 26) {
                            intent.putExtra("android.provider.extra.INITIAL_URI", Uri.parse(str2));
                        }
                        if (intent.resolveActivity(activity2.getPackageManager()) != null) {
                            activity2.startActivityForResult(intent, b.f592B);
                            return;
                        } else {
                            Log.e("FilePickerDelegate", "Can't find a valid activity to handle the request. Make sure you've a file explorer installed.");
                            bVar.b("invalid_format_type", "Can't handle the provided file type.");
                            return;
                        }
                    }
                    return;
                }
            } else if (str.equals("custom")) {
                ArrayList arrayListH = g.h((ArrayList) (map != null ? map.get("allowedExtensions") : null));
                b bVar2 = this.f599s;
                if (bVar2 != null) {
                    g.j(bVar2, g.c(str), (Boolean) (map != null ? map.get("allowMultipleSelection") : null), (Boolean) (map != null ? map.get("withData") : null), arrayListH, (Integer) (map != null ? map.get("compressionQuality") : null), iVar);
                    return;
                }
                return;
            }
        }
        A5.h.b(str);
        String strC2 = g.c(str);
        if (strC2 == null) {
            iVar.b();
            return;
        }
        b bVar3 = this.f599s;
        if (bVar3 != null) {
            g.j(bVar3, strC2, (Boolean) (map != null ? map.get("allowMultipleSelection") : null), (Boolean) (map != null ? map.get("withData") : null), g.h((ArrayList) (map != null ? map.get("allowedExtensions") : null)), (Integer) (map != null ? map.get("compressionQuality") : null), iVar);
        }
    }

    @Override // T4.a
    public final void onReattachedToActivityForConfigChanges(T4.b bVar) {
        A5.h.e(bVar, "binding");
        onAttachedToActivity(bVar);
    }
}
