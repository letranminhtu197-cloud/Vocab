package C4;

import J0.B;
import J0.E;
import J0.J;
import Q2.q;
import android.os.Looper;
import androidx.work.impl.WorkDatabase;
import io.flutter.plugins.firebase.core.FlutterFirebasePlugin;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import p018d2.C0289b;
import p025e2.AbstractC0303g;
import p025e2.InterfaceC0301e;
import p071l2.k;
import p091o3.j;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class h implements Runnable {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ Object f610s;
    public final /* synthetic */ Object t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ Object f611u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ Object f612v;

    public /* synthetic */ h(C0.e eVar, J j6, E e6, B b6) {
        this.r = 1;
        this.t = eVar;
        this.f610s = j6;
        this.f611u = e6;
        this.f612v = b6;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v0, types: [J0.J, java.lang.Object] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // java.lang.Runnable
    public final void run() {
        int i6 = this.r;
        ?? r6 = this.f610s;
        Object obj = this.f612v;
        Object obj2 = this.f611u;
        Object obj3 = this.t;
        switch (i6) {
            case 0:
                ((i) obj3).f614b.c((String) obj2, (String) obj, r6);
                break;
            case 1:
                r6.g(((C0.e) obj3).f380a, (E) obj2, (B) obj);
                break;
            case 2:
                p010b5.d dVar = (p010b5.d) obj3;
                p010b5.f fVar = (p010b5.f) obj;
                String str = (String) obj2;
                j jVar = (j) r6;
                HashMap map = p010b5.d.t;
                dVar.getClass();
                try {
                    String str2 = fVar.f4564a;
                    q.e(str2, "ApiKey must be set.");
                    String str3 = fVar.f4565b;
                    q.e(str3, "ApplicationId must be set.");
                    String str4 = fVar.f4569f;
                    String str5 = fVar.f4566c;
                    String str6 = fVar.f4567d;
                    L3.i iVar = new L3.i(str3, str2, str4, fVar.f4572i, str5, fVar.f4570g, str6);
                    try {
                        Looper.prepare();
                        break;
                    } catch (Exception unused) {
                    }
                    String str7 = fVar.f4568e;
                    if (str7 != null) {
                        p010b5.d.t.put(str, str7);
                    }
                    L3.g gVarI = L3.g.i(iVar, dVar.r, str);
                    j jVar2 = new j();
                    FlutterFirebasePlugin.cachedThreadPool.execute(new p010b5.c(dVar, gVarI, jVar2));
                    jVar.b((p010b5.g) android.support.v4.media.session.b.c(jVar2.f8049a));
                } catch (Exception e6) {
                    jVar.a(e6);
                    return;
                }
                break;
            case 3:
                List list = (List) obj3;
                k kVar = (k) obj2;
                C0289b c0289b = (C0289b) obj;
                WorkDatabase workDatabase = (WorkDatabase) r6;
                Iterator it = list.iterator();
                while (it.hasNext()) {
                    ((InterfaceC0301e) it.next()).a(kVar.f7677a);
                }
                AbstractC0303g.b(c0289b, workDatabase, list);
                break;
            default:
                ((i) obj3).f614b.c((String) obj2, (String) obj, r6);
                break;
        }
    }

    public /* synthetic */ h(p010b5.d dVar, p010b5.f fVar, String str, j jVar) {
        this.r = 2;
        this.t = dVar;
        this.f612v = fVar;
        this.f611u = str;
        this.f610s = jVar;
    }

    public /* synthetic */ h(Object obj, Object obj2, Object obj3, Object obj4, int i6) {
        this.r = i6;
        this.t = obj;
        this.f611u = obj2;
        this.f612v = obj3;
        this.f610s = obj4;
    }
}
