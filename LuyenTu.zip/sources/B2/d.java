package B2;

import A5.h;
import D3.j;
import D3.p;
import I3.Z;
import I3.f0;
import I3.r0;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.util.Pair;
import java.io.File;
import java.nio.ByteBuffer;
import java.security.GeneralSecurityException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import org.apache.tika.utils.StringUtils;
import p045h3.C0331c;
import p117t0.s;
import p135w2.i;
import p136w3.k;
import p136w3.l;
import p143x3.f;
import p143x3.g;

/* JADX INFO: loaded from: classes.dex */
public final class d implements p146y2.b, p089o1.e {
    public Object r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public Object f325s;
    public Object t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public Object f326u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public Object f327v;

    public d(p123u1.c cVar, HashMap map, HashMap map2, HashMap map3) {
        this.r = cVar;
        this.f326u = map2;
        this.f327v = map3;
        this.t = Collections.unmodifiableMap(map);
        TreeSet treeSet = new TreeSet();
        int i6 = 0;
        cVar.d(treeSet, false);
        long[] jArr = new long[treeSet.size()];
        Iterator it = treeSet.iterator();
        while (it.hasNext()) {
            jArr[i6] = ((Long) it.next()).longValue();
            i6++;
        }
        this.f325s = jArr;
    }

    public static d e(SharedPreferences sharedPreferences, ScheduledThreadPoolExecutor scheduledThreadPoolExecutor) {
        d dVar = new d();
        dVar.f326u = new ArrayDeque();
        dVar.r = sharedPreferences;
        dVar.f325s = "topic_operation_queue";
        dVar.t = ",";
        dVar.f327v = scheduledThreadPoolExecutor;
        synchronized (((ArrayDeque) dVar.f326u)) {
            try {
                ((ArrayDeque) dVar.f326u).clear();
                String string = ((SharedPreferences) dVar.r).getString((String) dVar.f325s, StringUtils.EMPTY);
                if (!TextUtils.isEmpty(string) && string.contains((String) dVar.t)) {
                    String[] strArrSplit = string.split((String) dVar.t, -1);
                    if (strArrSplit.length == 0) {
                        Log.e("FirebaseMessaging", "Corrupted queue. Please check the queue contents and item separator provided");
                    }
                    for (String str : strArrSplit) {
                        if (!TextUtils.isEmpty(str)) {
                            ((ArrayDeque) dVar.f326u).add(str);
                        }
                    }
                    return dVar;
                }
                return dVar;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public static String h(String str) {
        if (str == null || !I5.d.w0(str, "/")) {
            return "*";
        }
        String strSubstring = str.substring(0, I5.d.A0(str, "/", 0, 6));
        h.d(strSubstring, "substring(...)");
        return strSubstring;
    }

    @Override // p089o1.e
    public int a(long j6) {
        long[] jArr = (long[]) this.f325s;
        int iB = s.b(jArr, j6, false);
        if (iB < jArr.length) {
            return iB;
        }
        return -1;
    }

    public void b(Object obj, Object obj2, f0 f0Var, boolean z6) {
        byte[] bArrArray;
        if (((ConcurrentHashMap) this.f325s) == null) {
            throw new IllegalStateException("addPrimitive cannot be called after build");
        }
        if (obj == null && obj2 == null) {
            throw new GeneralSecurityException("at least one of the `fullPrimitive` or `primitive` must be set");
        }
        if (f0Var.D() != Z.t) {
            throw new GeneralSecurityException("only ENABLED key is allowed");
        }
        Integer numValueOf = Integer.valueOf(f0Var.B());
        if (f0Var.C() == r0.f1640v) {
            numValueOf = null;
        }
        p136w3.b bVarA = j.f823b.a(p.k(f0Var.A().B(), f0Var.A().C(), f0Var.A().A(), f0Var.C(), numValueOf));
        int iOrdinal = f0Var.C().ordinal();
        if (iOrdinal == 1) {
            bArrArray = ByteBuffer.allocate(5).put((byte) 1).putInt(f0Var.B()).array();
        } else if (iOrdinal == 2) {
            bArrArray = ByteBuffer.allocate(5).put((byte) 0).putInt(f0Var.B()).array();
        } else if (iOrdinal != 3) {
            if (iOrdinal != 4) {
                throw new GeneralSecurityException("unknown output prefix type");
            }
            bArrArray = ByteBuffer.allocate(5).put((byte) 0).putInt(f0Var.B()).array();
        } else {
            bArrArray = p136w3.b.f9667a;
        }
        k kVar = new k(obj, obj2, bArrArray, f0Var.D(), f0Var.C(), f0Var.B(), f0Var.A().B(), bVarA);
        ConcurrentHashMap concurrentHashMap = (ConcurrentHashMap) this.f325s;
        ArrayList arrayList = (ArrayList) this.t;
        ArrayList arrayList2 = new ArrayList();
        arrayList2.add(kVar);
        byte[] bArr = kVar.f9681c;
        l lVar = new l(bArr != null ? Arrays.copyOf(bArr, bArr.length) : null);
        List list = (List) concurrentHashMap.put(lVar, Collections.unmodifiableList(arrayList2));
        if (list != null) {
            ArrayList arrayList3 = new ArrayList();
            arrayList3.addAll(list);
            arrayList3.add(kVar);
            concurrentHashMap.put(lVar, Collections.unmodifiableList(arrayList3));
        }
        arrayList.add(kVar);
        if (z6) {
            if (((k) this.f326u) != null) {
                throw new IllegalStateException("you cannot set two primary primitives");
            }
            this.f326u = kVar;
        }
    }

    public g c() throws GeneralSecurityException {
        if (((Integer) this.r) == null) {
            throw new GeneralSecurityException("AES key size is not set");
        }
        if (((Integer) this.f325s) == null) {
            throw new GeneralSecurityException("HMAC key size is not set");
        }
        Integer num = (Integer) this.t;
        if (num == null) {
            throw new GeneralSecurityException("tag size is not set");
        }
        if (((f) this.f326u) == null) {
            throw new GeneralSecurityException("hash type is not set");
        }
        if (((f) this.f327v) == null) {
            throw new GeneralSecurityException("variant is not set");
        }
        int iIntValue = num.intValue();
        f fVar = (f) this.f326u;
        if (fVar == f.f10365c) {
            if (iIntValue > 20) {
                throw new GeneralSecurityException(String.format("Invalid tag size in bytes %d; can be at most 20 bytes for SHA1", num));
            }
        } else if (fVar == f.f10366d) {
            if (iIntValue > 28) {
                throw new GeneralSecurityException(String.format("Invalid tag size in bytes %d; can be at most 28 bytes for SHA224", num));
            }
        } else if (fVar == f.f10367e) {
            if (iIntValue > 32) {
                throw new GeneralSecurityException(String.format("Invalid tag size in bytes %d; can be at most 32 bytes for SHA256", num));
            }
        } else if (fVar == f.f10368f) {
            if (iIntValue > 48) {
                throw new GeneralSecurityException(String.format("Invalid tag size in bytes %d; can be at most 48 bytes for SHA384", num));
            }
        } else {
            if (fVar != f.f10369g) {
                throw new GeneralSecurityException("unknown hash type; must be SHA1, SHA224, SHA256, SHA384 or SHA512");
            }
            if (iIntValue > 64) {
                throw new GeneralSecurityException(String.format("Invalid tag size in bytes %d; can be at most 64 bytes for SHA512", num));
            }
        }
        return new g(((Integer) this.r).intValue(), ((Integer) this.f325s).intValue(), ((Integer) this.t).intValue(), (f) this.f327v, (f) this.f326u);
    }

    @Override // p089o1.e
    public long d(int i6) {
        return ((long[]) this.f325s)[i6];
    }

    @Override // p089o1.e
    public List f(long j6) {
        p123u1.c cVar = (p123u1.c) this.r;
        Map map = (Map) this.t;
        HashMap map2 = (HashMap) this.f326u;
        HashMap map3 = (HashMap) this.f327v;
        ArrayList arrayList = new ArrayList();
        cVar.g(j6, cVar.f9149h, arrayList);
        TreeMap treeMap = new TreeMap();
        cVar.i(j6, false, cVar.f9149h, treeMap);
        cVar.h(j6, map, map2, cVar.f9149h, treeMap);
        ArrayList arrayList2 = new ArrayList();
        int size = arrayList.size();
        int i6 = 0;
        while (i6 < size) {
            Object obj = arrayList.get(i6);
            i6++;
            Pair pair = (Pair) obj;
            String str = (String) map3.get(pair.second);
            if (str != null) {
                byte[] bArrDecode = Base64.decode(str, 0);
                Bitmap bitmapDecodeByteArray = BitmapFactory.decodeByteArray(bArrDecode, 0, bArrDecode.length);
                p123u1.f fVar = (p123u1.f) map2.get(pair.first);
                fVar.getClass();
                arrayList2.add(new p111s0.b(null, null, null, bitmapDecodeByteArray, fVar.f9166c, 0, fVar.f9168e, fVar.f9165b, 0, Integer.MIN_VALUE, -3.4028235E38f, fVar.f9169f, fVar.f9170g, false, -16777216, fVar.f9173j, 0.0f));
            }
        }
        for (Map.Entry entry : treeMap.entrySet()) {
            p123u1.f fVar2 = (p123u1.f) map2.get(entry.getKey());
            fVar2.getClass();
            p111s0.a aVar = (p111s0.a) entry.getValue();
            CharSequence charSequence = aVar.f8849a;
            charSequence.getClass();
            SpannableStringBuilder spannableStringBuilder = (SpannableStringBuilder) charSequence;
            for (p123u1.a aVar2 : (p123u1.a[]) spannableStringBuilder.getSpans(0, spannableStringBuilder.length(), p123u1.a.class)) {
                spannableStringBuilder.replace(spannableStringBuilder.getSpanStart(aVar2), spannableStringBuilder.getSpanEnd(aVar2), (CharSequence) StringUtils.EMPTY);
            }
            for (int i7 = 0; i7 < spannableStringBuilder.length(); i7++) {
                if (spannableStringBuilder.charAt(i7) == ' ') {
                    int i8 = i7 + 1;
                    int i9 = i8;
                    while (i9 < spannableStringBuilder.length() && spannableStringBuilder.charAt(i9) == ' ') {
                        i9++;
                    }
                    int i10 = i9 - i8;
                    if (i10 > 0) {
                        spannableStringBuilder.delete(i7, i10 + i7);
                    }
                }
            }
            if (spannableStringBuilder.length() > 0 && spannableStringBuilder.charAt(0) == ' ') {
                spannableStringBuilder.delete(0, 1);
            }
            for (int i11 = 0; i11 < spannableStringBuilder.length() - 1; i11++) {
                if (spannableStringBuilder.charAt(i11) == '\n') {
                    int i12 = i11 + 1;
                    if (spannableStringBuilder.charAt(i12) == ' ') {
                        spannableStringBuilder.delete(i12, i11 + 2);
                    }
                }
            }
            if (spannableStringBuilder.length() > 0 && spannableStringBuilder.charAt(spannableStringBuilder.length() - 1) == ' ') {
                spannableStringBuilder.delete(spannableStringBuilder.length() - 1, spannableStringBuilder.length());
            }
            for (int i13 = 0; i13 < spannableStringBuilder.length() - 1; i13++) {
                if (spannableStringBuilder.charAt(i13) == ' ') {
                    int i14 = i13 + 1;
                    if (spannableStringBuilder.charAt(i14) == '\n') {
                        spannableStringBuilder.delete(i13, i14);
                    }
                }
            }
            if (spannableStringBuilder.length() > 0 && spannableStringBuilder.charAt(spannableStringBuilder.length() - 1) == '\n') {
                spannableStringBuilder.delete(spannableStringBuilder.length() - 1, spannableStringBuilder.length());
            }
            float f4 = fVar2.f9166c;
            int i15 = fVar2.f9167d;
            aVar.f8853e = f4;
            aVar.f8854f = i15;
            aVar.f8855g = fVar2.f9168e;
            aVar.f8856h = fVar2.f9165b;
            aVar.f8860l = fVar2.f9169f;
            float f7 = fVar2.f9172i;
            int i16 = fVar2.f9171h;
            aVar.f8859k = f7;
            aVar.f8858j = i16;
            aVar.f8863p = fVar2.f9173j;
            arrayList2.add(aVar.a());
        }
        return arrayList2;
    }

    @Override // p089o1.e
    public int g() {
        return ((long[]) this.f325s).length;
    }

    @Override // p067k5.a
    public Object get() {
        return new c((Executor) ((p067k5.a) this.r).get(), (p142x2.f) ((p067k5.a) this.f325s).get(), (C2.d) ((A4.d) this.f327v).get(), (D2.d) ((p067k5.a) this.t).get(), (E2.c) ((p067k5.a) this.f326u).get());
    }

    public File i() {
        Context context = (Activity) this.f325s;
        if (context == null) {
            context = (Context) this.r;
        }
        return new File(context.getCacheDir(), "share_plus");
    }

    public void j(t2.a aVar) {
        p089o1.b bVar = new p089o1.b(1);
        p135w2.p pVar = (p135w2.p) this.f327v;
        i iVar = (i) this.r;
        String str = (String) this.f325s;
        t2.e eVar = (t2.e) this.f326u;
        t2.c cVar = (t2.c) this.t;
        e eVar2 = pVar.f9665c;
        C0331c c0331cA = i.a();
        c0331cA.A(iVar.f9648a);
        c0331cA.t = t2.d.r;
        c0331cA.f6060u = iVar.f9649b;
        i iVarH = c0331cA.h();
        p pVar2 = new p();
        pVar2.f838f = new HashMap();
        pVar2.f836d = Long.valueOf(pVar.f9663a.n());
        pVar2.f837e = Long.valueOf(pVar.f9664b.n());
        pVar2.f833a = str;
        pVar2.f835c = new p135w2.l(cVar, (byte[]) eVar.apply(aVar.f9020a));
        pVar2.f834b = null;
        c cVar2 = (c) eVar2;
        cVar2.f321b.execute(new a(cVar2, iVarH, bVar, pVar2.j()));
    }

    /* JADX WARN: Bottom block not found for handler: all -> 0x016c */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void k(java.util.Map r19) throws java.io.IOException {
        /*
            Method dump skipped, instruction units count: 866
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: B2.d.k(java.util.Map):void");
    }
}
