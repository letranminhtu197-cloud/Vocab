package B2;

import java.util.concurrent.Executor;
import java.util.logging.Logger;
import p135w2.p;
import p142x2.f;

/* JADX INFO: loaded from: classes.dex */
public final class c implements e {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final Logger f319f = Logger.getLogger(p.class.getName());

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C2.d f320a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Executor f321b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final f f322c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final D2.d f323d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final E2.c f324e;

    public c(Executor executor, f fVar, C2.d dVar, D2.d dVar2, E2.c cVar) {
        this.f321b = executor;
        this.f322c = fVar;
        this.f320a = dVar;
        this.f323d = dVar2;
        this.f324e = cVar;
    }
}
