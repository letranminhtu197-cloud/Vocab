package B2;

import D2.f;
import D3.p;
import K5.AbstractC0120y;
import K5.C0115t;
import K5.EnumC0118w;
import K5.Y;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Base64;
import android.util.Log;
import com.google.firebase.messaging.FirebaseMessaging;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import p018d2.q;
import p018d2.r;
import p018d2.s;
import p053i4.C0375h;
import p053i4.v;
import p053i4.w;
import p091o3.h;
import p121u.i;
import p121u.m;
import p135w2.l;
import p151z2.g;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class b implements E2.b, f, i, h, p091o3.a {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ Object f317s;
    public final /* synthetic */ Object t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ Object f318u;

    public /* synthetic */ b(D2.h hVar, Object obj, p135w2.i iVar, int i6) {
        this.r = i6;
        this.t = hVar;
        this.f318u = obj;
        this.f317s = iVar;
    }

    @Override // D2.f
    public Object apply(Object obj) throws Throwable {
        Cursor cursor;
        String str;
        long jInsert;
        p151z2.c cVar;
        int i6 = this.r;
        String str2 = "bytes";
        int i7 = 6;
        int i8 = 5;
        int i9 = 4;
        int i10 = 3;
        p151z2.c cVar2 = p151z2.c.f10775u;
        int i11 = 2;
        Object obj2 = this.f318u;
        Object obj3 = this.f317s;
        int i12 = 0;
        D2.h hVar = (D2.h) this.t;
        switch (i6) {
            case 1:
                ArrayList arrayList = (ArrayList) obj2;
                p135w2.i iVar = (p135w2.i) obj3;
                Cursor cursor2 = (Cursor) obj;
                while (cursor2.moveToNext()) {
                    long j6 = cursor2.getLong(0);
                    boolean z6 = cursor2.getInt(7) != 0;
                    p pVar = new p();
                    pVar.f838f = new HashMap();
                    String string = cursor2.getString(1);
                    if (string == null) {
                        throw new NullPointerException("Null transportName");
                    }
                    pVar.f833a = string;
                    pVar.f836d = Long.valueOf(cursor2.getLong(i11));
                    pVar.f837e = Long.valueOf(cursor2.getLong(i10));
                    if (z6) {
                        String string2 = cursor2.getString(4);
                        pVar.f835c = new l(string2 == null ? D2.h.f801w : new t2.c(string2), cursor2.getBlob(5));
                        str = str2;
                    } else {
                        String string3 = cursor2.getString(4);
                        t2.c cVar3 = string3 == null ? D2.h.f801w : new t2.c(string3);
                        Cursor cursorQuery = hVar.a().query("event_payloads", new String[]{str2}, "event_id = ?", new String[]{String.valueOf(j6)}, null, null, "sequence_num");
                        try {
                            ArrayList arrayList2 = new ArrayList();
                            int length = 0;
                            while (cursorQuery.moveToNext()) {
                                byte[] blob = cursorQuery.getBlob(0);
                                arrayList2.add(blob);
                                length += blob.length;
                            }
                            byte[] bArr = new byte[length];
                            int i13 = 0;
                            int length2 = 0;
                            while (i13 < arrayList2.size()) {
                                byte[] bArr2 = (byte[]) arrayList2.get(i13);
                                String str3 = str2;
                                cursor = cursorQuery;
                                try {
                                    System.arraycopy(bArr2, 0, bArr, length2, bArr2.length);
                                    length2 += bArr2.length;
                                    i13++;
                                    cursorQuery = cursor;
                                    str2 = str3;
                                } catch (Throwable th) {
                                    th = th;
                                    cursor.close();
                                    throw th;
                                }
                            }
                            str = str2;
                            cursorQuery.close();
                            pVar.f835c = new l(cVar3, bArr);
                        } catch (Throwable th2) {
                            th = th2;
                            cursor = cursorQuery;
                        }
                    }
                    if (!cursor2.isNull(6)) {
                        pVar.f834b = Integer.valueOf(cursor2.getInt(6));
                    }
                    arrayList.add(new D2.b(j6, iVar, pVar.j()));
                    str2 = str;
                    i10 = 3;
                    i11 = 2;
                }
                return null;
            case 2:
                p135w2.h hVar2 = (p135w2.h) obj2;
                l lVar = hVar2.f9644c;
                String str4 = hVar2.f9642a;
                p135w2.i iVar2 = (p135w2.i) obj3;
                SQLiteDatabase sQLiteDatabase = (SQLiteDatabase) obj;
                long jSimpleQueryForLong = hVar.a().compileStatement("PRAGMA page_size").simpleQueryForLong() * hVar.a().compileStatement("PRAGMA page_count").simpleQueryForLong();
                D2.a aVar = hVar.f803u;
                if (jSimpleQueryForLong >= aVar.f790a) {
                    hVar.j(1L, cVar2, str4);
                    return -1L;
                }
                Long lD = D2.h.d(sQLiteDatabase, iVar2);
                if (lD != null) {
                    jInsert = lD.longValue();
                } else {
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("backend_name", iVar2.f9648a);
                    contentValues.put(MimeTypesReaderMetKeys.MAGIC_PRIORITY_ATTR, Integer.valueOf(G2.a.a(iVar2.f9650c)));
                    contentValues.put("next_request_ms", (Integer) 0);
                    byte[] bArr3 = iVar2.f9649b;
                    if (bArr3 != null) {
                        contentValues.put("extras", Base64.encodeToString(bArr3, 0));
                    }
                    jInsert = sQLiteDatabase.insert("transport_contexts", null, contentValues);
                }
                int i14 = aVar.f794e;
                byte[] bArr4 = lVar.f9656b;
                boolean z7 = bArr4.length <= i14;
                ContentValues contentValues2 = new ContentValues();
                contentValues2.put("context_id", Long.valueOf(jInsert));
                contentValues2.put("transport_name", str4);
                contentValues2.put("timestamp_ms", Long.valueOf(hVar2.f9645d));
                contentValues2.put("uptime_ms", Long.valueOf(hVar2.f9646e));
                contentValues2.put("payload_encoding", lVar.f9655a.f9023a);
                contentValues2.put("code", hVar2.f9643b);
                contentValues2.put("num_attempts", (Integer) 0);
                contentValues2.put("inline", Boolean.valueOf(z7));
                contentValues2.put("payload", z7 ? bArr4 : new byte[0]);
                long jInsert2 = sQLiteDatabase.insert("events", null, contentValues2);
                if (!z7) {
                    int iCeil = (int) Math.ceil(((double) bArr4.length) / ((double) i14));
                    for (int i15 = 1; i15 <= iCeil; i15++) {
                        byte[] bArrCopyOfRange = Arrays.copyOfRange(bArr4, (i15 - 1) * i14, Math.min(i15 * i14, bArr4.length));
                        ContentValues contentValues3 = new ContentValues();
                        contentValues3.put("event_id", Long.valueOf(jInsert2));
                        contentValues3.put("sequence_num", Integer.valueOf(i15));
                        contentValues3.put("bytes", bArrCopyOfRange);
                        sQLiteDatabase.insert("event_payloads", null, contentValues3);
                    }
                }
                for (Map.Entry entry : Collections.unmodifiableMap(hVar2.f9647f).entrySet()) {
                    ContentValues contentValues4 = new ContentValues();
                    contentValues4.put("event_id", Long.valueOf(jInsert2));
                    contentValues4.put("name", (String) entry.getKey());
                    contentValues4.put(MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, (String) entry.getValue());
                    sQLiteDatabase.insert("event_metadata", null, contentValues4);
                }
                return Long.valueOf(jInsert2);
            default:
                HashMap map = (HashMap) obj3;
                v vVar = (v) obj2;
                Cursor cursor3 = (Cursor) obj;
                hVar.getClass();
                while (cursor3.moveToNext()) {
                    String string4 = cursor3.getString(i12);
                    int i16 = cursor3.getInt(1);
                    p151z2.c cVar4 = p151z2.c.f10774s;
                    if (i16 != 0) {
                        if (i16 == 1) {
                            cVar4 = p151z2.c.t;
                        } else if (i16 == 2) {
                            cVar = cVar2;
                        } else if (i16 == 3) {
                            cVar4 = p151z2.c.f10776v;
                        } else if (i16 == i9) {
                            cVar4 = p151z2.c.f10777w;
                        } else if (i16 == i8) {
                            cVar4 = p151z2.c.f10778x;
                        } else if (i16 == i7) {
                            cVar4 = p151z2.c.y;
                        } else {
                            p025e2.v.i("SQLiteEventStore", "%n is not valid. No matched LogEventDropped-Reason found. Treated it as REASON_UNKNOWN", Integer.valueOf(i16));
                        }
                        cVar = cVar4;
                    } else {
                        cVar = cVar4;
                    }
                    long j7 = cursor3.getLong(2);
                    if (!map.containsKey(string4)) {
                        map.put(string4, new ArrayList());
                    }
                    ((List) map.get(string4)).add(new p151z2.d(j7, cVar));
                    i12 = 0;
                    i7 = 6;
                    i8 = 5;
                    i9 = 4;
                }
                for (Map.Entry entry2 : map.entrySet()) {
                    int i17 = p151z2.e.f10782c;
                    new ArrayList();
                    ((ArrayList) vVar.t).add(new p151z2.e((String) entry2.getKey(), Collections.unmodifiableList((List) entry2.getValue())));
                }
                long jN = hVar.f802s.n();
                SQLiteDatabase sQLiteDatabaseA = hVar.a();
                sQLiteDatabaseA.beginTransaction();
                try {
                    Cursor cursorRawQuery = sQLiteDatabaseA.rawQuery("SELECT last_metrics_upload_ms FROM global_log_event_state LIMIT 1", new String[0]);
                    try {
                        cursorRawQuery.moveToNext();
                        g gVar = new g(cursorRawQuery.getLong(0), jN);
                        cursorRawQuery.close();
                        sQLiteDatabaseA.setTransactionSuccessful();
                        sQLiteDatabaseA.endTransaction();
                        vVar.f6368s = gVar;
                        vVar.f6369u = new p151z2.b(new p151z2.f(hVar.a().compileStatement("PRAGMA page_size").simpleQueryForLong() * hVar.a().compileStatement("PRAGMA page_count").simpleQueryForLong(), D2.a.f789f.f790a));
                        vVar.r = (String) hVar.f804v.get();
                        return new p151z2.a((g) vVar.f6368s, Collections.unmodifiableList((ArrayList) vVar.t), (p151z2.b) vVar.f6369u, (String) vVar.r);
                    } catch (Throwable th3) {
                        cursorRawQuery.close();
                        throw th3;
                    }
                } catch (Throwable th4) {
                    sQLiteDatabaseA.endTransaction();
                    throw th4;
                }
        }
    }

    /* JADX WARN: Type inference failed for: r2v3, types: [s5.h, z5.e] */
    @Override // p121u.i
    public Object b(p121u.h hVar) {
        switch (this.r) {
            case 4:
                Executor executor = (Executor) this.t;
                String str = (String) this.f317s;
                p154z5.a aVar = (p154z5.a) this.f318u;
                AtomicBoolean atomicBoolean = new AtomicBoolean(false);
                q qVar = new q(atomicBoolean, 0);
                m mVar = hVar.f9089c;
                if (mVar != null) {
                    mVar.a(qVar, p018d2.m.r);
                }
                executor.execute(new r(atomicBoolean, hVar, aVar, 0));
                return str;
            default:
                q5.h hVar2 = (q5.h) this.t;
                EnumC0118w enumC0118w = (EnumC0118w) this.f317s;
                ?? r6 = (p116s5.h) this.f318u;
                B4.f fVar = new B4.f((Y) hVar2.j(C0115t.f2136s), 15);
                m mVar2 = hVar.f9089c;
                if (mVar2 != null) {
                    mVar2.a(fVar, p018d2.m.r);
                }
                return AbstractC0120y.p(AbstractC0120y.b(hVar2), null, enumC0118w, new s(r6, hVar, null), 1);
        }
    }

    @Override // E2.b
    public Object d() {
        c cVar = (c) this.t;
        p135w2.i iVar = (p135w2.i) this.f317s;
        p135w2.h hVar = (p135w2.h) this.f318u;
        D2.h hVar2 = (D2.h) cVar.f323d;
        hVar2.getClass();
        t2.d dVar = iVar.f9650c;
        String str = hVar.f9642a;
        String str2 = iVar.f9648a;
        String strX = p025e2.v.x("SQLiteEventStore");
        if (Log.isLoggable(strX, 3)) {
            Log.d(strX, "Storing event with priority=" + dVar + ", name=" + str + " for destination " + str2);
        }
        ((Long) hVar2.e(new b(hVar2, (Object) hVar, iVar, 2))).getClass();
        cVar.f320a.a(iVar, 1, false);
        return null;
    }

    @Override // p091o3.a
    public Object f(p091o3.i iVar) {
        p080m4.f fVar;
        URL url;
        switch (this.r) {
            case 7:
                p073l4.e eVar = (p073l4.e) this.t;
                p091o3.i iVar2 = (p091o3.i) this.f317s;
                p091o3.i iVar3 = (p091o3.i) this.f318u;
                if (!iVar2.h() || iVar2.f() == null) {
                    return android.support.v4.media.session.b.D(Boolean.FALSE);
                }
                p080m4.f fVar2 = (p080m4.f) iVar2.f();
                return (iVar3.h() && (fVar = (p080m4.f) iVar3.f()) != null && fVar2.f7855c.equals(fVar.f7855c)) ? android.support.v4.media.session.b.D(Boolean.FALSE) : eVar.f7721d.d(fVar2).l(eVar.f7719b, new p073l4.d(eVar));
            default:
                p080m4.l lVar = (p080m4.l) this.t;
                p091o3.i iVar4 = (p091o3.i) this.f317s;
                p091o3.i iVar5 = (p091o3.i) this.f318u;
                if (!iVar4.h()) {
                    return android.support.v4.media.session.b.C(new p073l4.f("Firebase Installations failed to get installation auth token for config update listener connection.", iVar4.e()));
                }
                if (!iVar5.h()) {
                    return android.support.v4.media.session.b.C(new p073l4.f("Firebase Installations failed to get installation ID for config update listener connection.", iVar5.e()));
                }
                try {
                    try {
                        url = new URL(lVar.c(lVar.f7895n));
                        break;
                    } catch (MalformedURLException unused) {
                        Log.e("FirebaseRemoteConfig", "URL is malformed");
                        url = null;
                    }
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    lVar.i(httpURLConnection, (String) iVar5.f(), ((p014c4.a) iVar4.f()).f4612a);
                    return android.support.v4.media.session.b.D(httpURLConnection);
                } catch (IOException e6) {
                    return android.support.v4.media.session.b.C(new p073l4.f("Failed to open HTTP stream connection", e6));
                }
        }
    }

    @Override // p091o3.h
    public p091o3.q h(Object obj) {
        FirebaseMessaging firebaseMessaging = (FirebaseMessaging) this.t;
        String str = (String) this.f317s;
        w wVar = (w) this.f318u;
        String str2 = (String) obj;
        M4.i iVarD = FirebaseMessaging.d(firebaseMessaging.f5066b);
        String strE = firebaseMessaging.e();
        String strA = firebaseMessaging.f5073i.a();
        synchronized (iVarD) {
            String strA2 = w.a(System.currentTimeMillis(), str2, strA);
            if (strA2 != null) {
                SharedPreferences.Editor editorEdit = ((SharedPreferences) iVarD.f2508s).edit();
                editorEdit.putString(M4.i.l(strE, str), strA2);
                editorEdit.commit();
            }
        }
        if (wVar == null || !str2.equals(wVar.f6371a)) {
            L3.g gVar = firebaseMessaging.f5065a;
            gVar.a();
            if ("[DEFAULT]".equals(gVar.f2201b)) {
                if (Log.isLoggable("FirebaseMessaging", 3)) {
                    StringBuilder sb = new StringBuilder("Invoking onNewToken for app: ");
                    gVar.a();
                    sb.append(gVar.f2201b);
                    Log.d("FirebaseMessaging", sb.toString());
                }
                Intent intent = new Intent("com.google.firebase.messaging.NEW_TOKEN");
                intent.putExtra("token", str2);
                new C0375h(firebaseMessaging.f5066b).b(intent);
            }
        }
        return android.support.v4.media.session.b.D(str2);
    }

    public /* synthetic */ b(Object obj, Object obj2, Object obj3, int i6) {
        this.r = i6;
        this.t = obj;
        this.f317s = obj2;
        this.f318u = obj3;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public /* synthetic */ b(q5.h hVar, EnumC0118w enumC0118w, p154z5.e eVar) {
        this.r = 5;
        this.t = hVar;
        this.f317s = enumC0118w;
        this.f318u = (p116s5.h) eVar;
    }
}
