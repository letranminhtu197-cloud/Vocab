package B2;

import J0.B;
import J0.E;
import K5.AbstractC0114s;
import K5.AbstractC0120y;
import K5.a0;
import W4.q;
import android.content.Context;
import android.content.Intent;
import android.speech.tts.TextToSpeech;
import androidx.work.impl.WorkDatabase;
import com.google.android.gms.internal.play_billing.AbstractC0252u0;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.logging.Logger;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.external.ExternalParser;
import org.apache.tika.utils.StringUtils;
import p018d2.y;
import p025e2.C0299c;
import p025e2.C0304h;
import p025e2.D;
import p025e2.F;
import p025e2.I;
import p025e2.InterfaceC0297a;
import p025e2.t;
import p025e2.v;
import p053i4.AbstractServiceC0374g;
import p068l.v0;
import p071l2.p;
import p091o3.j;
import p101q0.M;
import p107r2.f;
import p108r3.C;
import p108r3.C0468z;
import p108r3.T;
import p121u.k;
import p135w2.h;
import p135w2.i;
import p140x0.C0503z;
import p140x0.N;
import p142x2.g;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements Runnable {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ Object f315s;
    public final /* synthetic */ Object t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ Object f316u;

    public /* synthetic */ a(c cVar, i iVar, p089o1.b bVar, h hVar) {
        this.r = 0;
        this.f315s = cVar;
        this.t = iVar;
        this.f316u = hVar;
    }

    /* JADX WARN: Type inference failed for: r1v8, types: [J0.J, java.lang.Object] */
    @Override // java.lang.Runnable
    public final void run() {
        boolean zBooleanValue;
        boolean z6;
        switch (this.r) {
            case 0:
                c cVar = (c) this.f315s;
                i iVar = (i) this.t;
                String str = iVar.f9648a;
                h hVar = (h) this.f316u;
                cVar.getClass();
                Logger logger = c.f319f;
                try {
                    g gVarA = cVar.f322c.a(str);
                    if (gVarA == null) {
                        String str2 = "Transport backend '" + str + "' is not registered";
                        logger.warning(str2);
                        new IllegalArgumentException(str2);
                    } else {
                        ((D2.h) cVar.f324e).o(new b(cVar, iVar, ((p124u2.b) gVarA).a(hVar), 0));
                    }
                    return;
                } catch (Exception e6) {
                    logger.warning("Error scheduling event " + e6.getMessage());
                    return;
                }
            case 1:
                String str3 = (String) this.f315s;
                B4.e eVar = (B4.e) this.t;
                Context context = (Context) this.f316u;
                TextToSpeech textToSpeech = B4.i.f356a;
                if (textToSpeech != null && B4.i.f357b) {
                    textToSpeech.speak(str3, 0, null, "lt-widget");
                    eVar.b();
                    return;
                }
                B4.i.f358c = str3;
                B4.i.f359d.add(eVar);
                if (B4.i.f356a == null) {
                    B4.i.f356a = new TextToSpeech(context, new B4.g(0));
                    return;
                }
                return;
            case 2:
                C0.e eVar2 = (C0.e) this.f315s;
                this.t.h(eVar2.f380a, eVar2.f381b, (B) this.f316u);
                return;
            case 3:
                Map map = (Map) this.f315s;
                p073l4.e eVar3 = (p073l4.e) this.t;
                j jVar = (j) this.f316u;
                try {
                    M4.c cVar2 = new M4.c();
                    cVar2.f2483a = new HashMap();
                    for (Map.Entry entry : map.entrySet()) {
                        String str4 = (String) entry.getKey();
                        Object value = entry.getValue();
                        if (value instanceof String) {
                            cVar2.f2483a.put(str4, (String) value);
                        } else if (value instanceof Long) {
                            cVar2.f2483a.put(str4, Long.toString(((Number) value).longValue()));
                        } else if (value instanceof Integer) {
                            cVar2.f2483a.put(str4, Long.toString(((Number) value).intValue()));
                        } else if (value instanceof Double) {
                            cVar2.f2483a.put(str4, Double.toString(((Number) value).doubleValue()));
                        } else if (value == null) {
                            cVar2.f2483a.put(str4, null);
                        }
                    }
                    android.support.v4.media.session.b.c(android.support.v4.media.session.b.g(eVar3.f7719b, new D(eVar3, new io.flutter.plugin.editing.j(cVar2), 3)));
                    jVar.b(null);
                    return;
                } catch (Exception e7) {
                    jVar.a(e7);
                    return;
                }
            case 4:
                C0299c c0299c = (C0299c) this.f315s;
                k kVar = (k) this.t;
                I i6 = (I) this.f316u;
                c0299c.getClass();
                try {
                    zBooleanValue = ((Boolean) kVar.f9091s.get()).booleanValue();
                    break;
                } catch (InterruptedException | ExecutionException unused) {
                    zBooleanValue = true;
                }
                synchronized (c0299c.f5445k) {
                    try {
                        p071l2.k kVarP = AbstractC0252u0.p(i6.f5408a);
                        String str5 = kVarP.f7677a;
                        if (c0299c.c(str5) == i6) {
                            c0299c.b(str5);
                        }
                        y.e().a(C0299c.f5434l, C0299c.class.getSimpleName() + StringUtils.SPACE + str5 + " executed; reschedule = " + zBooleanValue);
                        ArrayList arrayList = c0299c.f5444j;
                        int size = arrayList.size();
                        int i7 = 0;
                        while (i7 < size) {
                            Object obj = arrayList.get(i7);
                            i7++;
                            ((InterfaceC0297a) obj).b(kVarP, zBooleanValue);
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                    break;
                }
                return;
            case 5:
                V4.d dVar = (V4.d) this.f315s;
                C0304h c0304h = (C0304h) this.t;
                C0299c c0299c2 = (C0299c) dVar.f3633s;
                c0299c2.getClass();
                p071l2.k kVar2 = c0304h.f5451a;
                String str6 = kVar2.f7677a;
                ArrayList arrayList2 = new ArrayList();
                p pVar = (p) c0299c2.f5439e.n(new R3.e(c0299c2, arrayList2, str6, 1));
                if (pVar == null) {
                    y.e().h(C0299c.f5434l, "Didn't find WorkSpec for id " + kVar2);
                    ((p084n2.a) c0299c2.f5438d.f6369u).execute(new p015d.b(c0299c2, kVar2, 2));
                    return;
                }
                synchronized (c0299c2.f5445k) {
                    try {
                        synchronized (c0299c2.f5445k) {
                            z6 = c0299c2.c(str6) != null;
                            break;
                        }
                        if (z6) {
                            Set set = (Set) c0299c2.f5442h.get(str6);
                            if (((C0304h) set.iterator().next()).f5451a.f7678b == kVar2.f7678b) {
                                set.add(c0304h);
                                y.e().a(C0299c.f5434l, "Work " + kVar2 + " is already enqueued for processing");
                            } else {
                                ((p084n2.a) c0299c2.f5438d.f6369u).execute(new p015d.b(c0299c2, kVar2, 2));
                            }
                            return;
                        }
                        if (pVar.t != kVar2.f7678b) {
                            ((p084n2.a) c0299c2.f5438d.f6369u).execute(new p015d.b(c0299c2, kVar2, 2));
                            return;
                        }
                        I i8 = new I(new v0(c0299c2.f5436b, c0299c2.f5437c, c0299c2.f5438d, c0299c2, c0299c2.f5439e, pVar, arrayList2));
                        AbstractC0114s abstractC0114s = (AbstractC0114s) i8.f5411d.f6368s;
                        a0 a0VarC = AbstractC0120y.c();
                        abstractC0114s.getClass();
                        k kVarW = AbstractC0252u0.w(v.E(abstractC0114s, a0VarC), new F(i8, null));
                        kVarW.f9091s.a(new a(c0299c2, kVarW, i8, 4), (p084n2.a) c0299c2.f5438d.f6369u);
                        c0299c2.f5441g.put(str6, i8);
                        HashSet hashSet = new HashSet();
                        hashSet.add(c0304h);
                        c0299c2.f5442h.put(str6, hashSet);
                        y.e().a(C0299c.f5434l, C0299c.class.getSimpleName() + ": processing " + kVar2);
                        return;
                    } catch (Throwable th2) {
                        throw th2;
                    }
                }
            case 6:
                AbstractServiceC0374g abstractServiceC0374g = (AbstractServiceC0374g) this.f315s;
                Intent intent = (Intent) this.t;
                j jVar2 = (j) this.f316u;
                try {
                    abstractServiceC0374g.b(intent);
                    return;
                } finally {
                    jVar2.b(null);
                }
            case 7:
                WorkDatabase workDatabase = (WorkDatabase) this.f315s;
                String str7 = (String) this.t;
                t tVar = (t) this.f316u;
                p071l2.t tVarV = workDatabase.v();
                tVarV.getClass();
                A5.h.e(str7, "name");
                Iterator it = ((List) X2.a.I(tVarV.f7708a, true, false, new p071l2.b(str7, 9))).iterator();
                while (it.hasNext()) {
                    p078m2.g.a(tVar, (String) it.next());
                }
                return;
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                ((ExternalParser) this.f315s).lambda$extractMetadata$2((InputStream) this.t, (Metadata) this.f316u);
                return;
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                f fVar = (f) this.f315s;
                String str8 = (String) this.t;
                Object obj2 = this.f316u;
                q qVar = fVar.f8756s;
                if (qVar != null) {
                    qVar.a(str8, obj2, null);
                    return;
                }
                return;
            default:
                N n6 = (N) this.f315s;
                C0468z c0468z = (C0468z) this.t;
                E e8 = (E) this.f316u;
                y0.d dVar2 = n6.f9796c;
                T tF = c0468z.f();
                D3.p pVar2 = dVar2.f10448u;
                D3.e eVar4 = dVar2.f10451x;
                eVar4.getClass();
                pVar2.getClass();
                pVar2.f835c = C.n(tF);
                if (!tF.isEmpty()) {
                    pVar2.f838f = (E) tF.get(0);
                    e8.getClass();
                    pVar2.f834b = e8;
                }
                if (((E) pVar2.f837e) == null) {
                    pVar2.f837e = D3.p.n(eVar4, (C) pVar2.f835c, (E) pVar2.f838f, (M) pVar2.f833a);
                }
                pVar2.t(((C0503z) eVar4).o());
                return;
        }
    }

    public /* synthetic */ a(Object obj, Object obj2, Object obj3, int i6) {
        this.r = i6;
        this.f315s = obj;
        this.t = obj2;
        this.f316u = obj3;
    }
}
