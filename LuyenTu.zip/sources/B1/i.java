package B1;

import android.media.MicrophoneInfo;

/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class i {
    public static /* bridge */ /* synthetic */ MicrophoneInfo h(Object obj) {
        return (MicrophoneInfo) obj;
    }
}
