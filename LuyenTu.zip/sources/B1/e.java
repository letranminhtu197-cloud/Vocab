package B1;

/* JADX INFO: loaded from: classes.dex */
public interface e {
    void v();

    void w(int i6, Object obj);
}
