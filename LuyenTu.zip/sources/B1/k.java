package B1;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public final class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f305a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f306b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f307c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f308d;

    public k(int i6, int i7, long j6, long j7) {
        this.f305a = i6;
        this.f306b = i7;
        this.f307c = j6;
        this.f308d = j7;
    }

    public static k a(File file) throws IOException {
        DataInputStream dataInputStream = new DataInputStream(new FileInputStream(file));
        try {
            k kVar = new k(dataInputStream.readInt(), dataInputStream.readInt(), dataInputStream.readLong(), dataInputStream.readLong());
            dataInputStream.close();
            return kVar;
        } catch (Throwable th) {
            try {
                dataInputStream.close();
                throw th;
            } catch (Throwable th2) {
                th.addSuppressed(th2);
                throw th;
            }
        }
    }

    public final void b(File file) throws IOException {
        file.delete();
        DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(file));
        try {
            dataOutputStream.writeInt(this.f305a);
            dataOutputStream.writeInt(this.f306b);
            dataOutputStream.writeLong(this.f307c);
            dataOutputStream.writeLong(this.f308d);
            dataOutputStream.close();
        } catch (Throwable th) {
            try {
                dataOutputStream.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && (obj instanceof k)) {
            k kVar = (k) obj;
            if (this.f306b == kVar.f306b && this.f307c == kVar.f307c && this.f305a == kVar.f305a && this.f308d == kVar.f308d) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return Objects.hash(Integer.valueOf(this.f306b), Long.valueOf(this.f307c), Integer.valueOf(this.f305a), Long.valueOf(this.f308d));
    }
}
