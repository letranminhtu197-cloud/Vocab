package B1;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class h implements Runnable {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ Context f304s;

    public /* synthetic */ h(Context context, int i6) {
        this.r = i6;
        this.f304s = context;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.r) {
            case 0:
                new ThreadPoolExecutor(0, 1, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue()).execute(new h(this.f304s, 1));
                break;
            case 1:
                f.t(this.f304s, new d(0), f.f294a, false);
                break;
            case 2:
                Context context = this.f304s;
                AtomicBoolean atomicBoolean = B4.a.f348a;
                try {
                    A5.h.b(context);
                    B4.a.b(context);
                    break;
                } catch (Throwable unused) {
                }
                atomicBoolean.set(false);
                break;
            default:
                if (B4.i.f356a == null) {
                    B4.i.f356a = new TextToSpeech(this.f304s, new B4.g(1));
                    break;
                }
                break;
        }
    }
}
