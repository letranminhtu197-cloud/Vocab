package B1;

import android.content.Intent;
import android.content.IntentSender;
import java.util.concurrent.CopyOnWriteArraySet;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements Runnable {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ int f275s;
    public final /* synthetic */ Object t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ Object f276u;

    public /* synthetic */ a(int i6, int i7, Object obj, Object obj2) {
        this.r = i7;
        this.t = obj;
        this.f275s = i6;
        this.f276u = obj2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.r) {
            case 0:
                ((e) ((b) this.t).f279c).w(this.f275s, this.f276u);
                break;
            case 1:
                p015d.k kVar = (p015d.k) this.t;
                Object obj = ((p034g.a) this.f276u).r;
                String str = (String) kVar.f5108a.get(Integer.valueOf(this.f275s));
                if (str != null) {
                    p029f.d dVar = (p029f.d) kVar.f5112e.get(str);
                    if ((dVar != null ? dVar.f5523a : null) == null) {
                        kVar.f5114g.remove(str);
                        kVar.f5113f.put(str, obj);
                    } else {
                        p029f.b bVar = dVar.f5523a;
                        if (kVar.f5111d.remove(str)) {
                            bVar.i(obj);
                        }
                    }
                    break;
                }
                break;
            case 2:
                ((p015d.k) this.t).a(this.f275s, 0, new Intent().setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (IntentSender.SendIntentException) this.f276u));
                break;
            default:
                CopyOnWriteArraySet<p117t0.h> copyOnWriteArraySet = (CopyOnWriteArraySet) this.t;
                p117t0.f fVar = (p117t0.f) this.f276u;
                for (p117t0.h hVar : copyOnWriteArraySet) {
                    if (!hVar.f8968d) {
                        int i6 = this.f275s;
                        if (i6 != -1) {
                            hVar.f8966b.a(i6);
                        }
                        hVar.f8967c = true;
                        fVar.a(hVar.f8965a);
                    }
                }
                break;
        }
    }
}
