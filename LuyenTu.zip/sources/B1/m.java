package B1;

/* JADX INFO: loaded from: classes.dex */
public final class m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f312a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final byte[] f313b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f314c;

    public m(int i6, boolean z6, byte[] bArr) {
        this.f312a = i6;
        this.f313b = bArr;
        this.f314c = z6;
    }
}
