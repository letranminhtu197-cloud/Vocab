package B1;

import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class d implements Executor {
    public final /* synthetic */ int r;

    public /* synthetic */ d(int i6) {
        this.r = i6;
    }

    private final void a(Runnable runnable) {
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        switch (this.r) {
            case 0:
                runnable.run();
                break;
            case 1:
                break;
            default:
                p075m.a.a0().f7750f.f7753g.execute(runnable);
                break;
        }
    }
}
