package B1;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.os.Build;
import android.util.Log;
import com.google.crypto.tink.shaded.protobuf.T;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.Executor;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.Inflater;
import org.apache.tika.fork.ForkServer;
import org.apache.tika.metadata.TikaCoreProperties;

/* JADX INFO: loaded from: classes.dex */
public abstract class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Z3.e f294a = new Z3.e(2);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final byte[] f295b = {112, 114, 111, 0};

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final byte[] f296c = {112, 114, 109, 0};

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final byte[] f297d = {48, 49, 53, 0};

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final byte[] f298e = {48, 49, 48, 0};

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final byte[] f299f = {48, 48, 57, 0};

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final byte[] f300g = {48, 48, 53, 0};

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final byte[] f301h = {48, 48, 49, 0};

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final byte[] f302i = {48, 48, 49, 0};

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final byte[] f303j = {48, 48, 50, 0};

    public static byte[] a(byte[] bArr) {
        Deflater deflater = new Deflater(1);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream(byteArrayOutputStream, deflater);
            try {
                deflaterOutputStream.write(bArr);
                deflaterOutputStream.close();
                deflater.end();
                return byteArrayOutputStream.toByteArray();
            } catch (Throwable th) {
                try {
                    deflaterOutputStream.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        } catch (Throwable th3) {
            deflater.end();
            throw th3;
        }
    }

    public static byte[] b(c[] cVarArr, byte[] bArr) throws IOException {
        int i6 = 0;
        int length = 0;
        for (c cVar : cVarArr) {
            length += ((((cVar.f291g * 2) + 7) & (-8)) / 8) + (cVar.f289e * 2) + d(cVar.f285a, cVar.f286b, bArr).getBytes(StandardCharsets.UTF_8).length + 16 + cVar.f290f;
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(length);
        if (Arrays.equals(bArr, f299f)) {
            int length2 = cVarArr.length;
            while (i6 < length2) {
                c cVar2 = cVarArr[i6];
                q(byteArrayOutputStream, cVar2, d(cVar2.f285a, cVar2.f286b, bArr));
                p(byteArrayOutputStream, cVar2);
                i6++;
            }
        } else {
            for (c cVar3 : cVarArr) {
                q(byteArrayOutputStream, cVar3, d(cVar3.f285a, cVar3.f286b, bArr));
            }
            int length3 = cVarArr.length;
            while (i6 < length3) {
                p(byteArrayOutputStream, cVarArr[i6]);
                i6++;
            }
        }
        if (byteArrayOutputStream.size() == length) {
            return byteArrayOutputStream.toByteArray();
        }
        throw new IllegalStateException("The bytes saved do not match expectation. actual=" + byteArrayOutputStream.size() + " expected=" + length);
    }

    public static boolean c(File file) {
        if (!file.isDirectory()) {
            file.delete();
            return true;
        }
        File[] fileArrListFiles = file.listFiles();
        if (fileArrListFiles == null) {
            return false;
        }
        boolean z6 = true;
        for (File file2 : fileArrListFiles) {
            z6 = c(file2) && z6;
        }
        return z6;
    }

    public static String d(String str, String str2, byte[] bArr) {
        byte[] bArr2 = f301h;
        boolean zEquals = Arrays.equals(bArr, bArr2);
        byte[] bArr3 = f300g;
        Object obj = (zEquals || Arrays.equals(bArr, bArr3)) ? TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER : "!";
        if (str.length() <= 0) {
            if ("!".equals(obj)) {
                return str2.replace(TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER, "!");
            }
            if (TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER.equals(obj)) {
                return str2.replace("!", TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER);
            }
        } else {
            if (str2.equals("classes.dex")) {
                return str;
            }
            if (str2.contains("!") || str2.contains(TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER)) {
                if ("!".equals(obj)) {
                    return str2.replace(TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER, "!");
                }
                if (TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER.equals(obj)) {
                    return str2.replace("!", TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER);
                }
            } else if (!str2.endsWith(".apk")) {
                StringBuilder sb = new StringBuilder();
                sb.append(str);
                return T.m(sb, (Arrays.equals(bArr, bArr2) || Arrays.equals(bArr, bArr3)) ? TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER : "!", str2);
            }
        }
        return str2;
    }

    public static void e(PackageInfo packageInfo, File file) {
        try {
            DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(new File(file, "profileinstaller_profileWrittenFor_lastUpdateTime.dat")));
            try {
                dataOutputStream.writeLong(packageInfo.lastUpdateTime);
                dataOutputStream.close();
            } catch (Throwable th) {
                try {
                    dataOutputStream.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        } catch (IOException unused) {
        }
    }

    public static byte[] f(InputStream inputStream, int i6) throws IOException {
        byte[] bArr = new byte[i6];
        int i7 = 0;
        while (i7 < i6) {
            int i8 = inputStream.read(bArr, i7, i6 - i7);
            if (i8 < 0) {
                throw new IllegalStateException(T.g("Not enough bytes to read: ", i6));
            }
            i7 += i8;
        }
        return bArr;
    }

    public static int[] g(ByteArrayInputStream byteArrayInputStream, int i6) {
        int[] iArr = new int[i6];
        int iM = 0;
        for (int i7 = 0; i7 < i6; i7++) {
            iM += (int) m(byteArrayInputStream, 2);
            iArr[i7] = iM;
        }
        return iArr;
    }

    public static byte[] h(FileInputStream fileInputStream, int i6, int i7) {
        Inflater inflater = new Inflater();
        try {
            byte[] bArr = new byte[i7];
            byte[] bArr2 = new byte[2048];
            int i8 = 0;
            int iInflate = 0;
            while (!inflater.finished() && !inflater.needsDictionary() && i8 < i6) {
                int i9 = fileInputStream.read(bArr2);
                if (i9 < 0) {
                    throw new IllegalStateException("Invalid zip data. Stream ended after $totalBytesRead bytes. Expected " + i6 + " bytes");
                }
                inflater.setInput(bArr2, 0, i9);
                try {
                    iInflate += inflater.inflate(bArr, iInflate, i7 - iInflate);
                    i8 += i9;
                } catch (DataFormatException e6) {
                    throw new IllegalStateException(e6.getMessage());
                }
            }
            if (i8 == i6) {
                if (!inflater.finished()) {
                    throw new IllegalStateException("Inflater did not finish");
                }
                inflater.end();
                return bArr;
            }
            throw new IllegalStateException("Didn't read enough bytes during decompression. expected=" + i6 + " actual=" + i8);
        } catch (Throwable th) {
            inflater.end();
            throw th;
        }
    }

    public static c[] i(FileInputStream fileInputStream, byte[] bArr, byte[] bArr2, c[] cVarArr) throws IOException {
        byte[] bArr3 = f302i;
        if (!Arrays.equals(bArr, bArr3)) {
            if (!Arrays.equals(bArr, f303j)) {
                throw new IllegalStateException("Unsupported meta version");
            }
            int iM = (int) m(fileInputStream, 2);
            byte[] bArrH = h(fileInputStream, (int) m(fileInputStream, 4), (int) m(fileInputStream, 4));
            if (fileInputStream.read() > 0) {
                throw new IllegalStateException("Content found after the end of file");
            }
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bArrH);
            try {
                c[] cVarArrK = k(byteArrayInputStream, bArr2, iM, cVarArr);
                byteArrayInputStream.close();
                return cVarArrK;
            } catch (Throwable th) {
                try {
                    byteArrayInputStream.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
        if (Arrays.equals(f297d, bArr2)) {
            throw new IllegalStateException("Requires new Baseline Profile Metadata. Please rebuild the APK with Android Gradle Plugin 7.2 Canary 7 or higher");
        }
        if (!Arrays.equals(bArr, bArr3)) {
            throw new IllegalStateException("Unsupported meta version");
        }
        int iM2 = (int) m(fileInputStream, 1);
        byte[] bArrH2 = h(fileInputStream, (int) m(fileInputStream, 4), (int) m(fileInputStream, 4));
        if (fileInputStream.read() > 0) {
            throw new IllegalStateException("Content found after the end of file");
        }
        ByteArrayInputStream byteArrayInputStream2 = new ByteArrayInputStream(bArrH2);
        try {
            c[] cVarArrJ = j(byteArrayInputStream2, iM2, cVarArr);
            byteArrayInputStream2.close();
            return cVarArrJ;
        } catch (Throwable th3) {
            try {
                byteArrayInputStream2.close();
            } catch (Throwable th4) {
                th3.addSuppressed(th4);
            }
            throw th3;
        }
    }

    public static c[] j(ByteArrayInputStream byteArrayInputStream, int i6, c[] cVarArr) {
        if (byteArrayInputStream.available() == 0) {
            return new c[0];
        }
        if (i6 != cVarArr.length) {
            throw new IllegalStateException("Mismatched number of dex files found in metadata");
        }
        String[] strArr = new String[i6];
        int[] iArr = new int[i6];
        for (int i7 = 0; i7 < i6; i7++) {
            int iM = (int) m(byteArrayInputStream, 2);
            iArr[i7] = (int) m(byteArrayInputStream, 2);
            strArr[i7] = new String(f(byteArrayInputStream, iM), StandardCharsets.UTF_8);
        }
        for (int i8 = 0; i8 < i6; i8++) {
            c cVar = cVarArr[i8];
            if (!cVar.f286b.equals(strArr[i8])) {
                throw new IllegalStateException("Order of dexfiles in metadata did not match baseline");
            }
            int i9 = iArr[i8];
            cVar.f289e = i9;
            cVar.f292h = g(byteArrayInputStream, i9);
        }
        return cVarArr;
    }

    public static c[] k(ByteArrayInputStream byteArrayInputStream, byte[] bArr, int i6, c[] cVarArr) throws IOException {
        if (byteArrayInputStream.available() == 0) {
            return new c[0];
        }
        if (i6 != cVarArr.length) {
            throw new IllegalStateException("Mismatched number of dex files found in metadata");
        }
        for (int i7 = 0; i7 < i6; i7++) {
            m(byteArrayInputStream, 2);
            String str = new String(f(byteArrayInputStream, (int) m(byteArrayInputStream, 2)), StandardCharsets.UTF_8);
            long jM = m(byteArrayInputStream, 4);
            int iM = (int) m(byteArrayInputStream, 2);
            c cVar = null;
            if (cVarArr.length > 0) {
                int iIndexOf = str.indexOf("!");
                if (iIndexOf < 0) {
                    iIndexOf = str.indexOf(TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER);
                }
                String strSubstring = iIndexOf > 0 ? str.substring(iIndexOf + 1) : str;
                for (int i8 = 0; i8 < cVarArr.length; i8++) {
                    if (cVarArr[i8].f286b.equals(strSubstring)) {
                        cVar = cVarArr[i8];
                        break;
                    }
                }
            }
            if (cVar == null) {
                throw new IllegalStateException("Missing profile key: ".concat(str));
            }
            cVar.f288d = jM;
            int[] iArrG = g(byteArrayInputStream, iM);
            if (Arrays.equals(bArr, f301h)) {
                cVar.f289e = iM;
                cVar.f292h = iArrG;
            }
        }
        return cVarArr;
    }

    public static c[] l(FileInputStream fileInputStream, byte[] bArr, String str) throws IOException {
        if (!Arrays.equals(bArr, f298e)) {
            throw new IllegalStateException("Unsupported version");
        }
        int iM = (int) m(fileInputStream, 1);
        byte[] bArrH = h(fileInputStream, (int) m(fileInputStream, 4), (int) m(fileInputStream, 4));
        if (fileInputStream.read() > 0) {
            throw new IllegalStateException("Content found after the end of file");
        }
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bArrH);
        try {
            c[] cVarArrN = n(byteArrayInputStream, str, iM);
            byteArrayInputStream.close();
            return cVarArrN;
        } catch (Throwable th) {
            try {
                byteArrayInputStream.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    public static long m(InputStream inputStream, int i6) throws IOException {
        byte[] bArrF = f(inputStream, i6);
        long j6 = 0;
        for (int i7 = 0; i7 < i6; i7++) {
            j6 += ((long) (bArrF[i7] & ForkServer.ERROR)) << (i7 * 8);
        }
        return j6;
    }

    public static c[] n(ByteArrayInputStream byteArrayInputStream, String str, int i6) throws IOException {
        int i7 = 0;
        if (byteArrayInputStream.available() == 0) {
            return new c[0];
        }
        c[] cVarArr = new c[i6];
        for (int i8 = 0; i8 < i6; i8++) {
            int iM = (int) m(byteArrayInputStream, 2);
            int iM2 = (int) m(byteArrayInputStream, 2);
            cVarArr[i8] = new c(str, new String(f(byteArrayInputStream, iM), StandardCharsets.UTF_8), m(byteArrayInputStream, 4), iM2, (int) m(byteArrayInputStream, 4), (int) m(byteArrayInputStream, 4), new int[iM2], new TreeMap());
        }
        int i9 = 0;
        while (i9 < i6) {
            c cVar = cVarArr[i9];
            int iAvailable = byteArrayInputStream.available();
            int i10 = cVar.f290f;
            int i11 = cVar.f291g;
            TreeMap treeMap = cVar.f293i;
            int i12 = iAvailable - i10;
            int iM3 = i7;
            while (byteArrayInputStream.available() > i12) {
                iM3 += (int) m(byteArrayInputStream, 2);
                treeMap.put(Integer.valueOf(iM3), 1);
                int iM4 = (int) m(byteArrayInputStream, 2);
                while (iM4 > 0) {
                    m(byteArrayInputStream, 2);
                    int iM5 = (int) m(byteArrayInputStream, 1);
                    if (iM5 != 6 && iM5 != 7) {
                        while (iM5 > 0) {
                            m(byteArrayInputStream, 1);
                            int i13 = i7;
                            int i14 = i9;
                            for (int iM6 = (int) m(byteArrayInputStream, 1); iM6 > 0; iM6--) {
                                m(byteArrayInputStream, 2);
                            }
                            iM5--;
                            i7 = i13;
                            i9 = i14;
                        }
                    }
                    iM4--;
                    i7 = i7;
                    i9 = i9;
                }
            }
            int i15 = i7;
            int i16 = i9;
            if (byteArrayInputStream.available() != i12) {
                throw new IllegalStateException("Read too much data during profile line parse");
            }
            cVar.f292h = g(byteArrayInputStream, cVar.f289e);
            BitSet bitSetValueOf = BitSet.valueOf(f(byteArrayInputStream, (((i11 * 2) + 7) & (-8)) / 8));
            for (int i17 = i15; i17 < i11; i17++) {
                int i18 = bitSetValueOf.get(i17) ? 2 : i15;
                if (bitSetValueOf.get(i17 + i11)) {
                    i18 |= 4;
                }
                if (i18 != 0) {
                    Integer numValueOf = (Integer) treeMap.get(Integer.valueOf(i17));
                    if (numValueOf == null) {
                        numValueOf = Integer.valueOf(i15);
                    }
                    treeMap.put(Integer.valueOf(i17), Integer.valueOf(i18 | numValueOf.intValue()));
                }
            }
            i9 = i16 + 1;
            i7 = i15;
        }
        return cVarArr;
    }

    public static boolean o(ByteArrayOutputStream byteArrayOutputStream, byte[] bArr, c[] cVarArr) throws IOException {
        long j6;
        ArrayList arrayList;
        int length;
        byte[] bArr2 = f297d;
        int i6 = 0;
        if (!Arrays.equals(bArr, bArr2)) {
            byte[] bArr3 = f298e;
            if (Arrays.equals(bArr, bArr3)) {
                byte[] bArrB = b(cVarArr, bArr3);
                u(byteArrayOutputStream, cVarArr.length, 1);
                u(byteArrayOutputStream, bArrB.length, 4);
                byte[] bArrA = a(bArrB);
                u(byteArrayOutputStream, bArrA.length, 4);
                byteArrayOutputStream.write(bArrA);
                return true;
            }
            byte[] bArr4 = f300g;
            if (Arrays.equals(bArr, bArr4)) {
                u(byteArrayOutputStream, cVarArr.length, 1);
                for (c cVar : cVarArr) {
                    int size = cVar.f293i.size() * 4;
                    String strD = d(cVar.f285a, cVar.f286b, bArr4);
                    Charset charset = StandardCharsets.UTF_8;
                    v(byteArrayOutputStream, strD.getBytes(charset).length);
                    v(byteArrayOutputStream, cVar.f292h.length);
                    u(byteArrayOutputStream, size, 4);
                    u(byteArrayOutputStream, cVar.f287c, 4);
                    byteArrayOutputStream.write(strD.getBytes(charset));
                    Iterator it = cVar.f293i.keySet().iterator();
                    while (it.hasNext()) {
                        v(byteArrayOutputStream, ((Integer) it.next()).intValue());
                        v(byteArrayOutputStream, 0);
                    }
                    for (int i7 : cVar.f292h) {
                        v(byteArrayOutputStream, i7);
                    }
                }
                return true;
            }
            byte[] bArr5 = f299f;
            if (Arrays.equals(bArr, bArr5)) {
                byte[] bArrB2 = b(cVarArr, bArr5);
                u(byteArrayOutputStream, cVarArr.length, 1);
                u(byteArrayOutputStream, bArrB2.length, 4);
                byte[] bArrA2 = a(bArrB2);
                u(byteArrayOutputStream, bArrA2.length, 4);
                byteArrayOutputStream.write(bArrA2);
                return true;
            }
            byte[] bArr6 = f301h;
            if (!Arrays.equals(bArr, bArr6)) {
                return false;
            }
            v(byteArrayOutputStream, cVarArr.length);
            for (c cVar2 : cVarArr) {
                String str = cVar2.f285a;
                TreeMap treeMap = cVar2.f293i;
                String strD2 = d(str, cVar2.f286b, bArr6);
                Charset charset2 = StandardCharsets.UTF_8;
                v(byteArrayOutputStream, strD2.getBytes(charset2).length);
                v(byteArrayOutputStream, treeMap.size());
                v(byteArrayOutputStream, cVar2.f292h.length);
                u(byteArrayOutputStream, cVar2.f287c, 4);
                byteArrayOutputStream.write(strD2.getBytes(charset2));
                Iterator it2 = treeMap.keySet().iterator();
                while (it2.hasNext()) {
                    v(byteArrayOutputStream, ((Integer) it2.next()).intValue());
                }
                for (int i8 : cVar2.f292h) {
                    v(byteArrayOutputStream, i8);
                }
            }
            return true;
        }
        ArrayList arrayList2 = new ArrayList(3);
        ArrayList arrayList3 = new ArrayList(3);
        ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
        try {
            v(byteArrayOutputStream2, cVarArr.length);
            int i9 = 2;
            int i10 = 2;
            for (c cVar3 : cVarArr) {
                u(byteArrayOutputStream2, cVar3.f287c, 4);
                u(byteArrayOutputStream2, cVar3.f288d, 4);
                u(byteArrayOutputStream2, cVar3.f291g, 4);
                String strD3 = d(cVar3.f285a, cVar3.f286b, bArr2);
                Charset charset3 = StandardCharsets.UTF_8;
                int length2 = strD3.getBytes(charset3).length;
                v(byteArrayOutputStream2, length2);
                i10 = i10 + 14 + length2;
                byteArrayOutputStream2.write(strD3.getBytes(charset3));
            }
            byte[] byteArray = byteArrayOutputStream2.toByteArray();
            if (i10 != byteArray.length) {
                throw new IllegalStateException("Expected size " + i10 + ", does not match actual size " + byteArray.length);
            }
            m mVar = new m(1, false, byteArray);
            byteArrayOutputStream2.close();
            arrayList2.add(mVar);
            ByteArrayOutputStream byteArrayOutputStream3 = new ByteArrayOutputStream();
            int i11 = 0;
            int i12 = 0;
            while (i11 < cVarArr.length) {
                try {
                    c cVar4 = cVarArr[i11];
                    v(byteArrayOutputStream3, i11);
                    v(byteArrayOutputStream3, cVar4.f289e);
                    i12 = i12 + 4 + (cVar4.f289e * i9);
                    int[] iArr = cVar4.f292h;
                    int length3 = iArr.length;
                    int i13 = i6;
                    int i14 = i9;
                    int i15 = i13;
                    while (i15 < length3) {
                        int i16 = iArr[i15];
                        v(byteArrayOutputStream3, i16 - i13);
                        i15++;
                        i13 = i16;
                    }
                    i11++;
                    i9 = i14;
                    i6 = 0;
                } catch (Throwable th) {
                    try {
                        byteArrayOutputStream3.close();
                        throw th;
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                        throw th;
                    }
                }
            }
            byte[] byteArray2 = byteArrayOutputStream3.toByteArray();
            if (i12 != byteArray2.length) {
                throw new IllegalStateException("Expected size " + i12 + ", does not match actual size " + byteArray2.length);
            }
            m mVar2 = new m(3, true, byteArray2);
            byteArrayOutputStream3.close();
            arrayList2.add(mVar2);
            ByteArrayOutputStream byteArrayOutputStream4 = new ByteArrayOutputStream();
            int i17 = 0;
            int i18 = 0;
            while (i17 < cVarArr.length) {
                try {
                    c cVar5 = cVarArr[i17];
                    Iterator it3 = cVar5.f293i.entrySet().iterator();
                    int iIntValue = 0;
                    while (it3.hasNext()) {
                        iIntValue |= ((Integer) ((Map.Entry) it3.next()).getValue()).intValue();
                    }
                    ByteArrayOutputStream byteArrayOutputStream5 = new ByteArrayOutputStream();
                    try {
                        r(byteArrayOutputStream5, iIntValue, cVar5);
                        byte[] byteArray3 = byteArrayOutputStream5.toByteArray();
                        byteArrayOutputStream5.close();
                        ByteArrayOutputStream byteArrayOutputStream6 = new ByteArrayOutputStream();
                        try {
                            s(byteArrayOutputStream6, cVar5);
                            byte[] byteArray4 = byteArrayOutputStream6.toByteArray();
                            byteArrayOutputStream6.close();
                            v(byteArrayOutputStream4, i17);
                            int length4 = byteArray3.length + 2 + byteArray4.length;
                            int i19 = i18 + 6;
                            ArrayList arrayList4 = arrayList3;
                            u(byteArrayOutputStream4, length4, 4);
                            v(byteArrayOutputStream4, iIntValue);
                            byteArrayOutputStream4.write(byteArray3);
                            byteArrayOutputStream4.write(byteArray4);
                            i18 = i19 + length4;
                            i17++;
                            arrayList3 = arrayList4;
                        } catch (Throwable th3) {
                            try {
                                byteArrayOutputStream6.close();
                                throw th3;
                            } catch (Throwable th4) {
                                th3.addSuppressed(th4);
                                throw th3;
                            }
                        }
                    } catch (Throwable th5) {
                        try {
                            byteArrayOutputStream5.close();
                            throw th5;
                        } catch (Throwable th6) {
                            th5.addSuppressed(th6);
                            throw th5;
                        }
                    }
                } catch (Throwable th7) {
                    try {
                        byteArrayOutputStream4.close();
                        throw th7;
                    } catch (Throwable th8) {
                        th7.addSuppressed(th8);
                        throw th7;
                    }
                }
            }
            ArrayList arrayList5 = arrayList3;
            byte[] byteArray5 = byteArrayOutputStream4.toByteArray();
            if (i18 != byteArray5.length) {
                throw new IllegalStateException("Expected size " + i18 + ", does not match actual size " + byteArray5.length);
            }
            m mVar3 = new m(4, true, byteArray5);
            byteArrayOutputStream4.close();
            arrayList2.add(mVar3);
            long j7 = 4;
            long size2 = j7 + j7 + 4 + ((long) (arrayList2.size() * 16));
            u(byteArrayOutputStream, arrayList2.size(), 4);
            int i20 = 0;
            while (i20 < arrayList2.size()) {
                m mVar4 = (m) arrayList2.get(i20);
                int i21 = mVar4.f312a;
                byte[] bArr7 = mVar4.f313b;
                if (i21 == 1) {
                    j6 = 0;
                } else if (i21 == 2) {
                    j6 = 1;
                } else if (i21 == 3) {
                    j6 = 2;
                } else if (i21 == 4) {
                    j6 = 3;
                } else {
                    if (i21 != 5) {
                        throw null;
                    }
                    j6 = 4;
                }
                u(byteArrayOutputStream, j6, 4);
                u(byteArrayOutputStream, size2, 4);
                if (mVar4.f314c) {
                    long length5 = bArr7.length;
                    byte[] bArrA3 = a(bArr7);
                    arrayList = arrayList5;
                    arrayList.add(bArrA3);
                    u(byteArrayOutputStream, bArrA3.length, 4);
                    u(byteArrayOutputStream, length5, 4);
                    length = bArrA3.length;
                } else {
                    arrayList = arrayList5;
                    arrayList.add(bArr7);
                    u(byteArrayOutputStream, bArr7.length, 4);
                    u(byteArrayOutputStream, 0L, 4);
                    length = bArr7.length;
                }
                size2 += (long) length;
                i20++;
                arrayList5 = arrayList;
            }
            ArrayList arrayList6 = arrayList5;
            for (int i22 = 0; i22 < arrayList6.size(); i22++) {
                byteArrayOutputStream.write((byte[]) arrayList6.get(i22));
            }
            return true;
        } catch (Throwable th9) {
            try {
                byteArrayOutputStream2.close();
                throw th9;
            } catch (Throwable th10) {
                th9.addSuppressed(th10);
                throw th9;
            }
        }
    }

    public static void p(ByteArrayOutputStream byteArrayOutputStream, c cVar) throws IOException {
        s(byteArrayOutputStream, cVar);
        int i6 = cVar.f291g;
        int[] iArr = cVar.f292h;
        int length = iArr.length;
        int i7 = 0;
        int i8 = 0;
        while (i7 < length) {
            int i9 = iArr[i7];
            v(byteArrayOutputStream, i9 - i8);
            i7++;
            i8 = i9;
        }
        byte[] bArr = new byte[(((i6 * 2) + 7) & (-8)) / 8];
        for (Map.Entry entry : cVar.f293i.entrySet()) {
            int iIntValue = ((Integer) entry.getKey()).intValue();
            int iIntValue2 = ((Integer) entry.getValue()).intValue();
            if ((iIntValue2 & 2) != 0) {
                int i10 = iIntValue / 8;
                bArr[i10] = (byte) (bArr[i10] | (1 << (iIntValue % 8)));
            }
            if ((iIntValue2 & 4) != 0) {
                int i11 = iIntValue + i6;
                int i12 = i11 / 8;
                bArr[i12] = (byte) ((1 << (i11 % 8)) | bArr[i12]);
            }
        }
        byteArrayOutputStream.write(bArr);
    }

    public static void q(ByteArrayOutputStream byteArrayOutputStream, c cVar, String str) throws IOException {
        Charset charset = StandardCharsets.UTF_8;
        v(byteArrayOutputStream, str.getBytes(charset).length);
        v(byteArrayOutputStream, cVar.f289e);
        u(byteArrayOutputStream, cVar.f290f, 4);
        u(byteArrayOutputStream, cVar.f287c, 4);
        u(byteArrayOutputStream, cVar.f291g, 4);
        byteArrayOutputStream.write(str.getBytes(charset));
    }

    public static void r(ByteArrayOutputStream byteArrayOutputStream, int i6, c cVar) throws IOException {
        int i7 = cVar.f291g;
        byte[] bArr = new byte[(((Integer.bitCount(i6 & (-2)) * i7) + 7) & (-8)) / 8];
        for (Map.Entry entry : cVar.f293i.entrySet()) {
            int iIntValue = ((Integer) entry.getKey()).intValue();
            int iIntValue2 = ((Integer) entry.getValue()).intValue();
            int i8 = 0;
            for (int i9 = 1; i9 <= 4; i9 <<= 1) {
                if (i9 != 1 && (i9 & i6) != 0) {
                    if ((i9 & iIntValue2) == i9) {
                        int i10 = (i8 * i7) + iIntValue;
                        int i11 = i10 / 8;
                        bArr[i11] = (byte) ((1 << (i10 % 8)) | bArr[i11]);
                    }
                    i8++;
                }
            }
        }
        byteArrayOutputStream.write(bArr);
    }

    public static void s(ByteArrayOutputStream byteArrayOutputStream, c cVar) throws IOException {
        int i6 = 0;
        for (Map.Entry entry : cVar.f293i.entrySet()) {
            int iIntValue = ((Integer) entry.getKey()).intValue();
            if ((((Integer) entry.getValue()).intValue() & 1) != 0) {
                v(byteArrayOutputStream, iIntValue - i6);
                v(byteArrayOutputStream, 0);
                i6 = iIntValue;
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:107:0x0192 A[Catch: all -> 0x018f, TRY_ENTER, TryCatch #31 {all -> 0x018f, blocks: (B:94:0x016e, B:96:0x017a, B:107:0x0192, B:108:0x0197), top: B:283:0x016e }] */
    /* JADX WARN: Code duplicated, block: B:114:0x01a1 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:115:0x01a3 A[Catch: IllegalStateException -> 0x0189, IOException -> 0x018b, FileNotFoundException -> 0x018d, TRY_LEAVE, TryCatch #34 {FileNotFoundException -> 0x018d, IOException -> 0x018b, IllegalStateException -> 0x0189, blocks: (B:92:0x0166, B:97:0x0184, B:115:0x01a3, B:113:0x01a0, B:112:0x019d), top: B:299:0x0166 }] */
    /* JADX WARN: Code duplicated, block: B:122:0x01b9  */
    /* JADX WARN: Code duplicated, block: B:132:0x01e3 A[Catch: all -> 0x01f1, TRY_LEAVE, TryCatch #14 {all -> 0x01f1, blocks: (B:130:0x01d7, B:132:0x01e3, B:141:0x01f4), top: B:272:0x01d7 }] */
    /* JADX WARN: Code duplicated, block: B:141:0x01f4 A[Catch: all -> 0x01f1, TRY_ENTER, TRY_LEAVE, TryCatch #14 {all -> 0x01f1, blocks: (B:130:0x01d7, B:132:0x01e3, B:141:0x01f4), top: B:272:0x01d7 }] */
    /* JADX WARN: Code duplicated, block: B:152:0x0211  */
    /* JADX WARN: Code duplicated, block: B:156:0x021d  */
    /* JADX WARN: Code duplicated, block: B:157:0x0221  */
    /* JADX WARN: Code duplicated, block: B:166:0x0243 A[Catch: all -> 0x0281, TryCatch #26 {all -> 0x0281, blocks: (B:164:0x023d, B:166:0x0243, B:167:0x0247, B:169:0x024d), top: B:277:0x023d }] */
    /* JADX WARN: Code duplicated, block: B:169:0x024d A[Catch: all -> 0x0281, TRY_LEAVE, TryCatch #26 {all -> 0x0281, blocks: (B:164:0x023d, B:166:0x0243, B:167:0x0247, B:169:0x024d), top: B:277:0x023d }] */
    /* JADX WARN: Code duplicated, block: B:235:0x02d2  */
    /* JADX WARN: Code duplicated, block: B:239:0x02dc  */
    /* JADX WARN: Code duplicated, block: B:246:0x02ec  */
    /* JADX WARN: Code duplicated, block: B:269:0x0107 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:277:0x023d A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:283:0x016e A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:296:0x01d2 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:297:0x0225 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:300:0x0252 A[EDGE_INSN: B:300:0x0252->B:171:0x0252 BREAK  A[LOOP:0: B:167:0x0247->B:301:?], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:37:0x00dd  */
    /* JADX WARN: Code duplicated, block: B:55:0x0111 A[Catch: all -> 0x0126, IllegalStateException -> 0x0129, IOException -> 0x012b, TRY_LEAVE, TryCatch #11 {IOException -> 0x012b, blocks: (B:53:0x0107, B:55:0x0111, B:66:0x012d, B:67:0x0132), top: B:269:0x0107, outer: #5 }] */
    /* JADX WARN: Code duplicated, block: B:66:0x012d A[Catch: all -> 0x0126, IllegalStateException -> 0x0129, IOException -> 0x012b, TRY_ENTER, TryCatch #11 {IOException -> 0x012b, blocks: (B:53:0x0107, B:55:0x0111, B:66:0x012d, B:67:0x0132), top: B:269:0x0107, outer: #5 }] */
    /* JADX WARN: Code duplicated, block: B:96:0x017a A[Catch: all -> 0x018f, TRY_LEAVE, TryCatch #31 {all -> 0x018f, blocks: (B:94:0x016e, B:96:0x017a, B:107:0x0192, B:108:0x0197), top: B:283:0x016e }] */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r7v10 */
    /* JADX WARN: Type inference failed for: r7v11 */
    /* JADX WARN: Type inference failed for: r7v12 */
    /* JADX WARN: Type inference failed for: r7v18 */
    /* JADX WARN: Type inference failed for: r7v20 */
    /* JADX WARN: Type inference failed for: r7v21 */
    /* JADX WARN: Type inference failed for: r7v23 */
    /* JADX WARN: Type inference failed for: r7v25, types: [int] */
    /* JADX WARN: Type inference failed for: r7v26 */
    /* JADX WARN: Type inference failed for: r7v27 */
    /* JADX WARN: Type inference failed for: r7v32 */
    /* JADX WARN: Type inference failed for: r7v33 */
    /* JADX WARN: Type inference failed for: r7v39 */
    /* JADX WARN: Type inference failed for: r7v4 */
    /* JADX WARN: Type inference failed for: r7v40 */
    /* JADX WARN: Type inference failed for: r7v41 */
    /* JADX WARN: Type inference failed for: r7v42 */
    /* JADX WARN: Type inference failed for: r7v43 */
    /* JADX WARN: Type inference failed for: r7v44 */
    /* JADX WARN: Type inference failed for: r7v45 */
    /* JADX WARN: Type inference failed for: r7v46 */
    /* JADX WARN: Type inference failed for: r7v47 */
    /* JADX WARN: Type inference failed for: r7v48 */
    /* JADX WARN: Type inference failed for: r7v49 */
    /* JADX WARN: Type inference failed for: r7v5, types: [java.io.FileInputStream, java.io.InputStream] */
    /* JADX WARN: Type inference failed for: r7v50 */
    /* JADX WARN: Type inference failed for: r7v51 */
    /* JADX WARN: Type inference failed for: r7v52 */
    /* JADX WARN: Type inference failed for: r7v53 */
    /* JADX WARN: Type inference failed for: r7v54 */
    /* JADX WARN: Type inference failed for: r7v55 */
    /* JADX WARN: Type inference failed for: r7v56 */
    /* JADX WARN: Type inference failed for: r7v57 */
    /* JADX WARN: Type inference failed for: r7v6 */
    /* JADX WARN: Type inference failed for: r7v7 */
    /* JADX WARN: Type inference failed for: r7v8 */
    /* JADX WARN: Type inference failed for: r7v9 */
    /* JADX WARN: Type inference failed for: r9v16 */
    /* JADX WARN: Type inference failed for: r9v17, types: [boolean] */
    /* JADX WARN: Type inference failed for: r9v18 */
    public static void t(Context context, Executor executor, e eVar, boolean z6) {
        boolean z7;
        ?? J6;
        byte[] bArr;
        c[] cVarArrL;
        c[] cVarArr;
        e eVar2;
        c[] cVarArr2;
        byte[] bArr2;
        ?? r7;
        byte[] bArr3;
        ?? r8;
        boolean z8;
        ByteArrayInputStream byteArrayInputStream;
        Throwable th;
        FileOutputStream fileOutputStream;
        Throwable th2;
        FileChannel channel;
        FileLock fileLockTryLock;
        byte[] bArr4;
        int i6;
        ?? r9;
        boolean z9;
        boolean z10;
        ?? r10;
        ByteArrayOutputStream byteArrayOutputStream;
        b bVar;
        ?? r11;
        String str;
        FileInputStream fileInputStreamJ;
        ?? r12;
        ?? r13;
        boolean z11;
        Context applicationContext = context.getApplicationContext();
        String packageName = applicationContext.getPackageName();
        ApplicationInfo applicationInfo = applicationContext.getApplicationInfo();
        AssetManager assets = applicationContext.getAssets();
        String name = new File(applicationInfo.sourceDir).getName();
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(packageName, 0);
            File filesDir = context.getFilesDir();
            if (!z6) {
                File file = new File(filesDir, "profileinstaller_profileWrittenFor_lastUpdateTime.dat");
                if (file.exists()) {
                    try {
                        DataInputStream dataInputStream = new DataInputStream(new FileInputStream(file));
                        try {
                            long j6 = dataInputStream.readLong();
                            dataInputStream.close();
                            z11 = j6 == packageInfo.lastUpdateTime;
                            if (z11) {
                                eVar.w(2, null);
                            }
                        } catch (Throwable th3) {
                            try {
                                dataInputStream.close();
                                throw th3;
                            } catch (Throwable th4) {
                                th3.addSuppressed(th4);
                                throw th3;
                            }
                        }
                    } catch (IOException unused) {
                        z11 = false;
                    }
                } else {
                    z11 = false;
                }
                if (z11) {
                    Log.d("ProfileInstaller", "Skipping profile installation for " + context.getPackageName());
                    l.c(context, false);
                    return;
                }
            }
            Log.d("ProfileInstaller", "Installing profile for " + context.getPackageName());
            File file2 = new File(new File("/data/misc/profiles/cur/0", packageName), "primary.prof");
            b bVar2 = new b(assets, executor, eVar, name, file2);
            byte[] bArr5 = (byte[]) bVar2.f280d;
            if (bArr5 != null) {
                if (!file2.exists()) {
                    try {
                        if (file2.createNewFile()) {
                            bVar2.f277a = true;
                            J6 = bVar2.j(assets, "dexopt/baseline.prof");
                            bArr = f295b;
                            if (J6 != 0) {
                                if (Arrays.equals(bArr, f(J6, 4))) {
                                    throw new IllegalStateException("Invalid magic");
                                }
                                cVarArrL = l(J6, f(J6, 4), (String) bVar2.f283g);
                                J6.close();
                                bVar2.f284h = cVarArrL;
                            }
                            cVarArr = (c[]) bVar2.f284h;
                            if (cVarArr != null) {
                                str = "dexopt/baseline.profm";
                                fileInputStreamJ = bVar2.j(assets, "dexopt/baseline.profm");
                                r11 = str;
                                if (fileInputStreamJ == null) {
                                    if (fileInputStreamJ != null) {
                                        fileInputStreamJ.close();
                                        r11 = str;
                                    }
                                    bVar = null;
                                    J6 = r11;
                                } else {
                                    if (Arrays.equals(f296c, f(fileInputStreamJ, 4))) {
                                        throw new IllegalStateException("Invalid magic");
                                    }
                                    byte[] bArrF = f(fileInputStreamJ, 4);
                                    bVar2.f284h = i(fileInputStreamJ, bArrF, bArr5, cVarArr);
                                    fileInputStreamJ.close();
                                    bVar = bVar2;
                                    J6 = bArrF;
                                }
                                if (bVar != null) {
                                    bVar2 = bVar;
                                }
                            }
                            eVar2 = (e) bVar2.f279c;
                            cVarArr2 = (c[]) bVar2.f284h;
                            bArr2 = (byte[]) bVar2.f280d;
                            r7 = J6;
                            r7 = J6;
                            if (cVarArr2 != null) {
                                z10 = bVar2.f277a;
                                if (z10) {
                                    throw new IllegalStateException("This device doesn't support aot. Did you call deviceSupportsAotProfile()?");
                                }
                                byteArrayOutputStream = new ByteArrayOutputStream();
                                byteArrayOutputStream.write(bArr);
                                byteArrayOutputStream.write(bArr2);
                                if (o(byteArrayOutputStream, bArr2, cVarArr2)) {
                                    bVar2.f281e = byteArrayOutputStream.toByteArray();
                                    byteArrayOutputStream.close();
                                    r10 = byteArrayOutputStream;
                                    bVar2.f284h = null;
                                    r7 = r10;
                                } else {
                                    eVar2.w(5, null);
                                    bVar2.f284h = null;
                                    byteArrayOutputStream.close();
                                    r7 = byteArrayOutputStream;
                                }
                            }
                            bArr3 = (byte[]) bVar2.f281e;
                            if (bArr3 != null) {
                                if (bVar2.f277a) {
                                    throw new IllegalStateException("This device doesn't support aot. Did you call deviceSupportsAotProfile()?");
                                }
                                byteArrayInputStream = new ByteArrayInputStream(bArr3);
                                fileOutputStream = new FileOutputStream((File) bVar2.f282f);
                                channel = fileOutputStream.getChannel();
                                fileLockTryLock = channel.tryLock();
                                if (fileLockTryLock != null) {
                                    if (fileLockTryLock.isValid()) {
                                        bArr4 = new byte[512];
                                        while (true) {
                                            i6 = byteArrayInputStream.read(bArr4);
                                            if (i6 > 0) {
                                                break;
                                                break;
                                            }
                                            fileOutputStream.write(bArr4, 0, i6);
                                        }
                                        r9 = 1;
                                        bVar2.l(1, null);
                                        fileLockTryLock.close();
                                        channel.close();
                                        fileOutputStream.close();
                                        byteArrayInputStream.close();
                                        bVar2.f281e = null;
                                        bVar2.f284h = null;
                                        z8 = true;
                                    }
                                }
                                throw new IOException("Unable to acquire a lock on the underlying file channel.");
                            }
                            z8 = false;
                            r9 = 1;
                            if (z8) {
                                e(packageInfo, filesDir);
                            }
                            z9 = z8;
                            r12 = r9;
                        } else {
                            bVar2.l(4, null);
                        }
                    } catch (IOException unused2) {
                        z7 = true;
                        bVar2.l(4, null);
                    }
                } else if (file2.canWrite()) {
                    bVar2.f277a = true;
                    try {
                        J6 = bVar2.j(assets, "dexopt/baseline.prof");
                    } catch (FileNotFoundException e6) {
                        eVar.w(6, e6);
                        J6 = 0;
                    } catch (IOException e7) {
                        eVar.w(7, e7);
                        J6 = 0;
                    }
                    bArr = f295b;
                    try {
                        if (J6 != 0) {
                            try {
                                try {
                                    if (Arrays.equals(bArr, f(J6, 4))) {
                                        throw new IllegalStateException("Invalid magic");
                                    }
                                    cVarArrL = l(J6, f(J6, 4), (String) bVar2.f283g);
                                    try {
                                        J6.close();
                                    } catch (IOException e8) {
                                        eVar.w(7, e8);
                                    }
                                    bVar2.f284h = cVarArrL;
                                } catch (IllegalStateException e9) {
                                    eVar.w(8, e9);
                                    try {
                                        J6.close();
                                    } catch (IOException e10) {
                                        eVar.w(7, e10);
                                    }
                                    cVarArrL = null;
                                }
                            } catch (IOException e11) {
                                eVar.w(7, e11);
                                J6.close();
                                cVarArrL = null;
                            }
                        }
                        cVarArr = (c[]) bVar2.f284h;
                        if (cVarArr != null && ((J6 = Build.VERSION.SDK_INT) >= 31 || J6 == 24 || J6 == 25)) {
                            try {
                                str = "dexopt/baseline.profm";
                                fileInputStreamJ = bVar2.j(assets, "dexopt/baseline.profm");
                                r11 = str;
                                if (fileInputStreamJ == null) {
                                    try {
                                        if (Arrays.equals(f296c, f(fileInputStreamJ, 4))) {
                                            throw new IllegalStateException("Invalid magic");
                                        }
                                        byte[] bArrF2 = f(fileInputStreamJ, 4);
                                        bVar2.f284h = i(fileInputStreamJ, bArrF2, bArr5, cVarArr);
                                        fileInputStreamJ.close();
                                        bVar = bVar2;
                                        J6 = bArrF2;
                                    } catch (Throwable th5) {
                                        try {
                                            fileInputStreamJ.close();
                                            throw th5;
                                        } catch (Throwable th6) {
                                            th5.addSuppressed(th6);
                                            throw th5;
                                        }
                                    }
                                } else {
                                    if (fileInputStreamJ != null) {
                                        fileInputStreamJ.close();
                                        r11 = str;
                                    }
                                    bVar = null;
                                    J6 = r11;
                                }
                            } catch (FileNotFoundException e12) {
                                eVar.w(9, e12);
                                r11 = J6;
                            } catch (IOException e13) {
                                eVar.w(7, e13);
                                r11 = J6;
                            } catch (IllegalStateException e14) {
                                bVar2.f284h = null;
                                eVar.w(8, e14);
                                r11 = J6;
                            }
                            if (bVar != null) {
                                bVar2 = bVar;
                            }
                        }
                        eVar2 = (e) bVar2.f279c;
                        cVarArr2 = (c[]) bVar2.f284h;
                        bArr2 = (byte[]) bVar2.f280d;
                        r7 = J6;
                        r7 = J6;
                        if (cVarArr2 != null && bArr2 != null) {
                            z10 = bVar2.f277a;
                            if (z10) {
                                throw new IllegalStateException("This device doesn't support aot. Did you call deviceSupportsAotProfile()?");
                            }
                            try {
                                byteArrayOutputStream = new ByteArrayOutputStream();
                                try {
                                    byteArrayOutputStream.write(bArr);
                                    byteArrayOutputStream.write(bArr2);
                                    if (o(byteArrayOutputStream, bArr2, cVarArr2)) {
                                        eVar2.w(5, null);
                                        bVar2.f284h = null;
                                        byteArrayOutputStream.close();
                                        r7 = byteArrayOutputStream;
                                    } else {
                                        bVar2.f281e = byteArrayOutputStream.toByteArray();
                                        byteArrayOutputStream.close();
                                        r10 = byteArrayOutputStream;
                                        bVar2.f284h = null;
                                        r7 = r10;
                                    }
                                } catch (Throwable th7) {
                                    try {
                                        byteArrayOutputStream.close();
                                        throw th7;
                                    } catch (Throwable th8) {
                                        th7.addSuppressed(th8);
                                        throw th7;
                                    }
                                }
                            } catch (IOException e15) {
                                eVar2.w(7, e15);
                                r10 = z10;
                            } catch (IllegalStateException e16) {
                                eVar2.w(8, e16);
                                r10 = z10;
                            }
                        }
                        bArr3 = (byte[]) bVar2.f281e;
                        if (bArr3 != null) {
                            z8 = false;
                            r9 = 1;
                        } else {
                            try {
                                if (bVar2.f277a) {
                                    throw new IllegalStateException("This device doesn't support aot. Did you call deviceSupportsAotProfile()?");
                                }
                                try {
                                    try {
                                        byteArrayInputStream = new ByteArrayInputStream(bArr3);
                                        try {
                                            try {
                                                fileOutputStream = new FileOutputStream((File) bVar2.f282f);
                                                try {
                                                    try {
                                                        channel = fileOutputStream.getChannel();
                                                        try {
                                                            fileLockTryLock = channel.tryLock();
                                                            try {
                                                                try {
                                                                    if (fileLockTryLock != null) {
                                                                        try {
                                                                            if (fileLockTryLock.isValid()) {
                                                                                bArr4 = new byte[512];
                                                                                while (true) {
                                                                                    i6 = byteArrayInputStream.read(bArr4);
                                                                                    if (i6 > 0) {
                                                                                        break;
                                                                                    } else {
                                                                                        fileOutputStream.write(bArr4, 0, i6);
                                                                                    }
                                                                                }
                                                                                r9 = 1;
                                                                                bVar2.l(1, null);
                                                                                fileLockTryLock.close();
                                                                                channel.close();
                                                                                fileOutputStream.close();
                                                                                byteArrayInputStream.close();
                                                                                bVar2.f281e = null;
                                                                                bVar2.f284h = null;
                                                                                z8 = true;
                                                                            }
                                                                        } catch (Throwable th9) {
                                                                            th = th9;
                                                                            Throwable th10 = th;
                                                                            if (fileLockTryLock == null) {
                                                                                throw th10;
                                                                            }
                                                                            try {
                                                                                fileLockTryLock.close();
                                                                                throw th10;
                                                                            } catch (Throwable th11) {
                                                                                th10.addSuppressed(th11);
                                                                                throw th10;
                                                                            }
                                                                        }
                                                                    }
                                                                    throw new IOException("Unable to acquire a lock on the underlying file channel.");
                                                                } catch (Throwable th12) {
                                                                    th = th12;
                                                                }
                                                            } catch (Throwable th13) {
                                                                th = th13;
                                                                Throwable th14 = th;
                                                                if (channel == null) {
                                                                    throw th14;
                                                                }
                                                                try {
                                                                    channel.close();
                                                                    throw th14;
                                                                } catch (Throwable th15) {
                                                                    th14.addSuppressed(th15);
                                                                    throw th14;
                                                                }
                                                            }
                                                        } catch (Throwable th16) {
                                                            th = th16;
                                                        }
                                                    } catch (Throwable th17) {
                                                        th = th17;
                                                        th2 = th;
                                                        try {
                                                            fileOutputStream.close();
                                                            throw th2;
                                                        } catch (Throwable th18) {
                                                            th2.addSuppressed(th18);
                                                            throw th2;
                                                        }
                                                    }
                                                } catch (Throwable th19) {
                                                    th = th19;
                                                    th2 = th;
                                                    fileOutputStream.close();
                                                    throw th2;
                                                }
                                            } catch (Throwable th20) {
                                                th = th20;
                                                th = th;
                                                try {
                                                    byteArrayInputStream.close();
                                                    throw th;
                                                } catch (Throwable th21) {
                                                    th.addSuppressed(th21);
                                                    throw th;
                                                }
                                            }
                                        } catch (Throwable th22) {
                                            th = th22;
                                            th = th;
                                            byteArrayInputStream.close();
                                            throw th;
                                        }
                                    } catch (FileNotFoundException e17) {
                                        e = e17;
                                        r7 = 1;
                                        bVar2.l(6, e);
                                        r8 = r7;
                                        bVar2.f281e = null;
                                        bVar2.f284h = null;
                                        z8 = false;
                                        r9 = r8;
                                    } catch (IOException e18) {
                                        e = e18;
                                        r7 = 1;
                                        bVar2.l(7, e);
                                        r8 = r7;
                                        bVar2.f281e = null;
                                        bVar2.f284h = null;
                                        z8 = false;
                                        r9 = r8;
                                    }
                                } catch (FileNotFoundException e19) {
                                    e = e19;
                                    bVar2.l(6, e);
                                    r8 = r7;
                                    bVar2.f281e = null;
                                    bVar2.f284h = null;
                                    z8 = false;
                                    r9 = r8;
                                } catch (IOException e20) {
                                    e = e20;
                                    bVar2.l(7, e);
                                    r8 = r7;
                                    bVar2.f281e = null;
                                    bVar2.f284h = null;
                                    z8 = false;
                                    r9 = r8;
                                }
                            } catch (Throwable th23) {
                                bVar2.f281e = null;
                                bVar2.f284h = null;
                                throw th23;
                            }
                        }
                        if (z8) {
                            e(packageInfo, filesDir);
                        }
                        z9 = z8;
                        r12 = r9;
                    } catch (Throwable th24) {
                        try {
                            J6.close();
                            throw th24;
                        } catch (IOException e21) {
                            eVar.w(7, e21);
                            throw th24;
                        }
                    }
                } else {
                    bVar2.l(4, null);
                }
                if (z9 || !z6) {
                    r13 = 0;
                } else {
                    r13 = r12;
                }
                l.c(context, r13);
            }
            bVar2.l(3, Integer.valueOf(Build.VERSION.SDK_INT));
            z7 = true;
            z9 = false;
            r12 = z7;
            if (z9) {
                r13 = 0;
            } else {
                r13 = 0;
            }
            l.c(context, r13);
        } catch (PackageManager.NameNotFoundException e22) {
            eVar.w(7, e22);
            l.c(context, false);
        }
    }

    public static void u(ByteArrayOutputStream byteArrayOutputStream, long j6, int i6) throws IOException {
        byte[] bArr = new byte[i6];
        for (int i7 = 0; i7 < i6; i7++) {
            bArr[i7] = (byte) ((j6 >> (i7 * 8)) & 255);
        }
        byteArrayOutputStream.write(bArr);
    }

    public static void v(ByteArrayOutputStream byteArrayOutputStream, int i6) throws IOException {
        u(byteArrayOutputStream, i6, 2);
    }
}
