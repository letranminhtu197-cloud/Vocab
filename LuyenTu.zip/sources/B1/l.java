package B1;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.os.Build;
import java.io.File;
import java.io.IOException;

/* JADX INFO: loaded from: classes.dex */
public abstract class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final p121u.m f309a = new p121u.m();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Object f310b = new Object();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static Z3.e f311c = null;

    public static long a(Context context) {
        PackageManager packageManager = context.getApplicationContext().getPackageManager();
        return Build.VERSION.SDK_INT >= 33 ? j.a(packageManager, context).lastUpdateTime : packageManager.getPackageInfo(context.getPackageName(), 0).lastUpdateTime;
    }

    public static Z3.e b() {
        Z3.e eVar = new Z3.e(5);
        f311c = eVar;
        f309a.k(eVar);
        return f311c;
    }

    /* JADX WARN: Code duplicated, block: B:101:0x00f4 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:109:0x00a8 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:20:0x002c  */
    /* JADX WARN: Code duplicated, block: B:21:0x002e  */
    /* JADX WARN: Code duplicated, block: B:43:0x006f  */
    /* JADX WARN: Code duplicated, block: B:49:0x0092  */
    /* JADX WARN: Code duplicated, block: B:58:0x00b2  */
    /* JADX WARN: Code duplicated, block: B:67:0x00c3 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:68:0x00c5  */
    /* JADX WARN: Code duplicated, block: B:69:0x00c8 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:70:0x00ca  */
    /* JADX WARN: Code duplicated, block: B:71:0x00cc A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:72:0x00ce  */
    public static void c(Context context, boolean z6) {
        int i6;
        boolean z7;
        int i7;
        File file;
        boolean z8;
        File file2;
        long length;
        boolean z9;
        File file3;
        k kVarA;
        k kVar;
        int i8;
        AssetFileDescriptor assetFileDescriptorOpenFd;
        if (z6 || f311c == null) {
            synchronized (f310b) {
                if (z6) {
                    i6 = 0;
                    assetFileDescriptorOpenFd = context.getAssets().openFd("dexopt/baseline.prof");
                    if (assetFileDescriptorOpenFd.getLength() > 0) {
                        z7 = true;
                    } else {
                        z7 = false;
                    }
                    assetFileDescriptorOpenFd.close();
                    i7 = Build.VERSION.SDK_INT;
                    if (i7 >= 28) {
                        file = new File(new File("/data/misc/profiles/ref/", context.getPackageName()), "primary.prof");
                        long length2 = file.length();
                        if (file.exists()) {
                            z8 = false;
                        } else {
                            z8 = false;
                        }
                        file2 = new File(new File("/data/misc/profiles/cur/0/", context.getPackageName()), "primary.prof");
                        length = file2.length();
                        if (file2.exists()) {
                            z9 = false;
                        } else {
                            z9 = false;
                        }
                        long jA = a(context);
                        file3 = new File(context.getFilesDir(), "profileInstalled");
                        if (file3.exists()) {
                            kVarA = k.a(file3);
                        } else {
                            kVarA = null;
                        }
                        if (kVarA == null) {
                            if (!z7) {
                                i6 = 327680;
                            } else if (z8) {
                                i6 = 1;
                            } else if (z9) {
                                i6 = 2;
                            }
                        } else if (!z7) {
                            i6 = 327680;
                        } else if (z8) {
                            i6 = 1;
                        } else if (z9) {
                            i6 = 2;
                        }
                        if (z6) {
                            i6 = 2;
                        }
                        if (kVarA != null) {
                            i6 = 3;
                        }
                        kVar = new k(1, i6, jA, length);
                        if (kVarA != null) {
                            kVar.b(file3);
                        } else {
                            kVar.b(file3);
                        }
                        b();
                        return;
                    }
                    b();
                    return;
                }
                if (f311c != null) {
                    return;
                }
                i6 = 0;
                try {
                    assetFileDescriptorOpenFd = context.getAssets().openFd("dexopt/baseline.prof");
                    try {
                        if (assetFileDescriptorOpenFd.getLength() > 0) {
                            z7 = true;
                        } else {
                            z7 = false;
                        }
                        assetFileDescriptorOpenFd.close();
                        i7 = Build.VERSION.SDK_INT;
                        if (i7 >= 28 && i7 != 30) {
                            file = new File(new File("/data/misc/profiles/ref/", context.getPackageName()), "primary.prof");
                            long length3 = file.length();
                            if (file.exists() || length3 <= 0) {
                                z8 = false;
                            } else {
                                z8 = true;
                            }
                            file2 = new File(new File("/data/misc/profiles/cur/0/", context.getPackageName()), "primary.prof");
                            length = file2.length();
                            if (file2.exists() || length <= 0) {
                                z9 = false;
                            } else {
                                z9 = true;
                            }
                            try {
                                long jA2 = a(context);
                                file3 = new File(context.getFilesDir(), "profileInstalled");
                                if (file3.exists()) {
                                    try {
                                        kVarA = k.a(file3);
                                    } catch (IOException unused) {
                                        b();
                                        return;
                                    }
                                } else {
                                    kVarA = null;
                                }
                                if (kVarA == null && kVarA.f307c == jA2 && (i8 = kVarA.f306b) != 2) {
                                    i6 = i8;
                                } else if (!z7) {
                                    i6 = 327680;
                                } else if (z8) {
                                    i6 = 1;
                                } else if (z9) {
                                    i6 = 2;
                                }
                                if (z6 && z9 && i6 != 1) {
                                    i6 = 2;
                                }
                                if (kVarA != null && kVarA.f306b == 2 && i6 == 1 && length3 < kVarA.f308d) {
                                    i6 = 3;
                                }
                                kVar = new k(1, i6, jA2, length);
                                if (kVarA != null || !kVarA.equals(kVar)) {
                                    try {
                                        kVar.b(file3);
                                    } catch (IOException unused2) {
                                    }
                                }
                                b();
                                return;
                            } catch (PackageManager.NameNotFoundException unused3) {
                                b();
                                return;
                            }
                        }
                        b();
                        return;
                    } catch (Throwable th) {
                        if (assetFileDescriptorOpenFd == null) {
                            throw th;
                        }
                        try {
                            assetFileDescriptorOpenFd.close();
                            throw th;
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                            throw th;
                        }
                    }
                } catch (IOException unused4) {
                    z7 = false;
                }
                throw th;
            }
        }
    }
}
