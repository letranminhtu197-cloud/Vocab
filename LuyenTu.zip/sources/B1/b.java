package B1;

import L4.AbstractActivityC0123b;
import L4.C0127f;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Build;
import android.os.Trace;
import android.util.Log;
import android.view.Surface;
import androidx.lifecycle.C0198u;
import com.google.crypto.tink.shaded.protobuf.T;
import io.flutter.embedding.engine.plugins.lifecycle.HiddenLifecycleReference;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import org.apache.tika.utils.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import p068l.v0;

/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f277a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f278b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f279c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Object f280d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f281e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final Object f282f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Object f283g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public Object f284h;

    public b(HttpURLConnection httpURLConnection, p080m4.h hVar, p080m4.d dVar, LinkedHashSet linkedHashSet, p080m4.k kVar, ScheduledExecutorService scheduledExecutorService) {
        this.f279c = httpURLConnection;
        this.f280d = hVar;
        this.f281e = dVar;
        this.f278b = linkedHashSet;
        this.f282f = kVar;
        this.f283g = scheduledExecutorService;
        this.f284h = new Random();
        this.f277a = false;
    }

    public void a(S4.b bVar) {
        HashMap map = (HashMap) this.f278b;
        p061j5.a.d("FlutterEngineConnectionRegistry#add ".concat(bVar.getClass().getSimpleName()));
        try {
            if (map.containsKey(bVar.getClass())) {
                Log.w("FlutterEngineCxnRegstry", "Attempted to register plugin (" + bVar + ") but it was already registered with this FlutterEngine (" + ((M4.b) this.f279c) + ").");
                Trace.endSection();
                return;
            }
            bVar.toString();
            map.put(bVar.getClass(), bVar);
            bVar.onAttachedToEngine((S4.a) this.f281e);
            if (bVar instanceof T4.a) {
                T4.a aVar = (T4.a) bVar;
                ((HashMap) this.f282f).put(bVar.getClass(), aVar);
                if (h()) {
                    aVar.onAttachedToActivity((v0) this.f284h);
                }
            }
            Trace.endSection();
        } catch (Throwable th) {
            try {
                Trace.endSection();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    public void b(AbstractActivityC0123b abstractActivityC0123b, C0198u c0198u) {
        v0 v0Var = new v0();
        v0Var.t = new HashSet();
        v0Var.f7491u = new HashSet();
        v0Var.f7492v = new HashSet();
        v0Var.f7493w = new HashSet();
        new HashSet();
        v0Var.f7494x = new HashSet();
        v0Var.r = abstractActivityC0123b;
        v0Var.f7490s = new HiddenLifecycleReference(c0198u);
        this.f284h = v0Var;
        Intent intent = abstractActivityC0123b.getIntent();
        if (intent != null ? intent.getBooleanExtra("enable-software-rendering", false) : false) {
            String str = M4.e.f2494h.f2485b;
        } else {
            boolean z6 = ((Q4.d) this.f280d).f3247a;
        }
        M4.b bVar = (M4.b) this.f279c;
        bVar.f2477s.getClass();
        V4.d dVar = bVar.f2478u;
        io.flutter.embedding.engine.renderer.h hVar = bVar.f2462b;
        N4.b bVar2 = bVar.f2463c;
        io.flutter.plugin.platform.k kVar = (io.flutter.plugin.platform.k) dVar.f3633s;
        if (kVar.f6514s != null) {
            throw new AssertionError("A PlatformViewsController can only be attached to a single output target.\nattach was called while the PlatformViewsController was already attached.");
        }
        kVar.f6514s = abstractActivityC0123b;
        kVar.f6516v = hVar;
        kVar.f6518x = new p066k4.c(bVar2, 17);
        io.flutter.plugin.platform.j jVar = (io.flutter.plugin.platform.j) dVar.t;
        if (jVar.f6497s != null) {
            throw new AssertionError("A PlatformViewsController can only be attached to a single output target.\nattach was called while the PlatformViewsController was already attached.");
        }
        jVar.f6497s = abstractActivityC0123b;
        A0.i iVar = new A0.i(bVar2, 17);
        jVar.f6499v = iVar;
        iVar.f64s = jVar.f6496E;
        kVar.f6518x.f7289s = dVar;
        for (T4.a aVar : ((HashMap) this.f282f).values()) {
            if (this.f277a) {
                aVar.onReattachedToActivityForConfigChanges((v0) this.f284h);
            } else {
                aVar.onAttachedToActivity((v0) this.f284h);
            }
        }
        this.f277a = false;
    }

    public void c(long j6, int i6) {
        if (i6 == 0) {
            k(new p073l4.i("Unable to fetch the latest version of the template."));
        } else {
            ((ScheduledExecutorService) this.f283g).schedule(new p080m4.b(this, i6, j6), ((Random) this.f284h).nextInt(4), TimeUnit.SECONDS);
        }
    }

    public void d() {
        if (!h()) {
            Log.e("FlutterEngineCxnRegstry", "Attempted to detach plugins from an Activity when no Activity was attached.");
            return;
        }
        p061j5.a.d("FlutterEngineConnectionRegistry#detachFromActivity");
        try {
            Iterator it = ((HashMap) this.f282f).values().iterator();
            while (it.hasNext()) {
                ((T4.a) it.next()).onDetachedFromActivity();
            }
            e();
            Trace.endSection();
        } catch (Throwable th) {
            try {
                Trace.endSection();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    public void e() {
        M4.b bVar = (M4.b) this.f279c;
        io.flutter.plugin.platform.k kVar = bVar.f2477s;
        p066k4.c cVar = kVar.f6518x;
        if (cVar != null) {
            cVar.f7289s = null;
        }
        kVar.c();
        kVar.f6518x = null;
        kVar.f6514s = null;
        kVar.f6516v = null;
        io.flutter.plugin.platform.j jVar = bVar.t;
        A0.i iVar = jVar.f6499v;
        if (iVar != null) {
            iVar.f64s = null;
        }
        Surface surface = jVar.f6494B;
        if (surface != null) {
            surface.release();
            jVar.f6494B = null;
            jVar.C = null;
        }
        jVar.f6499v = null;
        jVar.f6497s = null;
        this.f283g = null;
        this.f284h = null;
    }

    public void f() {
        if (h()) {
            d();
        }
    }

    public void g(InputStream inputStream) throws IOException {
        boolean zIsEmpty;
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "utf-8"));
        String strI = StringUtils.EMPTY;
        while (true) {
            String line = bufferedReader.readLine();
            if (line == null) {
                break;
            }
            strI = T.i(strI, line);
            if (line.contains("}")) {
                int iIndexOf = strI.indexOf(123);
                int iLastIndexOf = strI.lastIndexOf(125);
                strI = (iIndexOf < 0 || iLastIndexOf < 0 || iIndexOf >= iLastIndexOf) ? StringUtils.EMPTY : strI.substring(iIndexOf, iLastIndexOf + 1);
                if (strI.isEmpty()) {
                    continue;
                } else {
                    try {
                        JSONObject jSONObject = new JSONObject(strI);
                        if (jSONObject.has("featureDisabled") && jSONObject.getBoolean("featureDisabled")) {
                            ((p080m4.k) this.f282f).b(new p073l4.i("The server is temporarily unavailable. Try again in a few minutes."));
                            break;
                        }
                        synchronized (this) {
                            zIsEmpty = ((LinkedHashSet) this.f278b).isEmpty();
                        }
                        if (zIsEmpty) {
                            break;
                        }
                        if (jSONObject.has("latestTemplateVersionNumber")) {
                            long j6 = ((p080m4.h) this.f280d).f7871g.f7902a.getLong("last_template_version", 0L);
                            long j7 = jSONObject.getLong("latestTemplateVersionNumber");
                            if (j7 > j6) {
                                c(j7, 3);
                            }
                        }
                        strI = StringUtils.EMPTY;
                    } catch (JSONException e6) {
                        k(new p073l4.f("Unable to parse config update message.", e6.getCause()));
                        Log.e("FirebaseRemoteConfig", "Unable to parse latest config update message.", e6);
                    }
                }
            }
        }
        bufferedReader.close();
    }

    public boolean h() {
        return ((C0127f) this.f283g) != null;
    }

    public void i() {
        HttpURLConnection httpURLConnection = (HttpURLConnection) this.f279c;
        if (httpURLConnection == null) {
            return;
        }
        InputStream inputStream = null;
        try {
            try {
                try {
                    inputStream = httpURLConnection.getInputStream();
                    g(inputStream);
                    if (inputStream != null) {
                        inputStream.close();
                    }
                } catch (Throwable th) {
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e6) {
                            Log.d("FirebaseRemoteConfig", "Exception thrown when closing connection stream. Retrying connection...", e6);
                        }
                    }
                    throw th;
                }
            } catch (IOException e7) {
                if (!this.f277a) {
                    Log.d("FirebaseRemoteConfig", "Real-time connection was closed due to an exception.", e7);
                }
                if (inputStream != null) {
                    inputStream.close();
                }
            }
        } catch (IOException e8) {
            Log.d("FirebaseRemoteConfig", "Exception thrown when closing connection stream. Retrying connection...", e8);
        }
    }

    public FileInputStream j(AssetManager assetManager, String str) {
        try {
            return assetManager.openFd(str).createInputStream();
        } catch (FileNotFoundException e6) {
            String message = e6.getMessage();
            if (message == null || !message.contains("compressed")) {
                return null;
            }
            ((e) this.f279c).v();
            return null;
        }
    }

    public synchronized void k(p073l4.g gVar) {
        Iterator it = ((LinkedHashSet) this.f278b).iterator();
        while (it.hasNext()) {
            ((p073l4.b) it.next()).b(gVar);
        }
    }

    public void l(int i6, Serializable serializable) {
        ((Executor) this.f278b).execute(new a(i6, 0, this, serializable));
    }

    public b(AssetManager assetManager, Executor executor, e eVar, String str, File file) {
        byte[] bArr;
        this.f277a = false;
        this.f278b = executor;
        this.f279c = eVar;
        this.f283g = str;
        this.f282f = file;
        int i6 = Build.VERSION.SDK_INT;
        if (i6 >= 31) {
            bArr = f.f297d;
        } else {
            switch (i6) {
                case 24:
                case 25:
                    bArr = f.f301h;
                    break;
                case 26:
                    bArr = f.f300g;
                    break;
                case 27:
                    bArr = f.f299f;
                    break;
                case 28:
                case 29:
                case 30:
                    bArr = f.f298e;
                    break;
                default:
                    bArr = null;
                    break;
            }
        }
        this.f280d = bArr;
    }

    public b(Context context, M4.b bVar, Q4.d dVar) {
        this.f278b = new HashMap();
        this.f282f = new HashMap();
        this.f277a = false;
        new HashMap();
        new HashMap();
        new HashMap();
        this.f279c = bVar;
        this.f280d = dVar;
        N4.b bVar2 = bVar.f2463c;
        A0.i iVar = bVar.f2477s.r;
        this.f281e = new S4.a(context, bVar, bVar2);
    }
}
