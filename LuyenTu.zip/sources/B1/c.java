package B1;

import java.util.TreeMap;

/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f285a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f286b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f287c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f288d = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f289e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f290f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f291g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int[] f292h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final TreeMap f293i;

    public c(String str, String str2, long j6, int i6, int i7, int i8, int[] iArr, TreeMap treeMap) {
        this.f285a = str;
        this.f286b = str2;
        this.f287c = j6;
        this.f289e = i6;
        this.f290f = i7;
        this.f291g = i8;
        this.f292h = iArr;
        this.f293i = treeMap;
    }
}
