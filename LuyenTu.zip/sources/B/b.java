package B;

import android.app.Notification;
import android.app.Person;
import android.app.job.JobParameters;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.graphics.drawable.Icon;
import android.icu.text.DecimalFormatSymbols;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.PrecomputedText;
import android.view.DisplayCutout;
import android.view.ViewConfiguration;
import android.widget.TextView;
import androidx.core.graphics.drawable.IconCompat;
import java.util.concurrent.Executor;
import p068l.C0407u;
import w.E;

/* JADX INFO: loaded from: classes.dex */
public abstract class b {
    public static void a(Notification.Builder builder, Person person) {
        builder.addPerson(person);
    }

    public static Handler b(Looper looper) {
        return Handler.createAsync(looper);
    }

    public static Handler c(Looper looper) {
        return Handler.createAsync(looper);
    }

    public static E d(Person person) {
        CharSequence name = person.getName();
        IconCompat iconCompatD = person.getIcon() != null ? IconCompat.d(person.getIcon()) : null;
        String uri = person.getUri();
        String key = person.getKey();
        boolean zIsBot = person.isBot();
        boolean zIsImportant = person.isImportant();
        E e6 = new E();
        e6.f9450a = name;
        e6.f9451b = iconCompatD;
        e6.f9452c = uri;
        e6.f9453d = key;
        e6.f9454e = zIsBot;
        e6.f9455f = zIsImportant;
        return e6;
    }

    public static String[] e(DecimalFormatSymbols decimalFormatSymbols) {
        return decimalFormatSymbols.getDigitStrings();
    }

    public static long f(PackageInfo packageInfo) {
        return packageInfo.getLongVersionCode();
    }

    public static Executor g(Context context) {
        return context.getMainExecutor();
    }

    public static void h(JobParameters jobParameters) {
        jobParameters.getNetwork();
    }

    public static int i(Object obj) {
        return ((Icon) obj).getResId();
    }

    public static String j(Object obj) {
        return ((Icon) obj).getResPackage();
    }

    public static int k(DisplayCutout displayCutout) {
        return displayCutout.getSafeInsetBottom();
    }

    public static int l(DisplayCutout displayCutout) {
        return displayCutout.getSafeInsetLeft();
    }

    public static int m(DisplayCutout displayCutout) {
        return displayCutout.getSafeInsetRight();
    }

    public static int n(DisplayCutout displayCutout) {
        return displayCutout.getSafeInsetTop();
    }

    public static int o(ViewConfiguration viewConfiguration) {
        return viewConfiguration.getScaledHoverSlop();
    }

    public static PrecomputedText.Params p(C0407u c0407u) {
        return c0407u.getTextMetricsParams();
    }

    public static int q(Object obj) {
        return ((Icon) obj).getType();
    }

    public static Uri r(Object obj) {
        return ((Icon) obj).getUri();
    }

    public static void s(TextView textView, int i6) {
        textView.setFirstBaselineToTopHeight(i6);
    }

    public static void t(Notification.Action.Builder builder) {
        builder.setSemanticAction(0);
    }

    public static boolean u(ViewConfiguration viewConfiguration) {
        return viewConfiguration.shouldShowMenuShortcutsWhenKeyboardPresent();
    }

    public static Person v(E e6) {
        Person.Builder name = new Person.Builder().setName(e6.f9450a);
        IconCompat iconCompat = e6.f9451b;
        return name.setIcon(iconCompat != null ? iconCompat.j(null) : null).setUri(e6.f9452c).setKey(e6.f9453d).setBot(e6.f9454e).setImportant(e6.f9455f).build();
    }
}
