package A0;

import J0.U;
import J0.X;
import R0.F;
import R0.G;
import android.os.Handler;
import p101q0.B;
import p101q0.C0427o;
import p101q0.D;
import p101q0.InterfaceC0421i;

/* JADX INFO: loaded from: classes.dex */
public final class t implements G {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final X f125a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final p086n4.a f126b = new p086n4.a(13, false);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final p001a1.a f127c = new p001a1.a(1);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f128d = -9223372036854775807L;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ u f129e;

    public t(u uVar, N0.e eVar) {
        this.f129e = uVar;
        this.f125a = new X(eVar, null, null);
    }

    @Override // R0.G
    public final int a(InterfaceC0421i interfaceC0421i, int i6, boolean z6) {
        return this.f125a.a(interfaceC0421i, i6, z6);
    }

    @Override // R0.G
    public final void b(p117t0.l lVar, int i6, int i7) {
        this.f125a.b(lVar, i6, 0);
    }

    @Override // R0.G
    public final void c(long j6, int i6, int i7, int i8, F f4) {
        long jE;
        long jK;
        this.f125a.c(j6, i6, i7, i8, f4);
        while (this.f125a.q(false)) {
            p001a1.a aVar = this.f127c;
            aVar.i();
            if (this.f125a.v(this.f126b, aVar, 0, false) == -4) {
                aVar.l();
            } else {
                aVar = null;
            }
            if (aVar != null) {
                long j7 = aVar.f9572x;
                B bR = this.f129e.t.r(aVar);
                if (bR != null) {
                    p012c1.a aVar2 = (p012c1.a) bR.r[0];
                    String str = aVar2.r;
                    String str2 = aVar2.f4603s;
                    if ("urn:mpeg:dash:event:2012".equals(str) && ("1".equals(str2) || "2".equals(str2) || "3".equals(str2))) {
                        try {
                            jK = p117t0.s.K(p117t0.s.n(aVar2.f4605v));
                        } catch (D unused) {
                            jK = -9223372036854775807L;
                        }
                        if (jK != -9223372036854775807L) {
                            s sVar = new s(j7, jK);
                            Handler handler = this.f129e.f131u;
                            handler.sendMessage(handler.obtainMessage(1, sVar));
                        }
                    }
                }
            }
        }
        X x5 = this.f125a;
        U u6 = x5.f1757a;
        synchronized (x5) {
            int i9 = x5.f1773s;
            jE = i9 == 0 ? -1L : x5.e(i9);
        }
        u6.b(jE);
    }

    @Override // R0.G
    public final void d(C0427o c0427o) {
        this.f125a.d(c0427o);
    }
}
