package A0;

/* JADX INFO: loaded from: classes.dex */
public final class s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f123a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f124b;

    public s(long j6, long j7) {
        this.f123a = j6;
        this.f124b = j7;
    }
}
