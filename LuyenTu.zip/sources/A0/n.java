package A0;

import R0.C0141g;
import R0.InterfaceC0142h;
import android.app.Activity;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import com.google.android.gms.internal.play_billing.AbstractC0252u0;
import com.google.crypto.tink.shaded.protobuf.T;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.fork.ForkServer;
import org.apache.tika.pipes.PipesConfigBase;
import org.apache.tika.utils.StringUtils;
import p101q0.C0427o;
import p101q0.G;
import p108r3.AbstractC0460q;
import p108r3.AbstractC0465w;
import p108r3.D;
import p108r3.F;
import p108r3.Y;

/* JADX INFO: loaded from: classes.dex */
public final class n implements F4.h, InterfaceC0142h {
    public int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public Object f96s;
    public Object t;

    public n(String str, String... strArr) {
        String string;
        if (strArr.length == 0) {
            string = StringUtils.EMPTY;
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append('[');
            for (String str2 : strArr) {
                if (sb.length() > 1) {
                    sb.append(",");
                }
                sb.append(str2);
            }
            sb.append("] ");
            string = sb.toString();
        }
        this.t = string;
        this.f96s = str;
        int length = str.length();
        Object[] objArr = {str, 23};
        if (!(length <= 23)) {
            throw new IllegalArgumentException(String.format("tag \"%s\" is longer than the %d character maximum", objArr));
        }
        int i6 = 2;
        while (i6 <= 7 && !Log.isLoggable((String) this.f96s, i6)) {
            i6++;
        }
        this.r = i6;
    }

    @Override // F4.h
    public void a(F4.f fVar) {
        ((Handler) this.t).post(fVar.f1254b);
    }

    @Override // F4.h
    public void b() {
        HandlerThread handlerThread = (HandlerThread) this.f96s;
        if (handlerThread != null) {
            handlerThread.quit();
            this.f96s = null;
            this.t = null;
        }
    }

    public p027e4.b d() {
        if (!StringUtils.EMPTY.isEmpty()) {
            throw new IllegalStateException("Missing required properties:".concat(StringUtils.EMPTY));
        }
        return new p027e4.b(((Long) this.t).longValue(), (String) this.f96s, this.r);
    }

    /* JADX WARN: Code duplicated, block: B:74:0x01a3  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r17v11 */
    /* JADX WARN: Type inference failed for: r17v12 */
    /* JADX WARN: Type inference failed for: r17v13 */
    /* JADX WARN: Type inference failed for: r17v4 */
    /* JADX WARN: Type inference failed for: r3v6 */
    /* JADX WARN: Type inference failed for: r3v8, types: [java.lang.Object[]] */
    /* JADX WARN: Type inference failed for: r4v10 */
    /* JADX WARN: Type inference failed for: r4v12 */
    /* JADX WARN: Type inference failed for: r4v15 */
    /* JADX WARN: Type inference failed for: r4v16, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r4v19 */
    /* JADX WARN: Type inference failed for: r4v2 */
    /* JADX WARN: Type inference failed for: r4v20 */
    /* JADX WARN: Type inference failed for: r4v23 */
    /* JADX WARN: Type inference failed for: r4v24 */
    /* JADX WARN: Type inference failed for: r4v25 */
    /* JADX WARN: Type inference failed for: r4v3 */
    /* JADX WARN: Type inference failed for: r4v7 */
    public Y e() {
        int i6;
        boolean z6;
        char c2;
        ?? r6;
        char c6;
        short[] sArr;
        int i7;
        boolean z7;
        ?? r17;
        boolean z8;
        ?? r7;
        Y y;
        boolean z9;
        D d6 = (D) this.t;
        if (d6 != null) {
            throw d6.a();
        }
        int i8 = this.r;
        Object[] objArrCopyOf = (Object[]) this.f96s;
        if (i8 == 0) {
            y = Y.f8791x;
        } else {
            int i9 = 1;
            D d7 = null;
            ?? r8 = 0;
            D d8 = null;
            D d9 = null;
            boolean z10 = false;
            if (i8 == 1) {
                Objects.requireNonNull(objArrCopyOf[0]);
                Objects.requireNonNull(objArrCopyOf[1]);
                y = new Y(null, objArrCopyOf, 1);
            } else {
                AbstractC0252u0.h(i8, objArrCopyOf.length >> 1);
                int iL = F.l(i8);
                char c7 = 2;
                if (i8 == 1) {
                    Objects.requireNonNull(objArrCopyOf[0]);
                    Objects.requireNonNull(objArrCopyOf[1]);
                    i6 = 1;
                    z9 = false;
                } else {
                    int i10 = iL - 1;
                    if (iL <= 128) {
                        byte[] bArr = new byte[iL];
                        Arrays.fill(bArr, (byte) -1);
                        int i11 = 0;
                        int i12 = 0;
                        while (i11 < i8) {
                            int i13 = i11 * 2;
                            int i14 = i12 * 2;
                            Object obj = objArrCopyOf[i13];
                            Objects.requireNonNull(obj);
                            Object obj2 = objArrCopyOf[i13 ^ i9];
                            Objects.requireNonNull(obj2);
                            int iM = AbstractC0460q.m(obj.hashCode());
                            while (true) {
                                int i15 = iM & i10;
                                i7 = i9;
                                z7 = z10;
                                int i16 = bArr[i15] & ForkServer.ERROR;
                                if (i16 == 255) {
                                    bArr[i15] = (byte) i14;
                                    if (i12 < i11) {
                                        objArrCopyOf[i14] = obj;
                                        objArrCopyOf[i14 ^ 1] = obj2;
                                    }
                                    i12++;
                                    break;
                                }
                                if (obj.equals(objArrCopyOf[i16 == true ? 1 : 0])) {
                                    int i17 = ~i16;
                                    Object obj3 = objArrCopyOf[i17 == true ? 1 : 0];
                                    Objects.requireNonNull(obj3);
                                    d8 = new D(obj, obj2, obj3);
                                    objArrCopyOf[i17 == true ? 1 : 0] = obj2;
                                    break;
                                }
                                iM = i15 + 1;
                                i9 = i7;
                                z10 = z7;
                            }
                            i11++;
                            i9 = i7;
                            z10 = z7;
                        }
                        i6 = i9;
                        z6 = z10;
                        if (i12 == i8) {
                            r8 = bArr;
                            z9 = z6;
                        } else {
                            sArr = new Object[3];
                            sArr[z6 ? 1 : 0] = bArr;
                            sArr[i6] = Integer.valueOf(i12);
                            sArr[2] = d8;
                            r8 = sArr;
                            z9 = z6;
                        }
                    } else {
                        i6 = 1;
                        z6 = false;
                        if (iL <= 32768) {
                            sArr = new short[iL];
                            Arrays.fill(sArr, (short) -1);
                            int i18 = 0;
                            for (int i19 = 0; i19 < i8; i19++) {
                                int i20 = i19 * 2;
                                int i21 = i18 * 2;
                                Object obj4 = objArrCopyOf[i20];
                                Objects.requireNonNull(obj4);
                                Object obj5 = objArrCopyOf[i20 ^ 1];
                                Objects.requireNonNull(obj5);
                                int iM2 = AbstractC0460q.m(obj4.hashCode());
                                while (true) {
                                    int i22 = iM2 & i10;
                                    int i23 = sArr[i22] & 65535;
                                    if (i23 == 65535) {
                                        sArr[i22] = (short) i21;
                                        if (i18 < i19) {
                                            objArrCopyOf[i21] = obj4;
                                            objArrCopyOf[i21 ^ 1] = obj5;
                                        }
                                        i18++;
                                        break;
                                    }
                                    if (obj4.equals(objArrCopyOf[i23 == true ? 1 : 0])) {
                                        int i24 = ~i23;
                                        Object obj6 = objArrCopyOf[i24 == true ? 1 : 0];
                                        Objects.requireNonNull(obj6);
                                        d9 = new D(obj4, obj5, obj6);
                                        objArrCopyOf[i24 == true ? 1 : 0] = obj5;
                                        break;
                                    }
                                    iM2 = i22 + 1;
                                }
                            }
                            if (i18 == i8) {
                                r8 = sArr;
                                z9 = z6;
                            } else {
                                r8 = new Object[]{sArr, Integer.valueOf(i18), d9};
                                z9 = z6;
                            }
                        } else {
                            int[] iArr = new int[iL];
                            Arrays.fill(iArr, -1);
                            int i25 = 0;
                            int i26 = 0;
                            while (i25 < i8) {
                                int i27 = i25 * 2;
                                int i28 = i26 * 2;
                                Object obj7 = objArrCopyOf[i27];
                                Objects.requireNonNull(obj7);
                                Object obj8 = objArrCopyOf[i27 ^ 1];
                                Objects.requireNonNull(obj8);
                                int iM3 = AbstractC0460q.m(obj7.hashCode());
                                while (true) {
                                    int i29 = iM3 & i10;
                                    int i30 = iArr[i29];
                                    if (i30 == -1) {
                                        iArr[i29] = i28;
                                        if (i26 < i25) {
                                            objArrCopyOf[i28] = obj7;
                                            objArrCopyOf[i28 ^ 1] = obj8;
                                        }
                                        i26++;
                                        c6 = c7;
                                        break;
                                    }
                                    c6 = c7;
                                    if (obj7.equals(objArrCopyOf[i30])) {
                                        int i31 = i30 ^ 1;
                                        Object obj9 = objArrCopyOf[i31];
                                        Objects.requireNonNull(obj9);
                                        d7 = new D(obj7, obj8, obj9);
                                        objArrCopyOf[i31] = obj8;
                                        break;
                                    }
                                    iM3 = i29 + 1;
                                    c7 = c6;
                                }
                                i25++;
                                c7 = c6;
                            }
                            c2 = c7;
                            if (i26 == i8) {
                                r6 = iArr;
                                r17 = z6;
                            } else {
                                Object[] objArr = new Object[3];
                                objArr[0] = iArr;
                                objArr[1] = Integer.valueOf(i26);
                                objArr[c2] = d7;
                                r6 = objArr;
                                r17 = z6;
                            }
                        }
                    }
                    z8 = r6 instanceof Object[];
                    r7 = r6;
                    if (z8) {
                        Object[] objArr2 = (Object[]) r6;
                        this.t = (D) objArr2[c2];
                        Object obj10 = objArr2[r17];
                        int iIntValue = ((Integer) objArr2[i6]).intValue();
                        objArrCopyOf = Arrays.copyOf(objArrCopyOf, iIntValue * 2);
                        r7 = obj10;
                        i8 = iIntValue;
                    }
                    y = new Y(r7, objArrCopyOf, i8);
                }
                c2 = 2;
                r6 = r8;
                r17 = z9;
                z8 = r6 instanceof Object[];
                r7 = r6;
                if (z8) {
                    Object[] objArr3 = (Object[]) r6;
                    this.t = (D) objArr3[c2];
                    Object obj11 = objArr3[r17];
                    int iIntValue2 = ((Integer) objArr3[i6]).intValue();
                    objArrCopyOf = Arrays.copyOf(objArrCopyOf, iIntValue2 * 2);
                    r7 = obj11;
                    i8 = iIntValue2;
                }
                y = new Y(r7, objArrCopyOf, i8);
            }
        }
        D d10 = (D) this.t;
        if (d10 == null) {
            return y;
        }
        throw d10.a();
    }

    public Object f(int i6) {
        SparseArray sparseArray = (SparseArray) this.f96s;
        if (this.r == -1) {
            this.r = 0;
        }
        while (true) {
            int i7 = this.r;
            if (i7 <= 0 || i6 >= sparseArray.keyAt(i7)) {
                break;
            }
            this.r--;
        }
        while (this.r < sparseArray.size() - 1 && i6 >= sparseArray.keyAt(this.r + 1)) {
            this.r++;
        }
        return sparseArray.valueAt(this.r);
    }

    public int g() {
        int i6 = this.r;
        if (Build.VERSION.SDK_INT < 35) {
            return 2;
        }
        View viewFindViewById = ((Activity) this.f96s).findViewById(i6);
        if (viewFindViewById != null) {
            return viewFindViewById.getContentSensitivity();
        }
        throw new IllegalArgumentException(T.h("FlutterView with ID ", i6, "not found"));
    }

    public void h(Object obj, Object obj2) {
        int i6 = (this.r + 1) * 2;
        Object[] objArr = (Object[]) this.f96s;
        if (i6 > objArr.length) {
            this.f96s = Arrays.copyOf(objArr, AbstractC0465w.d(objArr.length, i6));
        }
        if (obj == null) {
            throw new NullPointerException("null key in entry: null=" + obj2);
        }
        if (obj2 == null) {
            throw new NullPointerException("null value in entry: " + obj + "=null");
        }
        Object[] objArr2 = (Object[]) this.f96s;
        int i7 = this.r;
        int i8 = i7 * 2;
        objArr2[i8] = obj;
        objArr2[i8 + 1] = obj2;
        this.r = i7 + 1;
    }

    @Override // R0.InterfaceC0142h
    public C0141g i(R0.q qVar, long j6) {
        long j7;
        long position = qVar.getPosition();
        int iMin = (int) Math.min(112800, qVar.getLength() - position);
        p117t0.l lVar = (p117t0.l) this.t;
        lVar.C(iMin);
        qVar.z(lVar.f8987a, 0, iMin);
        int i6 = lVar.f8989c;
        long j8 = -1;
        long j9 = -1;
        long j10 = -9223372036854775807L;
        while (true) {
            if (lVar.a() < 188) {
                j7 = -9223372036854775807L;
                break;
            }
            byte[] bArr = lVar.f8987a;
            int i7 = lVar.f8988b;
            while (true) {
                if (i7 >= i6) {
                    j7 = -9223372036854775807L;
                    break;
                }
                j7 = -9223372036854775807L;
                if (bArr[i7] == 71) {
                    break;
                }
                i7++;
            }
            int i8 = i7 + 188;
            if (i8 > i6) {
                break;
            }
            long jY = AbstractC0252u0.y(lVar, i7, this.r);
            if (jY != j7) {
                long jB = ((p117t0.q) this.f96s).b(jY);
                if (jB > j6) {
                    return j10 == j7 ? new C0141g(-1, jB, position) : new C0141g(0, -9223372036854775807L, position + j9);
                }
                if (PipesConfigBase.DEFAULT_MAX_FOR_EMIT_BATCH + jB > j6) {
                    return new C0141g(0, -9223372036854775807L, position + ((long) i7));
                }
                j10 = jB;
                j9 = i7;
            }
            lVar.F(i8);
            j8 = i8;
        }
        return j10 != j7 ? new C0141g(-2, j10, position + j8) : C0141g.f3336d;
    }

    public void j(int i6) {
        int i7 = this.r;
        if (Build.VERSION.SDK_INT < 35) {
            throw new IllegalStateException("isSupported() should be called before attempting to set content sensitivity as it is not supported on this device.");
        }
        View viewFindViewById = ((Activity) this.f96s).findViewById(i7);
        if (viewFindViewById == null) {
            throw new IllegalArgumentException(T.h("FlutterView with ID ", i7, "not found"));
        }
        if (viewFindViewById.getContentSensitivity() == i6) {
            return;
        }
        viewFindViewById.setContentSensitivity(i6);
        viewFindViewById.invalidate();
    }

    @Override // R0.InterfaceC0142h
    public void k() {
        p117t0.l lVar = (p117t0.l) this.t;
        byte[] bArr = p117t0.s.f9007f;
        lVar.getClass();
        lVar.D(bArr, bArr.length);
    }

    public List l(CharSequence charSequence) {
        charSequence.getClass();
        G g7 = (G) this.t;
        g7.getClass();
        p104q3.h hVar = new p104q3.h(g7, this, charSequence);
        ArrayList arrayList = new ArrayList();
        while (hVar.hasNext()) {
            arrayList.add((String) hVar.next());
        }
        return Collections.unmodifiableList(arrayList);
    }

    @Override // F4.h
    public void start() {
        HandlerThread handlerThread = new HandlerThread("Sqflite", this.r);
        this.f96s = handlerThread;
        handlerThread.start();
        this.t = new Handler(((HandlerThread) this.f96s).getLooper());
    }

    public n(int i6, int i7) {
        switch (i7) {
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                this.f96s = new Object[i6 * 2];
                this.r = 0;
                break;
            default:
                this.r = i6;
                break;
        }
    }

    public n(G g7) {
        this.t = g7;
        this.f96s = p104q3.c.r;
        this.r = Integer.MAX_VALUE;
    }

    public n(C0427o c0427o, int i6, String str) {
        this.f96s = c0427o;
        this.r = i6;
        this.t = str;
    }
}
