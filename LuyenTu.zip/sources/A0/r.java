package A0;

import J0.Y;
import p101q0.C0427o;

/* JADX INFO: loaded from: classes.dex */
public final class r implements Y {
    public final C0427o r;
    public long[] t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f119u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public B0.g f120v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f121w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f122x;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final V4.d f118s = new V4.d();
    public long y = -9223372036854775807L;

    public r(B0.g gVar, C0427o c0427o, boolean z6) {
        this.r = c0427o;
        this.f120v = gVar;
        this.t = gVar.f228b;
        b(gVar, z6);
    }

    public final void b(B0.g gVar, boolean z6) {
        int i6 = this.f122x;
        long j6 = -9223372036854775807L;
        long j7 = i6 == 0 ? -9223372036854775807L : this.t[i6 - 1];
        this.f119u = z6;
        this.f120v = gVar;
        long[] jArr = gVar.f228b;
        this.t = jArr;
        long j8 = this.y;
        if (j8 == -9223372036854775807L) {
            if (j7 != -9223372036854775807L) {
                this.f122x = p117t0.s.b(jArr, j7, false);
            }
        } else {
            int iB = p117t0.s.b(jArr, j8, true);
            this.f122x = iB;
            if (this.f119u && iB == this.t.length) {
                j6 = j8;
            }
            this.y = j6;
        }
    }

    @Override // J0.Y
    public final boolean e() {
        return true;
    }

    @Override // J0.Y
    public final int i(p086n4.a aVar, p134w0.e eVar, int i6) {
        int i7 = this.f122x;
        boolean z6 = i7 == this.t.length;
        if (z6 && !this.f119u) {
            eVar.f7516s = 4;
            return -4;
        }
        if ((i6 & 2) != 0 || !this.f121w) {
            aVar.t = this.r;
            this.f121w = true;
            return -5;
        }
        if (z6) {
            return -3;
        }
        if ((i6 & 1) == 0) {
            this.f122x = i7 + 1;
        }
        if ((i6 & 4) == 0) {
            byte[] bArrP = this.f118s.P(this.f120v.f227a[i7]);
            eVar.k(bArrP.length);
            eVar.f9570v.put(bArrP);
        }
        eVar.f9572x = this.t[i7];
        eVar.f7516s = 1;
        return -4;
    }

    @Override // J0.Y
    public final int l(long j6) {
        int iMax = Math.max(this.f122x, p117t0.s.b(this.t, j6, true));
        int i6 = iMax - this.f122x;
        this.f122x = iMax;
        return i6;
    }

    @Override // J0.Y
    public final void a() {
    }
}
