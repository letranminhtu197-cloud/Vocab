package A0;

/* JADX INFO: loaded from: classes.dex */
public final class p extends K0.b {

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final o f103u;

    public p(o oVar, long j6, long j7) {
        super(j6, j7);
        this.f103u = oVar;
    }

    @Override // K0.n
    public final long a() {
        b();
        return this.f103u.e(this.t);
    }

    @Override // K0.n
    public final long f() {
        b();
        return this.f103u.f(this.t);
    }
}
