package A0;

import java.util.List;
import p101q0.C0414b;
import p101q0.C0430s;
import p101q0.C0434w;
import p101q0.M;
import p101q0.N;
import p101q0.O;

/* JADX INFO: loaded from: classes.dex */
public final class h extends O {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f54b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f55c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f56d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f57e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final long f58f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final long f59g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final long f60h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final B0.c f61i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final C0434w f62j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final C0430s f63k;

    public h(long j6, long j7, long j8, int i6, long j9, long j10, long j11, B0.c cVar, C0434w c0434w, C0430s c0430s) {
        p117t0.a.h(cVar.f205d == (c0430s != null));
        this.f54b = j6;
        this.f55c = j7;
        this.f56d = j8;
        this.f57e = i6;
        this.f58f = j9;
        this.f59g = j10;
        this.f60h = j11;
        this.f61i = cVar;
        this.f62j = c0434w;
        this.f63k = c0430s;
    }

    @Override // p101q0.O
    public final int b(Object obj) {
        int iIntValue;
        if ((obj instanceof Integer) && (iIntValue = ((Integer) obj).intValue() - this.f57e) >= 0 && iIntValue < h()) {
            return iIntValue;
        }
        return -1;
    }

    @Override // p101q0.O
    public final M f(int i6, M m6, boolean z6) {
        p117t0.a.f(i6, h());
        B0.c cVar = this.f61i;
        String str = z6 ? cVar.b(i6).f231a : null;
        Integer numValueOf = z6 ? Integer.valueOf(this.f57e + i6) : null;
        long jD = cVar.d(i6);
        long jH = p117t0.s.H(cVar.b(i6).f232b - cVar.b(0).f232b) - this.f58f;
        m6.getClass();
        C0414b c0414b = C0414b.f8316c;
        m6.f8233a = str;
        m6.f8234b = numValueOf;
        m6.f8235c = 0;
        m6.f8236d = jD;
        m6.f8237e = jH;
        m6.f8239g = c0414b;
        m6.f8238f = false;
        return m6;
    }

    @Override // p101q0.O
    public final int h() {
        return this.f61i.f214m.size();
    }

    @Override // p101q0.O
    public final Object l(int i6) {
        p117t0.a.f(i6, h());
        return Integer.valueOf(this.f57e + i6);
    }

    /* JADX WARN: Code duplicated, block: B:44:0x00c7  */
    @Override // p101q0.O
    public final N m(int i6, N n6, long j6) {
        boolean z6;
        long j7;
        long j8;
        boolean z7;
        long j9;
        l lVarB;
        p117t0.a.f(i6, 1);
        B0.c cVar = this.f61i;
        boolean z8 = cVar.f205d;
        long jC = this.f60h;
        if (z8 && cVar.f206e != -9223372036854775807L && cVar.f203b == -9223372036854775807L) {
            long j10 = 0;
            if (j6 > 0) {
                jC += j6;
                if (jC > this.f59g) {
                    z6 = true;
                    j8 = -9223372036854775807L;
                    j7 = -9223372036854775807L;
                }
                Object obj = N.f8240q;
                if (cVar.f205d || cVar.f206e == j7 || cVar.f203b != j7) {
                    z7 = false;
                } else {
                    z7 = z6;
                }
                n6.b(this.f62j, cVar, this.f54b, this.f55c, this.f56d, true, z7, this.f63k, j8, this.f59g, h() - 1, this.f58f);
                return n6;
            }
            long j11 = this.f58f + jC;
            long jD = cVar.d(0);
            int i7 = 0;
            while (i7 < cVar.f214m.size() - 1 && j11 >= jD) {
                j11 -= jD;
                i7++;
                jD = cVar.d(i7);
            }
            B0.h hVarB = cVar.b(i7);
            List list = hVarB.f233c;
            z6 = true;
            int size = list.size();
            j7 = -9223372036854775807L;
            int i8 = 0;
            while (true) {
                if (i8 >= size) {
                    j9 = j10;
                    i8 = -1;
                    break;
                }
                j9 = j10;
                if (((B0.a) list.get(i8)).f193b == 2) {
                    break;
                }
                i8++;
                j10 = j9;
            }
            if (i8 != -1 && (lVarB = ((B0.m) ((B0.a) hVarB.f233c.get(i8)).f194c.get(0)).b()) != null && lVarB.w(jD) != j9) {
                jC = (lVarB.c(lVarB.d(j11, jD)) + jC) - j11;
            }
        } else {
            z6 = true;
            j7 = -9223372036854775807L;
        }
        j8 = jC;
        Object obj2 = N.f8240q;
        if (cVar.f205d) {
            z7 = false;
        } else {
            z7 = false;
        }
        n6.b(this.f62j, cVar, this.f54b, this.f55c, this.f56d, true, z7, this.f63k, j8, this.f59g, h() - 1, this.f58f);
        return n6;
    }

    @Override // p101q0.O
    public final int o() {
        return 1;
    }
}
