package A0;

import J0.C0073b;

/* JADX INFO: loaded from: classes.dex */
public final class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final K0.g f97a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final B0.m f98b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final B0.b f99c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final l f100d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f101e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final long f102f;

    public o(long j6, B0.m mVar, B0.b bVar, K0.g gVar, long j7, l lVar) {
        this.f101e = j6;
        this.f98b = mVar;
        this.f99c = bVar;
        this.f102f = j7;
        this.f97a = gVar;
        this.f100d = lVar;
    }

    public final o a(long j6, B0.m mVar) throws C0073b {
        long jD;
        long jD2;
        l lVarB = this.f98b.b();
        l lVarB2 = mVar.b();
        if (lVarB == null) {
            return new o(j6, mVar, this.f99c, this.f97a, this.f102f, lVarB);
        }
        if (!lVarB.q()) {
            return new o(j6, mVar, this.f99c, this.f97a, this.f102f, lVarB2);
        }
        long jW = lVarB.w(j6);
        if (jW == 0) {
            return new o(j6, mVar, this.f99c, this.f97a, this.f102f, lVarB2);
        }
        p117t0.a.i(lVarB2);
        long jS = lVarB.s();
        long jC = lVarB.c(jS);
        long j7 = jW + jS;
        long j8 = j7 - 1;
        long jG = lVarB.g(j8, j6) + lVarB.c(j8);
        long jS2 = lVarB2.s();
        long jC2 = lVarB2.c(jS2);
        long j9 = this.f102f;
        if (jG != jC2) {
            if (jG < jC2) {
                throw new C0073b();
            }
            if (jC2 < jC) {
                jD2 = j9 - (lVarB2.d(jC, j6) - jS);
            } else {
                jD = lVarB.d(jC2, j6) - jS2;
            }
            return new o(j6, mVar, this.f99c, this.f97a, jD2, lVarB2);
        }
        jD = j7 - jS2;
        jD2 = jD + j9;
        return new o(j6, mVar, this.f99c, this.f97a, jD2, lVarB2);
    }

    public final long b(long j6) {
        l lVar = this.f100d;
        p117t0.a.i(lVar);
        return lVar.j(this.f101e, j6) + this.f102f;
    }

    public final long c(long j6) {
        long jB = b(j6);
        l lVar = this.f100d;
        p117t0.a.i(lVar);
        return (lVar.x(this.f101e, j6) + jB) - 1;
    }

    public final long d() {
        l lVar = this.f100d;
        p117t0.a.i(lVar);
        return lVar.w(this.f101e);
    }

    public final long e(long j6) {
        long jF = f(j6);
        l lVar = this.f100d;
        p117t0.a.i(lVar);
        return lVar.g(j6 - this.f102f, this.f101e) + jF;
    }

    public final long f(long j6) {
        l lVar = this.f100d;
        p117t0.a.i(lVar);
        return lVar.c(j6 - this.f102f);
    }

    public final boolean g(long j6, long j7) {
        l lVar = this.f100d;
        p117t0.a.i(lVar);
        return lVar.q() || j7 == -9223372036854775807L || e(j6) <= j7;
    }
}
