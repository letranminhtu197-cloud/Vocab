package A0;

import android.os.Handler;
import android.os.Message;
import java.util.TreeMap;

/* JADX INFO: loaded from: classes.dex */
public final class u implements Handler.Callback {
    public final N0.e r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final i f130s;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public B0.c f133w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f134x;
    public boolean y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f135z;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final TreeMap f132v = new TreeMap();

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final Handler f131u = p117t0.s.m(this);
    public final p006b1.b t = new p006b1.b(1);

    public u(B0.c cVar, i iVar, N0.e eVar) {
        this.f133w = cVar;
        this.f130s = iVar;
        this.r = eVar;
    }

    @Override // android.os.Handler.Callback
    public final boolean handleMessage(Message message) {
        if (!this.f135z) {
            if (message.what != 1) {
                return false;
            }
            s sVar = (s) message.obj;
            long j6 = sVar.f123a;
            long j7 = sVar.f124b;
            Long lValueOf = Long.valueOf(j7);
            TreeMap treeMap = this.f132v;
            Long l6 = (Long) treeMap.get(lValueOf);
            if (l6 == null) {
                treeMap.put(Long.valueOf(j7), Long.valueOf(j6));
                return true;
            }
            if (l6.longValue() > j6) {
                treeMap.put(Long.valueOf(j7), Long.valueOf(j6));
            }
        }
        return true;
    }
}
