package A0;

import R0.A;
import R0.C0143i;
import R0.G;
import android.os.SystemClock;

/* JADX INFO: loaded from: classes.dex */
public final class m implements l, R0.q, R0.r {
    public long r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public Object f95s;

    public /* synthetic */ m(long j6, Object obj) {
        this.r = j6;
        this.f95s = obj;
    }

    @Override // R0.q
    public void A(int i6) {
        ((R0.q) this.f95s).A(i6);
    }

    public void B(Exception exc) {
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        if (((Exception) this.f95s) == null) {
            this.f95s = exc;
            this.r = 100 + jElapsedRealtime;
        }
        if (jElapsedRealtime >= this.r) {
            Exception exc2 = (Exception) this.f95s;
            if (exc2 != exc) {
                exc2.addSuppressed(exc);
            }
            Exception exc3 = (Exception) this.f95s;
            this.f95s = null;
            throw exc3;
        }
    }

    @Override // R0.q
    public int a(int i6) {
        return ((R0.q) this.f95s).a(i6);
    }

    @Override // R0.q
    public boolean b(byte[] bArr, int i6, int i7, boolean z6) {
        return ((R0.q) this.f95s).b(bArr, 0, i7, z6);
    }

    @Override // A0.l
    public long c(long j6) {
        return ((C0143i) this.f95s).f3344e[(int) j6] - this.r;
    }

    @Override // A0.l
    public long d(long j6, long j7) {
        return p117t0.s.f(((C0143i) this.f95s).f3344e, j6 + this.r, true);
    }

    @Override // R0.r
    public void e() {
        ((R0.r) this.f95s).e();
    }

    @Override // A0.l
    public long g(long j6, long j7) {
        return ((C0143i) this.f95s).f3343d[(int) j6];
    }

    @Override // R0.q
    public long getLength() {
        return ((R0.q) this.f95s).getLength() - this.r;
    }

    @Override // R0.q
    public long getPosition() {
        return ((R0.q) this.f95s).getPosition() - this.r;
    }

    @Override // R0.q
    public int h(byte[] bArr, int i6, int i7) {
        return ((R0.q) this.f95s).h(bArr, i6, i7);
    }

    @Override // R0.r
    public void i(A a5) {
        ((R0.r) this.f95s).i(new Z0.c(this, a5, a5));
    }

    @Override // A0.l
    public long j(long j6, long j7) {
        return 0L;
    }

    @Override // A0.l
    public long m(long j6, long j7) {
        return -9223372036854775807L;
    }

    @Override // A0.l
    public B0.j n(long j6) {
        C0143i c0143i = (C0143i) this.f95s;
        int i6 = (int) j6;
        return new B0.j(c0143i.f3342c[i6], c0143i.f3341b[i6], null);
    }

    @Override // R0.q
    public void o() {
        ((R0.q) this.f95s).o();
    }

    @Override // R0.q
    public void p(int i6) {
        ((R0.q) this.f95s).p(i6);
    }

    @Override // A0.l
    public boolean q() {
        return true;
    }

    @Override // R0.r
    public G r(int i6, int i7) {
        return ((R0.r) this.f95s).r(i6, i7);
    }

    @Override // p101q0.InterfaceC0421i
    public int read(byte[] bArr, int i6, int i7) {
        return ((R0.q) this.f95s).read(bArr, i6, i7);
    }

    @Override // R0.q
    public void readFully(byte[] bArr, int i6, int i7) {
        ((R0.q) this.f95s).readFully(bArr, i6, i7);
    }

    @Override // A0.l
    public long s() {
        return 0L;
    }

    @Override // R0.q
    public boolean t(int i6, boolean z6) {
        return ((R0.q) this.f95s).t(i6, true);
    }

    @Override // R0.q
    public boolean v(byte[] bArr, int i6, int i7, boolean z6) {
        return ((R0.q) this.f95s).v(bArr, i6, i7, z6);
    }

    @Override // A0.l
    public long w(long j6) {
        return ((C0143i) this.f95s).f3340a;
    }

    @Override // A0.l
    public long x(long j6, long j7) {
        return ((C0143i) this.f95s).f3340a;
    }

    @Override // R0.q
    public long y() {
        return ((R0.q) this.f95s).y() - this.r;
    }

    @Override // R0.q
    public void z(byte[] bArr, int i6, int i7) {
        ((R0.q) this.f95s).z(bArr, i6, i7);
    }

    public m(R0.q qVar, long j6) {
        this.f95s = qVar;
        p117t0.a.d(qVar.getPosition() >= j6);
        this.r = j6;
    }
}
