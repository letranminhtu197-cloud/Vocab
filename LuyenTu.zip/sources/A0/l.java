package A0;

/* JADX INFO: loaded from: classes.dex */
public interface l {
    long c(long j6);

    long d(long j6, long j7);

    long g(long j6, long j7);

    long j(long j6, long j7);

    long m(long j6, long j7);

    B0.j n(long j6);

    boolean q();

    long s();

    long w(long j6);

    long x(long j6, long j7);
}
