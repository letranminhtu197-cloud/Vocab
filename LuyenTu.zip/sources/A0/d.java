package A0;

import p108r3.C;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int[] f24a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f25b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f26c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f27d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f28e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f29f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f30g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final C f31h;

    public d(int i6, int i7, int[] iArr, int i8, int i9, int i10, int i11, C c2) {
        this.f25b = i6;
        this.f24a = iArr;
        this.f26c = i7;
        this.f28e = i8;
        this.f29f = i9;
        this.f30g = i10;
        this.f27d = i11;
        this.f31h = c2;
    }
}
