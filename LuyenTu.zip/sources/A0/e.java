package A0;

import J0.C;
import J0.C0083l;
import J0.C0090t;
import J0.D;
import J0.X;
import J0.Y;
import J0.Z;
import J0.a0;
import J0.h0;
import android.util.Pair;
import android.util.SparseArray;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.tika.metadata.TikaCoreProperties;
import org.apache.tika.utils.StringUtils;
import p053i4.v;
import p101q0.C0426n;
import p101q0.C0427o;
import p101q0.P;
import p108r3.AbstractC0460q;
import p108r3.T;
import p128v0.A;
import p140x0.J;
import p140x0.c0;

/* JADX INFO: loaded from: classes.dex */
public final class e implements D, Z, K0.i {

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public static final Pattern f32O = Pattern.compile("CC([1-4])=(.+)");

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public static final Pattern f33P = Pattern.compile("([1-4])=lang:(\\w+)(,.+)?");

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final h0 f34A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public final d[] f35B;
    public final Z3.e C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final u f36D;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public final C0.e f38F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public final C0.e f39G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public C f40H;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public C0083l f43K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public B0.c f44L;

    /* JADX INFO: renamed from: M, reason: collision with root package name */
    public int f45M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public List f46N;
    public final int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final n f47s;
    public final A t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final C0.i f48u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final M4.m f49v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final v f50w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final long f51x;
    public final N0.p y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final N0.e f52z;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public K0.j[] f41I = new K0.j[0];

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public r[] f42J = new r[0];

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public final IdentityHashMap f37E = new IdentityHashMap();

    public e(int i6, B0.c cVar, v vVar, int i7, n nVar, A a5, C0.i iVar, C0.e eVar, M4.m mVar, C0.e eVar2, long j6, N0.p pVar, N0.e eVar3, Z3.e eVar4, i iVar2, y0.k kVar) {
        int i8;
        int i9;
        int[][] iArr;
        boolean[] zArr;
        C0427o[] c0427oArrI;
        B0.f fVarA;
        Integer num;
        this.r = i6;
        this.f44L = cVar;
        this.f50w = vVar;
        this.f45M = i7;
        this.f47s = nVar;
        this.t = a5;
        this.f48u = iVar;
        this.f39G = eVar;
        this.f49v = mVar;
        this.f38F = eVar2;
        this.f51x = j6;
        this.y = pVar;
        this.f52z = eVar3;
        this.C = eVar4;
        this.f36D = new u(cVar, iVar2, eVar3);
        int i10 = 0;
        eVar4.getClass();
        p108r3.A a7 = p108r3.C.f8765s;
        T t = T.f8782v;
        this.f43K = new C0083l(t, t);
        B0.h hVarB = cVar.b(i7);
        List list = hVarB.f234d;
        this.f46N = list;
        List list2 = hVarB.f233c;
        int size = list2.size();
        HashMap map = new HashMap(AbstractC0460q.a(size));
        ArrayList arrayList = new ArrayList(size);
        SparseArray sparseArray = new SparseArray(size);
        for (int i11 = 0; i11 < size; i11++) {
            map.put(Long.valueOf(((B0.a) list2.get(i11)).f192a), Integer.valueOf(i11));
            ArrayList arrayList2 = new ArrayList();
            arrayList2.add(Integer.valueOf(i11));
            arrayList.add(arrayList2);
            sparseArray.put(i11, arrayList2);
        }
        for (int i12 = 0; i12 < size; i12++) {
            B0.a aVar = (B0.a) list2.get(i12);
            List list3 = aVar.f196e;
            List list4 = aVar.f197f;
            B0.f fVarA2 = a("http://dashif.org/guidelines/trickmode", list3);
            fVarA2 = fVarA2 == null ? a("http://dashif.org/guidelines/trickmode", list4) : fVarA2;
            int iIntValue = (fVarA2 == null || (num = (Integer) map.get(Long.valueOf(Long.parseLong(fVarA2.f225b)))) == null) ? i12 : num.intValue();
            if (iIntValue == i12 && (fVarA = a("urn:mpeg:dash:adaptation-set-switching:2016", list4)) != null) {
                String str = fVarA.f225b;
                int i13 = p117t0.s.f9002a;
                for (String str2 : str.split(",", -1)) {
                    Integer num2 = (Integer) map.get(Long.valueOf(Long.parseLong(str2)));
                    if (num2 != null) {
                        iIntValue = Math.min(iIntValue, num2.intValue());
                    }
                }
            }
            if (iIntValue != i12) {
                List list5 = (List) sparseArray.get(i12);
                List list6 = (List) sparseArray.get(iIntValue);
                list6.addAll(list5);
                sparseArray.put(i12, list6);
                arrayList.remove(list5);
            }
        }
        int size2 = arrayList.size();
        int[][] iArr2 = new int[size2][];
        for (int i14 = 0; i14 < size2; i14++) {
            int[] iArrH0 = android.support.v4.media.session.b.h0((Collection) arrayList.get(i14));
            iArr2[i14] = iArrH0;
            Arrays.sort(iArrH0);
        }
        boolean[] zArr2 = new boolean[size2];
        C0427o[][] c0427oArr = new C0427o[size2][];
        int i15 = 0;
        int i16 = 0;
        while (i15 < size2) {
            int[] iArr3 = iArr2[i15];
            int length = iArr3.length;
            int i17 = i10;
            while (true) {
                if (i17 >= length) {
                    iArr = iArr2;
                    break;
                }
                List list7 = ((B0.a) list2.get(iArr3[i17])).f194c;
                iArr = iArr2;
                while (i10 < list7.size()) {
                    if (!((B0.m) list7.get(i10)).f248u.isEmpty()) {
                        zArr2[i15] = true;
                        i16++;
                        break;
                    }
                    i10++;
                }
                i17++;
                iArr2 = iArr;
                i10 = 0;
            }
            int[] iArr4 = iArr[i15];
            int length2 = iArr4.length;
            int i18 = 0;
            while (true) {
                if (i18 >= length2) {
                    zArr = zArr2;
                    c0427oArrI = new C0427o[0];
                    break;
                }
                int i19 = iArr4[i18];
                B0.a aVar2 = (B0.a) list2.get(i19);
                List list8 = ((B0.a) list2.get(i19)).f195d;
                int[] iArr5 = iArr4;
                int i20 = 0;
                while (i20 < list8.size()) {
                    B0.f fVar = (B0.f) list8.get(i20);
                    int i21 = length2;
                    zArr = zArr2;
                    if ("urn:scte:dash:cc:cea-608:2015".equals(fVar.f224a)) {
                        C0426n c0426n = new C0426n();
                        c0426n.f8363l = p101q0.C.l("application/cea-608");
                        c0426n.f8352a = A3.a.n(new StringBuilder(), aVar2.f192a, ":cea608");
                        c0427oArrI = i(fVar, f32O, new C0427o(c0426n));
                        break;
                    }
                    if ("urn:scte:dash:cc:cea-708:2015".equals(fVar.f224a)) {
                        C0426n c0426n2 = new C0426n();
                        c0426n2.f8363l = p101q0.C.l("application/cea-708");
                        c0426n2.f8352a = A3.a.n(new StringBuilder(), aVar2.f192a, ":cea708");
                        c0427oArrI = i(fVar, f33P, new C0427o(c0426n2));
                        break;
                    }
                    i20++;
                    length2 = i21;
                    zArr2 = zArr;
                }
                i18++;
                iArr4 = iArr5;
            }
            c0427oArr[i15] = c0427oArrI;
            if (c0427oArrI.length != 0) {
                i16++;
            }
            i15++;
            zArr2 = zArr;
            iArr2 = iArr;
            i10 = 0;
        }
        int[][] iArr6 = iArr2;
        boolean[] zArr3 = zArr2;
        int size3 = list.size() + i16 + size2;
        P[] pArr = new P[size3];
        d[] dVarArr = new d[size3];
        int i22 = 0;
        int i23 = 0;
        while (i22 < size2) {
            int[] iArr7 = iArr6[i22];
            ArrayList arrayList3 = new ArrayList();
            int length3 = iArr7.length;
            int i24 = 0;
            while (i24 < length3) {
                arrayList3.addAll(((B0.a) list2.get(iArr7[i24])).f194c);
                i24++;
                size2 = size2;
            }
            int i25 = size2;
            int size4 = arrayList3.size();
            C0427o[] c0427oArr2 = new C0427o[size4];
            int i26 = 0;
            while (i26 < size4) {
                int i27 = size4;
                C0427o c0427o = ((B0.m) arrayList3.get(i26)).r;
                C0427o[][] c0427oArr3 = c0427oArr;
                C0426n c0426nA = c0427o.a();
                c0426nA.f8351I = iVar.c(c0427o);
                c0427oArr2[i26] = new C0427o(c0426nA);
                i26++;
                size4 = i27;
                c0427oArr = c0427oArr3;
            }
            C0427o[][] c0427oArr4 = c0427oArr;
            B0.a aVar3 = (B0.a) list2.get(iArr7[0]);
            int i28 = i23;
            long j7 = aVar3.f192a;
            String string = j7 != -1 ? Long.toString(j7) : com.google.crypto.tink.shaded.protobuf.T.g("unset:", i22);
            int i29 = i28 + 1;
            if (zArr3[i22]) {
                i8 = i28 + 2;
            } else {
                i8 = i29;
                i29 = -1;
            }
            if (c0427oArr4[i22].length != 0) {
                i9 = i8 + 1;
            } else {
                i9 = i8;
                i8 = -1;
            }
            e(nVar, c0427oArr2);
            List list9 = list2;
            pArr[i28] = new P(string, c0427oArr2);
            int i30 = aVar3.f193b;
            p108r3.A a8 = p108r3.C.f8765s;
            T t6 = T.f8782v;
            d dVar = new d(i30, 0, iArr7, i28, i29, i8, -1, t6);
            int i31 = i28;
            dVarArr[i31] = dVar;
            int i32 = -1;
            if (i29 != -1) {
                String strI = com.google.crypto.tink.shaded.protobuf.T.i(string, ":emsg");
                C0426n c0426n3 = new C0426n();
                c0426n3.f8352a = strI;
                c0426n3.f8363l = p101q0.C.l("application/x-emsg");
                pArr[i29] = new P(strI, new C0427o(c0426n3));
                dVarArr[i29] = new d(5, 1, iArr7, i31, -1, -1, -1, t6);
                i32 = -1;
            }
            if (i8 != i32) {
                i31 = i31;
                String strI2 = com.google.crypto.tink.shaded.protobuf.T.i(string, ":cc");
                dVarArr[i8] = new d(3, 1, iArr7, i31, -1, -1, -1, p108r3.C.p(c0427oArr4[i22]));
                e(nVar, c0427oArr4[i22]);
                pArr[i8] = new P(strI2, c0427oArr4[i22]);
            } else {
                i31 = i31;
            }
            i22++;
            size2 = i25;
            i23 = i9;
            c0427oArr = c0427oArr4;
            list2 = list9;
        }
        int i33 = 0;
        while (i33 < list.size()) {
            B0.g gVar = (B0.g) list.get(i33);
            C0426n c0426n4 = new C0426n();
            c0426n4.f8352a = gVar.a();
            c0426n4.f8363l = p101q0.C.l("application/x-emsg");
            pArr[i23] = new P(gVar.a() + TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER + i33, new C0427o(c0426n4));
            p108r3.A a9 = p108r3.C.f8765s;
            dVarArr[i23] = new d(5, 2, new int[0], -1, -1, -1, i33, T.f8782v);
            i33++;
            i23++;
        }
        Pair pairCreate = Pair.create(new h0(pArr), dVarArr);
        this.f34A = (h0) pairCreate.first;
        this.f35B = (d[]) pairCreate.second;
    }

    public static B0.f a(String str, List list) {
        for (int i6 = 0; i6 < list.size(); i6++) {
            B0.f fVar = (B0.f) list.get(i6);
            if (str.equals(fVar.f224a)) {
                return fVar;
            }
        }
        return null;
    }

    public static void e(n nVar, C0427o[] c0427oArr) {
        for (int i6 = 0; i6 < c0427oArr.length; i6++) {
            C0427o c0427o = c0427oArr[i6];
            K0.d dVar = (K0.d) nVar.t;
            p033f5.f fVar = (p033f5.f) dVar.t;
            if (dVar.f1996s && fVar.h(c0427o)) {
                C0426n c0426nA = c0427o.a();
                String str = c0427o.f8393j;
                c0426nA.f8363l = p101q0.C.l("application/x-media3-cues");
                c0426nA.f8348F = fVar.d(c0427o);
                StringBuilder sb = new StringBuilder();
                sb.append(c0427o.f8396m);
                sb.append(str != null ? StringUtils.SPACE.concat(str) : StringUtils.EMPTY);
                c0426nA.f8360i = sb.toString();
                c0426nA.f8367q = Long.MAX_VALUE;
                c0427o = new C0427o(c0426nA);
            }
            c0427oArr[i6] = c0427o;
        }
    }

    public static C0427o[] i(B0.f fVar, Pattern pattern, C0427o c0427o) {
        String str = fVar.f225b;
        if (str == null) {
            return new C0427o[]{c0427o};
        }
        int i6 = p117t0.s.f9002a;
        String[] strArrSplit = str.split(";", -1);
        C0427o[] c0427oArr = new C0427o[strArrSplit.length];
        for (int i7 = 0; i7 < strArrSplit.length; i7++) {
            Matcher matcher = pattern.matcher(strArrSplit[i7]);
            if (!matcher.matches()) {
                return new C0427o[]{c0427o};
            }
            int i8 = Integer.parseInt(matcher.group(1));
            C0426n c0426nA = c0427o.a();
            c0426nA.f8352a = c0427o.f8384a + TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER + i8;
            c0426nA.f8347E = i8;
            c0426nA.f8355d = matcher.group(2);
            c0427oArr[i7] = new C0427o(c0426nA);
        }
        return c0427oArr;
    }

    @Override // J0.a0
    public final boolean b() {
        return this.f43K.b();
    }

    public final int c(int[] iArr, int i6) {
        int i7 = iArr[i6];
        if (i7 != -1) {
            d[] dVarArr = this.f35B;
            int i8 = dVarArr[i7].f28e;
            for (int i9 = 0; i9 < iArr.length; i9++) {
                int i10 = iArr[i9];
                if (i10 == i8 && dVarArr[i10].f26c == 0) {
                    return i9;
                }
            }
        }
        return -1;
    }

    @Override // J0.a0
    public final long d() {
        return this.f43K.d();
    }

    @Override // J0.D
    public final long f() {
        return -9223372036854775807L;
    }

    @Override // J0.a0
    public final boolean g(J j6) {
        return this.f43K.g(j6);
    }

    @Override // J0.D
    public final void h(C c2, long j6) {
        this.f40H = c2;
        c2.p(this);
    }

    @Override // J0.D
    public final h0 j() {
        return this.f34A;
    }

    /* JADX WARN: Code duplicated, block: B:121:0x024a  */
    /* JADX WARN: Multi-variable type inference failed */
    @Override // J0.D
    public final long k(M0.c[] cVarArr, boolean[] zArr, Y[] yArr, boolean[] zArr2, long j6) throws Throwable {
        int i6;
        boolean z6;
        int[] iArr;
        int i7;
        int i8;
        int[] iArr2;
        boolean z7;
        int i9;
        P pA;
        p108r3.C c2;
        int i10;
        t tVar;
        boolean z8;
        int[] iArr3 = new int[cVarArr.length];
        int i11 = 0;
        int i12 = 0;
        while (true) {
            i6 = -1;
            if (i12 >= cVarArr.length) {
                break;
            }
            M0.c cVar = cVarArr[i12];
            if (cVar != null) {
                iArr3[i12] = this.f34A.b(cVar.f2332a);
            } else {
                iArr3[i12] = -1;
            }
            i12++;
        }
        for (int i13 = 0; i13 < cVarArr.length; i13++) {
            if (cVarArr[i13] == null || !zArr[i13]) {
                Y y = yArr[i13];
                if (y instanceof K0.j) {
                    ((K0.j) y).z(this);
                } else if (y instanceof K0.h) {
                    K0.h hVar = (K0.h) y;
                    K0.j jVar = hVar.f2013v;
                    boolean[] zArr3 = jVar.f2027u;
                    int i14 = hVar.t;
                    p117t0.a.h(zArr3[i14]);
                    jVar.f2027u[i14] = false;
                }
                yArr[i13] = null;
            }
        }
        int i15 = 0;
        while (true) {
            z6 = true;
            if (i15 >= cVarArr.length) {
                break;
            }
            Y y5 = yArr[i15];
            if ((y5 instanceof C0090t) || (y5 instanceof K0.h)) {
                int iC = c(iArr3, i15);
                if (iC == -1) {
                    z8 = yArr[i15] instanceof C0090t;
                } else {
                    Y y6 = yArr[i15];
                    z8 = (y6 instanceof K0.h) && ((K0.h) y6).r == yArr[iC];
                }
                if (!z8) {
                    Y y7 = yArr[i15];
                    if (y7 instanceof K0.h) {
                        K0.h hVar2 = (K0.h) y7;
                        K0.j jVar2 = hVar2.f2013v;
                        boolean[] zArr4 = jVar2.f2027u;
                        int i16 = hVar2.t;
                        p117t0.a.h(zArr4[i16]);
                        jVar2.f2027u[i16] = false;
                    }
                    yArr[i15] = null;
                }
            }
            i15++;
        }
        int i17 = 0;
        while (i17 < cVarArr.length) {
            M0.c cVar2 = cVarArr[i17];
            if (cVar2 == null) {
                i7 = i11;
                i8 = i17;
                iArr2 = iArr3;
                z7 = z6 ? 1 : 0;
            } else {
                Y y8 = yArr[i17];
                if (y8 == null) {
                    zArr2[i17] = z6;
                    d dVar = this.f35B[iArr3[i17]];
                    int i18 = dVar.f26c;
                    if (i18 == 0) {
                        int i19 = dVar.f29f;
                        boolean z9 = i19 != i6 ? z6 ? 1 : 0 : i11;
                        if (z9 != 0) {
                            pA = this.f34A.a(i19);
                            i9 = z6 ? 1 : 0;
                        } else {
                            i9 = i11;
                            pA = null;
                        }
                        int i20 = dVar.f30g;
                        if (i20 != i6) {
                            c2 = this.f35B[i20].f31h;
                        } else {
                            p108r3.A a5 = p108r3.C.f8765s;
                            c2 = T.f8782v;
                        }
                        int size = c2.size() + i9;
                        C0427o[] c0427oArr = new C0427o[size];
                        int[] iArr4 = new int[size];
                        if (z9 != 0) {
                            c0427oArr[i11] = pA.f8260d[i11];
                            iArr4[i11] = 5;
                            i10 = z6 ? 1 : 0;
                        } else {
                            i10 = i11;
                        }
                        ArrayList arrayList = new ArrayList();
                        for (int i21 = i11; i21 < c2.size(); i21++) {
                            C0427o c0427o = (C0427o) c2.get(i21);
                            c0427oArr[i10] = c0427o;
                            iArr4[i10] = 3;
                            arrayList.add(c0427o);
                            i10 += z6 ? 1 : 0;
                        }
                        if (!this.f44L.f205d || z9 == 0) {
                            tVar = null;
                        } else {
                            u uVar = this.f36D;
                            tVar = new t(uVar, uVar.r);
                        }
                        n nVar = this.f47s;
                        N0.p pVar = this.y;
                        B0.c cVar3 = this.f44L;
                        v vVar = this.f50w;
                        int i22 = this.f45M;
                        int[] iArr5 = dVar.f24a;
                        int i23 = dVar.f25b;
                        i8 = i17;
                        long j7 = this.f51x;
                        A a7 = this.t;
                        p128v0.h hVarA = ((p128v0.g) nVar.f96s).a();
                        if (a7 != null) {
                            hVarA.l(a7);
                        }
                        t tVar2 = tVar;
                        i7 = 0;
                        iArr2 = iArr3;
                        z7 = true;
                        K0.j jVar3 = new K0.j(dVar.f25b, iArr4, c0427oArr, new q((K0.d) nVar.t, pVar, cVar3, vVar, i22, iArr5, cVar2, i23, hVarA, j7, nVar.r, z9, arrayList, tVar), this, this.f52z, j6, this.f48u, this.f39G, this.f49v, this.f38F);
                        synchronized (this) {
                            this.f37E.put(jVar3, tVar2);
                        }
                        yArr[i8] = jVar3;
                    } else {
                        i7 = i11;
                        i8 = i17;
                        iArr2 = iArr3;
                        z7 = z6 ? 1 : 0;
                        if (i18 == 2) {
                            yArr[i8] = new r((B0.g) this.f46N.get(dVar.f27d), cVar2.f2332a.f8260d[i7], this.f44L.f205d);
                        }
                    }
                } else {
                    i7 = i11;
                    i8 = i17;
                    iArr2 = iArr3;
                    z7 = z6 ? 1 : 0;
                    if (y8 instanceof K0.j) {
                        ((K0.j) y8).f2028v.f113j = cVar2;
                    }
                }
            }
            i17 = i8 + 1;
            z6 = z7;
            iArr3 = iArr2;
            i11 = i7;
            i6 = -1;
        }
        int i24 = i11;
        int[] iArr6 = iArr3;
        boolean z10 = z6 ? 1 : 0;
        while (i11 < cVarArr.length) {
            if (yArr[i11] != null || cVarArr[i11] == null) {
                iArr = iArr6;
            } else {
                d dVar2 = this.f35B[iArr6[i11]];
                if (dVar2.f26c == z10) {
                    iArr = iArr6;
                    int iC2 = c(iArr, i11);
                    if (iC2 == -1) {
                        yArr[i11] = new C0090t();
                    } else {
                        K0.j jVar4 = (K0.j) yArr[iC2];
                        int i25 = dVar2.f25b;
                        boolean[] zArr5 = jVar4.f2027u;
                        X[] xArr = jVar4.f2017E;
                        int i26 = i24;
                        while (true) {
                            if (i26 >= xArr.length) {
                                throw new IllegalStateException();
                            }
                            if (jVar4.f2026s[i26] == i25) {
                                p117t0.a.h((zArr5[i26] ? 1 : 0) ^ (z10 ? 1 : 0));
                                zArr5[i26] = z10;
                                xArr[i26].y(j6, z10);
                                yArr[i11] = new K0.h(jVar4, jVar4, xArr[i26], i26);
                                break;
                            }
                            i26++;
                        }
                    }
                } else {
                    iArr = iArr6;
                }
            }
            i11++;
            iArr6 = iArr;
        }
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList();
        int length = yArr.length;
        for (int i27 = i24; i27 < length; i27++) {
            Y y9 = yArr[i27];
            if (y9 instanceof K0.j) {
                arrayList2.add((K0.j) y9);
            } else if (y9 instanceof r) {
                arrayList3.add((r) y9);
            }
        }
        K0.j[] jVarArr = new K0.j[arrayList2.size()];
        this.f41I = jVarArr;
        arrayList2.toArray(jVarArr);
        r[] rVarArr = new r[arrayList3.size()];
        this.f42J = rVarArr;
        arrayList3.toArray(rVarArr);
        Z3.e eVar = this.C;
        AbstractList abstractListN = AbstractC0460q.n(arrayList2, new c(i24));
        eVar.getClass();
        this.f43K = new C0083l(arrayList2, abstractListN);
        return j6;
    }

    @Override // J0.Z
    public final void l(a0 a0Var) {
        this.f40H.l(this);
    }

    @Override // J0.a0
    public final long m() {
        return this.f43K.m();
    }

    @Override // J0.D
    public final void n() {
        this.y.a();
    }

    /* JADX WARN: Code duplicated, block: B:21:0x0063  */
    @Override // J0.D
    public final long q(long j6, c0 c0Var) {
        long jF;
        int i6 = 0;
        for (K0.j jVar : this.f41I) {
            if (jVar.r == 2) {
                o[] oVarArr = jVar.f2028v.f112i;
                int length = oVarArr.length;
                while (i6 < length) {
                    o oVar = oVarArr[i6];
                    l lVar = oVar.f100d;
                    long j7 = oVar.f102f;
                    l lVar2 = oVar.f100d;
                    if (lVar != null) {
                        long jD = oVar.d();
                        if (jD != 0) {
                            p117t0.a.i(lVar2);
                            long jD2 = lVar2.d(j6, oVar.f101e) + j7;
                            long jF2 = oVar.f(jD2);
                            if (jF2 >= j6) {
                                jF = jF2;
                            } else {
                                if (jD != -1) {
                                    p117t0.a.i(lVar2);
                                    if (jD2 >= ((lVar2.s() + j7) + jD) - 1) {
                                        jF = jF2;
                                    }
                                }
                                jF = oVar.f(jD2 + 1);
                            }
                            return c0Var.a(j6, jF2, jF);
                        }
                    }
                    i6++;
                    j6 = j6;
                }
                break;
            }
        }
        return j6;
    }

    @Override // J0.D
    public final long s(long j6) throws Throwable {
        int i6;
        K0.a aVar;
        K0.j[] jVarArr = this.f41I;
        int length = jVarArr.length;
        int i7 = 0;
        while (i7 < length) {
            K0.j jVar = jVarArr[i7];
            X[] xArr = jVar.f2017E;
            X x5 = jVar.f2016D;
            N0.o oVar = jVar.f2031z;
            ArrayList arrayList = jVar.f2015B;
            jVar.f2023K = j6;
            if (jVar.w()) {
                jVar.f2022J = j6;
                i6 = i7;
            } else {
                int i8 = 0;
                while (true) {
                    if (i8 < arrayList.size()) {
                        aVar = (K0.a) arrayList.get(i8);
                        long j7 = aVar.f2009x;
                        i6 = i7;
                        if (j7 == j6 && aVar.f1986B == -9223372036854775807L) {
                            break;
                        }
                        if (j7 <= j6) {
                            i8++;
                            i7 = i6;
                        }
                    } else {
                        i6 = i7;
                    }
                    aVar = null;
                    break;
                }
                if (aVar != null ? x5.x(aVar.e(0)) : x5.y(j6, j6 < jVar.d())) {
                    jVar.f2024L = jVar.y(x5.m(), 0);
                    for (X x6 : xArr) {
                        x6.y(j6, true);
                    }
                } else {
                    jVar.f2022J = j6;
                    jVar.f2025M = false;
                    arrayList.clear();
                    jVar.f2024L = 0;
                    if (oVar.d()) {
                        x5.g();
                        for (X x7 : xArr) {
                            x7.g();
                        }
                        oVar.b();
                    } else {
                        oVar.t = null;
                        x5.w(false);
                        for (X x8 : jVar.f2017E) {
                            x8.w(false);
                        }
                    }
                    i7 = i6 + 1;
                }
            }
            i7 = i6 + 1;
        }
        for (r rVar : this.f42J) {
            int iB = p117t0.s.b(rVar.t, j6, true);
            rVar.f122x = iB;
            rVar.y = (rVar.f119u && iB == rVar.t.length) ? j6 : -9223372036854775807L;
        }
        return j6;
    }

    @Override // J0.D
    public final void t(long j6) throws Throwable {
        long j7;
        for (K0.j jVar : this.f41I) {
            if (!jVar.w()) {
                X x5 = jVar.f2016D;
                int i6 = x5.f1772q;
                x5.f(j6, true);
                X x6 = jVar.f2016D;
                int i7 = x6.f1772q;
                if (i7 > i6) {
                    synchronized (x6) {
                        j7 = x6.f1771p == 0 ? Long.MIN_VALUE : x6.f1770n[x6.r];
                    }
                    int i8 = 0;
                    while (true) {
                        X[] xArr = jVar.f2017E;
                        if (i8 >= xArr.length) {
                            break;
                        }
                        xArr[i8].f(j7, jVar.f2027u[i8]);
                        i8++;
                    }
                }
                int iMin = Math.min(jVar.y(i7, 0), jVar.f2024L);
                if (iMin > 0) {
                    p117t0.s.M(jVar.f2015B, 0, iMin);
                    jVar.f2024L -= iMin;
                }
            }
        }
    }

    @Override // J0.a0
    public final void u(long j6) {
        this.f43K.u(j6);
    }
}
