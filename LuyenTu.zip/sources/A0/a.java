package A0;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.language.detect.LanguageDetector;
import org.apache.tika.language.translate.Translator;
import org.apache.tika.utils.CompareUtils;
import p101q0.C0427o;
import p108r3.AbstractC0463u;
import p108r3.C0461s;
import p108r3.S;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements Comparator {
    public final /* synthetic */ int r;

    public /* synthetic */ a(int i6) {
        this.r = i6;
    }

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        switch (this.r) {
            case 0:
                B0.b bVar = (B0.b) obj;
                B0.b bVar2 = (B0.b) obj2;
                int iCompare = Integer.compare(bVar.f200c, bVar2.f200c);
                return iCompare != 0 ? iCompare : bVar.f199b.compareTo(bVar2.f199b);
            case 1:
                byte[] bArr = (byte[]) obj;
                byte[] bArr2 = (byte[]) obj2;
                if (bArr.length != bArr2.length) {
                    return bArr.length - bArr2.length;
                }
                for (int i6 = 0; i6 < bArr.length; i6++) {
                    byte b6 = bArr[i6];
                    byte b7 = bArr2[i6];
                    if (b6 != b7) {
                        return b6 - b7;
                    }
                }
                return 0;
            case 2:
                return ((C0427o) obj2).f8392i - ((C0427o) obj).f8392i;
            case 3:
                Integer num = (Integer) obj;
                Integer num2 = (Integer) obj2;
                if (num.intValue() == -1) {
                    return num2.intValue() == -1 ? 0 : -1;
                }
                if (num2.intValue() == -1) {
                    return 1;
                }
                return num.intValue() - num2.intValue();
            case 4:
                return Integer.compare(((M0.h) ((List) obj).get(0)).f2358w, ((M0.h) ((List) obj2).get(0)).f2358w);
            case 5:
                return ((M0.g) Collections.max((List) obj)).compareTo((M0.g) Collections.max((List) obj2));
            case 6:
                List list = (List) obj;
                List list2 = (List) obj2;
                int i7 = 9;
                return C0461s.f(M0.p.c((M0.p) Collections.max(list, new a(8)), (M0.p) Collections.max(list2, new a(8)))).a(list.size(), list2.size()).b((M0.p) Collections.max(list, new a(i7)), (M0.p) Collections.max(list2, new a(i7)), new a(i7)).e();
            case 7:
                return ((M0.m) ((List) obj).get(0)).compareTo((M0.m) ((List) obj2).get(0));
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                return M0.p.c((M0.p) obj, (M0.p) obj2);
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                M0.p pVar = (M0.p) obj;
                M0.p pVar2 = (M0.p) obj2;
                boolean z6 = pVar.f2392v;
                int i8 = pVar.f2383A;
                S sA = (z6 && pVar.y) ? M0.q.f2396j : M0.q.f2396j.a();
                pVar.f2393w.getClass();
                return AbstractC0463u.f8826a.b(Integer.valueOf(pVar.f2384B), Integer.valueOf(pVar2.f2384B), sA).b(Integer.valueOf(i8), Integer.valueOf(pVar2.f2383A), sA).e();
            case 10:
                return ((N0.s) obj).f2612a - ((N0.s) obj2).f2612a;
            case 11:
                return Float.compare(((N0.s) obj).f2614c, ((N0.s) obj2).f2614c);
            case 12:
                return CompareUtils.compareClassName((Translator) obj, (Translator) obj2);
            case 13:
                return CompareUtils.compareClassName((LanguageDetector) obj, (LanguageDetector) obj2);
            case 14:
                return CompareUtils.compareClassName(obj, obj2);
            case 15:
                return Integer.compare(((p095p1.d) obj2).f8132b, ((p095p1.d) obj).f8132b);
            case 16:
                return Integer.compare(((w1.d) obj).f9599a.f9602b, ((w1.d) obj2).f9599a.f9602b);
            default:
                return Long.compare(((w1.c) obj).f9596b, ((w1.c) obj2).f9596b);
        }
    }
}
