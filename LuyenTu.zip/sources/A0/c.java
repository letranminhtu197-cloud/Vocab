package A0;

import I3.C0048b;
import I3.F;
import I3.Q;
import I3.r0;
import J0.V;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.util.Base64;
import com.google.crypto.tink.shaded.protobuf.AbstractC0270h;
import com.google.crypto.tink.shaded.protobuf.C0277o;
import com.google.crypto.tink.shaded.protobuf.T;
import com.google.firebase.abt.component.AbtRegistrar;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.util.ArrayList;
import java.util.Map;
import p018d2.G;
import p045h3.C0331c;
import p053i4.v;
import p101q0.D;
import p101q0.P;
import p101q0.X;
import p108r3.AbstractC0460q;
import p108r3.C;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class c implements p104q3.e, D3.b, D2.f, p117t0.c, Q3.e, p104q3.i, R0.m {
    public final /* synthetic */ int r;

    public /* synthetic */ c(int i6) {
        this.r = i6;
    }

    public static Bitmap e(byte[] bArr, int i6) throws F0.d {
        try {
            return G.s(bArr, i6);
        } catch (D e6) {
            throw new F0.d("Could not decode image data with BitmapFactory. (data.length = " + bArr.length + ", input length = " + i6 + ")", e6);
        } catch (IOException e7) {
            throw new F0.d(e7);
        }
    }

    public A4.b a(Context context) {
        switch (this.r) {
            case 1:
                return new A4.b(context, 0);
            default:
                return new A4.c(context, 0);
        }
    }

    @Override // p117t0.c
    public void accept(Object obj) {
        ((V) obj).f1750b.getClass();
    }

    @Override // p104q3.e, D2.f
    public Object apply(Object obj) {
        switch (this.r) {
            case 0:
                return C.u(Integer.valueOf(((K0.j) obj).r));
            case 6:
                D0.s sVar = (D0.s) obj;
                sVar.l();
                return C.n(AbstractC0460q.n(sVar.f748Z.f1831b, new c(18)));
            case 7:
                Cursor cursorRawQuery = ((SQLiteDatabase) obj).rawQuery("SELECT distinct t._id, t.backend_name, t.priority, t.extras FROM transport_contexts AS t, events AS e WHERE e.context_id = t._id", new String[0]);
                try {
                    ArrayList arrayList = new ArrayList();
                    while (cursorRawQuery.moveToNext()) {
                        C0331c c0331cA = p135w2.i.a();
                        c0331cA.A(cursorRawQuery.getString(1));
                        c0331cA.t = G2.a.b(cursorRawQuery.getInt(2));
                        String string = cursorRawQuery.getString(3);
                        c0331cA.f6060u = string == null ? null : Base64.decode(string, 0);
                        arrayList.add(c0331cA.h());
                        break;
                    }
                    return arrayList;
                } finally {
                    cursorRawQuery.close();
                }
            case 16:
                return ((R0.p) obj).a().getClass().getSimpleName();
            case 18:
                return Integer.valueOf(((P) obj).f8259c);
            case 19:
                return Long.valueOf(((p089o1.a) obj).f7983b);
            default:
                return Long.valueOf(((p089o1.a) obj).f7984c);
        }
    }

    @Override // R0.m
    public Constructor b() {
        if (Boolean.TRUE.equals(Class.forName("androidx.media3.decoder.flac.FlacLibrary").getMethod("isAvailable", null).invoke(null, null))) {
            return Class.forName("androidx.media3.decoder.flac.FlacExtractor").asSubclass(R0.p.class).getConstructor(Integer.TYPE);
        }
        return null;
    }

    public A4.d c(Context context, A4.b bVar) {
        switch (this.r) {
            case 3:
                return new A4.d(context, bVar);
            default:
                return new A4.f(context, bVar);
        }
    }

    @Override // D3.b
    public p136w3.b d(D3.p pVar) throws GeneralSecurityException {
        switch (this.r) {
            case 5:
                if (!((String) pVar.f833a).equals("type.googleapis.com/google.crypto.tink.AesSivKey")) {
                    throw new IllegalArgumentException("Wrong type URL in call to AesSivParameters.parseParameters");
                }
                try {
                    F fB = F.B((AbstractC0270h) pVar.f836d, C0277o.a());
                    if (fB.z() != 0) {
                        throw new GeneralSecurityException("Only version 0 keys are accepted");
                    }
                    int size = fB.y().size();
                    if (size != 32 && size != 48 && size != 64) {
                        throw new InvalidAlgorithmParameterException(String.format("Invalid key size %d; only 32-byte, 48-byte and 64-byte AES-SIV keys are supported", Integer.valueOf(size)));
                    }
                    r0 r0Var = (r0) pVar.f838f;
                    Map map = B3.g.f342e;
                    if (!map.containsKey(r0Var)) {
                        throw new GeneralSecurityException("Unable to parse OutputPrefixType: " + r0Var.b());
                    }
                    B3.e eVar = (B3.e) map.get(r0Var);
                    if (eVar == null) {
                        throw new GeneralSecurityException("Variant is not set");
                    }
                    B3.f fVar = new B3.f(size, eVar);
                    A4.d dVar = new A4.d(3, false);
                    dVar.t = null;
                    dVar.f177u = null;
                    dVar.f176s = fVar;
                    dVar.t = new i(K3.a.a(fB.y().i()), 8);
                    dVar.f177u = (Integer) pVar.f834b;
                    return dVar.r();
                } catch (com.google.crypto.tink.shaded.protobuf.C unused) {
                    throw new GeneralSecurityException("Parsing AesSivKey failed");
                }
            case 10:
                if (!((String) pVar.f833a).equals("type.googleapis.com/google.crypto.tink.AesCmacKey")) {
                    throw new IllegalArgumentException("Wrong type URL in call to AesCmacParameters.parseParameters");
                }
                try {
                    C0048b c0048bD = C0048b.D((AbstractC0270h) pVar.f836d, C0277o.a());
                    if (c0048bD.B() != 0) {
                        throw new GeneralSecurityException("Only version 0 keys are accepted");
                    }
                    A4.d dVar2 = new A4.d(6, false);
                    dVar2.f176s = null;
                    dVar2.t = null;
                    dVar2.f177u = E3.c.f1110f;
                    dVar2.Q(c0048bD.z().size());
                    int iY = c0048bD.A().y();
                    if (iY < 10 || 16 < iY) {
                        throw new GeneralSecurityException(T.g("Invalid tag size for AesCmacParameters: ", iY));
                    }
                    dVar2.t = Integer.valueOf(iY);
                    dVar2.f177u = E3.e.a((r0) pVar.f838f);
                    E3.d dVarT = dVar2.t();
                    A4.d dVar3 = new A4.d(5, false);
                    dVar3.t = null;
                    dVar3.f177u = null;
                    dVar3.f176s = dVarT;
                    dVar3.t = new i(K3.a.a(c0048bD.z().i()), 8);
                    dVar3.f177u = (Integer) pVar.f834b;
                    return dVar3.s();
                } catch (com.google.crypto.tink.shaded.protobuf.C | IllegalArgumentException unused2) {
                    throw new GeneralSecurityException("Parsing AesCmacKey failed");
                }
            default:
                if (!((String) pVar.f833a).equals("type.googleapis.com/google.crypto.tink.HmacKey")) {
                    throw new IllegalArgumentException("Wrong type URL in call to HmacProtoSerialization.parseKey");
                }
                try {
                    Q qE = Q.E((AbstractC0270h) pVar.f836d, C0277o.a());
                    if (qE.C() != 0) {
                        throw new GeneralSecurityException("Only version 0 keys are accepted");
                    }
                    v vVar = new v();
                    vVar.r = null;
                    vVar.f6368s = null;
                    vVar.t = null;
                    vVar.f6369u = E3.c.o;
                    vVar.r = Integer.valueOf(qE.A().size());
                    vVar.f6368s = Integer.valueOf(qE.B().A());
                    vVar.t = E3.k.a(qE.B().z());
                    vVar.f6369u = E3.k.b((r0) pVar.f838f);
                    E3.j jVarM = vVar.m();
                    A4.d dVar4 = new A4.d(7, false);
                    dVar4.t = null;
                    dVar4.f177u = null;
                    dVar4.f176s = jVarM;
                    dVar4.t = new i(K3.a.a(qE.A().i()), 8);
                    dVar4.f177u = (Integer) pVar.f834b;
                    return dVar4.u();
                } catch (com.google.crypto.tink.shaded.protobuf.C | IllegalArgumentException unused3) {
                    throw new GeneralSecurityException("Parsing HmacKey failed");
                }
        }
    }

    @Override // Q3.e
    public Object g(D3.p pVar) {
        return AbtRegistrar.lambda$getComponents$0(pVar);
    }

    @Override // p104q3.i
    public Object get() {
        try {
            Class<?> cls = Class.forName("androidx.media3.effect.DefaultVideoFrameProcessor$Factory$Builder");
            Object objInvoke = cls.getMethod("build", null).invoke(cls.getConstructor(null).newInstance(null), null);
            objInvoke.getClass();
            return (X) objInvoke;
        } catch (Exception e6) {
            throw new IllegalStateException(e6);
        }
    }
}
