package A0;

import J0.C0093w;
import android.net.Uri;
import java.io.IOException;

/* JADX INFO: loaded from: classes.dex */
public final class g implements N0.j {
    public final /* synthetic */ k r;

    public /* synthetic */ g(k kVar) {
        this.r = kVar;
    }

    @Override // N0.j
    public N0.i A(N0.l lVar, long j6, long j7, IOException iOException, int i6) {
        N0.r rVar = (N0.r) lVar;
        k kVar = this.r;
        C0.e eVar = kVar.f88q;
        long j8 = rVar.r;
        Uri uri = rVar.f2609u.t;
        eVar.h(new C0093w(j7), rVar.t, iOException, true);
        kVar.f85m.getClass();
        kVar.w(iOException);
        return N0.o.f2605v;
    }

    @Override // N0.j
    public void D(N0.l lVar, long j6, long j7) {
        N0.r rVar = (N0.r) lVar;
        k kVar = this.r;
        long j8 = rVar.r;
        Uri uri = rVar.f2609u.t;
        C0093w c0093w = new C0093w(j7);
        kVar.f85m.getClass();
        kVar.f88q.e(c0093w, rVar.t, -1, null, 0, null, -9223372036854775807L, -9223372036854775807L);
        kVar.f75L = ((Long) rVar.f2611w).longValue() - j6;
        kVar.x(true);
    }

    public void a() {
        long j6;
        k kVar = this.r;
        synchronized (O0.a.f2774b) {
            try {
                j6 = O0.a.f2775c ? O0.a.f2776d : -9223372036854775807L;
            } catch (Throwable th) {
                throw th;
            }
        }
        kVar.f75L = j6;
        kVar.x(true);
    }

    @Override // N0.j
    public void o(N0.l lVar, long j6, long j7, boolean z6) {
        this.r.v((N0.r) lVar, j7);
    }
}
