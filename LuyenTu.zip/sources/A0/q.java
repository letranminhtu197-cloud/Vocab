package A0;

import J0.C0073b;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import p053i4.v;
import p101q0.C;
import p101q0.C0427o;

/* JADX INFO: loaded from: classes.dex */
public final class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final N0.p f104a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final v f105b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int[] f106c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f107d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final p128v0.h f108e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final long f109f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f110g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final t f111h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final o[] f112i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public M0.c f113j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public B0.c f114k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f115l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public C0073b f116m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f117n;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [A0.q, java.lang.Object] */
    public q(K0.d dVar, N0.p pVar, B0.c cVar, v vVar, int i6, int[] iArr, M0.c cVar2, int i7, p128v0.h hVar, long j6, int i8, boolean z6, ArrayList arrayList, t tVar) {
        p033f5.f fVar;
        o[] oVarArr;
        R0.p kVar;
        C0427o c0427o;
        R0.p aVar;
        K0.e eVar;
        ?? obj = new Object();
        obj.f104a = pVar;
        obj.f114k = cVar;
        obj.f105b = vVar;
        obj.f106c = iArr;
        obj.f113j = cVar2;
        obj.f107d = i7;
        obj.f108e = hVar;
        obj.f115l = i6;
        obj.f109f = j6;
        obj.f110g = i8;
        t tVar2 = tVar;
        obj.f111h = tVar2;
        long jD = cVar.d(i6);
        ArrayList arrayListA = obj.a();
        int[] iArr2 = cVar2.f2334c;
        obj.f112i = new o[iArr2.length];
        int i9 = 0;
        int i10 = 0;
        q qVar = obj;
        while (i10 < qVar.f112i.length) {
            B0.m mVar = (B0.m) arrayListA.get(iArr2[i10]);
            B0.b bVarN = vVar.N(mVar.f247s);
            o[] oVarArr2 = qVar.f112i;
            B0.b bVar = bVarN == null ? (B0.b) mVar.f247s.get(i9) : bVarN;
            C0427o c0427o2 = mVar.r;
            p033f5.f fVar2 = (p033f5.f) dVar.t;
            String str = c0427o2.f8395l;
            if (C.j(str)) {
                if (dVar.f1996s) {
                    aVar = new p089o1.i(fVar2.c(c0427o2), c0427o2);
                } else {
                    arrayListA = arrayListA;
                    eVar = null;
                    mVar = mVar;
                    oVarArr = oVarArr2;
                }
                long j7 = jD;
                int i11 = i10;
                oVarArr[i11] = new o(j7, mVar, bVar, eVar, 0L, mVar.b());
                i10 = i11 + 1;
                qVar = this;
                arrayListA = arrayListA;
                tVar2 = tVar;
                jD = j7;
                i9 = 0;
            } else {
                if (str != null && (str.startsWith("video/webm") || str.startsWith("audio/webm") || str.startsWith("application/webm") || str.startsWith("video/x-matroska") || str.startsWith("audio/x-matroska") || str.startsWith("application/x-matroska"))) {
                    arrayListA = arrayListA;
                    c0427o = c0427o2;
                    oVarArr = oVarArr2;
                    fVar = fVar2;
                    kVar = new p057j1.d(fVar, dVar.f1996s ? 1 : 3);
                } else if (Objects.equals(str, "image/jpeg")) {
                    aVar = new V0.a(1);
                } else if (Objects.equals(str, "image/png")) {
                    kVar = new V0.a(1, (byte) 0);
                    oVarArr = oVarArr2;
                    c0427o = c0427o2;
                    fVar = fVar2;
                } else {
                    arrayListA = arrayListA;
                    int i12 = z6 ? 4 : 0;
                    fVar = fVar2;
                    oVarArr = oVarArr2;
                    kVar = new p070l1.k(fVar, dVar.f1996s ? i12 : i12 | 32, null, arrayList, tVar2);
                    c0427o = c0427o2;
                }
                if (dVar.f1996s && !C.j(str) && !(kVar.a() instanceof p070l1.k) && !(kVar.a() instanceof p057j1.d)) {
                    kVar = new p089o1.n(kVar, fVar);
                }
                eVar = new K0.e(kVar, i7, c0427o);
                long j8 = jD;
                int i13 = i10;
                oVarArr[i13] = new o(j8, mVar, bVar, eVar, 0L, mVar.b());
                i10 = i13 + 1;
                qVar = this;
                arrayListA = arrayListA;
                tVar2 = tVar;
                jD = j8;
                i9 = 0;
            }
            kVar = aVar;
            oVarArr = oVarArr2;
            c0427o = c0427o2;
            fVar = fVar2;
            if (dVar.f1996s) {
                kVar = new p089o1.n(kVar, fVar);
            }
            eVar = new K0.e(kVar, i7, c0427o);
            long j9 = jD;
            int i14 = i10;
            oVarArr[i14] = new o(j9, mVar, bVar, eVar, 0L, mVar.b());
            i10 = i14 + 1;
            qVar = this;
            arrayListA = arrayListA;
            tVar2 = tVar;
            jD = j9;
            i9 = 0;
        }
    }

    public final ArrayList a() {
        List list = this.f114k.b(this.f115l).f233c;
        ArrayList arrayList = new ArrayList();
        for (int i6 : this.f106c) {
            arrayList.addAll(((B0.a) list.get(i6)).f194c);
        }
        return arrayList;
    }

    public final o b(int i6) {
        o[] oVarArr = this.f112i;
        o oVar = oVarArr[i6];
        B0.b bVarN = this.f105b.N(oVar.f98b.f247s);
        if (bVarN == null || bVarN.equals(oVar.f99c)) {
            return oVar;
        }
        o oVar2 = new o(oVar.f101e, oVar.f98b, bVarN, oVar.f97a, oVar.f102f, oVar.f100d);
        oVarArr[i6] = oVar2;
        return oVar2;
    }
}
