package A0;

import C1.C0013n;
import C1.I;
import N5.x;
import N5.y;
import android.content.Context;
import android.media.AudioAttributes;
import android.os.Build;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.inputmethod.InputMethodManager;
import java.security.GeneralSecurityException;
import java.security.Provider;
import java.security.Security;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import org.apache.tika.pipes.PipesServer;
import p030f0.AbstractComponentCallbacksC0325s;
import p030f0.D;
import p030f0.H;
import p068l.N;
import p101q0.AbstractC0415c;
import p101q0.AbstractC0416d;
import p101q0.C0417e;

/* JADX INFO: loaded from: classes.dex */
public final class i implements l, p146y2.b, G4.c, J3.h, p091o3.d, W4.b, W4.o, p029f.b, N, p091o3.a {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public Object f64s;

    public /* synthetic */ i(Object obj, int i6) {
        this.r = i6;
        this.f64s = obj;
    }

    public static boolean t(int i6) {
        return (48 <= i6 && i6 <= 57) || i6 == 35 || i6 == 42;
    }

    @Override // G4.c
    public void a(Object obj) {
        ((W4.p) this.f64s).a(obj);
    }

    @Override // G4.c
    public void b(Object obj, String str) {
        ((W4.p) this.f64s).c("sqlite_error", str, obj);
    }

    @Override // A0.l
    public long c(long j6) {
        return 0L;
    }

    @Override // A0.l
    public long d(long j6, long j7) {
        return 0L;
    }

    @Override // p068l.N
    public void e(p062k.i iVar, p062k.j jVar) {
        p062k.f fVar = (p062k.f) this.f64s;
        Handler handler = fVar.f7159w;
        handler.removeCallbacksAndMessages(null);
        ArrayList arrayList = fVar.y;
        int size = arrayList.size();
        int i6 = 0;
        while (true) {
            if (i6 >= size) {
                i6 = -1;
                break;
            } else if (iVar == ((p062k.e) arrayList.get(i6)).f7138b) {
                break;
            } else {
                i6++;
            }
        }
        if (i6 == -1) {
            return;
        }
        int i7 = i6 + 1;
        handler.postAtTime(new F4.m(this, i7 < arrayList.size() ? (p062k.e) arrayList.get(i7) : null, jVar, iVar, 1), iVar, SystemClock.uptimeMillis() + 200);
    }

    @Override // p091o3.a
    public /* bridge */ /* synthetic */ Object f(p091o3.i iVar) {
        ArrayList arrayList = new ArrayList();
        arrayList.addAll((List) this.f64s);
        return android.support.v4.media.session.b.D(arrayList);
    }

    @Override // p067k5.a
    public Object get() {
        return new D2.j(Integer.valueOf(D2.j.f806u).intValue(), (Context) ((p067k5.a) this.f64s).get(), "com.google.android.datatransport.events");
    }

    @Override // p068l.N
    public void h(p062k.i iVar, MenuItem menuItem) {
        ((p062k.f) this.f64s).f7159w.removeCallbacksAndMessages(iVar);
    }

    @Override // p029f.b
    public void i(Object obj) {
        p029f.a aVar = (p029f.a) obj;
        H h7 = (H) this.f64s;
        D d6 = (D) h7.f5547E.pollLast();
        if (d6 == null) {
            Log.w("FragmentManager", "No Activities were started for result for " + this);
            return;
        }
        String str = d6.r;
        int i6 = d6.f5540s;
        AbstractComponentCallbacksC0325s abstractComponentCallbacksC0325sR = h7.f5560c.r(str);
        if (abstractComponentCallbacksC0325sR != null) {
            abstractComponentCallbacksC0325sR.p(i6, aVar.r, aVar.f5520s);
            return;
        }
        Log.w("FragmentManager", "Activity result delivered for unknown Fragment " + str);
    }

    @Override // A0.l
    public long j(long j6, long j7) {
        return 0L;
    }

    @Override // J3.h
    public Object k(String str) throws GeneralSecurityException {
        String[] strArr = {"GmsCore_OpenSSL", "AndroidOpenSSL", "Conscrypt"};
        ArrayList arrayList = new ArrayList();
        int i6 = 0;
        for (int i7 = 0; i7 < 3; i7++) {
            Provider provider = Security.getProvider(strArr[i7]);
            if (provider != null) {
                arrayList.add(provider);
            }
        }
        int size = arrayList.size();
        Exception exc = null;
        while (i6 < size) {
            Object obj = arrayList.get(i6);
            i6++;
            try {
                return ((Z3.e) this.f64s).m(str, (Provider) obj);
            } catch (Exception e6) {
                if (exc == null) {
                    exc = e6;
                }
            }
        }
        throw new GeneralSecurityException("No good Provider found.", exc);
    }

    @Override // W4.b
    public void l(Object obj, V4.d dVar) {
        A4.d dVar2 = (A4.d) this.f64s;
        if (((io.flutter.view.b) dVar2.f177u) == null) {
            dVar.m(null);
            return;
        }
        HashMap map = (HashMap) obj;
        String str = (String) map.get("type");
        HashMap map2 = (HashMap) map.get("data");
        str.getClass();
        switch (str) {
            case "tooltip":
                String str2 = (String) map2.get("message");
                if (str2 != null) {
                    io.flutter.view.h hVar = (io.flutter.view.h) ((io.flutter.view.b) dVar2.f177u).f6538a;
                    if (Build.VERSION.SDK_INT < 28) {
                        AccessibilityEvent accessibilityEventD = hVar.d(0, 32);
                        accessibilityEventD.getText().add(str2);
                        hVar.h(accessibilityEventD);
                    }
                    break;
                }
                break;
            case "announce":
                String str3 = (String) map2.get("message");
                if (str3 != null) {
                    io.flutter.view.b bVar = (io.flutter.view.b) dVar2.f177u;
                    if (Build.VERSION.SDK_INT >= 36) {
                        bVar.getClass();
                        Log.w("AccessibilityBridge", "Using AnnounceSemanticsEvent for accessibility is deprecated on Android. Migrate to using semantic properties for a more robust and accessible user experience.\nFlutter: If you are unsure why you are seeing this bug, it might be because you are using a widget that calls this method. See https://github.com/flutter/flutter/issues/165510 for more details.\nAndroid documentation: https://developer.android.com/reference/android/view/View#announceForAccessibility(java.lang.CharSequence)");
                    }
                    ((io.flutter.view.h) bVar.f6538a).f6621a.announceForAccessibility(str3);
                    break;
                }
                break;
            case "tap":
                Integer num = (Integer) map.get("nodeId");
                if (num != null) {
                    io.flutter.view.b bVar2 = (io.flutter.view.b) dVar2.f177u;
                    ((io.flutter.view.h) bVar2.f6538a).g(num.intValue(), 1);
                    break;
                }
                break;
            case "focus":
                Integer num2 = (Integer) map.get("nodeId");
                if (num2 != null) {
                    io.flutter.view.b bVar3 = (io.flutter.view.b) dVar2.f177u;
                    ((io.flutter.view.h) bVar3.f6538a).g(num2.intValue(), 8);
                    break;
                }
                break;
            case "longPress":
                Integer num3 = (Integer) map.get("nodeId");
                if (num3 != null) {
                    io.flutter.view.b bVar4 = (io.flutter.view.b) dVar2.f177u;
                    ((io.flutter.view.h) bVar4.f6538a).g(num3.intValue(), 2);
                    break;
                }
                break;
        }
        dVar.m(null);
    }

    @Override // A0.l
    public long m(long j6, long j7) {
        return -9223372036854775807L;
    }

    @Override // A0.l
    public B0.j n(long j6) {
        return (B0.j) this.f64s;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public void o(I i6, p116s5.c cVar) {
        C0013n c0013n;
        if (cVar instanceof C0013n) {
            c0013n = (C0013n) cVar;
            int i7 = c0013n.f504w;
            if ((i7 & Integer.MIN_VALUE) != 0) {
                c0013n.f504w = i7 - Integer.MIN_VALUE;
            } else {
                c0013n = new C0013n(this, cVar);
            }
        } else {
            c0013n = new C0013n(this, cVar);
        }
        Object obj = c0013n.f502u;
        int i8 = c0013n.f504w;
        if (i8 != 0) {
            if (i8 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            X2.a.O(obj);
            throw new D3.u();
        }
        X2.a.O(obj);
        x xVar = (x) this.f64s;
        c0013n.f504w = 1;
        xVar.b(i6, c0013n);
    }

    @Override // W4.o
    public void onMethodCall(W4.n nVar, W4.p pVar) {
        boolean z6 = true;
        switch (this.r) {
            case 18:
                p066k4.c cVar = (p066k4.c) this.f64s;
                if (((V4.d) cVar.f7289s) != null) {
                    String str = nVar.f3729a;
                    str.getClass();
                    switch (str) {
                        case "Scribe.isFeatureAvailable":
                            try {
                                V4.d dVar = (V4.d) cVar.f7289s;
                                if (Build.VERSION.SDK_INT >= 34) {
                                    if (((InputMethodManager) dVar.f3633s).isStylusHandwritingAvailable()) {
                                    }
                                    ((V4.h) pVar).a(Boolean.valueOf(z6));
                                    break;
                                } else {
                                    dVar.getClass();
                                }
                                z6 = false;
                                ((V4.h) pVar).a(Boolean.valueOf(z6));
                                break;
                            } catch (IllegalStateException e6) {
                                ((V4.h) pVar).c("error", e6.getMessage(), null);
                                return;
                            }
                            break;
                        case "Scribe.startStylusHandwriting":
                            if (Build.VERSION.SDK_INT >= 33) {
                                try {
                                    V4.d dVar2 = (V4.d) cVar.f7289s;
                                    ((InputMethodManager) dVar2.f3633s).startStylusHandwriting((View) dVar2.t);
                                    ((V4.h) pVar).a(null);
                                } catch (IllegalStateException e7) {
                                    ((V4.h) pVar).c("error", e7.getMessage(), null);
                                    return;
                                }
                                break;
                            } else {
                                ((V4.h) pVar).c("error", "Requires API level 33 or higher.", null);
                                break;
                            }
                            break;
                        case "Scribe.isStylusHandwritingAvailable":
                            if (Build.VERSION.SDK_INT >= 34) {
                                try {
                                    ((V4.h) pVar).a(Boolean.valueOf(((InputMethodManager) ((V4.d) cVar.f7289s).f3633s).isStylusHandwritingAvailable()));
                                } catch (IllegalStateException e8) {
                                    ((V4.h) pVar).c("error", e8.getMessage(), null);
                                    return;
                                }
                                break;
                            } else {
                                ((V4.h) pVar).c("error", "Requires API level 34 or higher.", null);
                                break;
                            }
                            break;
                        default:
                            ((V4.h) pVar).b();
                            break;
                    }
                }
                break;
            default:
                p066k4.c cVar2 = (p066k4.c) this.f64s;
                if (((io.flutter.plugin.editing.g) cVar2.f7289s) != null) {
                    String str2 = nVar.f3729a;
                    Object obj = nVar.f3730b;
                    str2.getClass();
                    if (!str2.equals("SpellCheck.initiateSpellCheck")) {
                        ((V4.h) pVar).b();
                    } else {
                        try {
                            ArrayList arrayList = (ArrayList) obj;
                            ((io.flutter.plugin.editing.g) cVar2.f7289s).a((String) arrayList.get(0), (String) arrayList.get(1), (V4.h) pVar);
                        } catch (IllegalStateException e9) {
                            ((V4.h) pVar).c("error", e9.getMessage(), null);
                        }
                    }
                    break;
                }
                break;
        }
    }

    @Override // p091o3.d
    public void p(p091o3.i iVar) {
        ((CountDownLatch) this.f64s).countDown();
    }

    @Override // A0.l
    public boolean q() {
        return true;
    }

    public void r(Set set) {
        Object objE;
        int[] iArr;
        A5.h.e(set, "tableIds");
        if (set.isEmpty()) {
            return;
        }
        x xVar = (x) this.f64s;
        do {
            objE = xVar.e();
            int[] iArr2 = (int[]) objE;
            int length = iArr2.length;
            iArr = new int[length];
            for (int i6 = 0; i6 < length; i6++) {
                iArr[i6] = set.contains(Integer.valueOf(i6)) ? iArr2[i6] + 1 : iArr2[i6];
            }
            P5.u uVar = O5.c.f2806b;
            if (objE == null) {
                objE = uVar;
            }
        } while (!xVar.g(objE, iArr));
    }

    @Override // A0.l
    public long s() {
        return 0L;
    }

    @Override // A0.l
    public long w(long j6) {
        return 1L;
    }

    @Override // A0.l
    public long x(long j6, long j7) {
        return 1L;
    }

    public i(N4.b bVar, int i6) {
        this.r = i6;
        switch (i6) {
            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                new W4.q(bVar, "flutter/platform_views_2", W4.x.f3738a, null).b(new M4.i(this, 17));
                break;
            default:
                M4.m mVar = new M4.m(18);
                W4.q qVar = new W4.q(bVar, "flutter/navigation", W4.l.f3728a, null);
                this.f64s = qVar;
                qVar.b(mVar);
                break;
        }
    }

    public i(int i6, byte b6) {
        this.r = i6;
        switch (i6) {
            case 11:
                this.f64s = null;
                break;
            case 24:
                this.f64s = new HashMap();
                break;
            default:
                this.f64s = new D0.d(5, 1.0f, false);
                break;
        }
    }

    public i(C0417e c0417e) {
        this.r = 29;
        AudioAttributes.Builder usage = new AudioAttributes.Builder().setContentType(c0417e.f8321a).setFlags(c0417e.f8322b).setUsage(c0417e.f8323c);
        int i6 = p117t0.s.f9002a;
        if (i6 >= 29) {
            AbstractC0415c.a(usage, 1);
        }
        if (i6 >= 32) {
            AbstractC0416d.a(usage, 0);
        }
        this.f64s = usage.build();
    }

    public i(W4.f fVar) {
        this.r = 15;
        new W4.q(fVar, "flutter/keyboard", W4.x.f3738a, null).b(new A4.b(this));
    }

    public i(UUID uuid, int i6, byte[] bArr) {
        this.r = 26;
        this.f64s = uuid;
    }

    public i(int i6) {
        this.r = 2;
        this.f64s = y.a(new int[i6]);
    }

    @Override // A0.l
    public long g(long j6, long j7) {
        return j7;
    }
}
