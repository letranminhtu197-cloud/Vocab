package A0;

import J0.AbstractC0072a;
import J0.C0073b;
import J0.C0093w;
import J0.D;
import J0.E;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.SparseArray;
import java.io.IOException;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.tika.pipes.PipesConfigBase;
import p053i4.v;
import p101q0.AbstractC0435x;
import p101q0.C0430s;
import p101q0.C0431t;
import p101q0.C0434w;
import p128v0.A;

/* JADX INFO: loaded from: classes.dex */
public final class k extends AbstractC0072a {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public N0.o f65A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public A f66B;
    public b C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public Handler f67D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public C0430s f68E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public Uri f69F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public final Uri f70G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public B0.c f71H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public boolean f72I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public long f73J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public long f74K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public long f75L;

    /* JADX INFO: renamed from: M, reason: collision with root package name */
    public int f76M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public long f77N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public int f78O;

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public C0434w f79P;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final boolean f80h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final p128v0.g f81i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final n f82j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final Z3.e f83k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final C0.i f84l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final M4.m f85m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final v f86n;
    public final long o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final long f87p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final C0.e f88q;
    public final N0.q r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final p066k4.c f89s;
    public final Object t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final SparseArray f90u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final f f91v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final f f92w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final i f93x;
    public final N0.p y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public p128v0.h f94z;

    static {
        AbstractC0435x.a("media3.exoplayer.dash");
    }

    /* JADX WARN: Type inference failed for: r2v11, types: [A0.f] */
    /* JADX WARN: Type inference failed for: r2v12, types: [A0.f] */
    public k(C0434w c0434w, p128v0.g gVar, N0.q qVar, n nVar, Z3.e eVar, C0.i iVar, M4.m mVar, long j6, long j7) {
        this.f79P = c0434w;
        this.f68E = c0434w.f8424c;
        C0431t c0431t = c0434w.f8423b;
        c0431t.getClass();
        Uri uri = c0431t.f8414a;
        this.f69F = uri;
        this.f70G = uri;
        this.f71H = null;
        this.f81i = gVar;
        this.r = qVar;
        this.f82j = nVar;
        this.f84l = iVar;
        this.f85m = mVar;
        this.o = j6;
        this.f87p = j7;
        this.f83k = eVar;
        this.f86n = new v(1);
        this.f80h = false;
        this.f88q = a(null);
        this.t = new Object();
        this.f90u = new SparseArray();
        this.f93x = new i(this, 0);
        this.f77N = -9223372036854775807L;
        this.f75L = -9223372036854775807L;
        this.f89s = new p066k4.c(this, 1);
        this.y = new K2.i(this, 2);
        final int i6 = 0;
        this.f91v = new Runnable(this) { // from class: A0.f

            /* JADX INFO: renamed from: s, reason: collision with root package name */
            public final /* synthetic */ k f53s;

            {
                this.f53s = this;
            }

            @Override // java.lang.Runnable
            public final void run() {
                switch (i6) {
                    case 0:
                        this.f53s.y();
                        break;
                    default:
                        this.f53s.x(false);
                        break;
                }
            }
        };
        final int i7 = 1;
        this.f92w = new Runnable(this) { // from class: A0.f

            /* JADX INFO: renamed from: s, reason: collision with root package name */
            public final /* synthetic */ k f53s;

            {
                this.f53s = this;
            }

            @Override // java.lang.Runnable
            public final void run() {
                switch (i7) {
                    case 0:
                        this.f53s.y();
                        break;
                    default:
                        this.f53s.x(false);
                        break;
                }
            }
        };
    }

    public static boolean t(B0.h hVar) {
        List list = hVar.f233c;
        for (int i6 = 0; i6 < list.size(); i6++) {
            int i7 = ((B0.a) list.get(i6)).f193b;
            if (i7 == 1 || i7 == 2) {
                return true;
            }
        }
        return false;
    }

    @Override // J0.AbstractC0072a
    public final D b(E e6, N0.e eVar, long j6) {
        int iIntValue = ((Integer) e6.f1666a).intValue() - this.f78O;
        C0.e eVarA = a(e6);
        C0.e eVar2 = new C0.e(this.f1782d.f382c, 0, e6);
        int i6 = this.f78O + iIntValue;
        B0.c cVar = this.f71H;
        A a5 = this.f66B;
        long j7 = this.f75L;
        y0.k kVar = this.f1785g;
        p117t0.a.i(kVar);
        e eVar3 = new e(i6, cVar, this.f86n, iIntValue, this.f82j, a5, this.f84l, eVar2, this.f85m, eVarA, j7, this.y, eVar, this.f83k, this.f93x, kVar);
        this.f90u.put(i6, eVar3);
        return eVar3;
    }

    @Override // J0.AbstractC0072a
    public final synchronized C0434w h() {
        return this.f79P;
    }

    @Override // J0.AbstractC0072a
    public final void j() {
        this.y.a();
    }

    @Override // J0.AbstractC0072a
    public final void l(A a5) {
        this.f66B = a5;
        Looper looperMyLooper = Looper.myLooper();
        y0.k kVar = this.f1785g;
        p117t0.a.i(kVar);
        C0.i iVar = this.f84l;
        iVar.a(looperMyLooper, kVar);
        iVar.b();
        if (this.f80h) {
            x(false);
            return;
        }
        this.f94z = this.f81i.a();
        this.f65A = new N0.o("DashMediaSource");
        this.f67D = p117t0.s.m(null);
        y();
    }

    @Override // J0.AbstractC0072a
    public final void n(D d6) {
        e eVar = (e) d6;
        u uVar = eVar.f36D;
        uVar.f135z = true;
        uVar.f131u.removeCallbacksAndMessages(null);
        for (K0.j jVar : eVar.f41I) {
            jVar.z(eVar);
        }
        eVar.f40H = null;
        this.f90u.remove(eVar.r);
    }

    @Override // J0.AbstractC0072a
    public final void p() {
        this.f72I = false;
        this.f94z = null;
        N0.o oVar = this.f65A;
        if (oVar != null) {
            oVar.e(null);
            this.f65A = null;
        }
        this.f73J = 0L;
        this.f74K = 0L;
        this.f69F = this.f70G;
        this.C = null;
        Handler handler = this.f67D;
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
            this.f67D = null;
        }
        this.f75L = -9223372036854775807L;
        this.f76M = 0;
        this.f77N = -9223372036854775807L;
        this.f90u.clear();
        v vVar = this.f86n;
        ((HashMap) vVar.r).clear();
        ((HashMap) vVar.f6368s).clear();
        ((HashMap) vVar.t).clear();
        this.f84l.release();
    }

    @Override // J0.AbstractC0072a
    public final synchronized void s(C0434w c0434w) {
        this.f79P = c0434w;
    }

    public final void u() {
        boolean z6;
        N0.o oVar = this.f65A;
        g gVar = new g(this);
        synchronized (O0.a.f2774b) {
            z6 = O0.a.f2775c;
        }
        if (z6) {
            gVar.a();
            return;
        }
        if (oVar == null) {
            oVar = new N0.o("SntpClient");
        }
        oVar.f(new M4.m(6), new M4.i(gVar, 11), 1);
    }

    public final void v(N0.r rVar, long j6) {
        long j7 = rVar.r;
        Uri uri = rVar.f2609u.t;
        C0093w c0093w = new C0093w(j6);
        this.f85m.getClass();
        this.f88q.c(c0093w, rVar.t, -1, null, 0, null, -9223372036854775807L, -9223372036854775807L);
    }

    public final void w(IOException iOException) {
        p117t0.a.m("DashMediaSource", "Failed to resolve time offset.", iOException);
        this.f75L = System.currentTimeMillis() - SystemClock.elapsedRealtime();
        x(true);
    }

    /* JADX WARN: Code duplicated, block: B:126:0x0291  */
    /* JADX WARN: Code duplicated, block: B:156:0x02fa  */
    /* JADX WARN: Code duplicated, block: B:159:0x0301  */
    /* JADX WARN: Code duplicated, block: B:195:0x03b8  */
    /* JADX WARN: Code duplicated, block: B:196:0x03bd  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v17 */
    /* JADX WARN: Type inference failed for: r10v18, types: [int] */
    /* JADX WARN: Type inference failed for: r10v20 */
    /* JADX WARN: Type inference failed for: r15v10, types: [int] */
    /* JADX WARN: Type inference failed for: r15v12 */
    /* JADX WARN: Type inference failed for: r15v9 */
    public final void x(boolean z6) {
        long j6;
        long jMax;
        long j7;
        boolean z7;
        boolean z8;
        long j8;
        long j9;
        long j10;
        int i6;
        long jMin;
        float f4;
        float f7;
        long jS;
        long jH;
        long jMin2;
        boolean z9;
        boolean z10 = false;
        int i7 = 0;
        while (true) {
            SparseArray sparseArray = this.f90u;
            if (i7 >= sparseArray.size()) {
                break;
            }
            int iKeyAt = sparseArray.keyAt(i7);
            if (iKeyAt >= this.f78O) {
                e eVar = (e) sparseArray.valueAt(i7);
                B0.c cVar = this.f71H;
                int i8 = iKeyAt - this.f78O;
                eVar.f44L = cVar;
                eVar.f45M = i8;
                u uVar = eVar.f36D;
                uVar.y = z10;
                uVar.f133w = cVar;
                Iterator it = uVar.f132v.entrySet().iterator();
                while (it.hasNext()) {
                    if (((Long) ((Map.Entry) it.next()).getKey()).longValue() < uVar.f133w.f209h) {
                        it.remove();
                    }
                }
                K0.j[] jVarArr = eVar.f41I;
                if (jVarArr != null) {
                    int length = jVarArr.length;
                    for (?? r10 = z10; r10 < length; r10++) {
                        q qVar = jVarArr[r10].f2028v;
                        o[] oVarArr = qVar.f112i;
                        try {
                            qVar.f114k = cVar;
                            qVar.f115l = i8;
                            long jD = cVar.d(i8);
                            ArrayList arrayListA = qVar.a();
                            for (?? r15 = z10; r15 < oVarArr.length; r15++) {
                                try {
                                    oVarArr[r15] = oVarArr[r15].a(jD, (B0.m) arrayListA.get(qVar.f113j.f2334c[r15]));
                                } catch (C0073b e6) {
                                    e = e6;
                                    qVar.f116m = e;
                                }
                            }
                        } catch (C0073b e7) {
                            e = e7;
                        }
                        z10 = false;
                    }
                    z9 = true;
                    eVar.f40H.l(eVar);
                } else {
                    z9 = true;
                }
                eVar.f46N = cVar.b(i8).f234d;
                for (r rVar : eVar.f42J) {
                    for (B0.g gVar : eVar.f46N) {
                        if (gVar.a().equals(rVar.f120v.a())) {
                            rVar.b(gVar, (cVar.f205d && i8 == cVar.f214m.size() + (-1)) ? z9 : false);
                            break;
                        }
                    }
                }
            }
            i7++;
            z10 = false;
        }
        int i9 = 1;
        B0.h hVarB = this.f71H.b(0);
        int size = this.f71H.f214m.size() - 1;
        B0.h hVarB2 = this.f71H.b(size);
        long jD2 = this.f71H.d(size);
        long jH2 = p117t0.s.H(p117t0.s.w(this.f75L));
        long jD3 = this.f71H.d(0);
        long j11 = hVarB.f232b;
        List list = hVarB.f233c;
        long jH3 = p117t0.s.H(j11);
        boolean zT = t(hVarB);
        long jMax2 = jH3;
        int i10 = 0;
        while (true) {
            long j12 = jH3;
            if (i10 >= list.size()) {
                j6 = 0;
                jMax = jMax2;
                break;
            }
            B0.a aVar = (B0.a) list.get(i10);
            j6 = 0;
            List list2 = aVar.f194c;
            int i11 = aVar.f193b;
            boolean z11 = (i11 == i9 || i11 == 2) ? false : true;
            if ((!zT || !z11) && !list2.isEmpty()) {
                l lVarB = ((B0.m) list2.get(0)).b();
                if (lVarB == null || lVarB.x(jD3, jH2) == 0) {
                    jMax = j12;
                    break;
                }
                jMax2 = Math.max(jMax2, lVarB.c(lVarB.j(jD3, jH2)) + j12);
            }
            i10++;
            jH3 = j12;
            i9 = 1;
        }
        long j13 = hVarB2.f232b;
        List list3 = hVarB2.f233c;
        long jH4 = p117t0.s.H(j13);
        boolean zT2 = t(hVarB2);
        long jMin3 = Long.MAX_VALUE;
        int i12 = 0;
        while (true) {
            if (i12 >= list3.size()) {
                j7 = jMin3;
                break;
            }
            B0.a aVar2 = (B0.a) list3.get(i12);
            boolean z12 = zT2;
            List list4 = aVar2.f194c;
            int i13 = aVar2.f193b;
            long j14 = jH4;
            boolean z13 = (i13 == 1 || i13 == 2) ? false : true;
            if ((!z12 || !z13) && !list4.isEmpty()) {
                l lVarB2 = ((B0.m) list4.get(0)).b();
                if (lVarB2 == null) {
                    j7 = j14 + jD2;
                    break;
                }
                long jX = lVarB2.x(jD2, jH2);
                if (jX == j6) {
                    j7 = j14;
                    break;
                } else {
                    long j15 = (lVarB2.j(jD2, jH2) + jX) - 1;
                    jMin3 = Math.min(jMin3, lVarB2.g(j15, jD2) + lVarB2.c(j15) + j14);
                }
            }
            i12++;
            zT2 = z12;
            jH4 = j14;
        }
        if (!this.f71H.f205d) {
            z7 = false;
            break;
        }
        int i14 = 0;
        while (true) {
            if (i14 >= list3.size()) {
                z7 = true;
                break;
            }
            l lVarB3 = ((B0.m) ((B0.a) list3.get(i14)).f194c.get(0)).b();
            if (lVarB3 == null || lVarB3.q()) {
                z7 = false;
                break;
            }
            i14++;
        }
        if (z7) {
            long j16 = this.f71H.f207f;
            if (j16 != -9223372036854775807L) {
                jMax = Math.max(jMax, j7 - p117t0.s.H(j16));
            }
        }
        long j17 = j7 - jMax;
        B0.c cVar2 = this.f71H;
        if (cVar2.f205d) {
            p117t0.a.h(cVar2.f202a != -9223372036854775807L);
            long jH5 = (jH2 - p117t0.s.H(this.f71H.f202a)) - jMax;
            C0430s c0430s = h().f8424c;
            long jS2 = p117t0.s.S(jH5);
            long j18 = c0430s.f8411c;
            if (j18 != -9223372036854775807L) {
                jMin = Math.min(jS2, j18);
            } else {
                B0.t tVar = this.f71H.f211j;
                if (tVar != null) {
                    long j19 = tVar.f269c;
                    if (j19 != -9223372036854775807L) {
                        jMin = Math.min(jS2, j19);
                    } else {
                        jMin = jS2;
                    }
                } else {
                    jMin = jS2;
                }
            }
            long jS3 = p117t0.s.S(jH5 - j17);
            if (jS3 < j6 && jMin > j6) {
                jS3 = j6;
            }
            j8 = -9223372036854775807L;
            long j20 = this.f71H.f204c;
            if (j20 != -9223372036854775807L) {
                jS3 = Math.min(jS3 + j20, jS2);
            }
            long j21 = jS3;
            long j22 = c0430s.f8410b;
            if (j22 != -9223372036854775807L) {
                j21 = p117t0.s.j(j22, j21, jS2);
            } else {
                B0.t tVar2 = this.f71H.f211j;
                if (tVar2 != null) {
                    long j23 = tVar2.f268b;
                    if (j23 != -9223372036854775807L) {
                        j21 = p117t0.s.j(j23, j21, jS2);
                    }
                }
            }
            long j24 = j21;
            long j25 = j24 > jMin ? j24 : jMin;
            long j26 = this.f68E.f8409a;
            if (j26 == -9223372036854775807L) {
                B0.c cVar3 = this.f71H;
                B0.t tVar3 = cVar3.f211j;
                if (tVar3 != null) {
                    long j27 = tVar3.f267a;
                    if (j27 != -9223372036854775807L) {
                        j26 = j27;
                    } else {
                        j26 = cVar3.f208g;
                        if (j26 == -9223372036854775807L) {
                            j26 = this.o;
                        }
                    }
                } else {
                    j26 = cVar3.f208g;
                    if (j26 == -9223372036854775807L) {
                        j26 = this.o;
                    }
                }
            }
            if (j26 < j24) {
                j26 = j24;
            }
            long j28 = this.f87p;
            long j29 = j26 > j25 ? p117t0.s.j(p117t0.s.S(jH5 - Math.min(j28, j17 / 2)), j24, j25) : j26;
            z8 = z7;
            long j30 = j25;
            float f8 = c0430s.f8412d;
            if (f8 == -3.4028235E38f) {
                B0.t tVar4 = this.f71H.f211j;
                f8 = tVar4 != null ? tVar4.f270d : -3.4028235E38f;
            }
            float f9 = c0430s.f8413e;
            if (f9 == -3.4028235E38f) {
                B0.t tVar5 = this.f71H.f211j;
                f9 = tVar5 != null ? tVar5.f271e : -3.4028235E38f;
            }
            if (f8 == -3.4028235E38f && f9 == -3.4028235E38f) {
                B0.t tVar6 = this.f71H.f211j;
                if (tVar6 == null || tVar6.f267a == -9223372036854775807L) {
                    f7 = 1.0f;
                    f4 = 1.0f;
                }
                B0.t tVar7 = new B0.t();
                tVar7.f267a = j29;
                tVar7.f268b = j24;
                tVar7.f269c = j30;
                tVar7.f270d = f7;
                tVar7.f271e = f4;
                this.f68E = new C0430s(tVar7);
                jS = p117t0.s.S(jMax) + this.f71H.f202a;
                jH = jH5 - p117t0.s.H(this.f68E.f8409a);
                jMin2 = Math.min(j28, j17 / 2);
                if (jH < jMin2) {
                    j10 = jMin2;
                    j9 = jS;
                } else {
                    j9 = jS;
                    j10 = jH;
                }
            }
            f7 = f8;
            f4 = f9;
            B0.t tVar8 = new B0.t();
            tVar8.f267a = j29;
            tVar8.f268b = j24;
            tVar8.f269c = j30;
            tVar8.f270d = f7;
            tVar8.f271e = f4;
            this.f68E = new C0430s(tVar8);
            jS = p117t0.s.S(jMax) + this.f71H.f202a;
            jH = jH5 - p117t0.s.H(this.f68E.f8409a);
            jMin2 = Math.min(j28, j17 / 2);
            if (jH < jMin2) {
                j10 = jMin2;
                j9 = jS;
            } else {
                j9 = jS;
                j10 = jH;
            }
        } else {
            z8 = z7;
            j8 = -9223372036854775807L;
            j9 = -9223372036854775807L;
            j10 = j6;
        }
        long jH6 = jMax - p117t0.s.H(hVarB.f232b);
        B0.c cVar4 = this.f71H;
        m(new h(cVar4.f202a, j9, this.f75L, this.f78O, jH6, j17, j10, cVar4, h(), this.f71H.f205d ? this.f68E : null));
        if (this.f80h) {
            return;
        }
        Handler handler = this.f67D;
        f fVar = this.f92w;
        handler.removeCallbacks(fVar);
        if (z8) {
            Handler handler2 = this.f67D;
            B0.c cVar5 = this.f71H;
            long jW = p117t0.s.w(this.f75L);
            int size2 = cVar5.f214m.size() - 1;
            B0.h hVarB3 = cVar5.b(size2);
            long j31 = hVarB3.f232b;
            List list5 = hVarB3.f233c;
            long jH7 = p117t0.s.H(j31);
            long jD4 = cVar5.d(size2);
            long jH8 = p117t0.s.H(jW);
            long jH9 = p117t0.s.H(cVar5.f202a);
            long jH10 = p117t0.s.H(5000L);
            int i15 = 0;
            while (i15 < list5.size()) {
                List list6 = ((B0.a) list5.get(i15)).f194c;
                if (list6.isEmpty()) {
                    i6 = i15;
                } else {
                    i6 = i15;
                    l lVarB4 = ((B0.m) list6.get(0)).b();
                    if (lVarB4 != null) {
                        long jM = (lVarB4.m(jD4, jH8) + (jH9 + jH7)) - jH8;
                        if (jM < jH10 - PipesConfigBase.DEFAULT_MAX_FOR_EMIT_BATCH || (jM > jH10 && jM < jH10 + PipesConfigBase.DEFAULT_MAX_FOR_EMIT_BATCH)) {
                            jH10 = jM;
                        }
                    }
                }
                i15 = i6 + 1;
            }
            handler2.postDelayed(fVar, android.support.v4.media.session.b.A(jH10, 1000L, RoundingMode.CEILING));
        }
        if (this.f72I) {
            y();
            return;
        }
        if (z6) {
            B0.c cVar6 = this.f71H;
            if (cVar6.f205d) {
                long j32 = cVar6.f206e;
                if (j32 != j8) {
                    this.f67D.postDelayed(this.f91v, Math.max(j6, (this.f73J + (j32 == j6 ? 5000L : j32)) - SystemClock.elapsedRealtime()));
                }
            }
        }
    }

    public final void y() {
        Uri uri;
        this.f67D.removeCallbacks(this.f91v);
        if (this.f65A.c()) {
            return;
        }
        if (this.f65A.d()) {
            this.f72I = true;
            return;
        }
        synchronized (this.t) {
            uri = this.f69F;
        }
        this.f72I = false;
        N0.r rVar = new N0.r(this.f94z, uri, 4, this.r);
        p066k4.c cVar = this.f89s;
        this.f85m.getClass();
        this.f65A.f(rVar, cVar, 3);
        this.f88q.j(new C0093w(rVar.f2608s), rVar.t, -1, null, 0, null, -9223372036854775807L, -9223372036854775807L);
    }
}
