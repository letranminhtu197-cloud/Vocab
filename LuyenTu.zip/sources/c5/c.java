package c5;

import C1.C0005f;
import L4.z;
import R0.l;
import W4.m;
import android.util.Log;
import com.google.crypto.tink.shaded.protobuf.T;
import io.flutter.plugins.firebase.core.FlutterFirebasePlugin;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import org.apache.tika.utils.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import p025e2.D;
import p053i4.E;
import p053i4.v;
import p074l5.j;
import p091o3.q;

/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ c f4640a = new c();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final j f4641b = new j(new C0005f(5));

    public static m a() {
        return (m) f4641b.getValue();
    }

    public static void b(c cVar, W4.f fVar, final f fVar2) {
        cVar.getClass();
        A5.h.e(fVar, "binaryMessenger");
        String strConcat = StringUtils.EMPTY;
        if (StringUtils.EMPTY.length() > 0) {
            strConcat = ".".concat(StringUtils.EMPTY);
        }
        v vVar = new v(fVar, T.x("dev.flutter.pigeon.firebase_remote_config_platform_interface.FirebaseRemoteConfigHostApi.fetch", strConcat), a(), null);
        if (fVar2 != null) {
            final int i6 = 1;
            vVar.P(new W4.b() { // from class: c5.a
                @Override // W4.b
                public final void l(Object obj, V4.d dVar) {
                    q qVarD;
                    int i7 = i6;
                    int i8 = 6;
                    int i9 = 8;
                    int i10 = 5;
                    int i11 = 4;
                    int i12 = 3;
                    int i13 = 2;
                    int i14 = 1;
                    d dVar2 = fVar2;
                    int i15 = 0;
                    switch (i7) {
                        case 0:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj2 = ((List) obj).get(0);
                            A5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            b bVar = new b(dVar, i11);
                            ((f) dVar2).getClass();
                            bVar.a(new p074l5.i(f.a(f.b((String) obj2))));
                            return;
                        case 1:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj3 = ((List) obj).get(0);
                            A5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            b bVar2 = new b(dVar, i8);
                            f fVar3 = (f) dVar2;
                            fVar3.getClass();
                            f.b((String) obj3).a().j(new C2.j(bVar2, fVar3, 7));
                            return;
                        case 2:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj4 = ((List) obj).get(0);
                            A5.h.c(obj4, "null cannot be cast to non-null type kotlin.String");
                            b bVar3 = new b(dVar, i13);
                            f fVar4 = (f) dVar2;
                            fVar4.getClass();
                            p073l4.e eVarB = f.b((String) obj4);
                            eVarB.a().m(eVarB.f7719b, new p073l4.d(eVarB)).j(new C2.j(bVar3, fVar4, 10));
                            return;
                        case 3:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj5 = ((List) obj).get(0);
                            A5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            b bVar4 = new b(dVar, 7);
                            f fVar5 = (f) dVar2;
                            fVar5.getClass();
                            p073l4.e eVarB2 = f.b((String) obj5);
                            p091o3.i iVarB = eVarB2.f7720c.b();
                            p091o3.i iVarB2 = eVarB2.f7721d.b();
                            android.support.v4.media.session.b.l0(iVarB, iVarB2).d(eVarB2.f7719b, new B2.b(eVarB2, iVarB, iVarB2, 7)).j(new C2.j(bVar4, fVar5, 13));
                            return;
                        case 4:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj6 = list.get(0);
                            A5.h.c(obj6, "null cannot be cast to non-null type kotlin.String");
                            String str = (String) obj6;
                            Object obj7 = list.get(1);
                            A5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.firebase.firebaseremoteconfig.RemoteConfigPigeonSettings");
                            i iVar = (i) obj7;
                            b bVar5 = new b(dVar, i12);
                            f fVar6 = (f) dVar2;
                            fVar6.getClass();
                            z zVar = new z(2);
                            long j6 = iVar.f4649a;
                            if (j6 < 0) {
                                throw new IllegalArgumentException(String.format("Fetch connection timeout has to be a non-negative number. %d is an invalid argument", Long.valueOf(j6)));
                            }
                            zVar.f2312a = j6;
                            zVar.a(iVar.f4650b);
                            z zVar2 = new z(zVar);
                            p073l4.e eVarB3 = f.b(str);
                            android.support.v4.media.session.b.g(eVarB3.f7719b, new D(eVarB3, zVar2, i13)).j(new C2.j(bVar5, fVar6, i9));
                            return;
                        case 5:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj8 = list2.get(0);
                            A5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            Object obj9 = list2.get(1);
                            A5.h.c(obj9, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.Any?>");
                            b bVar6 = new b(dVar, i15);
                            f fVar7 = (f) dVar2;
                            fVar7.getClass();
                            p073l4.e eVarB4 = f.b((String) obj8);
                            HashMap map = new HashMap();
                            for (Map.Entry entry : ((Map) obj9).entrySet()) {
                                Object value = entry.getValue();
                                if (value instanceof byte[]) {
                                    map.put((String) entry.getKey(), new String((byte[]) value));
                                } else {
                                    map.put((String) entry.getKey(), value.toString());
                                }
                            }
                            try {
                                p080m4.e eVarC = p080m4.f.c();
                                eVarC.f7846a = new JSONObject(map);
                                qVarD = eVarB4.f7722e.d(eVarC.a()).m(R3.i.r, new l(26));
                            } catch (JSONException e6) {
                                Log.e("FirebaseRemoteConfig", "The provided defaults map could not be processed.", e6);
                                qVarD = android.support.v4.media.session.b.D(null);
                            }
                            qVarD.j(new C2.j(bVar6, fVar7, 12));
                            return;
                        case 6:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj10 = ((List) obj).get(0);
                            A5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            b bVar7 = new b(dVar, i9);
                            f fVar8 = (f) dVar2;
                            fVar8.getClass();
                            p073l4.e eVarB5 = f.b((String) obj10);
                            p091o3.i iVarB3 = eVarB5.f7721d.b();
                            p091o3.i iVarB4 = eVarB5.f7722e.b();
                            p091o3.i iVarB5 = eVarB5.f7720c.b();
                            Executor executor = eVarB5.f7719b;
                            q qVarG = android.support.v4.media.session.b.g(executor, new p073l4.c(eVarB5, i15));
                            p014c4.c cVar2 = (p014c4.c) eVarB5.f7726i;
                            android.support.v4.media.session.b.l0(iVarB3, iVarB4, iVarB5, qVarG, cVar2.c(), cVar2.d()).l(executor, new E(qVarG, i11)).j(new C2.j(bVar7, fVar8, 11));
                            return;
                        case 7:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj11 = list3.get(0);
                            A5.h.c(obj11, "null cannot be cast to non-null type kotlin.String");
                            Object obj12 = list3.get(1);
                            A5.h.c(obj12, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.Any?>");
                            b bVar8 = new b(dVar, i14);
                            f fVar9 = (f) dVar2;
                            fVar9.getClass();
                            p073l4.e eVarB6 = f.b((String) obj11);
                            p091o3.j jVar = new p091o3.j();
                            FlutterFirebasePlugin.cachedThreadPool.execute(new B2.a((Map) obj12, eVarB6, jVar, i12));
                            q qVar = jVar.f8049a;
                            A5.h.d(qVar, "getTask(...)");
                            qVar.j(new C2.j(bVar8, fVar9, 9));
                            return;
                        default:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj13 = ((List) obj).get(0);
                            A5.h.c(obj13, "null cannot be cast to non-null type kotlin.String");
                            b bVar9 = new b(dVar, i10);
                            ((f) dVar2).getClass();
                            bVar9.a(new p074l5.i(f.d(f.b((String) obj13).b())));
                            return;
                    }
                }
            });
        } else {
            vVar.P(null);
        }
        v vVar2 = new v(fVar, T.x("dev.flutter.pigeon.firebase_remote_config_platform_interface.FirebaseRemoteConfigHostApi.fetchAndActivate", strConcat), a(), null);
        if (fVar2 != null) {
            final int i7 = 2;
            vVar2.P(new W4.b() { // from class: c5.a
                @Override // W4.b
                public final void l(Object obj, V4.d dVar) {
                    q qVarD;
                    int i8 = i7;
                    int i9 = 6;
                    int i10 = 8;
                    int i11 = 5;
                    int i12 = 4;
                    int i13 = 3;
                    int i14 = 2;
                    int i15 = 1;
                    d dVar2 = fVar2;
                    int i16 = 0;
                    switch (i8) {
                        case 0:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj2 = ((List) obj).get(0);
                            A5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            b bVar = new b(dVar, i12);
                            ((f) dVar2).getClass();
                            bVar.a(new p074l5.i(f.a(f.b((String) obj2))));
                            return;
                        case 1:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj3 = ((List) obj).get(0);
                            A5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            b bVar2 = new b(dVar, i9);
                            f fVar3 = (f) dVar2;
                            fVar3.getClass();
                            f.b((String) obj3).a().j(new C2.j(bVar2, fVar3, 7));
                            return;
                        case 2:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj4 = ((List) obj).get(0);
                            A5.h.c(obj4, "null cannot be cast to non-null type kotlin.String");
                            b bVar3 = new b(dVar, i14);
                            f fVar4 = (f) dVar2;
                            fVar4.getClass();
                            p073l4.e eVarB = f.b((String) obj4);
                            eVarB.a().m(eVarB.f7719b, new p073l4.d(eVarB)).j(new C2.j(bVar3, fVar4, 10));
                            return;
                        case 3:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj5 = ((List) obj).get(0);
                            A5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            b bVar4 = new b(dVar, 7);
                            f fVar5 = (f) dVar2;
                            fVar5.getClass();
                            p073l4.e eVarB2 = f.b((String) obj5);
                            p091o3.i iVarB = eVarB2.f7720c.b();
                            p091o3.i iVarB2 = eVarB2.f7721d.b();
                            android.support.v4.media.session.b.l0(iVarB, iVarB2).d(eVarB2.f7719b, new B2.b(eVarB2, iVarB, iVarB2, 7)).j(new C2.j(bVar4, fVar5, 13));
                            return;
                        case 4:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj6 = list.get(0);
                            A5.h.c(obj6, "null cannot be cast to non-null type kotlin.String");
                            String str = (String) obj6;
                            Object obj7 = list.get(1);
                            A5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.firebase.firebaseremoteconfig.RemoteConfigPigeonSettings");
                            i iVar = (i) obj7;
                            b bVar5 = new b(dVar, i13);
                            f fVar6 = (f) dVar2;
                            fVar6.getClass();
                            z zVar = new z(2);
                            long j6 = iVar.f4649a;
                            if (j6 < 0) {
                                throw new IllegalArgumentException(String.format("Fetch connection timeout has to be a non-negative number. %d is an invalid argument", Long.valueOf(j6)));
                            }
                            zVar.f2312a = j6;
                            zVar.a(iVar.f4650b);
                            z zVar2 = new z(zVar);
                            p073l4.e eVarB3 = f.b(str);
                            android.support.v4.media.session.b.g(eVarB3.f7719b, new D(eVarB3, zVar2, i14)).j(new C2.j(bVar5, fVar6, i10));
                            return;
                        case 5:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj8 = list2.get(0);
                            A5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            Object obj9 = list2.get(1);
                            A5.h.c(obj9, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.Any?>");
                            b bVar6 = new b(dVar, i16);
                            f fVar7 = (f) dVar2;
                            fVar7.getClass();
                            p073l4.e eVarB4 = f.b((String) obj8);
                            HashMap map = new HashMap();
                            for (Map.Entry entry : ((Map) obj9).entrySet()) {
                                Object value = entry.getValue();
                                if (value instanceof byte[]) {
                                    map.put((String) entry.getKey(), new String((byte[]) value));
                                } else {
                                    map.put((String) entry.getKey(), value.toString());
                                }
                            }
                            try {
                                p080m4.e eVarC = p080m4.f.c();
                                eVarC.f7846a = new JSONObject(map);
                                qVarD = eVarB4.f7722e.d(eVarC.a()).m(R3.i.r, new l(26));
                            } catch (JSONException e6) {
                                Log.e("FirebaseRemoteConfig", "The provided defaults map could not be processed.", e6);
                                qVarD = android.support.v4.media.session.b.D(null);
                            }
                            qVarD.j(new C2.j(bVar6, fVar7, 12));
                            return;
                        case 6:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj10 = ((List) obj).get(0);
                            A5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            b bVar7 = new b(dVar, i10);
                            f fVar8 = (f) dVar2;
                            fVar8.getClass();
                            p073l4.e eVarB5 = f.b((String) obj10);
                            p091o3.i iVarB3 = eVarB5.f7721d.b();
                            p091o3.i iVarB4 = eVarB5.f7722e.b();
                            p091o3.i iVarB5 = eVarB5.f7720c.b();
                            Executor executor = eVarB5.f7719b;
                            q qVarG = android.support.v4.media.session.b.g(executor, new p073l4.c(eVarB5, i16));
                            p014c4.c cVar2 = (p014c4.c) eVarB5.f7726i;
                            android.support.v4.media.session.b.l0(iVarB3, iVarB4, iVarB5, qVarG, cVar2.c(), cVar2.d()).l(executor, new E(qVarG, i12)).j(new C2.j(bVar7, fVar8, 11));
                            return;
                        case 7:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj11 = list3.get(0);
                            A5.h.c(obj11, "null cannot be cast to non-null type kotlin.String");
                            Object obj12 = list3.get(1);
                            A5.h.c(obj12, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.Any?>");
                            b bVar8 = new b(dVar, i15);
                            f fVar9 = (f) dVar2;
                            fVar9.getClass();
                            p073l4.e eVarB6 = f.b((String) obj11);
                            p091o3.j jVar = new p091o3.j();
                            FlutterFirebasePlugin.cachedThreadPool.execute(new B2.a((Map) obj12, eVarB6, jVar, i13));
                            q qVar = jVar.f8049a;
                            A5.h.d(qVar, "getTask(...)");
                            qVar.j(new C2.j(bVar8, fVar9, 9));
                            return;
                        default:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj13 = ((List) obj).get(0);
                            A5.h.c(obj13, "null cannot be cast to non-null type kotlin.String");
                            b bVar9 = new b(dVar, i11);
                            ((f) dVar2).getClass();
                            bVar9.a(new p074l5.i(f.d(f.b((String) obj13).b())));
                            return;
                    }
                }
            });
        } else {
            vVar2.P(null);
        }
        v vVar3 = new v(fVar, T.x("dev.flutter.pigeon.firebase_remote_config_platform_interface.FirebaseRemoteConfigHostApi.activate", strConcat), a(), null);
        if (fVar2 != null) {
            final int i8 = 3;
            vVar3.P(new W4.b() { // from class: c5.a
                @Override // W4.b
                public final void l(Object obj, V4.d dVar) {
                    q qVarD;
                    int i9 = i8;
                    int i10 = 6;
                    int i11 = 8;
                    int i12 = 5;
                    int i13 = 4;
                    int i14 = 3;
                    int i15 = 2;
                    int i16 = 1;
                    d dVar2 = fVar2;
                    int i17 = 0;
                    switch (i9) {
                        case 0:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj2 = ((List) obj).get(0);
                            A5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            b bVar = new b(dVar, i13);
                            ((f) dVar2).getClass();
                            bVar.a(new p074l5.i(f.a(f.b((String) obj2))));
                            return;
                        case 1:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj3 = ((List) obj).get(0);
                            A5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            b bVar2 = new b(dVar, i10);
                            f fVar3 = (f) dVar2;
                            fVar3.getClass();
                            f.b((String) obj3).a().j(new C2.j(bVar2, fVar3, 7));
                            return;
                        case 2:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj4 = ((List) obj).get(0);
                            A5.h.c(obj4, "null cannot be cast to non-null type kotlin.String");
                            b bVar3 = new b(dVar, i15);
                            f fVar4 = (f) dVar2;
                            fVar4.getClass();
                            p073l4.e eVarB = f.b((String) obj4);
                            eVarB.a().m(eVarB.f7719b, new p073l4.d(eVarB)).j(new C2.j(bVar3, fVar4, 10));
                            return;
                        case 3:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj5 = ((List) obj).get(0);
                            A5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            b bVar4 = new b(dVar, 7);
                            f fVar5 = (f) dVar2;
                            fVar5.getClass();
                            p073l4.e eVarB2 = f.b((String) obj5);
                            p091o3.i iVarB = eVarB2.f7720c.b();
                            p091o3.i iVarB2 = eVarB2.f7721d.b();
                            android.support.v4.media.session.b.l0(iVarB, iVarB2).d(eVarB2.f7719b, new B2.b(eVarB2, iVarB, iVarB2, 7)).j(new C2.j(bVar4, fVar5, 13));
                            return;
                        case 4:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj6 = list.get(0);
                            A5.h.c(obj6, "null cannot be cast to non-null type kotlin.String");
                            String str = (String) obj6;
                            Object obj7 = list.get(1);
                            A5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.firebase.firebaseremoteconfig.RemoteConfigPigeonSettings");
                            i iVar = (i) obj7;
                            b bVar5 = new b(dVar, i14);
                            f fVar6 = (f) dVar2;
                            fVar6.getClass();
                            z zVar = new z(2);
                            long j6 = iVar.f4649a;
                            if (j6 < 0) {
                                throw new IllegalArgumentException(String.format("Fetch connection timeout has to be a non-negative number. %d is an invalid argument", Long.valueOf(j6)));
                            }
                            zVar.f2312a = j6;
                            zVar.a(iVar.f4650b);
                            z zVar2 = new z(zVar);
                            p073l4.e eVarB3 = f.b(str);
                            android.support.v4.media.session.b.g(eVarB3.f7719b, new D(eVarB3, zVar2, i15)).j(new C2.j(bVar5, fVar6, i11));
                            return;
                        case 5:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj8 = list2.get(0);
                            A5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            Object obj9 = list2.get(1);
                            A5.h.c(obj9, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.Any?>");
                            b bVar6 = new b(dVar, i17);
                            f fVar7 = (f) dVar2;
                            fVar7.getClass();
                            p073l4.e eVarB4 = f.b((String) obj8);
                            HashMap map = new HashMap();
                            for (Map.Entry entry : ((Map) obj9).entrySet()) {
                                Object value = entry.getValue();
                                if (value instanceof byte[]) {
                                    map.put((String) entry.getKey(), new String((byte[]) value));
                                } else {
                                    map.put((String) entry.getKey(), value.toString());
                                }
                            }
                            try {
                                p080m4.e eVarC = p080m4.f.c();
                                eVarC.f7846a = new JSONObject(map);
                                qVarD = eVarB4.f7722e.d(eVarC.a()).m(R3.i.r, new l(26));
                            } catch (JSONException e6) {
                                Log.e("FirebaseRemoteConfig", "The provided defaults map could not be processed.", e6);
                                qVarD = android.support.v4.media.session.b.D(null);
                            }
                            qVarD.j(new C2.j(bVar6, fVar7, 12));
                            return;
                        case 6:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj10 = ((List) obj).get(0);
                            A5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            b bVar7 = new b(dVar, i11);
                            f fVar8 = (f) dVar2;
                            fVar8.getClass();
                            p073l4.e eVarB5 = f.b((String) obj10);
                            p091o3.i iVarB3 = eVarB5.f7721d.b();
                            p091o3.i iVarB4 = eVarB5.f7722e.b();
                            p091o3.i iVarB5 = eVarB5.f7720c.b();
                            Executor executor = eVarB5.f7719b;
                            q qVarG = android.support.v4.media.session.b.g(executor, new p073l4.c(eVarB5, i17));
                            p014c4.c cVar2 = (p014c4.c) eVarB5.f7726i;
                            android.support.v4.media.session.b.l0(iVarB3, iVarB4, iVarB5, qVarG, cVar2.c(), cVar2.d()).l(executor, new E(qVarG, i13)).j(new C2.j(bVar7, fVar8, 11));
                            return;
                        case 7:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj11 = list3.get(0);
                            A5.h.c(obj11, "null cannot be cast to non-null type kotlin.String");
                            Object obj12 = list3.get(1);
                            A5.h.c(obj12, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.Any?>");
                            b bVar8 = new b(dVar, i16);
                            f fVar9 = (f) dVar2;
                            fVar9.getClass();
                            p073l4.e eVarB6 = f.b((String) obj11);
                            p091o3.j jVar = new p091o3.j();
                            FlutterFirebasePlugin.cachedThreadPool.execute(new B2.a((Map) obj12, eVarB6, jVar, i14));
                            q qVar = jVar.f8049a;
                            A5.h.d(qVar, "getTask(...)");
                            qVar.j(new C2.j(bVar8, fVar9, 9));
                            return;
                        default:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj13 = ((List) obj).get(0);
                            A5.h.c(obj13, "null cannot be cast to non-null type kotlin.String");
                            b bVar9 = new b(dVar, i12);
                            ((f) dVar2).getClass();
                            bVar9.a(new p074l5.i(f.d(f.b((String) obj13).b())));
                            return;
                    }
                }
            });
        } else {
            vVar3.P(null);
        }
        v vVar4 = new v(fVar, T.x("dev.flutter.pigeon.firebase_remote_config_platform_interface.FirebaseRemoteConfigHostApi.setConfigSettings", strConcat), a(), null);
        if (fVar2 != null) {
            final int i9 = 4;
            vVar4.P(new W4.b() { // from class: c5.a
                @Override // W4.b
                public final void l(Object obj, V4.d dVar) {
                    q qVarD;
                    int i10 = i9;
                    int i11 = 6;
                    int i12 = 8;
                    int i13 = 5;
                    int i14 = 4;
                    int i15 = 3;
                    int i16 = 2;
                    int i17 = 1;
                    d dVar2 = fVar2;
                    int i18 = 0;
                    switch (i10) {
                        case 0:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj2 = ((List) obj).get(0);
                            A5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            b bVar = new b(dVar, i14);
                            ((f) dVar2).getClass();
                            bVar.a(new p074l5.i(f.a(f.b((String) obj2))));
                            return;
                        case 1:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj3 = ((List) obj).get(0);
                            A5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            b bVar2 = new b(dVar, i11);
                            f fVar3 = (f) dVar2;
                            fVar3.getClass();
                            f.b((String) obj3).a().j(new C2.j(bVar2, fVar3, 7));
                            return;
                        case 2:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj4 = ((List) obj).get(0);
                            A5.h.c(obj4, "null cannot be cast to non-null type kotlin.String");
                            b bVar3 = new b(dVar, i16);
                            f fVar4 = (f) dVar2;
                            fVar4.getClass();
                            p073l4.e eVarB = f.b((String) obj4);
                            eVarB.a().m(eVarB.f7719b, new p073l4.d(eVarB)).j(new C2.j(bVar3, fVar4, 10));
                            return;
                        case 3:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj5 = ((List) obj).get(0);
                            A5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            b bVar4 = new b(dVar, 7);
                            f fVar5 = (f) dVar2;
                            fVar5.getClass();
                            p073l4.e eVarB2 = f.b((String) obj5);
                            p091o3.i iVarB = eVarB2.f7720c.b();
                            p091o3.i iVarB2 = eVarB2.f7721d.b();
                            android.support.v4.media.session.b.l0(iVarB, iVarB2).d(eVarB2.f7719b, new B2.b(eVarB2, iVarB, iVarB2, 7)).j(new C2.j(bVar4, fVar5, 13));
                            return;
                        case 4:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj6 = list.get(0);
                            A5.h.c(obj6, "null cannot be cast to non-null type kotlin.String");
                            String str = (String) obj6;
                            Object obj7 = list.get(1);
                            A5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.firebase.firebaseremoteconfig.RemoteConfigPigeonSettings");
                            i iVar = (i) obj7;
                            b bVar5 = new b(dVar, i15);
                            f fVar6 = (f) dVar2;
                            fVar6.getClass();
                            z zVar = new z(2);
                            long j6 = iVar.f4649a;
                            if (j6 < 0) {
                                throw new IllegalArgumentException(String.format("Fetch connection timeout has to be a non-negative number. %d is an invalid argument", Long.valueOf(j6)));
                            }
                            zVar.f2312a = j6;
                            zVar.a(iVar.f4650b);
                            z zVar2 = new z(zVar);
                            p073l4.e eVarB3 = f.b(str);
                            android.support.v4.media.session.b.g(eVarB3.f7719b, new D(eVarB3, zVar2, i16)).j(new C2.j(bVar5, fVar6, i12));
                            return;
                        case 5:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj8 = list2.get(0);
                            A5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            Object obj9 = list2.get(1);
                            A5.h.c(obj9, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.Any?>");
                            b bVar6 = new b(dVar, i18);
                            f fVar7 = (f) dVar2;
                            fVar7.getClass();
                            p073l4.e eVarB4 = f.b((String) obj8);
                            HashMap map = new HashMap();
                            for (Map.Entry entry : ((Map) obj9).entrySet()) {
                                Object value = entry.getValue();
                                if (value instanceof byte[]) {
                                    map.put((String) entry.getKey(), new String((byte[]) value));
                                } else {
                                    map.put((String) entry.getKey(), value.toString());
                                }
                            }
                            try {
                                p080m4.e eVarC = p080m4.f.c();
                                eVarC.f7846a = new JSONObject(map);
                                qVarD = eVarB4.f7722e.d(eVarC.a()).m(R3.i.r, new l(26));
                            } catch (JSONException e6) {
                                Log.e("FirebaseRemoteConfig", "The provided defaults map could not be processed.", e6);
                                qVarD = android.support.v4.media.session.b.D(null);
                            }
                            qVarD.j(new C2.j(bVar6, fVar7, 12));
                            return;
                        case 6:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj10 = ((List) obj).get(0);
                            A5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            b bVar7 = new b(dVar, i12);
                            f fVar8 = (f) dVar2;
                            fVar8.getClass();
                            p073l4.e eVarB5 = f.b((String) obj10);
                            p091o3.i iVarB3 = eVarB5.f7721d.b();
                            p091o3.i iVarB4 = eVarB5.f7722e.b();
                            p091o3.i iVarB5 = eVarB5.f7720c.b();
                            Executor executor = eVarB5.f7719b;
                            q qVarG = android.support.v4.media.session.b.g(executor, new p073l4.c(eVarB5, i18));
                            p014c4.c cVar2 = (p014c4.c) eVarB5.f7726i;
                            android.support.v4.media.session.b.l0(iVarB3, iVarB4, iVarB5, qVarG, cVar2.c(), cVar2.d()).l(executor, new E(qVarG, i14)).j(new C2.j(bVar7, fVar8, 11));
                            return;
                        case 7:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj11 = list3.get(0);
                            A5.h.c(obj11, "null cannot be cast to non-null type kotlin.String");
                            Object obj12 = list3.get(1);
                            A5.h.c(obj12, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.Any?>");
                            b bVar8 = new b(dVar, i17);
                            f fVar9 = (f) dVar2;
                            fVar9.getClass();
                            p073l4.e eVarB6 = f.b((String) obj11);
                            p091o3.j jVar = new p091o3.j();
                            FlutterFirebasePlugin.cachedThreadPool.execute(new B2.a((Map) obj12, eVarB6, jVar, i15));
                            q qVar = jVar.f8049a;
                            A5.h.d(qVar, "getTask(...)");
                            qVar.j(new C2.j(bVar8, fVar9, 9));
                            return;
                        default:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj13 = ((List) obj).get(0);
                            A5.h.c(obj13, "null cannot be cast to non-null type kotlin.String");
                            b bVar9 = new b(dVar, i13);
                            ((f) dVar2).getClass();
                            bVar9.a(new p074l5.i(f.d(f.b((String) obj13).b())));
                            return;
                    }
                }
            });
        } else {
            vVar4.P(null);
        }
        v vVar5 = new v(fVar, T.x("dev.flutter.pigeon.firebase_remote_config_platform_interface.FirebaseRemoteConfigHostApi.setDefaults", strConcat), a(), null);
        if (fVar2 != null) {
            final int i10 = 5;
            vVar5.P(new W4.b() { // from class: c5.a
                @Override // W4.b
                public final void l(Object obj, V4.d dVar) {
                    q qVarD;
                    int i11 = i10;
                    int i12 = 6;
                    int i13 = 8;
                    int i14 = 5;
                    int i15 = 4;
                    int i16 = 3;
                    int i17 = 2;
                    int i18 = 1;
                    d dVar2 = fVar2;
                    int i19 = 0;
                    switch (i11) {
                        case 0:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj2 = ((List) obj).get(0);
                            A5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            b bVar = new b(dVar, i15);
                            ((f) dVar2).getClass();
                            bVar.a(new p074l5.i(f.a(f.b((String) obj2))));
                            return;
                        case 1:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj3 = ((List) obj).get(0);
                            A5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            b bVar2 = new b(dVar, i12);
                            f fVar3 = (f) dVar2;
                            fVar3.getClass();
                            f.b((String) obj3).a().j(new C2.j(bVar2, fVar3, 7));
                            return;
                        case 2:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj4 = ((List) obj).get(0);
                            A5.h.c(obj4, "null cannot be cast to non-null type kotlin.String");
                            b bVar3 = new b(dVar, i17);
                            f fVar4 = (f) dVar2;
                            fVar4.getClass();
                            p073l4.e eVarB = f.b((String) obj4);
                            eVarB.a().m(eVarB.f7719b, new p073l4.d(eVarB)).j(new C2.j(bVar3, fVar4, 10));
                            return;
                        case 3:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj5 = ((List) obj).get(0);
                            A5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            b bVar4 = new b(dVar, 7);
                            f fVar5 = (f) dVar2;
                            fVar5.getClass();
                            p073l4.e eVarB2 = f.b((String) obj5);
                            p091o3.i iVarB = eVarB2.f7720c.b();
                            p091o3.i iVarB2 = eVarB2.f7721d.b();
                            android.support.v4.media.session.b.l0(iVarB, iVarB2).d(eVarB2.f7719b, new B2.b(eVarB2, iVarB, iVarB2, 7)).j(new C2.j(bVar4, fVar5, 13));
                            return;
                        case 4:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj6 = list.get(0);
                            A5.h.c(obj6, "null cannot be cast to non-null type kotlin.String");
                            String str = (String) obj6;
                            Object obj7 = list.get(1);
                            A5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.firebase.firebaseremoteconfig.RemoteConfigPigeonSettings");
                            i iVar = (i) obj7;
                            b bVar5 = new b(dVar, i16);
                            f fVar6 = (f) dVar2;
                            fVar6.getClass();
                            z zVar = new z(2);
                            long j6 = iVar.f4649a;
                            if (j6 < 0) {
                                throw new IllegalArgumentException(String.format("Fetch connection timeout has to be a non-negative number. %d is an invalid argument", Long.valueOf(j6)));
                            }
                            zVar.f2312a = j6;
                            zVar.a(iVar.f4650b);
                            z zVar2 = new z(zVar);
                            p073l4.e eVarB3 = f.b(str);
                            android.support.v4.media.session.b.g(eVarB3.f7719b, new D(eVarB3, zVar2, i17)).j(new C2.j(bVar5, fVar6, i13));
                            return;
                        case 5:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj8 = list2.get(0);
                            A5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            Object obj9 = list2.get(1);
                            A5.h.c(obj9, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.Any?>");
                            b bVar6 = new b(dVar, i19);
                            f fVar7 = (f) dVar2;
                            fVar7.getClass();
                            p073l4.e eVarB4 = f.b((String) obj8);
                            HashMap map = new HashMap();
                            for (Map.Entry entry : ((Map) obj9).entrySet()) {
                                Object value = entry.getValue();
                                if (value instanceof byte[]) {
                                    map.put((String) entry.getKey(), new String((byte[]) value));
                                } else {
                                    map.put((String) entry.getKey(), value.toString());
                                }
                            }
                            try {
                                p080m4.e eVarC = p080m4.f.c();
                                eVarC.f7846a = new JSONObject(map);
                                qVarD = eVarB4.f7722e.d(eVarC.a()).m(R3.i.r, new l(26));
                            } catch (JSONException e6) {
                                Log.e("FirebaseRemoteConfig", "The provided defaults map could not be processed.", e6);
                                qVarD = android.support.v4.media.session.b.D(null);
                            }
                            qVarD.j(new C2.j(bVar6, fVar7, 12));
                            return;
                        case 6:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj10 = ((List) obj).get(0);
                            A5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            b bVar7 = new b(dVar, i13);
                            f fVar8 = (f) dVar2;
                            fVar8.getClass();
                            p073l4.e eVarB5 = f.b((String) obj10);
                            p091o3.i iVarB3 = eVarB5.f7721d.b();
                            p091o3.i iVarB4 = eVarB5.f7722e.b();
                            p091o3.i iVarB5 = eVarB5.f7720c.b();
                            Executor executor = eVarB5.f7719b;
                            q qVarG = android.support.v4.media.session.b.g(executor, new p073l4.c(eVarB5, i19));
                            p014c4.c cVar2 = (p014c4.c) eVarB5.f7726i;
                            android.support.v4.media.session.b.l0(iVarB3, iVarB4, iVarB5, qVarG, cVar2.c(), cVar2.d()).l(executor, new E(qVarG, i15)).j(new C2.j(bVar7, fVar8, 11));
                            return;
                        case 7:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj11 = list3.get(0);
                            A5.h.c(obj11, "null cannot be cast to non-null type kotlin.String");
                            Object obj12 = list3.get(1);
                            A5.h.c(obj12, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.Any?>");
                            b bVar8 = new b(dVar, i18);
                            f fVar9 = (f) dVar2;
                            fVar9.getClass();
                            p073l4.e eVarB6 = f.b((String) obj11);
                            p091o3.j jVar = new p091o3.j();
                            FlutterFirebasePlugin.cachedThreadPool.execute(new B2.a((Map) obj12, eVarB6, jVar, i16));
                            q qVar = jVar.f8049a;
                            A5.h.d(qVar, "getTask(...)");
                            qVar.j(new C2.j(bVar8, fVar9, 9));
                            return;
                        default:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj13 = ((List) obj).get(0);
                            A5.h.c(obj13, "null cannot be cast to non-null type kotlin.String");
                            b bVar9 = new b(dVar, i14);
                            ((f) dVar2).getClass();
                            bVar9.a(new p074l5.i(f.d(f.b((String) obj13).b())));
                            return;
                    }
                }
            });
        } else {
            vVar5.P(null);
        }
        v vVar6 = new v(fVar, T.x("dev.flutter.pigeon.firebase_remote_config_platform_interface.FirebaseRemoteConfigHostApi.ensureInitialized", strConcat), a(), null);
        if (fVar2 != null) {
            final int i11 = 6;
            vVar6.P(new W4.b() { // from class: c5.a
                @Override // W4.b
                public final void l(Object obj, V4.d dVar) {
                    q qVarD;
                    int i12 = i11;
                    int i13 = 6;
                    int i14 = 8;
                    int i15 = 5;
                    int i16 = 4;
                    int i17 = 3;
                    int i18 = 2;
                    int i19 = 1;
                    d dVar2 = fVar2;
                    int i110 = 0;
                    switch (i12) {
                        case 0:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj2 = ((List) obj).get(0);
                            A5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            b bVar = new b(dVar, i16);
                            ((f) dVar2).getClass();
                            bVar.a(new p074l5.i(f.a(f.b((String) obj2))));
                            return;
                        case 1:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj3 = ((List) obj).get(0);
                            A5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            b bVar2 = new b(dVar, i13);
                            f fVar3 = (f) dVar2;
                            fVar3.getClass();
                            f.b((String) obj3).a().j(new C2.j(bVar2, fVar3, 7));
                            return;
                        case 2:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj4 = ((List) obj).get(0);
                            A5.h.c(obj4, "null cannot be cast to non-null type kotlin.String");
                            b bVar3 = new b(dVar, i18);
                            f fVar4 = (f) dVar2;
                            fVar4.getClass();
                            p073l4.e eVarB = f.b((String) obj4);
                            eVarB.a().m(eVarB.f7719b, new p073l4.d(eVarB)).j(new C2.j(bVar3, fVar4, 10));
                            return;
                        case 3:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj5 = ((List) obj).get(0);
                            A5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            b bVar4 = new b(dVar, 7);
                            f fVar5 = (f) dVar2;
                            fVar5.getClass();
                            p073l4.e eVarB2 = f.b((String) obj5);
                            p091o3.i iVarB = eVarB2.f7720c.b();
                            p091o3.i iVarB2 = eVarB2.f7721d.b();
                            android.support.v4.media.session.b.l0(iVarB, iVarB2).d(eVarB2.f7719b, new B2.b(eVarB2, iVarB, iVarB2, 7)).j(new C2.j(bVar4, fVar5, 13));
                            return;
                        case 4:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj6 = list.get(0);
                            A5.h.c(obj6, "null cannot be cast to non-null type kotlin.String");
                            String str = (String) obj6;
                            Object obj7 = list.get(1);
                            A5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.firebase.firebaseremoteconfig.RemoteConfigPigeonSettings");
                            i iVar = (i) obj7;
                            b bVar5 = new b(dVar, i17);
                            f fVar6 = (f) dVar2;
                            fVar6.getClass();
                            z zVar = new z(2);
                            long j6 = iVar.f4649a;
                            if (j6 < 0) {
                                throw new IllegalArgumentException(String.format("Fetch connection timeout has to be a non-negative number. %d is an invalid argument", Long.valueOf(j6)));
                            }
                            zVar.f2312a = j6;
                            zVar.a(iVar.f4650b);
                            z zVar2 = new z(zVar);
                            p073l4.e eVarB3 = f.b(str);
                            android.support.v4.media.session.b.g(eVarB3.f7719b, new D(eVarB3, zVar2, i18)).j(new C2.j(bVar5, fVar6, i14));
                            return;
                        case 5:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj8 = list2.get(0);
                            A5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            Object obj9 = list2.get(1);
                            A5.h.c(obj9, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.Any?>");
                            b bVar6 = new b(dVar, i110);
                            f fVar7 = (f) dVar2;
                            fVar7.getClass();
                            p073l4.e eVarB4 = f.b((String) obj8);
                            HashMap map = new HashMap();
                            for (Map.Entry entry : ((Map) obj9).entrySet()) {
                                Object value = entry.getValue();
                                if (value instanceof byte[]) {
                                    map.put((String) entry.getKey(), new String((byte[]) value));
                                } else {
                                    map.put((String) entry.getKey(), value.toString());
                                }
                            }
                            try {
                                p080m4.e eVarC = p080m4.f.c();
                                eVarC.f7846a = new JSONObject(map);
                                qVarD = eVarB4.f7722e.d(eVarC.a()).m(R3.i.r, new l(26));
                            } catch (JSONException e6) {
                                Log.e("FirebaseRemoteConfig", "The provided defaults map could not be processed.", e6);
                                qVarD = android.support.v4.media.session.b.D(null);
                            }
                            qVarD.j(new C2.j(bVar6, fVar7, 12));
                            return;
                        case 6:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj10 = ((List) obj).get(0);
                            A5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            b bVar7 = new b(dVar, i14);
                            f fVar8 = (f) dVar2;
                            fVar8.getClass();
                            p073l4.e eVarB5 = f.b((String) obj10);
                            p091o3.i iVarB3 = eVarB5.f7721d.b();
                            p091o3.i iVarB4 = eVarB5.f7722e.b();
                            p091o3.i iVarB5 = eVarB5.f7720c.b();
                            Executor executor = eVarB5.f7719b;
                            q qVarG = android.support.v4.media.session.b.g(executor, new p073l4.c(eVarB5, i110));
                            p014c4.c cVar2 = (p014c4.c) eVarB5.f7726i;
                            android.support.v4.media.session.b.l0(iVarB3, iVarB4, iVarB5, qVarG, cVar2.c(), cVar2.d()).l(executor, new E(qVarG, i16)).j(new C2.j(bVar7, fVar8, 11));
                            return;
                        case 7:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj11 = list3.get(0);
                            A5.h.c(obj11, "null cannot be cast to non-null type kotlin.String");
                            Object obj12 = list3.get(1);
                            A5.h.c(obj12, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.Any?>");
                            b bVar8 = new b(dVar, i19);
                            f fVar9 = (f) dVar2;
                            fVar9.getClass();
                            p073l4.e eVarB6 = f.b((String) obj11);
                            p091o3.j jVar = new p091o3.j();
                            FlutterFirebasePlugin.cachedThreadPool.execute(new B2.a((Map) obj12, eVarB6, jVar, i17));
                            q qVar = jVar.f8049a;
                            A5.h.d(qVar, "getTask(...)");
                            qVar.j(new C2.j(bVar8, fVar9, 9));
                            return;
                        default:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj13 = ((List) obj).get(0);
                            A5.h.c(obj13, "null cannot be cast to non-null type kotlin.String");
                            b bVar9 = new b(dVar, i15);
                            ((f) dVar2).getClass();
                            bVar9.a(new p074l5.i(f.d(f.b((String) obj13).b())));
                            return;
                    }
                }
            });
        } else {
            vVar6.P(null);
        }
        v vVar7 = new v(fVar, T.x("dev.flutter.pigeon.firebase_remote_config_platform_interface.FirebaseRemoteConfigHostApi.setCustomSignals", strConcat), a(), null);
        if (fVar2 != null) {
            final int i12 = 7;
            vVar7.P(new W4.b() { // from class: c5.a
                @Override // W4.b
                public final void l(Object obj, V4.d dVar) {
                    q qVarD;
                    int i13 = i12;
                    int i14 = 6;
                    int i15 = 8;
                    int i16 = 5;
                    int i17 = 4;
                    int i18 = 3;
                    int i19 = 2;
                    int i110 = 1;
                    d dVar2 = fVar2;
                    int i111 = 0;
                    switch (i13) {
                        case 0:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj2 = ((List) obj).get(0);
                            A5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            b bVar = new b(dVar, i17);
                            ((f) dVar2).getClass();
                            bVar.a(new p074l5.i(f.a(f.b((String) obj2))));
                            return;
                        case 1:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj3 = ((List) obj).get(0);
                            A5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            b bVar2 = new b(dVar, i14);
                            f fVar3 = (f) dVar2;
                            fVar3.getClass();
                            f.b((String) obj3).a().j(new C2.j(bVar2, fVar3, 7));
                            return;
                        case 2:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj4 = ((List) obj).get(0);
                            A5.h.c(obj4, "null cannot be cast to non-null type kotlin.String");
                            b bVar3 = new b(dVar, i19);
                            f fVar4 = (f) dVar2;
                            fVar4.getClass();
                            p073l4.e eVarB = f.b((String) obj4);
                            eVarB.a().m(eVarB.f7719b, new p073l4.d(eVarB)).j(new C2.j(bVar3, fVar4, 10));
                            return;
                        case 3:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj5 = ((List) obj).get(0);
                            A5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            b bVar4 = new b(dVar, 7);
                            f fVar5 = (f) dVar2;
                            fVar5.getClass();
                            p073l4.e eVarB2 = f.b((String) obj5);
                            p091o3.i iVarB = eVarB2.f7720c.b();
                            p091o3.i iVarB2 = eVarB2.f7721d.b();
                            android.support.v4.media.session.b.l0(iVarB, iVarB2).d(eVarB2.f7719b, new B2.b(eVarB2, iVarB, iVarB2, 7)).j(new C2.j(bVar4, fVar5, 13));
                            return;
                        case 4:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj6 = list.get(0);
                            A5.h.c(obj6, "null cannot be cast to non-null type kotlin.String");
                            String str = (String) obj6;
                            Object obj7 = list.get(1);
                            A5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.firebase.firebaseremoteconfig.RemoteConfigPigeonSettings");
                            i iVar = (i) obj7;
                            b bVar5 = new b(dVar, i18);
                            f fVar6 = (f) dVar2;
                            fVar6.getClass();
                            z zVar = new z(2);
                            long j6 = iVar.f4649a;
                            if (j6 < 0) {
                                throw new IllegalArgumentException(String.format("Fetch connection timeout has to be a non-negative number. %d is an invalid argument", Long.valueOf(j6)));
                            }
                            zVar.f2312a = j6;
                            zVar.a(iVar.f4650b);
                            z zVar2 = new z(zVar);
                            p073l4.e eVarB3 = f.b(str);
                            android.support.v4.media.session.b.g(eVarB3.f7719b, new D(eVarB3, zVar2, i19)).j(new C2.j(bVar5, fVar6, i15));
                            return;
                        case 5:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj8 = list2.get(0);
                            A5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            Object obj9 = list2.get(1);
                            A5.h.c(obj9, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.Any?>");
                            b bVar6 = new b(dVar, i111);
                            f fVar7 = (f) dVar2;
                            fVar7.getClass();
                            p073l4.e eVarB4 = f.b((String) obj8);
                            HashMap map = new HashMap();
                            for (Map.Entry entry : ((Map) obj9).entrySet()) {
                                Object value = entry.getValue();
                                if (value instanceof byte[]) {
                                    map.put((String) entry.getKey(), new String((byte[]) value));
                                } else {
                                    map.put((String) entry.getKey(), value.toString());
                                }
                            }
                            try {
                                p080m4.e eVarC = p080m4.f.c();
                                eVarC.f7846a = new JSONObject(map);
                                qVarD = eVarB4.f7722e.d(eVarC.a()).m(R3.i.r, new l(26));
                            } catch (JSONException e6) {
                                Log.e("FirebaseRemoteConfig", "The provided defaults map could not be processed.", e6);
                                qVarD = android.support.v4.media.session.b.D(null);
                            }
                            qVarD.j(new C2.j(bVar6, fVar7, 12));
                            return;
                        case 6:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj10 = ((List) obj).get(0);
                            A5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            b bVar7 = new b(dVar, i15);
                            f fVar8 = (f) dVar2;
                            fVar8.getClass();
                            p073l4.e eVarB5 = f.b((String) obj10);
                            p091o3.i iVarB3 = eVarB5.f7721d.b();
                            p091o3.i iVarB4 = eVarB5.f7722e.b();
                            p091o3.i iVarB5 = eVarB5.f7720c.b();
                            Executor executor = eVarB5.f7719b;
                            q qVarG = android.support.v4.media.session.b.g(executor, new p073l4.c(eVarB5, i111));
                            p014c4.c cVar2 = (p014c4.c) eVarB5.f7726i;
                            android.support.v4.media.session.b.l0(iVarB3, iVarB4, iVarB5, qVarG, cVar2.c(), cVar2.d()).l(executor, new E(qVarG, i17)).j(new C2.j(bVar7, fVar8, 11));
                            return;
                        case 7:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj11 = list3.get(0);
                            A5.h.c(obj11, "null cannot be cast to non-null type kotlin.String");
                            Object obj12 = list3.get(1);
                            A5.h.c(obj12, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.Any?>");
                            b bVar8 = new b(dVar, i110);
                            f fVar9 = (f) dVar2;
                            fVar9.getClass();
                            p073l4.e eVarB6 = f.b((String) obj11);
                            p091o3.j jVar = new p091o3.j();
                            FlutterFirebasePlugin.cachedThreadPool.execute(new B2.a((Map) obj12, eVarB6, jVar, i18));
                            q qVar = jVar.f8049a;
                            A5.h.d(qVar, "getTask(...)");
                            qVar.j(new C2.j(bVar8, fVar9, 9));
                            return;
                        default:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj13 = ((List) obj).get(0);
                            A5.h.c(obj13, "null cannot be cast to non-null type kotlin.String");
                            b bVar9 = new b(dVar, i16);
                            ((f) dVar2).getClass();
                            bVar9.a(new p074l5.i(f.d(f.b((String) obj13).b())));
                            return;
                    }
                }
            });
        } else {
            vVar7.P(null);
        }
        v vVar8 = new v(fVar, T.x("dev.flutter.pigeon.firebase_remote_config_platform_interface.FirebaseRemoteConfigHostApi.getAll", strConcat), a(), null);
        if (fVar2 != null) {
            final int i13 = 8;
            vVar8.P(new W4.b() { // from class: c5.a
                @Override // W4.b
                public final void l(Object obj, V4.d dVar) {
                    q qVarD;
                    int i14 = i13;
                    int i15 = 6;
                    int i16 = 8;
                    int i17 = 5;
                    int i18 = 4;
                    int i19 = 3;
                    int i110 = 2;
                    int i111 = 1;
                    d dVar2 = fVar2;
                    int i112 = 0;
                    switch (i14) {
                        case 0:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj2 = ((List) obj).get(0);
                            A5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            b bVar = new b(dVar, i18);
                            ((f) dVar2).getClass();
                            bVar.a(new p074l5.i(f.a(f.b((String) obj2))));
                            return;
                        case 1:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj3 = ((List) obj).get(0);
                            A5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            b bVar2 = new b(dVar, i15);
                            f fVar3 = (f) dVar2;
                            fVar3.getClass();
                            f.b((String) obj3).a().j(new C2.j(bVar2, fVar3, 7));
                            return;
                        case 2:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj4 = ((List) obj).get(0);
                            A5.h.c(obj4, "null cannot be cast to non-null type kotlin.String");
                            b bVar3 = new b(dVar, i110);
                            f fVar4 = (f) dVar2;
                            fVar4.getClass();
                            p073l4.e eVarB = f.b((String) obj4);
                            eVarB.a().m(eVarB.f7719b, new p073l4.d(eVarB)).j(new C2.j(bVar3, fVar4, 10));
                            return;
                        case 3:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj5 = ((List) obj).get(0);
                            A5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            b bVar4 = new b(dVar, 7);
                            f fVar5 = (f) dVar2;
                            fVar5.getClass();
                            p073l4.e eVarB2 = f.b((String) obj5);
                            p091o3.i iVarB = eVarB2.f7720c.b();
                            p091o3.i iVarB2 = eVarB2.f7721d.b();
                            android.support.v4.media.session.b.l0(iVarB, iVarB2).d(eVarB2.f7719b, new B2.b(eVarB2, iVarB, iVarB2, 7)).j(new C2.j(bVar4, fVar5, 13));
                            return;
                        case 4:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj6 = list.get(0);
                            A5.h.c(obj6, "null cannot be cast to non-null type kotlin.String");
                            String str = (String) obj6;
                            Object obj7 = list.get(1);
                            A5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.firebase.firebaseremoteconfig.RemoteConfigPigeonSettings");
                            i iVar = (i) obj7;
                            b bVar5 = new b(dVar, i19);
                            f fVar6 = (f) dVar2;
                            fVar6.getClass();
                            z zVar = new z(2);
                            long j6 = iVar.f4649a;
                            if (j6 < 0) {
                                throw new IllegalArgumentException(String.format("Fetch connection timeout has to be a non-negative number. %d is an invalid argument", Long.valueOf(j6)));
                            }
                            zVar.f2312a = j6;
                            zVar.a(iVar.f4650b);
                            z zVar2 = new z(zVar);
                            p073l4.e eVarB3 = f.b(str);
                            android.support.v4.media.session.b.g(eVarB3.f7719b, new D(eVarB3, zVar2, i110)).j(new C2.j(bVar5, fVar6, i16));
                            return;
                        case 5:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj8 = list2.get(0);
                            A5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            Object obj9 = list2.get(1);
                            A5.h.c(obj9, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.Any?>");
                            b bVar6 = new b(dVar, i112);
                            f fVar7 = (f) dVar2;
                            fVar7.getClass();
                            p073l4.e eVarB4 = f.b((String) obj8);
                            HashMap map = new HashMap();
                            for (Map.Entry entry : ((Map) obj9).entrySet()) {
                                Object value = entry.getValue();
                                if (value instanceof byte[]) {
                                    map.put((String) entry.getKey(), new String((byte[]) value));
                                } else {
                                    map.put((String) entry.getKey(), value.toString());
                                }
                            }
                            try {
                                p080m4.e eVarC = p080m4.f.c();
                                eVarC.f7846a = new JSONObject(map);
                                qVarD = eVarB4.f7722e.d(eVarC.a()).m(R3.i.r, new l(26));
                            } catch (JSONException e6) {
                                Log.e("FirebaseRemoteConfig", "The provided defaults map could not be processed.", e6);
                                qVarD = android.support.v4.media.session.b.D(null);
                            }
                            qVarD.j(new C2.j(bVar6, fVar7, 12));
                            return;
                        case 6:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj10 = ((List) obj).get(0);
                            A5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            b bVar7 = new b(dVar, i16);
                            f fVar8 = (f) dVar2;
                            fVar8.getClass();
                            p073l4.e eVarB5 = f.b((String) obj10);
                            p091o3.i iVarB3 = eVarB5.f7721d.b();
                            p091o3.i iVarB4 = eVarB5.f7722e.b();
                            p091o3.i iVarB5 = eVarB5.f7720c.b();
                            Executor executor = eVarB5.f7719b;
                            q qVarG = android.support.v4.media.session.b.g(executor, new p073l4.c(eVarB5, i112));
                            p014c4.c cVar2 = (p014c4.c) eVarB5.f7726i;
                            android.support.v4.media.session.b.l0(iVarB3, iVarB4, iVarB5, qVarG, cVar2.c(), cVar2.d()).l(executor, new E(qVarG, i18)).j(new C2.j(bVar7, fVar8, 11));
                            return;
                        case 7:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj11 = list3.get(0);
                            A5.h.c(obj11, "null cannot be cast to non-null type kotlin.String");
                            Object obj12 = list3.get(1);
                            A5.h.c(obj12, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.Any?>");
                            b bVar8 = new b(dVar, i111);
                            f fVar9 = (f) dVar2;
                            fVar9.getClass();
                            p073l4.e eVarB6 = f.b((String) obj11);
                            p091o3.j jVar = new p091o3.j();
                            FlutterFirebasePlugin.cachedThreadPool.execute(new B2.a((Map) obj12, eVarB6, jVar, i19));
                            q qVar = jVar.f8049a;
                            A5.h.d(qVar, "getTask(...)");
                            qVar.j(new C2.j(bVar8, fVar9, 9));
                            return;
                        default:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj13 = ((List) obj).get(0);
                            A5.h.c(obj13, "null cannot be cast to non-null type kotlin.String");
                            b bVar9 = new b(dVar, i17);
                            ((f) dVar2).getClass();
                            bVar9.a(new p074l5.i(f.d(f.b((String) obj13).b())));
                            return;
                    }
                }
            });
        } else {
            vVar8.P(null);
        }
        v vVar9 = new v(fVar, T.x("dev.flutter.pigeon.firebase_remote_config_platform_interface.FirebaseRemoteConfigHostApi.getProperties", strConcat), a(), null);
        if (fVar2 == null) {
            vVar9.P(null);
        } else {
            final int i14 = 0;
            vVar9.P(new W4.b() { // from class: c5.a
                @Override // W4.b
                public final void l(Object obj, V4.d dVar) {
                    q qVarD;
                    int i15 = i14;
                    int i16 = 6;
                    int i17 = 8;
                    int i18 = 5;
                    int i19 = 4;
                    int i110 = 3;
                    int i111 = 2;
                    int i112 = 1;
                    d dVar2 = fVar2;
                    int i113 = 0;
                    switch (i15) {
                        case 0:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj2 = ((List) obj).get(0);
                            A5.h.c(obj2, "null cannot be cast to non-null type kotlin.String");
                            b bVar = new b(dVar, i19);
                            ((f) dVar2).getClass();
                            bVar.a(new p074l5.i(f.a(f.b((String) obj2))));
                            return;
                        case 1:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj3 = ((List) obj).get(0);
                            A5.h.c(obj3, "null cannot be cast to non-null type kotlin.String");
                            b bVar2 = new b(dVar, i16);
                            f fVar3 = (f) dVar2;
                            fVar3.getClass();
                            f.b((String) obj3).a().j(new C2.j(bVar2, fVar3, 7));
                            return;
                        case 2:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj4 = ((List) obj).get(0);
                            A5.h.c(obj4, "null cannot be cast to non-null type kotlin.String");
                            b bVar3 = new b(dVar, i111);
                            f fVar4 = (f) dVar2;
                            fVar4.getClass();
                            p073l4.e eVarB = f.b((String) obj4);
                            eVarB.a().m(eVarB.f7719b, new p073l4.d(eVarB)).j(new C2.j(bVar3, fVar4, 10));
                            return;
                        case 3:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj5 = ((List) obj).get(0);
                            A5.h.c(obj5, "null cannot be cast to non-null type kotlin.String");
                            b bVar4 = new b(dVar, 7);
                            f fVar5 = (f) dVar2;
                            fVar5.getClass();
                            p073l4.e eVarB2 = f.b((String) obj5);
                            p091o3.i iVarB = eVarB2.f7720c.b();
                            p091o3.i iVarB2 = eVarB2.f7721d.b();
                            android.support.v4.media.session.b.l0(iVarB, iVarB2).d(eVarB2.f7719b, new B2.b(eVarB2, iVarB, iVarB2, 7)).j(new C2.j(bVar4, fVar5, 13));
                            return;
                        case 4:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list = (List) obj;
                            Object obj6 = list.get(0);
                            A5.h.c(obj6, "null cannot be cast to non-null type kotlin.String");
                            String str = (String) obj6;
                            Object obj7 = list.get(1);
                            A5.h.c(obj7, "null cannot be cast to non-null type io.flutter.plugins.firebase.firebaseremoteconfig.RemoteConfigPigeonSettings");
                            i iVar = (i) obj7;
                            b bVar5 = new b(dVar, i110);
                            f fVar6 = (f) dVar2;
                            fVar6.getClass();
                            z zVar = new z(2);
                            long j6 = iVar.f4649a;
                            if (j6 < 0) {
                                throw new IllegalArgumentException(String.format("Fetch connection timeout has to be a non-negative number. %d is an invalid argument", Long.valueOf(j6)));
                            }
                            zVar.f2312a = j6;
                            zVar.a(iVar.f4650b);
                            z zVar2 = new z(zVar);
                            p073l4.e eVarB3 = f.b(str);
                            android.support.v4.media.session.b.g(eVarB3.f7719b, new D(eVarB3, zVar2, i111)).j(new C2.j(bVar5, fVar6, i17));
                            return;
                        case 5:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list2 = (List) obj;
                            Object obj8 = list2.get(0);
                            A5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                            Object obj9 = list2.get(1);
                            A5.h.c(obj9, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.Any?>");
                            b bVar6 = new b(dVar, i113);
                            f fVar7 = (f) dVar2;
                            fVar7.getClass();
                            p073l4.e eVarB4 = f.b((String) obj8);
                            HashMap map = new HashMap();
                            for (Map.Entry entry : ((Map) obj9).entrySet()) {
                                Object value = entry.getValue();
                                if (value instanceof byte[]) {
                                    map.put((String) entry.getKey(), new String((byte[]) value));
                                } else {
                                    map.put((String) entry.getKey(), value.toString());
                                }
                            }
                            try {
                                p080m4.e eVarC = p080m4.f.c();
                                eVarC.f7846a = new JSONObject(map);
                                qVarD = eVarB4.f7722e.d(eVarC.a()).m(R3.i.r, new l(26));
                            } catch (JSONException e6) {
                                Log.e("FirebaseRemoteConfig", "The provided defaults map could not be processed.", e6);
                                qVarD = android.support.v4.media.session.b.D(null);
                            }
                            qVarD.j(new C2.j(bVar6, fVar7, 12));
                            return;
                        case 6:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj10 = ((List) obj).get(0);
                            A5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                            b bVar7 = new b(dVar, i17);
                            f fVar8 = (f) dVar2;
                            fVar8.getClass();
                            p073l4.e eVarB5 = f.b((String) obj10);
                            p091o3.i iVarB3 = eVarB5.f7721d.b();
                            p091o3.i iVarB4 = eVarB5.f7722e.b();
                            p091o3.i iVarB5 = eVarB5.f7720c.b();
                            Executor executor = eVarB5.f7719b;
                            q qVarG = android.support.v4.media.session.b.g(executor, new p073l4.c(eVarB5, i113));
                            p014c4.c cVar2 = (p014c4.c) eVarB5.f7726i;
                            android.support.v4.media.session.b.l0(iVarB3, iVarB4, iVarB5, qVarG, cVar2.c(), cVar2.d()).l(executor, new E(qVarG, i19)).j(new C2.j(bVar7, fVar8, 11));
                            return;
                        case 7:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            List list3 = (List) obj;
                            Object obj11 = list3.get(0);
                            A5.h.c(obj11, "null cannot be cast to non-null type kotlin.String");
                            Object obj12 = list3.get(1);
                            A5.h.c(obj12, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.Any?>");
                            b bVar8 = new b(dVar, i112);
                            f fVar9 = (f) dVar2;
                            fVar9.getClass();
                            p073l4.e eVarB6 = f.b((String) obj11);
                            p091o3.j jVar = new p091o3.j();
                            FlutterFirebasePlugin.cachedThreadPool.execute(new B2.a((Map) obj12, eVarB6, jVar, i110));
                            q qVar = jVar.f8049a;
                            A5.h.d(qVar, "getTask(...)");
                            qVar.j(new C2.j(bVar8, fVar9, 9));
                            return;
                        default:
                            A5.h.c(obj, "null cannot be cast to non-null type kotlin.collections.List<kotlin.Any?>");
                            Object obj13 = ((List) obj).get(0);
                            A5.h.c(obj13, "null cannot be cast to non-null type kotlin.String");
                            b bVar9 = new b(dVar, i18);
                            ((f) dVar2).getClass();
                            bVar9.a(new p074l5.i(f.d(f.b((String) obj13).b())));
                            return;
                    }
                }
            });
        }
    }
}
