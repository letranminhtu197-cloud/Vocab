package c5;

/* JADX INFO: loaded from: classes.dex */
public interface d {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final c f4642k = c.f4640a;
}
