package c5;

import C1.B;
import android.os.Handler;
import android.os.Looper;
import io.flutter.plugins.firebase.core.FlutterFirebasePlugin;
import io.flutter.plugins.firebase.core.FlutterFirebasePluginRegistry;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Objects;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import p073l4.l;
import p080m4.q;
import p091o3.j;

/* JADX INFO: loaded from: classes.dex */
public final class f implements FlutterFirebasePlugin, S4.b, W4.i, d {

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public A4.d f4645s;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public W4.f f4646u;
    public final HashMap r = new HashMap();
    public final Handler t = new Handler(Looper.getMainLooper());

    public static HashMap a(p073l4.e eVar) {
        String str;
        HashMap map = new HashMap();
        map.put("fetchTimeout", Long.valueOf(eVar.c().f7912c.f2312a));
        map.put("minimumFetchInterval", Long.valueOf(eVar.c().f7912c.f2313b));
        map.put("lastFetchTime", Long.valueOf(eVar.c().f7910a));
        int i6 = eVar.c().f7911b;
        if (i6 == -1) {
            str = "success";
        } else if (i6 != 0) {
            str = "failure";
            if (i6 != 1 && i6 == 2) {
                str = "throttled";
            }
        } else {
            str = "noFetchYet";
        }
        map.put("lastFetchStatus", str);
        return map;
    }

    public static p073l4.e b(String str) {
        p073l4.e eVarC = ((l) L3.g.f(str).c(l.class)).c();
        A5.h.d(eVarC, "getInstance(...)");
        return eVarC;
    }

    public static void c(p154z5.c cVar, Exception exc) {
        String message;
        HashMap map = new HashMap();
        if (exc instanceof p073l4.h) {
            map.put("code", "throttled");
            map.put("message", "frequency of requests exceeds throttled limits");
        } else if (exc instanceof p073l4.f) {
            map.put("code", "internal");
            map.put("message", "internal remote config fetch error");
        } else if (exc instanceof p073l4.i) {
            map.put("code", "remote-config-server-error");
            p073l4.i iVar = (p073l4.i) exc;
            map.put("message", iVar.getMessage());
            Throwable cause = iVar.getCause();
            if (cause != null && (message = cause.getMessage()) != null && I5.d.w0(message, "Forbidden")) {
                map.put("code", "forbidden");
            }
        } else {
            map.put("code", "unknown");
            map.put("message", "unknown remote config error");
        }
        cVar.a(new p074l5.i(X2.a.m(new g(exc != null ? exc.getMessage() : null, map))));
    }

    public static HashMap d(HashMap map) {
        HashMap map2 = new HashMap();
        for (String str : map.keySet()) {
            Object obj = map.get(str);
            A5.h.b(obj);
            q qVar = (q) obj;
            int i6 = qVar.f7914b;
            HashMap map3 = new HashMap();
            map3.put(MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, i6 == 0 ? p073l4.e.f7717l : qVar.f7913a.getBytes(p080m4.i.f7873e));
            String str2 = "static";
            if (i6 != 0) {
                if (i6 == 1) {
                    str2 = "default";
                } else if (i6 == 2) {
                    str2 = "remote";
                }
            }
            map3.put(ClimateForcast.SOURCE, str2);
            map2.put(str, map3);
        }
        return map2;
    }

    @Override // io.flutter.plugins.firebase.core.FlutterFirebasePlugin
    public final p091o3.i didReinitializeFirebaseCore() {
        j jVar = new j();
        FlutterFirebasePlugin.cachedThreadPool.execute(new B(this, jVar, 28));
        p091o3.q qVar = jVar.f8049a;
        A5.h.d(qVar, "getTask(...)");
        return qVar;
    }

    public final void e() {
        HashMap map = this.r;
        for (p080m4.j jVar : map.values()) {
            V4.d dVar = jVar.f7879b;
            e eVar = jVar.f7878a;
            synchronized (dVar) {
                ((LinkedHashSet) dVar.f3633s).remove(eVar);
            }
        }
        map.clear();
    }

    @Override // io.flutter.plugins.firebase.core.FlutterFirebasePlugin
    public final p091o3.i getPluginConstantsForFirebaseApp(L3.g gVar) {
        A5.h.e(gVar, "firebaseApp");
        j jVar = new j();
        FlutterFirebasePlugin.cachedThreadPool.execute(new p010b5.c(gVar, this, jVar));
        p091o3.q qVar = jVar.f8049a;
        A5.h.d(qVar, "getTask(...)");
        return qVar;
    }

    @Override // S4.b
    public final void onAttachedToEngine(S4.a aVar) {
        A5.h.e(aVar, "binding");
        W4.f fVar = aVar.f3498c;
        A5.h.d(fVar, "getBinaryMessenger(...)");
        c.b(d.f4642k, fVar, this);
        FlutterFirebasePluginRegistry.registerPlugin("plugins.flutter.io/firebase_remote_config", this);
        A4.d dVar = new A4.d(fVar, "plugins.flutter.io/firebase_remote_config_updated");
        this.f4645s = dVar;
        dVar.R(this);
        this.f4646u = fVar;
    }

    @Override // W4.i
    public final void onCancel(Object obj) {
        A5.h.e(obj, "arguments");
        Object obj2 = ((Map) obj).get("appName");
        Objects.requireNonNull(obj2);
        String str = (String) obj2;
        HashMap map = this.r;
        p080m4.j jVar = (p080m4.j) map.get(str);
        if (jVar != null) {
            V4.d dVar = jVar.f7879b;
            e eVar = jVar.f7878a;
            synchronized (dVar) {
                ((LinkedHashSet) dVar.f3633s).remove(eVar);
            }
            map.remove(str);
        }
    }

    @Override // S4.b
    public final void onDetachedFromEngine(S4.a aVar) {
        A5.h.e(aVar, "binding");
        W4.f fVar = this.f4646u;
        if (fVar == null) {
            throw new IllegalStateException("Required value was null.");
        }
        c.b(d.f4642k, fVar, null);
        this.f4646u = null;
        A4.d dVar = this.f4645s;
        A5.h.b(dVar);
        dVar.R(null);
        this.f4645s = null;
        e();
    }

    @Override // W4.i
    public final void onListen(Object obj, W4.g gVar) {
        p080m4.j jVar;
        A5.h.e(obj, "arguments");
        Object obj2 = ((Map) obj).get("appName");
        Objects.requireNonNull(obj2);
        String str = (String) obj2;
        p073l4.e eVarB = b(str);
        HashMap map = this.r;
        e eVar = new e(this, (W4.h) gVar);
        V4.d dVar = eVarB.f7727j;
        synchronized (dVar) {
            ((LinkedHashSet) dVar.f3633s).add(eVar);
            dVar.u();
            jVar = new p080m4.j(dVar, eVar);
        }
        map.put(str, jVar);
    }
}
