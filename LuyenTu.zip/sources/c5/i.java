package c5;

import java.util.List;
import p018d2.G;

/* JADX INFO: loaded from: classes.dex */
public final class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f4649a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f4650b;

    public i(long j6, long j7) {
        this.f4649a = j6;
        this.f4650b = j7;
    }

    public final List a() {
        return G.H(Long.valueOf(this.f4649a), Long.valueOf(this.f4650b));
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof i)) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        return android.support.v4.media.session.b.y(a(), ((i) obj).a());
    }

    public final int hashCode() {
        return a().hashCode();
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("RemoteConfigPigeonSettings(fetchTimeoutSeconds=");
        sb.append(this.f4649a);
        sb.append(", minimumFetchIntervalSeconds=");
        return A3.a.n(sb, this.f4650b, ")");
    }
}
