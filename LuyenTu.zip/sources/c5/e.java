package c5;

import C1.B;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class e implements p073l4.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ f f4643a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ W4.h f4644b;

    public e(f fVar, W4.h hVar) {
        this.f4643a = fVar;
        this.f4644b = hVar;
    }

    @Override // p073l4.b
    public final void a(p073l4.a aVar) {
        this.f4643a.t.post(new B(this.f4644b, new ArrayList(aVar.f7715a), 29));
    }

    @Override // p073l4.b
    public final void b(p073l4.g gVar) {
        this.f4644b.b("firebase_remote_config", gVar.getMessage(), null);
    }
}
