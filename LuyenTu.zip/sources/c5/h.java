package c5;

import W4.w;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Map;
import p033f5.k;
import p033f5.t;
import p033f5.u;
import p033f5.v;
import p040g5.q;
import p040g5.r;
import p040g5.s;
import p047h5.A;
import p047h5.B;
import p047h5.C;
import p047h5.C0363j;
import p047h5.C0364k;
import p047h5.C0367n;
import p047h5.D;
import p047h5.E;
import p047h5.EnumC0365l;
import p047h5.EnumC0366m;
import p047h5.F;
import p047h5.G;
import p047h5.H;
import p047h5.I;
import p047h5.J;
import p047h5.K;
import p047h5.L;
import p047h5.M;
import p047h5.o;
import p047h5.p;
import p047h5.x;
import p047h5.y;
import p047h5.z;
import p054i5.j;

/* JADX INFO: loaded from: classes.dex */
public final class h extends w {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f4648d;

    public /* synthetic */ h(int i6) {
        this.f4648d = i6;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v181, types: [h5.H[]] */
    /* JADX WARN: Type inference failed for: r2v183, types: [h5.E[]] */
    /* JADX WARN: Type inference failed for: r2v185, types: [h5.m[]] */
    /* JADX WARN: Type inference failed for: r2v187, types: [h5.l[]] */
    /* JADX WARN: Type inference failed for: r2v189, types: [h5.A[]] */
    /* JADX WARN: Type inference failed for: r2v191, types: [h5.I[]] */
    /* JADX WARN: Type inference failed for: r2v193, types: [h5.r[]] */
    /* JADX WARN: Type inference failed for: r2v195, types: [h5.p[]] */
    /* JADX WARN: Type inference failed for: r2v41, types: [f5.b[]] */
    /* JADX WARN: Type inference failed for: r2v43, types: [f5.g[]] */
    /* JADX WARN: Type inference failed for: r2v64, types: [g5.c[]] */
    /* JADX WARN: Type inference failed for: r2v66, types: [g5.u[]] */
    /* JADX WARN: Type inference failed for: r2v68, types: [g5.s[]] */
    /* JADX WARN: Type inference failed for: r5v11, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r5v21, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r5v42, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r6v1, types: [f5.b] */
    /* JADX WARN: Type inference failed for: r6v10, types: [h5.H] */
    /* JADX WARN: Type inference failed for: r6v11, types: [h5.E] */
    /* JADX WARN: Type inference failed for: r6v12, types: [h5.m] */
    /* JADX WARN: Type inference failed for: r6v13, types: [h5.l] */
    /* JADX WARN: Type inference failed for: r6v14, types: [h5.A] */
    /* JADX WARN: Type inference failed for: r6v15, types: [h5.I] */
    /* JADX WARN: Type inference failed for: r6v16, types: [h5.r] */
    /* JADX WARN: Type inference failed for: r6v17 */
    /* JADX WARN: Type inference failed for: r6v18, types: [h5.p] */
    /* JADX WARN: Type inference failed for: r6v2 */
    /* JADX WARN: Type inference failed for: r6v3, types: [f5.g] */
    /* JADX WARN: Type inference failed for: r6v5, types: [g5.c] */
    /* JADX WARN: Type inference failed for: r6v6, types: [g5.u] */
    /* JADX WARN: Type inference failed for: r6v7 */
    /* JADX WARN: Type inference failed for: r6v8, types: [g5.s] */
    @Override // W4.w
    public final Object f(byte b6, ByteBuffer byteBuffer) {
        ?? r6;
        ?? r7;
        Object tVar;
        Object j6;
        Object c2;
        ?? r8;
        switch (this.f4648d) {
            case 0:
                A5.h.e(byteBuffer, "buffer");
                if (b6 != -127) {
                    return super.f(b6, byteBuffer);
                }
                Object objE = e(byteBuffer);
                List list = objE instanceof List ? (List) objE : null;
                if (list == null) {
                    return null;
                }
                Object obj = list.get(0);
                A5.h.c(obj, "null cannot be cast to non-null type kotlin.Long");
                long jLongValue = ((Long) obj).longValue();
                Object obj2 = list.get(1);
                A5.h.c(obj2, "null cannot be cast to non-null type kotlin.Long");
                return new i(jLongValue, ((Long) obj2).longValue());
            case 1:
                A5.h.e(byteBuffer, "buffer");
                int i6 = 0;
                if (b6 == -127) {
                    Long l6 = (Long) e(byteBuffer);
                    if (l6 == null) {
                        return null;
                    }
                    int iLongValue = (int) l6.longValue();
                    p033f5.g.f5816s.getClass();
                    ?? Values = p033f5.g.values();
                    int length = Values.length;
                    while (i6 < length) {
                        r6 = Values[i6];
                        if (r6.r != iLongValue) {
                            i6++;
                        }
                    }
                    return null;
                }
                if (b6 == -126) {
                    Long l7 = (Long) e(byteBuffer);
                    if (l7 == null) {
                        return null;
                    }
                    int iLongValue2 = (int) l7.longValue();
                    p033f5.b.f5805s.getClass();
                    ?? Values2 = p033f5.b.values();
                    int length2 = Values2.length;
                    while (i6 < length2) {
                        r6 = Values2[i6];
                        if (r6.r != iLongValue2) {
                            i6++;
                        }
                    }
                    return null;
                }
                if (b6 == -125) {
                    Object objE2 = e(byteBuffer);
                    List list2 = objE2 instanceof List ? (List) objE2 : null;
                    if (list2 == null) {
                        return null;
                    }
                    Object obj3 = list2.get(0);
                    A5.h.c(obj3, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                    return new t((List) obj3, (String) list2.get(1), (String) list2.get(2), (String) list2.get(3));
                }
                if (b6 == -124) {
                    Object objE3 = e(byteBuffer);
                    List list3 = objE3 instanceof List ? (List) objE3 : null;
                    if (list3 == null) {
                        return null;
                    }
                    Object obj4 = list3.get(0);
                    A5.h.c(obj4, "null cannot be cast to non-null type kotlin.Boolean");
                    boolean zBooleanValue = ((Boolean) obj4).booleanValue();
                    Object obj5 = list3.get(1);
                    A5.h.c(obj5, "null cannot be cast to non-null type io.flutter.plugins.googlesignin.GetCredentialRequestGoogleIdOptionParams");
                    return new p033f5.i(zBooleanValue, (p033f5.h) obj5, (String) list3.get(2), (String) list3.get(3), (String) list3.get(4));
                }
                if (b6 == -123) {
                    Object objE4 = e(byteBuffer);
                    List list4 = objE4 instanceof List ? (List) objE4 : null;
                    if (list4 == null) {
                        return null;
                    }
                    Object obj6 = list4.get(0);
                    A5.h.c(obj6, "null cannot be cast to non-null type kotlin.Boolean");
                    boolean zBooleanValue2 = ((Boolean) obj6).booleanValue();
                    Object obj7 = list4.get(1);
                    A5.h.c(obj7, "null cannot be cast to non-null type kotlin.Boolean");
                    return new p033f5.h(zBooleanValue2, ((Boolean) obj7).booleanValue());
                }
                if (b6 == -122) {
                    Object objE5 = e(byteBuffer);
                    List list5 = objE5 instanceof List ? (List) objE5 : null;
                    if (list5 == null) {
                        return null;
                    }
                    Object obj8 = list5.get(0);
                    A5.h.c(obj8, "null cannot be cast to non-null type kotlin.String");
                    Object obj9 = list5.get(1);
                    A5.h.c(obj9, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                    return new p033f5.w((String) obj8, (List) obj9);
                }
                if (b6 == -121) {
                    Object objE6 = e(byteBuffer);
                    List list6 = objE6 instanceof List ? (List) objE6 : null;
                    if (list6 == null) {
                        return null;
                    }
                    String str = (String) list6.get(0);
                    String str2 = (String) list6.get(1);
                    String str3 = (String) list6.get(2);
                    Object obj10 = list6.get(3);
                    A5.h.c(obj10, "null cannot be cast to non-null type kotlin.String");
                    String str4 = (String) obj10;
                    Object obj11 = list6.get(4);
                    A5.h.c(obj11, "null cannot be cast to non-null type kotlin.String");
                    return new v(str, str2, str3, str4, (String) obj11, (String) list6.get(5));
                }
                if (b6 == -120) {
                    Object objE7 = e(byteBuffer);
                    List list7 = objE7 instanceof List ? (List) objE7 : null;
                    if (list7 == null) {
                        return null;
                    }
                    Object obj12 = list7.get(0);
                    A5.h.c(obj12, "null cannot be cast to non-null type io.flutter.plugins.googlesignin.GetCredentialFailureType");
                    return new p033f5.e((p033f5.g) obj12, (String) list7.get(1), (String) list7.get(2));
                }
                if (b6 == -119) {
                    Object objE8 = e(byteBuffer);
                    List list8 = objE8 instanceof List ? (List) objE8 : null;
                    if (list8 == null) {
                        return null;
                    }
                    Object obj13 = list8.get(0);
                    A5.h.c(obj13, "null cannot be cast to non-null type io.flutter.plugins.googlesignin.PlatformGoogleIdTokenCredential");
                    return new k((v) obj13);
                }
                if (b6 == -118) {
                    Object objE9 = e(byteBuffer);
                    List list9 = objE9 instanceof List ? (List) objE9 : null;
                    if (list9 == null) {
                        return null;
                    }
                    Object obj14 = list9.get(0);
                    A5.h.c(obj14, "null cannot be cast to non-null type io.flutter.plugins.googlesignin.AuthorizeFailureType");
                    return new p033f5.a((p033f5.b) obj14, (String) list9.get(1), (String) list9.get(2));
                }
                if (b6 != -117) {
                    return super.f(b6, byteBuffer);
                }
                Object objE10 = e(byteBuffer);
                List list10 = objE10 instanceof List ? (List) objE10 : null;
                if (list10 == null) {
                    return null;
                }
                String str5 = (String) list10.get(0);
                String str6 = (String) list10.get(1);
                Object obj15 = list10.get(2);
                A5.h.c(obj15, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                return new u(str5, (List) obj15, str6);
                return r6;
            case 2:
                A5.h.e(byteBuffer, "buffer");
                int i7 = 0;
                if (b6 == -127) {
                    Long l8 = (Long) e(byteBuffer);
                    if (l8 == null) {
                        return null;
                    }
                    int iLongValue3 = (int) l8.longValue();
                    s.f5936s.getClass();
                    ?? Values3 = s.values();
                    int length3 = Values3.length;
                    while (i7 < length3) {
                        r7 = Values3[i7];
                        if (r7.r != iLongValue3) {
                            i7++;
                        }
                    }
                    return null;
                }
                if (b6 == -126) {
                    Long l9 = (Long) e(byteBuffer);
                    if (l9 == null) {
                        return null;
                    }
                    int iLongValue4 = (int) l9.longValue();
                    p040g5.u.f5939s.getClass();
                    ?? Values4 = p040g5.u.values();
                    int length4 = Values4.length;
                    while (i7 < length4) {
                        r7 = Values4[i7];
                        if (r7.r != iLongValue4) {
                            i7++;
                        }
                    }
                    return null;
                }
                if (b6 == -125) {
                    Long l10 = (Long) e(byteBuffer);
                    if (l10 == null) {
                        return null;
                    }
                    int iLongValue5 = (int) l10.longValue();
                    p040g5.c.f5903s.getClass();
                    ?? Values5 = p040g5.c.values();
                    int length5 = Values5.length;
                    while (i7 < length5) {
                        r7 = Values5[i7];
                        if (r7.r != iLongValue5) {
                            i7++;
                        }
                    }
                    return null;
                }
                if (b6 == -124) {
                    Object objE11 = e(byteBuffer);
                    List list11 = objE11 instanceof List ? (List) objE11 : null;
                    if (list11 == null) {
                        return null;
                    }
                    Object obj16 = list11.get(0);
                    A5.h.c(obj16, "null cannot be cast to non-null type kotlin.Boolean");
                    boolean zBooleanValue3 = ((Boolean) obj16).booleanValue();
                    Object obj17 = list11.get(1);
                    A5.h.c(obj17, "null cannot be cast to non-null type kotlin.Boolean");
                    return new p040g5.e(zBooleanValue3, ((Boolean) obj17).booleanValue(), (Long) list11.get(2));
                }
                if (b6 == -123) {
                    Object objE12 = e(byteBuffer);
                    List list12 = objE12 instanceof List ? (List) objE12 : null;
                    if (list12 == null) {
                        return null;
                    }
                    Double d6 = (Double) list12.get(0);
                    Double d7 = (Double) list12.get(1);
                    Object obj18 = list12.get(2);
                    A5.h.c(obj18, "null cannot be cast to non-null type kotlin.Long");
                    return new q(d6, d7, ((Long) obj18).longValue());
                }
                if (b6 == -122) {
                    Object objE13 = e(byteBuffer);
                    List list13 = objE13 instanceof List ? (List) objE13 : null;
                    if (list13 == null) {
                        return null;
                    }
                    Object obj19 = list13.get(0);
                    A5.h.c(obj19, "null cannot be cast to non-null type io.flutter.plugins.imagepicker.ImageSelectionOptions");
                    return new r((q) obj19);
                }
                if (b6 == -121) {
                    Object objE14 = e(byteBuffer);
                    List list14 = objE14 instanceof List ? (List) objE14 : null;
                    if (list14 != null) {
                        return new p040g5.v((Long) list14.get(0));
                    }
                    return null;
                }
                if (b6 == -120) {
                    Object objE15 = e(byteBuffer);
                    List list15 = objE15 instanceof List ? (List) objE15 : null;
                    if (list15 == null) {
                        return null;
                    }
                    Object obj20 = list15.get(0);
                    A5.h.c(obj20, "null cannot be cast to non-null type io.flutter.plugins.imagepicker.SourceType");
                    return new p040g5.t((p040g5.u) obj20, (s) list15.get(1));
                }
                if (b6 == -119) {
                    Object objE16 = e(byteBuffer);
                    List list16 = objE16 instanceof List ? (List) objE16 : null;
                    if (list16 == null) {
                        return null;
                    }
                    Object obj21 = list16.get(0);
                    A5.h.c(obj21, "null cannot be cast to non-null type kotlin.String");
                    return new p040g5.a((String) obj21, (String) list16.get(1));
                }
                if (b6 != -118) {
                    return super.f(b6, byteBuffer);
                }
                Object objE17 = e(byteBuffer);
                List list17 = objE17 instanceof List ? (List) objE17 : null;
                if (list17 == null) {
                    return null;
                }
                Object obj22 = list17.get(0);
                A5.h.c(obj22, "null cannot be cast to non-null type io.flutter.plugins.imagepicker.CacheRetrievalType");
                p040g5.a aVar = (p040g5.a) list17.get(1);
                Object obj23 = list17.get(2);
                A5.h.c(obj23, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                return new p040g5.b((p040g5.c) obj22, aVar, (List) obj23);
                return r7;
            case 3:
                A5.h.e(byteBuffer, "buffer");
                int i8 = 0;
                if (b6 == -127) {
                    Long l11 = (Long) e(byteBuffer);
                    if (l11 != null) {
                        int iLongValue6 = (int) l11.longValue();
                        p.f6182s.getClass();
                        ?? Values6 = p.values();
                        int length6 = Values6.length;
                        while (i8 < length6) {
                            r8 = Values6[i8];
                            if (r8.r == iLongValue6) {
                                return r8;
                            }
                            i8++;
                        }
                    }
                    return null;
                }
                if (b6 == -126) {
                    Long l12 = (Long) e(byteBuffer);
                    if (l12 != null) {
                        int iLongValue7 = (int) l12.longValue();
                        p047h5.r.f6191s.getClass();
                        ?? Values7 = p047h5.r.values();
                        int length7 = Values7.length;
                        while (i8 < length7) {
                            r8 = Values7[i8];
                            if (r8.r == iLongValue7) {
                                return r8;
                            }
                            i8++;
                        }
                    }
                    return null;
                }
                if (b6 == -125) {
                    Long l13 = (Long) e(byteBuffer);
                    if (l13 != null) {
                        int iLongValue8 = (int) l13.longValue();
                        I.f6127s.getClass();
                        ?? Values8 = I.values();
                        int length8 = Values8.length;
                        while (i8 < length8) {
                            r8 = Values8[i8];
                            if (r8.r == iLongValue8) {
                                return r8;
                            }
                            i8++;
                        }
                    }
                    return null;
                }
                if (b6 == -124) {
                    Long l14 = (Long) e(byteBuffer);
                    if (l14 != null) {
                        int iLongValue9 = (int) l14.longValue();
                        A.f6089s.getClass();
                        ?? Values9 = A.values();
                        int length9 = Values9.length;
                        while (i8 < length9) {
                            r8 = Values9[i8];
                            if (r8.r == iLongValue9) {
                                return r8;
                            }
                            i8++;
                        }
                    }
                    return null;
                }
                if (b6 == -123) {
                    Long l15 = (Long) e(byteBuffer);
                    if (l15 != null) {
                        int iLongValue10 = (int) l15.longValue();
                        EnumC0365l.f6166s.getClass();
                        ?? Values10 = EnumC0365l.values();
                        int length10 = Values10.length;
                        while (i8 < length10) {
                            r8 = Values10[i8];
                            if (r8.r == iLongValue10) {
                                return r8;
                            }
                            i8++;
                        }
                    }
                    return null;
                }
                if (b6 == -122) {
                    Long l16 = (Long) e(byteBuffer);
                    if (l16 != null) {
                        int iLongValue11 = (int) l16.longValue();
                        EnumC0366m.f6167s.getClass();
                        ?? Values11 = EnumC0366m.values();
                        int length11 = Values11.length;
                        while (i8 < length11) {
                            r8 = Values11[i8];
                            if (r8.r == iLongValue11) {
                                return r8;
                            }
                            i8++;
                        }
                    }
                    return null;
                }
                if (b6 == -121) {
                    Long l17 = (Long) e(byteBuffer);
                    if (l17 != null) {
                        int iLongValue12 = (int) l17.longValue();
                        E.f6115s.getClass();
                        ?? Values12 = E.values();
                        int length12 = Values12.length;
                        while (i8 < length12) {
                            r8 = Values12[i8];
                            if (r8.r == iLongValue12) {
                                return r8;
                            }
                            i8++;
                        }
                    }
                    return null;
                }
                if (b6 == -120) {
                    Long l18 = (Long) e(byteBuffer);
                    if (l18 != null) {
                        int iLongValue13 = (int) l18.longValue();
                        H.f6123s.getClass();
                        ?? Values13 = H.values();
                        int length13 = Values13.length;
                        while (i8 < length13) {
                            r8 = Values13[i8];
                            if (r8.r == iLongValue13) {
                                return r8;
                            }
                            i8++;
                        }
                    }
                } else if (b6 == -119) {
                    Object objE18 = e(byteBuffer);
                    List list18 = objE18 instanceof List ? (List) objE18 : null;
                    if (list18 != null) {
                        Object obj24 = list18.get(0);
                        A5.h.c(obj24, "null cannot be cast to non-null type kotlin.String");
                        Object obj25 = list18.get(1);
                        A5.h.c(obj25, "null cannot be cast to non-null type io.flutter.plugins.inapppurchase.PlatformProductType");
                        return new G((String) obj24, (A) obj25);
                    }
                } else if (b6 == -118) {
                    Object objE19 = e(byteBuffer);
                    List list19 = objE19 instanceof List ? (List) objE19 : null;
                    if (list19 != null) {
                        return new C0363j((String) list19.get(0), (String) list19.get(1));
                    }
                } else if (b6 == -117) {
                    Object objE20 = e(byteBuffer);
                    List list20 = objE20 instanceof List ? (List) objE20 : null;
                    if (list20 != null) {
                        Object obj26 = list20.get(0);
                        A5.h.c(obj26, "null cannot be cast to non-null type io.flutter.plugins.inapppurchase.PlatformBillingResponse");
                        Object obj27 = list20.get(1);
                        A5.h.c(obj27, "null cannot be cast to non-null type kotlin.String");
                        Object obj28 = list20.get(2);
                        A5.h.c(obj28, "null cannot be cast to non-null type kotlin.Long");
                        tVar = new p047h5.q((p) obj26, (String) obj27, ((Long) obj28).longValue());
                        return tVar;
                    }
                } else if (b6 == -116) {
                    Object objE21 = e(byteBuffer);
                    List list21 = objE21 instanceof List ? (List) objE21 : null;
                    if (list21 != null) {
                        Object obj29 = list21.get(0);
                        A5.h.c(obj29, "null cannot be cast to non-null type kotlin.Long");
                        long jLongValue2 = ((Long) obj29).longValue();
                        Object obj30 = list21.get(1);
                        A5.h.c(obj30, "null cannot be cast to non-null type kotlin.String");
                        Object obj31 = list21.get(2);
                        A5.h.c(obj31, "null cannot be cast to non-null type kotlin.String");
                        return new p047h5.u(jLongValue2, (String) obj30, (String) obj31);
                    }
                } else if (b6 == -115) {
                    Object objE22 = e(byteBuffer);
                    List list22 = objE22 instanceof List ? (List) objE22 : null;
                    if (list22 != null) {
                        Object obj32 = list22.get(0);
                        A5.h.c(obj32, "null cannot be cast to non-null type kotlin.String");
                        String str7 = (String) obj32;
                        Object obj33 = list22.get(1);
                        A5.h.c(obj33, "null cannot be cast to non-null type kotlin.String");
                        String str8 = (String) obj33;
                        Object obj34 = list22.get(2);
                        A5.h.c(obj34, "null cannot be cast to non-null type kotlin.String");
                        String str9 = (String) obj34;
                        Object obj35 = list22.get(3);
                        A5.h.c(obj35, "null cannot be cast to non-null type io.flutter.plugins.inapppurchase.PlatformProductType");
                        A a5 = (A) obj35;
                        Object obj36 = list22.get(4);
                        A5.h.c(obj36, "null cannot be cast to non-null type kotlin.String");
                        j6 = new y(str7, str8, str9, a5, (String) obj36, (p047h5.u) list22.get(5), (List) list22.get(6), (List) list22.get(7));
                        return j6;
                    }
                } else if (b6 == -114) {
                    Object objE23 = e(byteBuffer);
                    List list23 = objE23 instanceof List ? (List) objE23 : null;
                    if (list23 != null) {
                        Object obj37 = list23.get(0);
                        A5.h.c(obj37, "null cannot be cast to non-null type io.flutter.plugins.inapppurchase.PlatformBillingResult");
                        Object obj38 = list23.get(1);
                        A5.h.c(obj38, "null cannot be cast to non-null type kotlin.collections.List<io.flutter.plugins.inapppurchase.PlatformProductDetails>");
                        Object obj39 = list23.get(2);
                        A5.h.c(obj39, "null cannot be cast to non-null type kotlin.collections.List<io.flutter.plugins.inapppurchase.PlatformUnfetchedProduct>");
                        return new z((p047h5.q) obj37, (List) obj38, (List) obj39);
                    }
                } else if (b6 == -113) {
                    Object objE24 = e(byteBuffer);
                    List list24 = objE24 instanceof List ? (List) objE24 : null;
                    if (list24 != null) {
                        Object obj40 = list24.get(0);
                        A5.h.c(obj40, "null cannot be cast to non-null type io.flutter.plugins.inapppurchase.PlatformBillingResult");
                        Object obj41 = list24.get(1);
                        A5.h.c(obj41, "null cannot be cast to non-null type kotlin.String");
                        return new C0364k((p047h5.q) obj40, (String) obj41);
                    }
                } else if (b6 == -112) {
                    Object objE25 = e(byteBuffer);
                    List list25 = objE25 instanceof List ? (List) objE25 : null;
                    if (list25 != null) {
                        Object obj42 = list25.get(0);
                        A5.h.c(obj42, "null cannot be cast to non-null type io.flutter.plugins.inapppurchase.PlatformInAppMessageResponse");
                        return new p047h5.s((p047h5.r) obj42, (String) list25.get(1));
                    }
                } else if (b6 == -111) {
                    Object objE26 = e(byteBuffer);
                    List list26 = objE26 instanceof List ? (List) objE26 : null;
                    if (list26 != null) {
                        Object obj43 = list26.get(0);
                        A5.h.c(obj43, "null cannot be cast to non-null type io.flutter.plugins.inapppurchase.PlatformBillingResult");
                        Object obj44 = list26.get(1);
                        A5.h.c(obj44, "null cannot be cast to non-null type kotlin.String");
                        return new C0367n((p047h5.q) obj43, (String) obj44);
                    }
                } else if (b6 == -110) {
                    Object objE27 = e(byteBuffer);
                    List list27 = objE27 instanceof List ? (List) objE27 : null;
                    if (list27 != null) {
                        Object obj45 = list27.get(0);
                        A5.h.c(obj45, "null cannot be cast to non-null type kotlin.String");
                        String str10 = (String) obj45;
                        Object obj46 = list27.get(1);
                        A5.h.c(obj46, "null cannot be cast to non-null type io.flutter.plugins.inapppurchase.PlatformReplacementMode");
                        j6 = new o(str10, (I) obj46, (String) list27.get(2), (String) list27.get(3), (String) list27.get(4), (String) list27.get(5), (String) list27.get(6));
                        return j6;
                    }
                } else if (b6 == -109) {
                    Object objE28 = e(byteBuffer);
                    List list28 = objE28 instanceof List ? (List) objE28 : null;
                    if (list28 != null) {
                        Object obj47 = list28.get(0);
                        A5.h.c(obj47, "null cannot be cast to non-null type kotlin.Long");
                        long jLongValue3 = ((Long) obj47).longValue();
                        Object obj48 = list28.get(1);
                        A5.h.c(obj48, "null cannot be cast to non-null type io.flutter.plugins.inapppurchase.PlatformRecurrenceMode");
                        H h7 = (H) obj48;
                        Object obj49 = list28.get(2);
                        A5.h.c(obj49, "null cannot be cast to non-null type kotlin.Long");
                        long jLongValue4 = ((Long) obj49).longValue();
                        Object obj50 = list28.get(3);
                        A5.h.c(obj50, "null cannot be cast to non-null type kotlin.String");
                        String str11 = (String) obj50;
                        Object obj51 = list28.get(4);
                        A5.h.c(obj51, "null cannot be cast to non-null type kotlin.String");
                        Object obj52 = list28.get(5);
                        A5.h.c(obj52, "null cannot be cast to non-null type kotlin.String");
                        j6 = new x(jLongValue3, h7, jLongValue4, str11, (String) obj51, (String) obj52);
                        return j6;
                    }
                } else if (b6 == -108) {
                    Object objE29 = e(byteBuffer);
                    List list29 = objE29 instanceof List ? (List) objE29 : null;
                    if (list29 != null) {
                        String str12 = (String) list29.get(0);
                        Object obj53 = list29.get(1);
                        A5.h.c(obj53, "null cannot be cast to non-null type kotlin.String");
                        String str13 = (String) obj53;
                        Object obj54 = list29.get(2);
                        A5.h.c(obj54, "null cannot be cast to non-null type kotlin.Long");
                        long jLongValue5 = ((Long) obj54).longValue();
                        Object obj55 = list29.get(3);
                        A5.h.c(obj55, "null cannot be cast to non-null type kotlin.String");
                        String str14 = (String) obj55;
                        Object obj56 = list29.get(4);
                        A5.h.c(obj56, "null cannot be cast to non-null type kotlin.String");
                        String str15 = (String) obj56;
                        Object obj57 = list29.get(5);
                        A5.h.c(obj57, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                        List list30 = (List) obj57;
                        Object obj58 = list29.get(6);
                        A5.h.c(obj58, "null cannot be cast to non-null type kotlin.Boolean");
                        boolean zBooleanValue4 = ((Boolean) obj58).booleanValue();
                        Object obj59 = list29.get(7);
                        A5.h.c(obj59, "null cannot be cast to non-null type kotlin.String");
                        String str16 = (String) obj59;
                        Object obj60 = list29.get(8);
                        A5.h.c(obj60, "null cannot be cast to non-null type kotlin.String");
                        String str17 = (String) obj60;
                        Object obj61 = list29.get(9);
                        A5.h.c(obj61, "null cannot be cast to non-null type kotlin.Boolean");
                        boolean zBooleanValue5 = ((Boolean) obj61).booleanValue();
                        Object obj62 = list29.get(10);
                        A5.h.c(obj62, "null cannot be cast to non-null type kotlin.Long");
                        long jLongValue6 = ((Long) obj62).longValue();
                        Object obj63 = list29.get(11);
                        A5.h.c(obj63, "null cannot be cast to non-null type io.flutter.plugins.inapppurchase.PlatformPurchaseState");
                        c2 = new B(str12, str13, jLongValue5, str14, str15, list30, zBooleanValue4, str16, str17, zBooleanValue5, jLongValue6, (E) obj63, (C0363j) list29.get(12), (p047h5.v) list29.get(13));
                        return c2;
                    }
                } else if (b6 == -107) {
                    Object objE30 = e(byteBuffer);
                    List list31 = objE30 instanceof List ? (List) objE30 : null;
                    if (list31 != null) {
                        Object obj64 = list31.get(0);
                        A5.h.c(obj64, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                        Object obj65 = list31.get(1);
                        A5.h.c(obj65, "null cannot be cast to non-null type kotlin.String");
                        return new p047h5.v((String) obj65, (List) obj64);
                    }
                } else if (b6 == -106) {
                    Object objE31 = e(byteBuffer);
                    List list32 = objE31 instanceof List ? (List) objE31 : null;
                    if (list32 != null) {
                        Object obj66 = list32.get(0);
                        A5.h.c(obj66, "null cannot be cast to non-null type kotlin.Long");
                        long jLongValue7 = ((Long) obj66).longValue();
                        Object obj67 = list32.get(1);
                        A5.h.c(obj67, "null cannot be cast to non-null type kotlin.Long");
                        long jLongValue8 = ((Long) obj67).longValue();
                        String str18 = (String) list32.get(2);
                        Object obj68 = list32.get(3);
                        A5.h.c(obj68, "null cannot be cast to non-null type kotlin.String");
                        String str19 = (String) obj68;
                        Object obj69 = list32.get(4);
                        A5.h.c(obj69, "null cannot be cast to non-null type kotlin.String");
                        String str20 = (String) obj69;
                        Object obj70 = list32.get(5);
                        A5.h.c(obj70, "null cannot be cast to non-null type kotlin.String");
                        Object obj71 = list32.get(6);
                        A5.h.c(obj71, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                        c2 = new C(jLongValue7, jLongValue8, str18, str19, str20, (String) obj70, (List) obj71);
                        return c2;
                    }
                } else if (b6 == -105) {
                    Object objE32 = e(byteBuffer);
                    List list33 = objE32 instanceof List ? (List) objE32 : null;
                    if (list33 != null) {
                        Object obj72 = list33.get(0);
                        A5.h.c(obj72, "null cannot be cast to non-null type io.flutter.plugins.inapppurchase.PlatformBillingResult");
                        Object obj73 = list33.get(1);
                        A5.h.c(obj73, "null cannot be cast to non-null type kotlin.collections.List<io.flutter.plugins.inapppurchase.PlatformPurchaseHistoryRecord>");
                        return new D((p047h5.q) obj72, (List) obj73);
                    }
                } else if (b6 == -104) {
                    Object objE33 = e(byteBuffer);
                    List list34 = objE33 instanceof List ? (List) objE33 : null;
                    if (list34 != null) {
                        Object obj74 = list34.get(0);
                        A5.h.c(obj74, "null cannot be cast to non-null type io.flutter.plugins.inapppurchase.PlatformBillingResult");
                        Object obj75 = list34.get(1);
                        A5.h.c(obj75, "null cannot be cast to non-null type kotlin.collections.List<io.flutter.plugins.inapppurchase.PlatformPurchase>");
                        return new F((p047h5.q) obj74, (List) obj75);
                    }
                } else if (b6 == -103) {
                    Object objE34 = e(byteBuffer);
                    List list35 = objE34 instanceof List ? (List) objE34 : null;
                    if (list35 != null) {
                        Object obj76 = list35.get(0);
                        A5.h.c(obj76, "null cannot be cast to non-null type kotlin.String");
                        String str21 = (String) obj76;
                        String str22 = (String) list35.get(1);
                        Object obj77 = list35.get(2);
                        A5.h.c(obj77, "null cannot be cast to non-null type kotlin.String");
                        String str23 = (String) obj77;
                        Object obj78 = list35.get(3);
                        A5.h.c(obj78, "null cannot be cast to non-null type kotlin.collections.List<kotlin.String>");
                        List list36 = (List) obj78;
                        Object obj79 = list35.get(4);
                        A5.h.c(obj79, "null cannot be cast to non-null type kotlin.collections.List<io.flutter.plugins.inapppurchase.PlatformPricingPhase>");
                        j6 = new J(str21, str22, str23, list36, (List) obj79, (p047h5.t) list35.get(5));
                        return j6;
                    }
                } else if (b6 == -102) {
                    Object objE35 = e(byteBuffer);
                    List list37 = objE35 instanceof List ? (List) objE35 : null;
                    if (list37 != null) {
                        String str24 = (String) list37.get(0);
                        Object obj80 = list37.get(1);
                        A5.h.c(obj80, "null cannot be cast to non-null type kotlin.String");
                        Object obj81 = list37.get(2);
                        A5.h.c(obj81, "null cannot be cast to non-null type kotlin.collections.List<io.flutter.plugins.inapppurchase.PlatformUserChoiceProduct>");
                        return new L(str24, (List) obj81, (String) obj80);
                    }
                } else if (b6 == -101) {
                    Object objE36 = e(byteBuffer);
                    List list38 = objE36 instanceof List ? (List) objE36 : null;
                    if (list38 != null) {
                        Object obj82 = list38.get(0);
                        A5.h.c(obj82, "null cannot be cast to non-null type kotlin.String");
                        String str25 = (String) list38.get(1);
                        Object obj83 = list38.get(2);
                        A5.h.c(obj83, "null cannot be cast to non-null type io.flutter.plugins.inapppurchase.PlatformProductType");
                        return new M((String) obj82, str25, (A) obj83);
                    }
                } else if (b6 == -100) {
                    Object objE37 = e(byteBuffer);
                    List list39 = objE37 instanceof List ? (List) objE37 : null;
                    if (list39 != null) {
                        Object obj84 = list39.get(0);
                        A5.h.c(obj84, "null cannot be cast to non-null type kotlin.Long");
                        long jLongValue9 = ((Long) obj84).longValue();
                        Object obj85 = list39.get(1);
                        A5.h.c(obj85, "null cannot be cast to non-null type kotlin.Long");
                        tVar = new p047h5.t(jLongValue9, ((Long) obj85).longValue());
                        return tVar;
                    }
                } else if (b6 == -99) {
                    Object objE38 = e(byteBuffer);
                    List list40 = objE38 instanceof List ? (List) objE38 : null;
                    if (list40 != null) {
                        Object obj86 = list40.get(0);
                        A5.h.c(obj86, "null cannot be cast to non-null type kotlin.Boolean");
                        return new p047h5.w(((Boolean) obj86).booleanValue());
                    }
                } else {
                    if (b6 != -98) {
                        return super.f(b6, byteBuffer);
                    }
                    Object objE39 = e(byteBuffer);
                    List list41 = objE39 instanceof List ? (List) objE39 : null;
                    if (list41 != null) {
                        Object obj87 = list41.get(0);
                        A5.h.c(obj87, "null cannot be cast to non-null type kotlin.String");
                        return new K((String) obj87);
                    }
                }
                return null;
            default:
                A5.h.e(byteBuffer, "buffer");
                if (b6 != -127) {
                    if (b6 != -126) {
                        return super.f(b6, byteBuffer);
                    }
                    Object objE40 = e(byteBuffer);
                    List list42 = objE40 instanceof List ? (List) objE40 : null;
                    if (list42 == null) {
                        return null;
                    }
                    Object obj88 = list42.get(0);
                    A5.h.c(obj88, "null cannot be cast to non-null type kotlin.Boolean");
                    return new p054i5.a(((Boolean) obj88).booleanValue());
                }
                Object objE41 = e(byteBuffer);
                List list43 = objE41 instanceof List ? (List) objE41 : null;
                if (list43 == null) {
                    return null;
                }
                Object obj89 = list43.get(0);
                A5.h.c(obj89, "null cannot be cast to non-null type kotlin.Boolean");
                boolean zBooleanValue6 = ((Boolean) obj89).booleanValue();
                Object obj90 = list43.get(1);
                A5.h.c(obj90, "null cannot be cast to non-null type kotlin.Boolean");
                boolean zBooleanValue7 = ((Boolean) obj90).booleanValue();
                Object obj91 = list43.get(2);
                A5.h.c(obj91, "null cannot be cast to non-null type kotlin.collections.Map<kotlin.String, kotlin.String>");
                return new j(zBooleanValue6, zBooleanValue7, (Map) obj91);
        }
    }

    /* JADX WARN: Unexpected iteration count in SwitchBreakVisitor. Please report as an issue */
    @Override // W4.w
    public final void k(W4.v vVar, Object obj) {
        switch (this.f4648d) {
            case 0:
                if (!(obj instanceof i)) {
                    super.k(vVar, obj);
                } else {
                    vVar.write(129);
                    k(vVar, ((i) obj).a());
                }
                break;
            case 1:
                if (obj instanceof p033f5.g) {
                    vVar.write(129);
                    k(vVar, Long.valueOf(((p033f5.g) obj).r));
                } else if (obj instanceof p033f5.b) {
                    vVar.write(130);
                    k(vVar, Long.valueOf(((p033f5.b) obj).r));
                } else if (obj instanceof t) {
                    vVar.write(131);
                    k(vVar, ((t) obj).a());
                } else if (obj instanceof p033f5.i) {
                    vVar.write(132);
                    k(vVar, ((p033f5.i) obj).a());
                } else if (obj instanceof p033f5.h) {
                    vVar.write(133);
                    k(vVar, ((p033f5.h) obj).a());
                } else if (obj instanceof p033f5.w) {
                    vVar.write(134);
                    p033f5.w wVar = (p033f5.w) obj;
                    k(vVar, p018d2.G.H(wVar.f5853a, wVar.f5854b));
                } else if (obj instanceof v) {
                    vVar.write(135);
                    k(vVar, ((v) obj).a());
                } else if (obj instanceof p033f5.e) {
                    vVar.write(136);
                    k(vVar, ((p033f5.e) obj).a());
                } else if (obj instanceof k) {
                    vVar.write(137);
                    k(vVar, p018d2.G.G(((k) obj).f5829a));
                } else if (obj instanceof p033f5.a) {
                    vVar.write(138);
                    k(vVar, ((p033f5.a) obj).a());
                } else if (!(obj instanceof u)) {
                    super.k(vVar, obj);
                } else {
                    vVar.write(139);
                    k(vVar, ((u) obj).a());
                }
                break;
            case 2:
                if (obj instanceof s) {
                    vVar.write(129);
                    k(vVar, Long.valueOf(((s) obj).r));
                } else if (obj instanceof p040g5.u) {
                    vVar.write(130);
                    k(vVar, Long.valueOf(((p040g5.u) obj).r));
                } else if (obj instanceof p040g5.c) {
                    vVar.write(131);
                    k(vVar, Long.valueOf(((p040g5.c) obj).r));
                } else if (obj instanceof p040g5.e) {
                    vVar.write(132);
                    p040g5.e eVar = (p040g5.e) obj;
                    k(vVar, p081m5.e.K(new Object[]{Boolean.valueOf(eVar.f5907a), Boolean.valueOf(eVar.f5908b), eVar.f5909c}));
                } else if (obj instanceof q) {
                    vVar.write(133);
                    q qVar = (q) obj;
                    k(vVar, p081m5.e.K(new Object[]{qVar.f5932a, qVar.f5933b, Long.valueOf(qVar.f5934c)}));
                } else if (obj instanceof r) {
                    vVar.write(134);
                    k(vVar, p018d2.G.G(((r) obj).f5935a));
                } else if (obj instanceof p040g5.v) {
                    vVar.write(135);
                    k(vVar, p018d2.G.G(((p040g5.v) obj).f5940a));
                } else if (obj instanceof p040g5.t) {
                    vVar.write(136);
                    p040g5.t tVar = (p040g5.t) obj;
                    k(vVar, p081m5.e.K(new Enum[]{tVar.f5937a, tVar.f5938b}));
                } else if (obj instanceof p040g5.a) {
                    vVar.write(137);
                    p040g5.a aVar = (p040g5.a) obj;
                    k(vVar, p081m5.e.K(new String[]{aVar.f5898a, aVar.f5899b}));
                } else if (!(obj instanceof p040g5.b)) {
                    super.k(vVar, obj);
                } else {
                    vVar.write(138);
                    p040g5.b bVar = (p040g5.b) obj;
                    k(vVar, p081m5.e.K(new Object[]{bVar.f5900a, bVar.f5901b, bVar.f5902c}));
                }
                break;
            case 3:
                if (obj instanceof p) {
                    vVar.write(129);
                    k(vVar, Long.valueOf(((p) obj).r));
                    break;
                } else if (obj instanceof p047h5.r) {
                    vVar.write(130);
                    k(vVar, Long.valueOf(((p047h5.r) obj).r));
                    break;
                } else if (obj instanceof I) {
                    vVar.write(131);
                    k(vVar, Long.valueOf(((I) obj).r));
                    break;
                } else if (obj instanceof A) {
                    vVar.write(132);
                    k(vVar, Long.valueOf(((A) obj).r));
                    break;
                } else if (obj instanceof EnumC0365l) {
                    vVar.write(133);
                    k(vVar, Long.valueOf(((EnumC0365l) obj).r));
                    break;
                } else if (obj instanceof EnumC0366m) {
                    vVar.write(134);
                    k(vVar, Long.valueOf(((EnumC0366m) obj).r));
                    break;
                } else if (obj instanceof E) {
                    vVar.write(135);
                    k(vVar, Long.valueOf(((E) obj).r));
                    break;
                } else if (obj instanceof H) {
                    vVar.write(136);
                    k(vVar, Long.valueOf(((H) obj).r));
                    break;
                } else {
                    if (obj instanceof G) {
                        vVar.write(137);
                        G g7 = (G) obj;
                        k(vVar, p081m5.e.K(new Object[]{g7.f6121a, g7.f6122b}));
                    } else if (obj instanceof C0363j) {
                        vVar.write(138);
                        C0363j c0363j = (C0363j) obj;
                        k(vVar, p081m5.e.K(new String[]{c0363j.f6162a, c0363j.f6163b}));
                    } else if (obj instanceof p047h5.q) {
                        vVar.write(139);
                        p047h5.q qVar2 = (p047h5.q) obj;
                        k(vVar, p081m5.e.K(new Object[]{qVar2.f6188a, qVar2.f6189b, Long.valueOf(qVar2.f6190c)}));
                    } else if (obj instanceof p047h5.u) {
                        vVar.write(140);
                        p047h5.u uVar = (p047h5.u) obj;
                        k(vVar, p081m5.e.K(new Object[]{Long.valueOf(uVar.f6198a), uVar.f6199b, uVar.f6200c}));
                    } else if (obj instanceof y) {
                        vVar.write(141);
                        y yVar = (y) obj;
                        k(vVar, p081m5.e.K(new Object[]{yVar.f6210a, yVar.f6211b, yVar.f6212c, yVar.f6213d, yVar.f6214e, yVar.f6215f, yVar.f6216g, yVar.f6217h}));
                    } else if (obj instanceof z) {
                        vVar.write(142);
                        z zVar = (z) obj;
                        k(vVar, p081m5.e.K(new Object[]{zVar.f6218a, zVar.f6219b, zVar.f6220c}));
                    } else if (obj instanceof C0364k) {
                        vVar.write(143);
                        C0364k c0364k = (C0364k) obj;
                        k(vVar, p081m5.e.K(new Object[]{c0364k.f6164a, c0364k.f6165b}));
                    } else if (obj instanceof p047h5.s) {
                        vVar.write(144);
                        p047h5.s sVar = (p047h5.s) obj;
                        k(vVar, p081m5.e.K(new Object[]{sVar.f6194a, sVar.f6195b}));
                    } else if (obj instanceof C0367n) {
                        vVar.write(145);
                        C0367n c0367n = (C0367n) obj;
                        k(vVar, p081m5.e.K(new Object[]{c0367n.f6168a, c0367n.f6169b}));
                    } else if (obj instanceof o) {
                        vVar.write(146);
                        o oVar = (o) obj;
                        k(vVar, p081m5.e.K(new Object[]{oVar.f6170a, oVar.f6171b, oVar.f6172c, oVar.f6173d, oVar.f6174e, oVar.f6175f, oVar.f6176g}));
                    } else if (obj instanceof x) {
                        vVar.write(147);
                        x xVar = (x) obj;
                        k(vVar, p081m5.e.K(new Object[]{Long.valueOf(xVar.f6204a), xVar.f6205b, Long.valueOf(xVar.f6206c), xVar.f6207d, xVar.f6208e, xVar.f6209f}));
                    } else if (obj instanceof B) {
                        vVar.write(148);
                        B b6 = (B) obj;
                        k(vVar, p081m5.e.K(new Object[]{b6.f6092a, b6.f6093b, Long.valueOf(b6.f6094c), b6.f6095d, b6.f6096e, b6.f6097f, Boolean.valueOf(b6.f6098g), b6.f6099h, b6.f6100i, Boolean.valueOf(b6.f6101j), Long.valueOf(b6.f6102k), b6.f6103l, b6.f6104m, b6.f6105n}));
                    } else if (obj instanceof p047h5.v) {
                        vVar.write(149);
                        p047h5.v vVar2 = (p047h5.v) obj;
                        k(vVar, p081m5.e.K(new Object[]{vVar2.f6201a, vVar2.f6202b}));
                    } else if (obj instanceof C) {
                        vVar.write(150);
                        C c2 = (C) obj;
                        k(vVar, p081m5.e.K(new Object[]{Long.valueOf(c2.f6106a), Long.valueOf(c2.f6107b), c2.f6108c, c2.f6109d, c2.f6110e, c2.f6111f, c2.f6112g}));
                    } else if (obj instanceof D) {
                        vVar.write(151);
                        D d6 = (D) obj;
                        k(vVar, p081m5.e.K(new Object[]{d6.f6113a, d6.f6114b}));
                    } else if (obj instanceof F) {
                        vVar.write(152);
                        F f4 = (F) obj;
                        k(vVar, p081m5.e.K(new Object[]{f4.f6119a, f4.f6120b}));
                    } else if (obj instanceof J) {
                        vVar.write(153);
                        J j6 = (J) obj;
                        k(vVar, p081m5.e.K(new Object[]{j6.f6129a, j6.f6130b, j6.f6131c, j6.f6132d, j6.f6133e, j6.f6134f}));
                    } else if (obj instanceof L) {
                        vVar.write(154);
                        L l6 = (L) obj;
                        k(vVar, p081m5.e.K(new Object[]{l6.f6136a, l6.f6137b, l6.f6138c}));
                    } else if (obj instanceof M) {
                        vVar.write(155);
                        M m6 = (M) obj;
                        k(vVar, p081m5.e.K(new Object[]{m6.f6139a, m6.f6140b, m6.f6141c}));
                    } else if (obj instanceof p047h5.t) {
                        vVar.write(156);
                        p047h5.t tVar2 = (p047h5.t) obj;
                        k(vVar, p081m5.e.K(new Long[]{Long.valueOf(tVar2.f6196a), Long.valueOf(tVar2.f6197b)}));
                    } else if (obj instanceof p047h5.w) {
                        vVar.write(157);
                        k(vVar, p018d2.G.G(Boolean.valueOf(((p047h5.w) obj).f6203a)));
                    } else if (!(obj instanceof K)) {
                        super.k(vVar, obj);
                    } else {
                        vVar.write(158);
                        k(vVar, p018d2.G.G(((K) obj).f6135a));
                    }
                    break;
                }
                break;
            default:
                if (obj instanceof j) {
                    vVar.write(129);
                    j jVar = (j) obj;
                    k(vVar, p081m5.e.K(new Object[]{Boolean.valueOf(jVar.f6389a), Boolean.valueOf(jVar.f6390b), jVar.f6391c}));
                } else if (!(obj instanceof p054i5.a)) {
                    super.k(vVar, obj);
                } else {
                    vVar.write(130);
                    k(vVar, p018d2.G.G(Boolean.valueOf(((p054i5.a) obj).f6382a)));
                }
                break;
        }
    }
}
