package c5;

import android.util.Log;
import java.util.List;
import java.util.Map;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.pipes.PipesServer;
import org.apache.tika.utils.XMLReaderUtils;
import p018d2.G;
import p033f5.j;
import p047h5.C0354a;
import p047h5.C0364k;
import p047h5.C0367n;
import p047h5.F;
import p047h5.q;
import p047h5.s;
import p047h5.z;
import p074l5.l;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class b implements p154z5.c {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ V4.d f4639s;

    public /* synthetic */ b(V4.d dVar, int i6) {
        this.r = i6;
        this.f4639s = dVar;
    }

    @Override // p154z5.c
    public final Object a(Object obj) {
        List listK;
        List listK2;
        List listK3;
        List listK4;
        List listK5;
        List listK6;
        List listK7;
        List listK8;
        List listK9;
        List listK10;
        List listK11;
        List listK12;
        List listK13;
        List listK14;
        List listK15;
        List listK16;
        List listK17;
        List listK18;
        List listK19;
        List listK20;
        List listK21;
        List listK22;
        List listK23;
        List listK24;
        List listK25;
        List listK26;
        List listK27;
        p074l5.i iVar = (p074l5.i) obj;
        switch (this.r) {
            case 0:
                Throwable thA = p074l5.i.a(iVar.r);
                V4.d dVar = this.f4639s;
                if (thA != null) {
                    if (thA instanceof g) {
                        g gVar = (g) thA;
                        listK = p081m5.e.K(new Object[]{gVar.r, gVar.f4647s, gVar.t});
                    } else {
                        listK = p081m5.e.K(new String[]{thA.getClass().getSimpleName(), thA.toString(), A3.a.m("Cause: ", thA.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA))});
                    }
                    dVar.m(listK);
                } else {
                    dVar.m(G.G(null));
                }
                break;
            case 1:
                Throwable thA2 = p074l5.i.a(iVar.r);
                V4.d dVar2 = this.f4639s;
                if (thA2 != null) {
                    if (thA2 instanceof g) {
                        g gVar2 = (g) thA2;
                        listK2 = p081m5.e.K(new Object[]{gVar2.r, gVar2.f4647s, gVar2.t});
                    } else {
                        listK2 = p081m5.e.K(new String[]{thA2.getClass().getSimpleName(), thA2.toString(), A3.a.m("Cause: ", thA2.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA2))});
                    }
                    dVar2.m(listK2);
                } else {
                    dVar2.m(G.G(null));
                }
                break;
            case 2:
                Throwable thA3 = p074l5.i.a(iVar.r);
                V4.d dVar3 = this.f4639s;
                if (thA3 != null) {
                    if (thA3 instanceof g) {
                        g gVar3 = (g) thA3;
                        listK3 = p081m5.e.K(new Object[]{gVar3.r, gVar3.f4647s, gVar3.t});
                    } else {
                        listK3 = p081m5.e.K(new String[]{thA3.getClass().getSimpleName(), thA3.toString(), A3.a.m("Cause: ", thA3.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA3))});
                    }
                    dVar3.m(listK3);
                } else {
                    Object obj2 = iVar.r;
                    if (obj2 instanceof p074l5.h) {
                        obj2 = null;
                    }
                    dVar3.m(G.G((Boolean) obj2));
                }
                break;
            case 3:
                Throwable thA4 = p074l5.i.a(iVar.r);
                V4.d dVar4 = this.f4639s;
                if (thA4 != null) {
                    if (thA4 instanceof g) {
                        g gVar4 = (g) thA4;
                        listK4 = p081m5.e.K(new Object[]{gVar4.r, gVar4.f4647s, gVar4.t});
                    } else {
                        listK4 = p081m5.e.K(new String[]{thA4.getClass().getSimpleName(), thA4.toString(), A3.a.m("Cause: ", thA4.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA4))});
                    }
                    dVar4.m(listK4);
                } else {
                    dVar4.m(G.G(null));
                }
                break;
            case 4:
                Throwable thA5 = p074l5.i.a(iVar.r);
                V4.d dVar5 = this.f4639s;
                if (thA5 != null) {
                    if (thA5 instanceof g) {
                        g gVar5 = (g) thA5;
                        listK5 = p081m5.e.K(new Object[]{gVar5.r, gVar5.f4647s, gVar5.t});
                    } else {
                        listK5 = p081m5.e.K(new String[]{thA5.getClass().getSimpleName(), thA5.toString(), A3.a.m("Cause: ", thA5.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA5))});
                    }
                    dVar5.m(listK5);
                } else {
                    Object obj3 = iVar.r;
                    if (obj3 instanceof p074l5.h) {
                        obj3 = null;
                    }
                    dVar5.m(G.G((Map) obj3));
                }
                break;
            case 5:
                Throwable thA6 = p074l5.i.a(iVar.r);
                V4.d dVar6 = this.f4639s;
                if (thA6 != null) {
                    if (thA6 instanceof g) {
                        g gVar6 = (g) thA6;
                        listK6 = p081m5.e.K(new Object[]{gVar6.r, gVar6.f4647s, gVar6.t});
                    } else {
                        listK6 = p081m5.e.K(new String[]{thA6.getClass().getSimpleName(), thA6.toString(), A3.a.m("Cause: ", thA6.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA6))});
                    }
                    dVar6.m(listK6);
                } else {
                    Object obj4 = iVar.r;
                    if (obj4 instanceof p074l5.h) {
                        obj4 = null;
                    }
                    dVar6.m(G.G((Map) obj4));
                }
                break;
            case 6:
                Throwable thA7 = p074l5.i.a(iVar.r);
                V4.d dVar7 = this.f4639s;
                if (thA7 != null) {
                    if (thA7 instanceof g) {
                        g gVar7 = (g) thA7;
                        listK7 = p081m5.e.K(new Object[]{gVar7.r, gVar7.f4647s, gVar7.t});
                    } else {
                        listK7 = p081m5.e.K(new String[]{thA7.getClass().getSimpleName(), thA7.toString(), A3.a.m("Cause: ", thA7.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA7))});
                    }
                    dVar7.m(listK7);
                } else {
                    dVar7.m(G.G(null));
                }
                break;
            case 7:
                Throwable thA8 = p074l5.i.a(iVar.r);
                V4.d dVar8 = this.f4639s;
                if (thA8 != null) {
                    if (thA8 instanceof g) {
                        g gVar8 = (g) thA8;
                        listK8 = p081m5.e.K(new Object[]{gVar8.r, gVar8.f4647s, gVar8.t});
                    } else {
                        listK8 = p081m5.e.K(new String[]{thA8.getClass().getSimpleName(), thA8.toString(), A3.a.m("Cause: ", thA8.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA8))});
                    }
                    dVar8.m(listK8);
                } else {
                    Object obj5 = iVar.r;
                    if (obj5 instanceof p074l5.h) {
                        obj5 = null;
                    }
                    dVar8.m(G.G((Boolean) obj5));
                }
                break;
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                Throwable thA9 = p074l5.i.a(iVar.r);
                V4.d dVar9 = this.f4639s;
                if (thA9 != null) {
                    if (thA9 instanceof g) {
                        g gVar9 = (g) thA9;
                        listK9 = p081m5.e.K(new Object[]{gVar9.r, gVar9.f4647s, gVar9.t});
                    } else {
                        listK9 = p081m5.e.K(new String[]{thA9.getClass().getSimpleName(), thA9.toString(), A3.a.m("Cause: ", thA9.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA9))});
                    }
                    dVar9.m(listK9);
                } else {
                    dVar9.m(G.G(null));
                }
                break;
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                Throwable thA10 = p074l5.i.a(iVar.r);
                V4.d dVar10 = this.f4639s;
                if (thA10 != null) {
                    if (thA10 instanceof p033f5.d) {
                        p033f5.d dVar11 = (p033f5.d) thA10;
                        listK10 = p081m5.e.K(new Object[]{dVar11.r, dVar11.f5810s, null});
                    } else {
                        listK10 = p081m5.e.K(new String[]{thA10.getClass().getSimpleName(), thA10.toString(), A3.a.m("Cause: ", thA10.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA10))});
                    }
                    dVar10.m(listK10);
                } else {
                    dVar10.m(G.G(null));
                }
                break;
            case 10:
                Throwable thA11 = p074l5.i.a(iVar.r);
                V4.d dVar12 = this.f4639s;
                if (thA11 != null) {
                    if (thA11 instanceof p033f5.d) {
                        p033f5.d dVar13 = (p033f5.d) thA11;
                        listK11 = p081m5.e.K(new Object[]{dVar13.r, dVar13.f5810s, null});
                    } else {
                        listK11 = p081m5.e.K(new String[]{thA11.getClass().getSimpleName(), thA11.toString(), A3.a.m("Cause: ", thA11.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA11))});
                    }
                    dVar12.m(listK11);
                } else {
                    Object obj6 = iVar.r;
                    dVar12.m(G.G((j) (obj6 instanceof p074l5.h ? null : obj6)));
                }
                break;
            case 11:
                Throwable thA12 = p074l5.i.a(iVar.r);
                V4.d dVar14 = this.f4639s;
                if (thA12 != null) {
                    if (thA12 instanceof p033f5.d) {
                        p033f5.d dVar15 = (p033f5.d) thA12;
                        listK12 = p081m5.e.K(new Object[]{dVar15.r, dVar15.f5810s, null});
                    } else {
                        listK12 = p081m5.e.K(new String[]{thA12.getClass().getSimpleName(), thA12.toString(), A3.a.m("Cause: ", thA12.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA12))});
                    }
                    dVar14.m(listK12);
                } else {
                    dVar14.m(G.G(null));
                }
                break;
            case 12:
                Throwable thA13 = p074l5.i.a(iVar.r);
                V4.d dVar16 = this.f4639s;
                if (thA13 != null) {
                    if (thA13 instanceof p033f5.d) {
                        p033f5.d dVar17 = (p033f5.d) thA13;
                        listK13 = p081m5.e.K(new Object[]{dVar17.r, dVar17.f5810s, null});
                    } else {
                        listK13 = p081m5.e.K(new String[]{thA13.getClass().getSimpleName(), thA13.toString(), A3.a.m("Cause: ", thA13.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA13))});
                    }
                    dVar16.m(listK13);
                } else {
                    dVar16.m(G.G(null));
                }
                break;
            case 13:
                Throwable thA14 = p074l5.i.a(iVar.r);
                V4.d dVar18 = this.f4639s;
                if (thA14 != null) {
                    if (thA14 instanceof p033f5.d) {
                        p033f5.d dVar19 = (p033f5.d) thA14;
                        listK14 = p081m5.e.K(new Object[]{dVar19.r, dVar19.f5810s, null});
                    } else {
                        listK14 = p081m5.e.K(new String[]{thA14.getClass().getSimpleName(), thA14.toString(), A3.a.m("Cause: ", thA14.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA14))});
                    }
                    dVar18.m(listK14);
                } else {
                    Object obj7 = iVar.r;
                    dVar18.m(G.G((p033f5.c) (obj7 instanceof p074l5.h ? null : obj7)));
                }
                break;
            case 14:
                Throwable thA15 = p074l5.i.a(iVar.r);
                V4.d dVar20 = this.f4639s;
                if (thA15 != null) {
                    if (thA15 instanceof p040g5.d) {
                        p040g5.d dVar21 = (p040g5.d) thA15;
                        listK15 = p081m5.e.K(new Object[]{dVar21.r, dVar21.f5906s, null});
                    } else {
                        listK15 = p081m5.e.K(new String[]{thA15.getClass().getSimpleName(), thA15.toString(), A3.a.m("Cause: ", thA15.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA15))});
                    }
                    dVar20.m(listK15);
                } else {
                    Object obj8 = iVar.r;
                    dVar20.m(G.G((List) (obj8 instanceof p074l5.h ? null : obj8)));
                }
                break;
            case 15:
                Throwable thA16 = p074l5.i.a(iVar.r);
                V4.d dVar22 = this.f4639s;
                if (thA16 != null) {
                    if (thA16 instanceof p040g5.d) {
                        p040g5.d dVar23 = (p040g5.d) thA16;
                        listK16 = p081m5.e.K(new Object[]{dVar23.r, dVar23.f5906s, null});
                    } else {
                        listK16 = p081m5.e.K(new String[]{thA16.getClass().getSimpleName(), thA16.toString(), A3.a.m("Cause: ", thA16.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA16))});
                    }
                    dVar22.m(listK16);
                } else {
                    Object obj9 = iVar.r;
                    dVar22.m(G.G((List) (obj9 instanceof p074l5.h ? null : obj9)));
                }
                break;
            case 16:
                Throwable thA17 = p074l5.i.a(iVar.r);
                V4.d dVar24 = this.f4639s;
                if (thA17 != null) {
                    if (thA17 instanceof p040g5.d) {
                        p040g5.d dVar25 = (p040g5.d) thA17;
                        listK17 = p081m5.e.K(new Object[]{dVar25.r, dVar25.f5906s, null});
                    } else {
                        listK17 = p081m5.e.K(new String[]{thA17.getClass().getSimpleName(), thA17.toString(), A3.a.m("Cause: ", thA17.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA17))});
                    }
                    dVar24.m(listK17);
                } else {
                    Object obj10 = iVar.r;
                    dVar24.m(G.G((List) (obj10 instanceof p074l5.h ? null : obj10)));
                }
                break;
            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                Throwable thA18 = p074l5.i.a(iVar.r);
                V4.d dVar26 = this.f4639s;
                if (thA18 != null) {
                    if (thA18 instanceof C0354a) {
                        C0354a c0354a = (C0354a) thA18;
                        listK18 = p081m5.e.K(new Object[]{c0354a.r, c0354a.f6145s, c0354a.t});
                    } else {
                        listK18 = p081m5.e.K(new String[]{thA18.getClass().getSimpleName(), thA18.toString(), A3.a.m("Cause: ", thA18.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA18))});
                    }
                    dVar26.m(listK18);
                } else {
                    Object obj11 = iVar.r;
                    if (obj11 instanceof p074l5.h) {
                        obj11 = null;
                    }
                    dVar26.m(G.G((q) obj11));
                }
                break;
            case 18:
                Throwable thA19 = p074l5.i.a(iVar.r);
                V4.d dVar27 = this.f4639s;
                if (thA19 != null) {
                    if (thA19 instanceof C0354a) {
                        C0354a c0354a2 = (C0354a) thA19;
                        listK19 = p081m5.e.K(new Object[]{c0354a2.r, c0354a2.f6145s, c0354a2.t});
                    } else {
                        listK19 = p081m5.e.K(new String[]{thA19.getClass().getSimpleName(), thA19.toString(), A3.a.m("Cause: ", thA19.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA19))});
                    }
                    dVar27.m(listK19);
                } else {
                    Object obj12 = iVar.r;
                    if (obj12 instanceof p074l5.h) {
                        obj12 = null;
                    }
                    dVar27.m(G.G((C0364k) obj12));
                }
                break;
            case 19:
                Throwable thA20 = p074l5.i.a(iVar.r);
                V4.d dVar28 = this.f4639s;
                if (thA20 != null) {
                    if (thA20 instanceof C0354a) {
                        C0354a c0354a3 = (C0354a) thA20;
                        listK20 = p081m5.e.K(new Object[]{c0354a3.r, c0354a3.f6145s, c0354a3.t});
                    } else {
                        listK20 = p081m5.e.K(new String[]{thA20.getClass().getSimpleName(), thA20.toString(), A3.a.m("Cause: ", thA20.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA20))});
                    }
                    dVar28.m(listK20);
                } else {
                    Object obj13 = iVar.r;
                    if (obj13 instanceof p074l5.h) {
                        obj13 = null;
                    }
                    dVar28.m(G.G((q) obj13));
                }
                break;
            case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
                Throwable thA21 = p074l5.i.a(iVar.r);
                V4.d dVar29 = this.f4639s;
                if (thA21 != null) {
                    if (thA21 instanceof C0354a) {
                        C0354a c0354a4 = (C0354a) thA21;
                        listK21 = p081m5.e.K(new Object[]{c0354a4.r, c0354a4.f6145s, c0354a4.t});
                    } else {
                        listK21 = p081m5.e.K(new String[]{thA21.getClass().getSimpleName(), thA21.toString(), A3.a.m("Cause: ", thA21.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA21))});
                    }
                    dVar29.m(listK21);
                } else {
                    Object obj14 = iVar.r;
                    if (obj14 instanceof p074l5.h) {
                        obj14 = null;
                    }
                    dVar29.m(G.G((q) obj14));
                }
                break;
            case 21:
                Throwable thA22 = p074l5.i.a(iVar.r);
                V4.d dVar30 = this.f4639s;
                if (thA22 != null) {
                    if (thA22 instanceof C0354a) {
                        C0354a c0354a5 = (C0354a) thA22;
                        listK22 = p081m5.e.K(new Object[]{c0354a5.r, c0354a5.f6145s, c0354a5.t});
                    } else {
                        listK22 = p081m5.e.K(new String[]{thA22.getClass().getSimpleName(), thA22.toString(), A3.a.m("Cause: ", thA22.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA22))});
                    }
                    dVar30.m(listK22);
                } else {
                    Object obj15 = iVar.r;
                    if (obj15 instanceof p074l5.h) {
                        obj15 = null;
                    }
                    dVar30.m(G.G((F) obj15));
                }
                break;
            case 22:
                Throwable thA23 = p074l5.i.a(iVar.r);
                V4.d dVar31 = this.f4639s;
                if (thA23 != null) {
                    if (thA23 instanceof C0354a) {
                        C0354a c0354a6 = (C0354a) thA23;
                        listK23 = p081m5.e.K(new Object[]{c0354a6.r, c0354a6.f6145s, c0354a6.t});
                    } else {
                        listK23 = p081m5.e.K(new String[]{thA23.getClass().getSimpleName(), thA23.toString(), A3.a.m("Cause: ", thA23.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA23))});
                    }
                    dVar31.m(listK23);
                } else {
                    Object obj16 = iVar.r;
                    if (obj16 instanceof p074l5.h) {
                        obj16 = null;
                    }
                    dVar31.m(G.G((q) obj16));
                }
                break;
            case 23:
                Throwable thA24 = p074l5.i.a(iVar.r);
                V4.d dVar32 = this.f4639s;
                if (thA24 != null) {
                    if (thA24 instanceof C0354a) {
                        C0354a c0354a7 = (C0354a) thA24;
                        listK24 = p081m5.e.K(new Object[]{c0354a7.r, c0354a7.f6145s, c0354a7.t});
                    } else {
                        listK24 = p081m5.e.K(new String[]{thA24.getClass().getSimpleName(), thA24.toString(), A3.a.m("Cause: ", thA24.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA24))});
                    }
                    dVar32.m(listK24);
                } else {
                    Object obj17 = iVar.r;
                    if (obj17 instanceof p074l5.h) {
                        obj17 = null;
                    }
                    dVar32.m(G.G((C0367n) obj17));
                }
                break;
            case 24:
                Throwable thA25 = p074l5.i.a(iVar.r);
                V4.d dVar33 = this.f4639s;
                if (thA25 != null) {
                    if (thA25 instanceof C0354a) {
                        C0354a c0354a8 = (C0354a) thA25;
                        listK25 = p081m5.e.K(new Object[]{c0354a8.r, c0354a8.f6145s, c0354a8.t});
                    } else {
                        listK25 = p081m5.e.K(new String[]{thA25.getClass().getSimpleName(), thA25.toString(), A3.a.m("Cause: ", thA25.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA25))});
                    }
                    dVar33.m(listK25);
                } else {
                    Object obj18 = iVar.r;
                    if (obj18 instanceof p074l5.h) {
                        obj18 = null;
                    }
                    dVar33.m(G.G((s) obj18));
                }
                break;
            case 25:
                Throwable thA26 = p074l5.i.a(iVar.r);
                V4.d dVar34 = this.f4639s;
                if (thA26 != null) {
                    if (thA26 instanceof C0354a) {
                        C0354a c0354a9 = (C0354a) thA26;
                        listK26 = p081m5.e.K(new Object[]{c0354a9.r, c0354a9.f6145s, c0354a9.t});
                    } else {
                        listK26 = p081m5.e.K(new String[]{thA26.getClass().getSimpleName(), thA26.toString(), A3.a.m("Cause: ", thA26.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA26))});
                    }
                    dVar34.m(listK26);
                } else {
                    Object obj19 = iVar.r;
                    if (obj19 instanceof p074l5.h) {
                        obj19 = null;
                    }
                    dVar34.m(G.G((z) obj19));
                }
                break;
            default:
                Throwable thA27 = p074l5.i.a(iVar.r);
                V4.d dVar35 = this.f4639s;
                if (thA27 != null) {
                    if (thA27 instanceof C0354a) {
                        C0354a c0354a10 = (C0354a) thA27;
                        listK27 = p081m5.e.K(new Object[]{c0354a10.r, c0354a10.f6145s, c0354a10.t});
                    } else {
                        listK27 = p081m5.e.K(new String[]{thA27.getClass().getSimpleName(), thA27.toString(), A3.a.m("Cause: ", thA27.getCause(), ", Stacktrace: ", Log.getStackTraceString(thA27))});
                    }
                    dVar35.m(listK27);
                } else {
                    Object obj20 = iVar.r;
                    if (obj20 instanceof p074l5.h) {
                        obj20 = null;
                    }
                    dVar35.m(G.G((q) obj20));
                }
                break;
        }
        return l.f7746a;
    }
}
