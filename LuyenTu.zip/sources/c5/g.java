package c5;

import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public final class g extends Throwable {
    public final String r = "firebase_remote_config";

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final String f4647s;
    public final HashMap t;

    public g(String str, HashMap map) {
        this.f4647s = str;
        this.t = map;
    }

    @Override // java.lang.Throwable
    public final String getMessage() {
        return this.f4647s;
    }
}
