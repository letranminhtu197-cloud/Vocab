package C3;

import android.content.Context;
import android.preference.PreferenceManager;
import p068l.v0;
import p136w3.f;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Object f581b = new Object();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final f f582a;

    public a(v0 v0Var) {
        Context context = (Context) v0Var.r;
        String str = (String) v0Var.f7490s;
        String str2 = (String) v0Var.t;
        if (str == null) {
            throw new IllegalArgumentException("keysetName cannot be null");
        }
        Context applicationContext = context.getApplicationContext();
        if (str2 == null) {
            PreferenceManager.getDefaultSharedPreferences(applicationContext).edit();
        } else {
            applicationContext.getSharedPreferences(str2, 0).edit();
        }
        this.f582a = (f) v0Var.f7494x;
    }
}
