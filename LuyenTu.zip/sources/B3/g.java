package B3;

import D3.k;
import D3.l;
import D3.v;
import I3.r0;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public abstract class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final l f338a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final k f339b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final D3.c f340c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final D3.a f341d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final Map f342e;

    static {
        K3.a aVarB = v.b("type.googleapis.com/google.crypto.tink.AesSivKey");
        f338a = new l(f.class);
        f339b = new k(aVarB);
        f340c = new D3.c(a.class);
        f341d = new D3.a(aVarB, new A0.c(5));
        HashMap map = new HashMap();
        e eVar = e.f334d;
        r0 r0Var = r0.f1640v;
        map.put(eVar, r0Var);
        e eVar2 = e.f332b;
        r0 r0Var2 = r0.t;
        map.put(eVar2, r0Var2);
        e eVar3 = e.f333c;
        r0 r0Var3 = r0.f1641w;
        map.put(eVar3, r0Var3);
        Collections.unmodifiableMap(map);
        EnumMap enumMap = new EnumMap(r0.class);
        enumMap.put(r0Var, eVar);
        enumMap.put(r0Var2, eVar2);
        enumMap.put(r0Var3, eVar3);
        enumMap.put(r0.f1639u, eVar3);
        f342e = Collections.unmodifiableMap(enumMap);
    }
}
