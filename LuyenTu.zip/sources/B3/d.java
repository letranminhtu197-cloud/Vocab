package B3;

import I3.B;
import I3.C;
import I3.C0054h;
import I3.C0055i;
import I3.C0056j;
import I3.C0058l;
import I3.C0059m;
import I3.C0060n;
import I3.C0061o;
import I3.C0062p;
import I3.C0064s;
import I3.C0065t;
import I3.C0066u;
import I3.C0067v;
import I3.C0069x;
import I3.C0070y;
import I3.C0071z;
import I3.D;
import I3.F;
import I3.J;
import I3.O;
import I3.Q;
import I3.S;
import I3.T;
import I3.U;
import I3.V;
import I3.X;
import I3.m0;
import I3.p0;
import I3.r;
import I3.u0;
import J3.n;
import com.google.crypto.tink.shaded.protobuf.AbstractC0263a;
import com.google.crypto.tink.shaded.protobuf.AbstractC0270h;
import com.google.crypto.tink.shaded.protobuf.C0277o;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.util.Collections;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public final class d extends D3.f {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f331d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ d(Class cls, b[] bVarArr, int i6) {
        super(cls, bVarArr);
        this.f331d = i6;
    }

    public static D3.d h(int i6, int i7) {
        C0064s c0064sA = C0065t.A();
        c0064sA.e();
        C0065t.x((C0065t) c0064sA.f5054s, i6);
        C0066u c0066uZ = C0067v.z();
        c0066uZ.e();
        C0067v.w((C0067v) c0066uZ.f5054s);
        C0067v c0067v = (C0067v) c0066uZ.b();
        c0064sA.e();
        C0065t.w((C0065t) c0064sA.f5054s, c0067v);
        return new D3.d((C0065t) c0064sA.b(), i7);
    }

    public static D3.d i(int i6, int i7, int i8) {
        C0059m c0059mB = C0060n.B();
        C0061o c0061oZ = C0062p.z();
        c0061oZ.e();
        C0062p.w((C0062p) c0061oZ.f5054s);
        C0062p c0062p = (C0062p) c0061oZ.b();
        c0059mB.e();
        C0060n.w((C0060n) c0059mB.f5054s, c0062p);
        c0059mB.e();
        C0060n.x((C0060n) c0059mB.f5054s, i6);
        C0060n c0060n = (C0060n) c0059mB.b();
        S sB = T.B();
        U uB = V.B();
        uB.e();
        V.w((V) uB.f5054s, O.f1624v);
        uB.e();
        V.x((V) uB.f5054s, i7);
        V v6 = (V) uB.b();
        sB.e();
        T.w((T) sB.f5054s, v6);
        sB.e();
        T.x((T) sB.f5054s, 32);
        T t = (T) sB.b();
        C0055i c0055iA = C0056j.A();
        c0055iA.e();
        C0056j.w((C0056j) c0055iA.f5054s, c0060n);
        c0055iA.e();
        C0056j.x((C0056j) c0055iA.f5054s, t);
        return new D3.d((C0056j) c0055iA.b(), i8);
    }

    public static D3.d j(int i6, int i7) {
        C0070y c0070yY = C0071z.y();
        c0070yY.e();
        C0071z.w((C0071z) c0070yY.f5054s, i6);
        return new D3.d((C0071z) c0070yY.b(), i7);
    }

    public static D3.d k(int i6, int i7) {
        C cY = D.y();
        cY.e();
        D.w((D) cY.f5054s, i6);
        return new D3.d((D) cY.b(), i7);
    }

    @Override // D3.f
    public int a() {
        switch (this.f331d) {
            case 1:
                return 2;
            case 2:
            default:
                return super.a();
            case 3:
                return 2;
        }
    }

    @Override // D3.f
    public final String b() {
        switch (this.f331d) {
            case 0:
                return "type.googleapis.com/google.crypto.tink.AesSivKey";
            case 1:
                return "type.googleapis.com/google.crypto.tink.AesCtrHmacAeadKey";
            case 2:
                return "type.googleapis.com/google.crypto.tink.AesEaxKey";
            case 3:
                return "type.googleapis.com/google.crypto.tink.AesGcmKey";
            case 4:
                return "type.googleapis.com/google.crypto.tink.AesGcmSivKey";
            case 5:
                return "type.googleapis.com/google.crypto.tink.ChaCha20Poly1305Key";
            case 6:
                return "type.googleapis.com/google.crypto.tink.KmsAeadKey";
            case 7:
                return "type.googleapis.com/google.crypto.tink.KmsEnvelopeAeadKey";
            default:
                return "type.googleapis.com/google.crypto.tink.XChaCha20Poly1305Key";
        }
    }

    @Override // D3.f
    public final D3.e d() {
        switch (this.f331d) {
            case 0:
                return new c(this);
            case 1:
                return new c(this, (byte) 0);
            case 2:
                return new c(this, (char) 0);
            case 3:
                return new c(this, 0);
            case 4:
                return new c(this, (short) 0);
            case 5:
                return new c(this, (byte) 0, false);
            case 6:
                return new c(this, (byte) 0, (byte) 0);
            case 7:
                return new c(this, (byte) 0, (char) 0);
            default:
                return new c(this, (byte) 0, 0);
        }
    }

    @Override // D3.f
    public final X e() {
        switch (this.f331d) {
            case 0:
                return X.t;
            case 1:
                return X.t;
            case 2:
                return X.t;
            case 3:
                return X.t;
            case 4:
                return X.t;
            case 5:
                return X.t;
            case 6:
                return X.f1631w;
            case 7:
                return X.f1631w;
            default:
                return X.t;
        }
    }

    @Override // D3.f
    public final AbstractC0263a f(AbstractC0270h abstractC0270h) {
        switch (this.f331d) {
            case 0:
                return F.B(abstractC0270h, C0277o.a());
            case 1:
                return C0054h.D(abstractC0270h, C0277o.a());
            case 2:
                return r.D(abstractC0270h, C0277o.a());
            case 3:
                return C0069x.B(abstractC0270h, C0277o.a());
            case 4:
                return B.B(abstractC0270h, C0277o.a());
            case 5:
                return J.B(abstractC0270h, C0277o.a());
            case 6:
                return m0.B(abstractC0270h, C0277o.a());
            case 7:
                return p0.B(abstractC0270h, C0277o.a());
            default:
                return u0.B(abstractC0270h, C0277o.a());
        }
    }

    @Override // D3.f
    public final void g(AbstractC0263a abstractC0263a) throws GeneralSecurityException {
        switch (this.f331d) {
            case 0:
                F f4 = (F) abstractC0263a;
                n.c(f4.z());
                if (f4.y().size() == 64) {
                    return;
                }
                throw new InvalidKeyException("invalid key size: " + f4.y().size() + ". Valid keys must have 64 bytes.");
            case 1:
                C0054h c0054h = (C0054h) abstractC0263a;
                n.c(c0054h.B());
                b[] bVarArr = {new b(J3.j.class, 4)};
                HashMap map = new HashMap();
                b bVar = bVarArr[0];
                Class cls = bVar.f328a;
                if (map.containsKey(cls)) {
                    throw new IllegalArgumentException(com.google.crypto.tink.shaded.protobuf.T.l(new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive "), cls));
                }
                map.put(cls, bVar);
                Class cls2 = bVarArr[0].f328a;
                Collections.unmodifiableMap(map);
                C0058l c0058lZ = c0054h.z();
                n.c(c0058lZ.C());
                n.a(c0058lZ.A().size());
                C0062p c0062pB = c0058lZ.B();
                if (c0062pB.y() < 12 || c0062pB.y() > 16) {
                    throw new GeneralSecurityException("invalid IV size");
                }
                b[] bVarArr2 = {new b(p136w3.j.class, 2)};
                HashMap map2 = new HashMap();
                b bVar2 = bVarArr2[0];
                Class cls3 = bVar2.f328a;
                if (map2.containsKey(cls3)) {
                    throw new IllegalArgumentException(com.google.crypto.tink.shaded.protobuf.T.l(new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive "), cls3));
                }
                map2.put(cls3, bVar2);
                Class cls4 = bVarArr2[0].f328a;
                Collections.unmodifiableMap(map2);
                Q qA = c0054h.A();
                n.c(qA.C());
                if (qA.A().size() < 16) {
                    throw new GeneralSecurityException("key too short");
                }
                E3.b.j(qA.B());
                return;
            case 2:
                r rVar = (r) abstractC0263a;
                n.c(rVar.B());
                n.a(rVar.z().size());
                if (rVar.A().y() != 12 && rVar.A().y() != 16) {
                    throw new GeneralSecurityException("invalid IV size; acceptable values have 12 or 16 bytes");
                }
                return;
            case 3:
                C0069x c0069x = (C0069x) abstractC0263a;
                n.c(c0069x.z());
                n.a(c0069x.y().size());
                return;
            case 4:
                B b6 = (B) abstractC0263a;
                n.c(b6.z());
                n.a(b6.y().size());
                return;
            case 5:
                J j6 = (J) abstractC0263a;
                n.c(j6.z());
                if (j6.y().size() != 32) {
                    throw new GeneralSecurityException("invalid ChaCha20Poly1305Key: incorrect key length");
                }
                return;
            case 6:
                n.c(((m0) abstractC0263a).z());
                return;
            case 7:
                n.c(((p0) abstractC0263a).z());
                return;
            default:
                u0 u0Var = (u0) abstractC0263a;
                n.c(u0Var.z());
                if (u0Var.y().size() != 32) {
                    throw new GeneralSecurityException("invalid XChaCha20Poly1305Key: incorrect key length");
                }
                return;
        }
    }
}
