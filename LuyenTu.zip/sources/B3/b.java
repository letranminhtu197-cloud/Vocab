package B3;

import I3.B;
import I3.C0048b;
import I3.C0054h;
import I3.C0058l;
import I3.C0069x;
import I3.F;
import I3.J;
import I3.O;
import I3.Q;
import I3.m0;
import I3.p0;
import I3.r;
import I3.u0;
import J3.l;
import M2.o;
import com.google.crypto.tink.shaded.protobuf.AbstractC0263a;
import com.google.crypto.tink.shaded.protobuf.T;
import java.security.GeneralSecurityException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.spec.SecretKeySpec;
import org.apache.tika.fork.ContentHandlerProxy;
import p143x3.u;

/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Class f328a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f329b;

    public b(Class cls, int i6) {
        this.f329b = i6;
        this.f328a = cls;
    }

    public final Object a(AbstractC0263a abstractC0263a) throws GeneralSecurityException {
        switch (this.f329b) {
            case 0:
                return new J3.d(((F) abstractC0263a).y().i());
            case 1:
                C0048b c0048b = (C0048b) abstractC0263a;
                return new l(new A4.d(c0048b.z().i()), c0048b.A().y());
            case 2:
                Q q4 = (Q) abstractC0263a;
                O oZ = q4.B().z();
                SecretKeySpec secretKeySpec = new SecretKeySpec(q4.A().i(), "HMAC");
                int iA = q4.B().A();
                int iOrdinal = oZ.ordinal();
                if (iOrdinal == 1) {
                    return new l(new o("HMACSHA1", secretKeySpec), iA);
                }
                if (iOrdinal == 2) {
                    return new l(new o("HMACSHA384", secretKeySpec), iA);
                }
                if (iOrdinal == 3) {
                    return new l(new o("HMACSHA256", secretKeySpec), iA);
                }
                if (iOrdinal == 4) {
                    return new l(new o("HMACSHA512", secretKeySpec), iA);
                }
                if (iOrdinal == 5) {
                    return new l(new o("HMACSHA224", secretKeySpec), iA);
                }
                throw new GeneralSecurityException("unknown hash");
            case 3:
                C0054h c0054h = (C0054h) abstractC0263a;
                b[] bVarArr = {new b(J3.j.class, 4)};
                HashMap map = new HashMap();
                for (b bVar : bVarArr) {
                    Class cls = bVar.f328a;
                    if (map.containsKey(cls)) {
                        throw new IllegalArgumentException(T.l(new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive "), cls));
                    }
                    map.put(cls, bVar);
                }
                if (bVarArr.length > 0) {
                    Class cls2 = bVarArr[0].f328a;
                }
                Map mapUnmodifiableMap = Collections.unmodifiableMap(map);
                C0058l c0058lZ = c0054h.z();
                b bVar2 = (b) mapUnmodifiableMap.get(J3.j.class);
                if (bVar2 == null) {
                    throw new IllegalArgumentException("Requested primitive class " + J3.j.class.getCanonicalName() + " not supported.");
                }
                J3.j jVar = (J3.j) bVar2.a(c0058lZ);
                b[] bVarArr2 = {new b(p136w3.j.class, 2)};
                HashMap map2 = new HashMap();
                for (b bVar3 : bVarArr2) {
                    Class cls3 = bVar3.f328a;
                    if (map2.containsKey(cls3)) {
                        throw new IllegalArgumentException(T.l(new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive "), cls3));
                    }
                    map2.put(cls3, bVar3);
                }
                if (bVarArr2.length > 0) {
                    Class cls4 = bVarArr2[0].f328a;
                }
                Map mapUnmodifiableMap2 = Collections.unmodifiableMap(map2);
                Q qA = c0054h.A();
                b bVar4 = (b) mapUnmodifiableMap2.get(p136w3.j.class);
                if (bVar4 != null) {
                    return new J3.g(jVar, (p136w3.j) bVar4.a(qA), c0054h.A().B().A());
                }
                throw new IllegalArgumentException("Requested primitive class " + p136w3.j.class.getCanonicalName() + " not supported.");
            case 4:
                C0058l c0058l = (C0058l) abstractC0263a;
                return new J3.a(c0058l.A().i(), c0058l.B().y());
            case 5:
                r rVar = (r) abstractC0263a;
                return new J3.b(rVar.z().i(), rVar.A().y());
            case 6:
                return new J3.c(((C0069x) abstractC0263a).y().i(), 0);
            case 7:
                return new p152z3.a(((B) abstractC0263a).y().i());
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                return new J3.c(((J) abstractC0263a).y().i(), 1);
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                String strX = ((m0) abstractC0263a).y().x();
                return p136w3.i.a(strX).c(strX);
            case 10:
                p0 p0Var = (p0) abstractC0263a;
                String strY = p0Var.y().y();
                return new u(p0Var.y().x(), p136w3.i.a(strY).c(strY));
            default:
                return new J3.c(((u0) abstractC0263a).y().i(), 2);
        }
    }
}
