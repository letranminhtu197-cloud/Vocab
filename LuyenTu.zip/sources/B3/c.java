package B3;

import I3.A;
import I3.B;
import I3.C0047a;
import I3.C0048b;
import I3.C0049c;
import I3.C0050d;
import I3.C0051e;
import I3.C0052f;
import I3.C0053g;
import I3.C0054h;
import I3.C0056j;
import I3.C0057k;
import I3.C0058l;
import I3.C0060n;
import I3.C0062p;
import I3.C0063q;
import I3.C0065t;
import I3.C0067v;
import I3.C0068w;
import I3.C0069x;
import I3.C0071z;
import I3.D;
import I3.E;
import I3.F;
import I3.G;
import I3.H;
import I3.I;
import I3.J;
import I3.L;
import I3.O;
import I3.P;
import I3.Q;
import I3.T;
import I3.V;
import I3.l0;
import I3.m0;
import I3.n0;
import I3.o0;
import I3.p0;
import I3.q0;
import I3.r;
import I3.t0;
import I3.u0;
import I3.v0;
import J3.m;
import J3.n;
import com.google.crypto.tink.shaded.protobuf.AbstractC0263a;
import com.google.crypto.tink.shaded.protobuf.AbstractC0270h;
import com.google.crypto.tink.shaded.protobuf.C0269g;
import com.google.crypto.tink.shaded.protobuf.C0277o;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.apache.tika.fork.ContentHandlerProxy;

/* JADX INFO: loaded from: classes.dex */
public final class c extends D3.e {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f330b = 0;

    public /* synthetic */ c(Class cls) {
        super(cls);
    }

    @Override // D3.e
    public final AbstractC0263a a(AbstractC0263a abstractC0263a) {
        switch (this.f330b) {
            case 0:
                E eA = F.A();
                byte[] bArrA = m.a(((H) abstractC0263a).x());
                C0269g c0269gG = AbstractC0270h.g(bArrA, 0, bArrA.length);
                eA.e();
                F.x((F) eA.f5054s, c0269gG);
                eA.e();
                F.w((F) eA.f5054s);
                return (F) eA.b();
            case 1:
                C0050d c0050d = (C0050d) abstractC0263a;
                C0047a c0047aC = C0048b.C();
                c0047aC.e();
                C0048b.w((C0048b) c0047aC.f5054s);
                byte[] bArrA2 = m.a(c0050d.y());
                C0269g c0269gG2 = AbstractC0270h.g(bArrA2, 0, bArrA2.length);
                c0047aC.e();
                C0048b.x((C0048b) c0047aC.f5054s, c0269gG2);
                C0052f c0052fZ = c0050d.z();
                c0047aC.e();
                C0048b.y((C0048b) c0047aC.f5054s, c0052fZ);
                return (C0048b) c0047aC.b();
            case 2:
                T t = (T) abstractC0263a;
                P pD = Q.D();
                pD.e();
                Q.w((Q) pD.f5054s);
                V vA = t.A();
                pD.e();
                Q.x((Q) pD.f5054s, vA);
                byte[] bArrA3 = m.a(t.z());
                C0269g c0269gG3 = AbstractC0270h.g(bArrA3, 0, bArrA3.length);
                pD.e();
                Q.y((Q) pD.f5054s, c0269gG3);
                return (Q) pD.b();
            case 3:
                C0056j c0056j = (C0056j) abstractC0263a;
                b[] bVarArr = {new b(J3.j.class, 4)};
                HashMap map = new HashMap();
                for (b bVar : bVarArr) {
                    Class cls = bVar.f328a;
                    if (map.containsKey(cls)) {
                        throw new IllegalArgumentException(com.google.crypto.tink.shaded.protobuf.T.l(new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive "), cls));
                    }
                    map.put(cls, bVar);
                }
                if (bVarArr.length > 0) {
                    Class cls2 = bVarArr[0].f328a;
                }
                Collections.unmodifiableMap(map);
                C0060n c0060nY = c0056j.y();
                C0057k c0057kD = C0058l.D();
                C0062p c0062pA = c0060nY.A();
                c0057kD.e();
                C0058l.x((C0058l) c0057kD.f5054s, c0062pA);
                byte[] bArrA4 = m.a(c0060nY.z());
                C0269g c0269gG4 = AbstractC0270h.g(bArrA4, 0, bArrA4.length);
                c0057kD.e();
                C0058l.y((C0058l) c0057kD.f5054s, c0269gG4);
                c0057kD.e();
                C0058l.w((C0058l) c0057kD.f5054s);
                C0058l c0058l = (C0058l) c0057kD.b();
                b[] bVarArr2 = {new b(p136w3.j.class, 2)};
                HashMap map2 = new HashMap();
                for (b bVar2 : bVarArr2) {
                    Class cls3 = bVar2.f328a;
                    if (map2.containsKey(cls3)) {
                        throw new IllegalArgumentException(com.google.crypto.tink.shaded.protobuf.T.l(new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive "), cls3));
                    }
                    map2.put(cls3, bVar2);
                }
                if (bVarArr2.length > 0) {
                    Class cls4 = bVarArr2[0].f328a;
                }
                Collections.unmodifiableMap(map2);
                T tZ = c0056j.z();
                P pD2 = Q.D();
                pD2.e();
                Q.w((Q) pD2.f5054s);
                V vA2 = tZ.A();
                pD2.e();
                Q.x((Q) pD2.f5054s, vA2);
                byte[] bArrA5 = m.a(tZ.z());
                C0269g c0269gG5 = AbstractC0270h.g(bArrA5, 0, bArrA5.length);
                pD2.e();
                Q.y((Q) pD2.f5054s, c0269gG5);
                Q q4 = (Q) pD2.b();
                C0053g c0053gC = C0054h.C();
                c0053gC.e();
                C0054h.x((C0054h) c0053gC.f5054s, c0058l);
                c0053gC.e();
                C0054h.y((C0054h) c0053gC.f5054s, q4);
                c0053gC.e();
                C0054h.w((C0054h) c0053gC.f5054s);
                return (C0054h) c0053gC.b();
            case 4:
                C0065t c0065t = (C0065t) abstractC0263a;
                C0063q c0063qC = r.C();
                byte[] bArrA6 = m.a(c0065t.y());
                C0269g c0269gG6 = AbstractC0270h.g(bArrA6, 0, bArrA6.length);
                c0063qC.e();
                r.y((r) c0063qC.f5054s, c0269gG6);
                C0067v c0067vZ = c0065t.z();
                c0063qC.e();
                r.x((r) c0063qC.f5054s, c0067vZ);
                c0063qC.e();
                r.w((r) c0063qC.f5054s);
                return (r) c0063qC.b();
            case 5:
                C0068w c0068wA = C0069x.A();
                byte[] bArrA7 = m.a(((C0071z) abstractC0263a).x());
                C0269g c0269gG7 = AbstractC0270h.g(bArrA7, 0, bArrA7.length);
                c0068wA.e();
                C0069x.x((C0069x) c0068wA.f5054s, c0269gG7);
                c0068wA.e();
                C0069x.w((C0069x) c0068wA.f5054s);
                return (C0069x) c0068wA.b();
            case 6:
                A A2 = B.A();
                byte[] bArrA8 = m.a(((D) abstractC0263a).x());
                C0269g c0269gG8 = AbstractC0270h.g(bArrA8, 0, bArrA8.length);
                A2.e();
                B.x((B) A2.f5054s, c0269gG8);
                A2.e();
                B.w((B) A2.f5054s);
                return (B) A2.b();
            case 7:
                I iA = J.A();
                iA.e();
                J.w((J) iA.f5054s);
                byte[] bArrA9 = m.a(32);
                C0269g c0269gG9 = AbstractC0270h.g(bArrA9, 0, bArrA9.length);
                iA.e();
                J.x((J) iA.f5054s, c0269gG9);
                return (J) iA.b();
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                l0 l0VarA = m0.A();
                l0VarA.e();
                m0.x((m0) l0VarA.f5054s, (n0) abstractC0263a);
                l0VarA.e();
                m0.w((m0) l0VarA.f5054s);
                return (m0) l0VarA.b();
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                o0 o0VarA = p0.A();
                o0VarA.e();
                p0.x((p0) o0VarA.f5054s, (q0) abstractC0263a);
                o0VarA.e();
                p0.w((p0) o0VarA.f5054s);
                return (p0) o0VarA.b();
            default:
                t0 t0VarA = u0.A();
                t0VarA.e();
                u0.w((u0) t0VarA.f5054s);
                byte[] bArrA10 = m.a(32);
                C0269g c0269gG10 = AbstractC0270h.g(bArrA10, 0, bArrA10.length);
                t0VarA.e();
                u0.x((u0) t0VarA.f5054s, c0269gG10);
                return (u0) t0VarA.b();
        }
    }

    @Override // D3.e
    public Map b() {
        switch (this.f330b) {
            case 0:
                HashMap map = new HashMap();
                G gY = H.y();
                gY.e();
                H.w((H) gY.f5054s);
                map.put("AES256_SIV", new D3.d((H) gY.b(), 1));
                G gY2 = H.y();
                gY2.e();
                H.w((H) gY2.f5054s);
                map.put("AES256_SIV_RAW", new D3.d((H) gY2.b(), 3));
                return Collections.unmodifiableMap(map);
            case 1:
                HashMap map2 = new HashMap();
                C0049c c0049cA = C0050d.A();
                c0049cA.e();
                C0050d.w((C0050d) c0049cA.f5054s);
                C0051e c0051eZ = C0052f.z();
                c0051eZ.e();
                C0052f.w((C0052f) c0051eZ.f5054s);
                C0052f c0052f = (C0052f) c0051eZ.b();
                c0049cA.e();
                C0050d.x((C0050d) c0049cA.f5054s, c0052f);
                map2.put("AES_CMAC", new D3.d((C0050d) c0049cA.b(), 1));
                C0049c c0049cA2 = C0050d.A();
                c0049cA2.e();
                C0050d.w((C0050d) c0049cA2.f5054s);
                C0051e c0051eZ2 = C0052f.z();
                c0051eZ2.e();
                C0052f.w((C0052f) c0051eZ2.f5054s);
                C0052f c0052f2 = (C0052f) c0051eZ2.b();
                c0049cA2.e();
                C0050d.x((C0050d) c0049cA2.f5054s, c0052f2);
                map2.put("AES256_CMAC", new D3.d((C0050d) c0049cA2.b(), 1));
                C0049c c0049cA3 = C0050d.A();
                c0049cA3.e();
                C0050d.w((C0050d) c0049cA3.f5054s);
                C0051e c0051eZ3 = C0052f.z();
                c0051eZ3.e();
                C0052f.w((C0052f) c0051eZ3.f5054s);
                C0052f c0052f3 = (C0052f) c0051eZ3.b();
                c0049cA3.e();
                C0050d.x((C0050d) c0049cA3.f5054s, c0052f3);
                map2.put("AES256_CMAC_RAW", new D3.d((C0050d) c0049cA3.b(), 3));
                return Collections.unmodifiableMap(map2);
            case 2:
                HashMap map3 = new HashMap();
                O o = O.f1624v;
                map3.put("HMAC_SHA256_128BITTAG", E3.b.h(32, 16, o, 1));
                map3.put("HMAC_SHA256_128BITTAG_RAW", E3.b.h(32, 16, o, 3));
                map3.put("HMAC_SHA256_256BITTAG", E3.b.h(32, 32, o, 1));
                map3.put("HMAC_SHA256_256BITTAG_RAW", E3.b.h(32, 32, o, 3));
                O o5 = O.f1625w;
                map3.put("HMAC_SHA512_128BITTAG", E3.b.h(64, 16, o5, 1));
                map3.put("HMAC_SHA512_128BITTAG_RAW", E3.b.h(64, 16, o5, 3));
                map3.put("HMAC_SHA512_256BITTAG", E3.b.h(64, 32, o5, 1));
                map3.put("HMAC_SHA512_256BITTAG_RAW", E3.b.h(64, 32, o5, 3));
                map3.put("HMAC_SHA512_512BITTAG", E3.b.h(64, 64, o5, 1));
                map3.put("HMAC_SHA512_512BITTAG_RAW", E3.b.h(64, 64, o5, 3));
                return Collections.unmodifiableMap(map3);
            case 3:
                HashMap map4 = new HashMap();
                map4.put("AES128_CTR_HMAC_SHA256", d.i(16, 16, 1));
                map4.put("AES128_CTR_HMAC_SHA256_RAW", d.i(16, 16, 3));
                map4.put("AES256_CTR_HMAC_SHA256", d.i(32, 32, 1));
                map4.put("AES256_CTR_HMAC_SHA256_RAW", d.i(32, 32, 3));
                return Collections.unmodifiableMap(map4);
            case 4:
                HashMap map5 = new HashMap();
                map5.put("AES128_EAX", d.h(16, 1));
                map5.put("AES128_EAX_RAW", d.h(16, 3));
                map5.put("AES256_EAX", d.h(32, 1));
                map5.put("AES256_EAX_RAW", d.h(32, 3));
                return Collections.unmodifiableMap(map5);
            case 5:
                HashMap map6 = new HashMap();
                map6.put("AES128_GCM", d.j(16, 1));
                map6.put("AES128_GCM_RAW", d.j(16, 3));
                map6.put("AES256_GCM", d.j(32, 1));
                map6.put("AES256_GCM_RAW", d.j(32, 3));
                return Collections.unmodifiableMap(map6);
            case 6:
                HashMap map7 = new HashMap();
                map7.put("AES128_GCM_SIV", d.k(16, 1));
                map7.put("AES128_GCM_SIV_RAW", d.k(16, 3));
                map7.put("AES256_GCM_SIV", d.k(32, 1));
                map7.put("AES256_GCM_SIV_RAW", d.k(32, 3));
                return Collections.unmodifiableMap(map7);
            case 7:
                HashMap map8 = new HashMap();
                map8.put("CHACHA20_POLY1305", new D3.d(L.w(), 1));
                map8.put("CHACHA20_POLY1305_RAW", new D3.d(L.w(), 3));
                return Collections.unmodifiableMap(map8);
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
            default:
                return super.b();
            case 10:
                HashMap map9 = new HashMap();
                map9.put("XCHACHA20_POLY1305", new D3.d(v0.w(), 1));
                map9.put("XCHACHA20_POLY1305_RAW", new D3.d(v0.w(), 3));
                return Collections.unmodifiableMap(map9);
        }
    }

    @Override // D3.e
    public final AbstractC0263a c(AbstractC0270h abstractC0270h) {
        switch (this.f330b) {
            case 0:
                return H.z(abstractC0270h, C0277o.a());
            case 1:
                return C0050d.B(abstractC0270h, C0277o.a());
            case 2:
                return T.C(abstractC0270h, C0277o.a());
            case 3:
                return C0056j.B(abstractC0270h, C0277o.a());
            case 4:
                return C0065t.B(abstractC0270h, C0277o.a());
            case 5:
                return C0071z.z(abstractC0270h, C0277o.a());
            case 6:
                return D.z(abstractC0270h, C0277o.a());
            case 7:
                return L.x(abstractC0270h, C0277o.a());
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                return n0.y(abstractC0270h, C0277o.a());
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                return q0.A(abstractC0270h, C0277o.a());
            default:
                return v0.x(abstractC0270h, C0277o.a());
        }
    }

    @Override // D3.e
    public final void e(AbstractC0263a abstractC0263a) throws GeneralSecurityException {
        switch (this.f330b) {
            case 0:
                H h7 = (H) abstractC0263a;
                if (h7.x() == 64) {
                    return;
                }
                throw new InvalidAlgorithmParameterException("invalid key size: " + h7.x() + ". Valid keys must have 64 bytes.");
            case 1:
                C0050d c0050d = (C0050d) abstractC0263a;
                E3.b.i(c0050d.z());
                if (c0050d.y() != 32) {
                    throw new GeneralSecurityException("AesCmacKey size wrong, must be 32 bytes");
                }
                return;
            case 2:
                T t = (T) abstractC0263a;
                if (t.z() < 16) {
                    throw new GeneralSecurityException("key too short");
                }
                E3.b.j(t.A());
                return;
            case 3:
                C0056j c0056j = (C0056j) abstractC0263a;
                b[] bVarArr = {new b(J3.j.class, 4)};
                HashMap map = new HashMap();
                for (b bVar : bVarArr) {
                    Class cls = bVar.f328a;
                    if (map.containsKey(cls)) {
                        throw new IllegalArgumentException(com.google.crypto.tink.shaded.protobuf.T.l(new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive "), cls));
                    }
                    map.put(cls, bVar);
                }
                if (bVarArr.length > 0) {
                    Class cls2 = bVarArr[0].f328a;
                }
                Collections.unmodifiableMap(map);
                C0060n c0060nY = c0056j.y();
                n.a(c0060nY.z());
                C0062p c0062pA = c0060nY.A();
                if (c0062pA.y() < 12 || c0062pA.y() > 16) {
                    throw new GeneralSecurityException("invalid IV size");
                }
                b[] bVarArr2 = {new b(p136w3.j.class, 2)};
                HashMap map2 = new HashMap();
                for (b bVar2 : bVarArr2) {
                    Class cls3 = bVar2.f328a;
                    if (map2.containsKey(cls3)) {
                        throw new IllegalArgumentException(com.google.crypto.tink.shaded.protobuf.T.l(new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive "), cls3));
                    }
                    map2.put(cls3, bVar2);
                }
                if (bVarArr2.length > 0) {
                    Class cls4 = bVarArr2[0].f328a;
                }
                Collections.unmodifiableMap(map2);
                T tZ = c0056j.z();
                if (tZ.z() < 16) {
                    throw new GeneralSecurityException("key too short");
                }
                E3.b.j(tZ.A());
                n.a(c0056j.y().z());
                return;
            case 4:
                C0065t c0065t = (C0065t) abstractC0263a;
                n.a(c0065t.y());
                if (c0065t.z().y() != 12 && c0065t.z().y() != 16) {
                    throw new GeneralSecurityException("invalid IV size; acceptable values have 12 or 16 bytes");
                }
                return;
            case 5:
                n.a(((C0071z) abstractC0263a).x());
                return;
            case 6:
                n.a(((D) abstractC0263a).x());
                return;
            case 7:
                return;
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                return;
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                q0 q0Var = (q0) abstractC0263a;
                if (q0Var.y().isEmpty() || !q0Var.z()) {
                    throw new GeneralSecurityException("invalid key format: missing KEK URI or DEK template");
                }
                return;
            default:
                return;
        }
    }

    public c(d dVar, byte b6, byte b7) {
        super(n0.class);
    }

    public c(d dVar, byte b6, char c2) {
        super(q0.class);
    }

    public c(d dVar, int i6) {
        super(C0071z.class);
    }

    public c(d dVar, byte b6, boolean z6) {
        super(L.class);
    }

    public c(d dVar, char c2) {
        super(C0065t.class);
    }

    public c(d dVar, short s6) {
        super(D.class);
    }

    public c(d dVar, byte b6, int i6) {
        super(v0.class);
    }

    public c(d dVar) {
        super(H.class);
    }

    public c(d dVar, byte b6) {
        super(C0056j.class);
    }

    public c(E3.b bVar) {
        super(T.class);
    }
}
