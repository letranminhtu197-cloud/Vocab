package B3;

import D3.q;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.Iterator;
import p018d2.G;
import p045h3.C0331c;
import p136w3.k;

/* JADX INFO: loaded from: classes.dex */
public final class i implements p136w3.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0331c f343a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Z3.e f344b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Z3.e f345c;

    public i(C0331c c0331c) {
        this.f343a = c0331c;
        boolean zIsEmpty = ((G3.a) c0331c.t).f1422a.isEmpty();
        Z3.e eVar = q.f839a;
        if (zIsEmpty) {
            this.f344b = eVar;
            this.f345c = eVar;
            return;
        }
        D3.g gVar = (D3.g) D3.h.f818b.f820a.get();
        gVar = gVar == null ? D3.h.f819c : gVar;
        q.a(c0331c);
        gVar.getClass();
        this.f344b = eVar;
        this.f345c = eVar;
    }

    @Override // p136w3.c
    public final byte[] a(byte[] bArr, byte[] bArr2) throws GeneralSecurityException {
        Z3.e eVar = this.f344b;
        C0331c c0331c = this.f343a;
        try {
            byte[] bArr3 = ((k) c0331c.f6060u).f9681c;
            byte[] bArrI = G.i(bArr3 == null ? null : Arrays.copyOf(bArr3, bArr3.length), ((p136w3.c) ((k) c0331c.f6060u).f9680b).a(bArr, bArr2));
            int i6 = ((k) c0331c.f6060u).f9684f;
            eVar.getClass();
            return bArrI;
        } catch (GeneralSecurityException e6) {
            eVar.getClass();
            throw e6;
        }
    }

    @Override // p136w3.c
    public final byte[] b(byte[] bArr, byte[] bArr2) throws GeneralSecurityException {
        int length = bArr.length;
        C0331c c0331c = this.f343a;
        Z3.e eVar = this.f345c;
        if (length > 5) {
            byte[] bArrCopyOf = Arrays.copyOf(bArr, 5);
            byte[] bArrCopyOfRange = Arrays.copyOfRange(bArr, 5, bArr.length);
            Iterator it = c0331c.t(bArrCopyOf).iterator();
            while (it.hasNext()) {
                try {
                    byte[] bArrB = ((p136w3.c) ((k) it.next()).f9680b).b(bArrCopyOfRange, bArr2);
                    eVar.getClass();
                    return bArrB;
                } catch (GeneralSecurityException e6) {
                    j.f346a.info("ciphertext prefix matches a key, but cannot decrypt: " + e6);
                }
            }
        }
        Iterator it2 = c0331c.t(p136w3.b.f9667a).iterator();
        while (it2.hasNext()) {
            try {
                byte[] bArrB2 = ((p136w3.c) ((k) it2.next()).f9680b).b(bArr, bArr2);
                eVar.getClass();
                return bArrB2;
            } catch (GeneralSecurityException unused) {
            }
        }
        eVar.getClass();
        throw new GeneralSecurityException("decryption failed");
    }
}
