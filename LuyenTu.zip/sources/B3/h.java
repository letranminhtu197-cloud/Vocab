package B3;

import D3.l;
import I3.F;
import I3.s0;
import com.google.crypto.tink.shaded.protobuf.T;
import java.security.GeneralSecurityException;
import java.util.Collections;
import java.util.HashMap;
import p136w3.n;

/* JADX INFO: loaded from: classes.dex */
public abstract class h {
    static {
        b[] bVarArr = {new b(p136w3.c.class, 0)};
        HashMap map = new HashMap();
        for (b bVar : bVarArr) {
            Class cls = bVar.f328a;
            Class cls2 = bVar.f328a;
            if (map.containsKey(cls)) {
                throw new IllegalArgumentException(T.l(new StringBuilder("KeyTypeManager constructed with duplicate factories for primitive "), cls2));
            }
            map.put(cls2, bVar);
        }
        if (bVarArr.length > 0) {
            Class cls3 = bVarArr[0].f328a;
        }
        Collections.unmodifiableMap(map);
        int i6 = s0.CONFIG_NAME_FIELD_NUMBER;
        try {
            a();
        } catch (GeneralSecurityException e6) {
            throw new ExceptionInInitializerError(e6);
        }
    }

    public static void a() {
        n.h(j.f347b);
        if (A3.b.a()) {
            return;
        }
        Class<F> cls = F.class;
        n.f(new d(cls, new b[]{new b(p136w3.c.class, 0)}, 0), true);
        l lVar = g.f338a;
        D3.j jVar = D3.j.f823b;
        jVar.e(g.f338a);
        jVar.d(g.f339b);
        jVar.c(g.f340c);
        jVar.b(g.f341d);
    }
}
