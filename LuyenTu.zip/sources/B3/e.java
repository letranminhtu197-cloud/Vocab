package B3;

/* JADX INFO: loaded from: classes.dex */
public final class e {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final e f332b = new e("TINK");

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final e f333c = new e("CRUNCHY");

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final e f334d = new e("NO_PREFIX");

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f335a;

    public e(String str) {
        this.f335a = str;
    }

    public final String toString() {
        return this.f335a;
    }
}
