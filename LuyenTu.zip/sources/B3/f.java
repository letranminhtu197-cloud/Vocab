package B3;

import com.google.crypto.tink.shaded.protobuf.T;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public final class f extends p136w3.b {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f336b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final e f337c;

    public f(int i6, e eVar) {
        this.f336b = i6;
        this.f337c = eVar;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof f)) {
            return false;
        }
        f fVar = (f) obj;
        return fVar.f336b == this.f336b && fVar.f337c == this.f337c;
    }

    public final int hashCode() {
        return Objects.hash(f.class, Integer.valueOf(this.f336b), this.f337c);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("AesSiv Parameters (variant: ");
        sb.append(this.f337c);
        sb.append(", ");
        return T.k(sb, this.f336b, "-byte key)");
    }
}
