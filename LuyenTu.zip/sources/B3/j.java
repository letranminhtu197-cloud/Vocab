package B3;

import java.util.logging.Logger;
import p045h3.C0331c;
import p136w3.m;

/* JADX INFO: loaded from: classes.dex */
public final class j implements m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Logger f346a = Logger.getLogger(j.class.getName());

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final j f347b = new j();

    @Override // p136w3.m
    public final Class a() {
        return p136w3.c.class;
    }

    @Override // p136w3.m
    public final Object b(C0331c c0331c) {
        return new i(c0331c);
    }

    @Override // p136w3.m
    public final Class c() {
        return p136w3.c.class;
    }
}
