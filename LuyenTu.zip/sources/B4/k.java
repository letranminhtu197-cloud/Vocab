package B4;

import com.google.crypto.tink.shaded.protobuf.T;
import java.util.Set;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: loaded from: classes.dex */
public final class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f360a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f361b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Set f362c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f363d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f364e;

    public k(int i6, boolean z6, Set set, String str, boolean z7) {
        A5.h.e(set, "answered");
        A5.h.e(str, "stamp");
        this.f360a = i6;
        this.f361b = z6;
        this.f362c = set;
        this.f363d = str;
        this.f364e = z7;
    }

    public static k a(k kVar, int i6, boolean z6, boolean z7, int i7) {
        if ((i7 & 1) != 0) {
            i6 = kVar.f360a;
        }
        int i8 = i6;
        if ((i7 & 2) != 0) {
            z6 = kVar.f361b;
        }
        Set set = kVar.f362c;
        String str = kVar.f363d;
        A5.h.e(set, "answered");
        A5.h.e(str, "stamp");
        return new k(i8, z6, set, str, z7);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof k)) {
            return false;
        }
        k kVar = (k) obj;
        return this.f360a == kVar.f360a && this.f361b == kVar.f361b && A5.h.a(this.f362c, kVar.f362c) && A5.h.a(this.f363d, kVar.f363d) && this.f364e == kVar.f364e;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f364e) + T.w((this.f362c.hashCode() + ((Boolean.hashCode(this.f361b) + (Integer.hashCode(this.f360a) * 31)) * 31)) * 31, 31, this.f363d);
    }

    public final String toString() {
        return "CardState(index=" + this.f360a + ", revealed=" + this.f361b + ", answered=" + this.f362c + ", stamp=" + this.f363d + ", translationShown=" + this.f364e + ")";
    }

    public /* synthetic */ k(int i6, Set set, String str, int i7) {
        this(i6, false, (i7 & 4) != 0 ? p081m5.o.r : set, (i7 & 8) != 0 ? StringUtils.EMPTY : str, false);
    }
}
