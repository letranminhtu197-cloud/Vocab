package B4;

import C1.C0016q;
import G0.A;
import G0.B;
import R0.InterfaceC0140f;
import R0.u;
import W4.p;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import com.google.crypto.tink.shaded.protobuf.T;
import com.luyentu.mobile.MainActivity;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.pipes.PipesServer;
import org.apache.tika.utils.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import p018d2.G;
import p047h5.C0358e;
import p047h5.C0359f;
import p047h5.C0364k;
import p047h5.C0367n;
import p047h5.F;
import p047h5.L;
import p047h5.M;
import p047h5.N;
import p053i4.v;
import p101q0.C0427o;
import p103q2.C0442f;
import p117t0.s;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class b implements W4.o, E2.b, A, p091o3.f, W5.b, W4.c, InterfaceC0140f, p091o3.d, p091o3.e {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ Object f349s;

    public /* synthetic */ b(p021d5.f fVar, V4.h hVar) {
        this.r = 19;
        this.f349s = hVar;
    }

    @Override // W5.b
    public Object a(Y5.b bVar) {
        return (Y5.c) this.f349s;
    }

    @Override // p091o3.f
    public void b(Object obj) {
        switch (this.r) {
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                ((Q.c) this.f349s).a(obj);
                break;
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                ((Q.e) this.f349s).a(obj);
                break;
            case 10:
                ((L5.c) this.f349s).a(obj);
                break;
            case 11:
            default:
                ((V.a) this.f349s).a(obj);
                break;
            case 12:
                ((L5.c) this.f349s).a(obj);
                break;
        }
    }

    @Override // R0.InterfaceC0140f
    public long c(long j6) {
        u uVar = (u) this.f349s;
        return s.j((j6 * ((long) uVar.f3376e)) / 1000000, 0L, uVar.f3381j - 1);
    }

    @Override // E2.b
    public Object d() {
        int i6 = this.r;
        Object obj = this.f349s;
        switch (i6) {
            case 1:
                D2.h hVar = (D2.h) ((D2.c) obj);
                hVar.getClass();
                int i7 = p151z2.a.f10768e;
                v vVar = new v();
                vVar.f6368s = null;
                vVar.t = new ArrayList();
                vVar.f6369u = null;
                vVar.r = StringUtils.EMPTY;
                HashMap map = new HashMap();
                SQLiteDatabase sQLiteDatabaseA = hVar.a();
                sQLiteDatabaseA.beginTransaction();
                try {
                    p151z2.a aVar = (p151z2.a) D2.h.t(sQLiteDatabaseA.rawQuery("SELECT log_source, reason, events_dropped_count FROM log_event_dropped", new String[0]), new B2.b(hVar, map, vVar, 3));
                    sQLiteDatabaseA.setTransactionSuccessful();
                    return aVar;
                } finally {
                    sQLiteDatabaseA.endTransaction();
                }
            case 2:
                D2.h hVar2 = (D2.h) ((D2.d) obj);
                long jN = hVar2.f802s.n() - hVar2.f803u.f793d;
                SQLiteDatabase sQLiteDatabaseA2 = hVar2.a();
                sQLiteDatabaseA2.beginTransaction();
                try {
                    String[] strArr = {String.valueOf(jN)};
                    Cursor cursorRawQuery = sQLiteDatabaseA2.rawQuery("SELECT COUNT(*), transport_name FROM events WHERE timestamp_ms < ? GROUP BY transport_name", strArr);
                    while (cursorRawQuery.moveToNext()) {
                        try {
                            hVar2.j(cursorRawQuery.getInt(0), p151z2.c.t, cursorRawQuery.getString(1));
                        } catch (Throwable th) {
                            cursorRawQuery.close();
                            throw th;
                        }
                    }
                    cursorRawQuery.close();
                    int iDelete = sQLiteDatabaseA2.delete("events", "timestamp_ms < ?", strArr);
                    sQLiteDatabaseA2.setTransactionSuccessful();
                    sQLiteDatabaseA2.endTransaction();
                    return Integer.valueOf(iDelete);
                } catch (Throwable th2) {
                    sQLiteDatabaseA2.endTransaction();
                    throw th2;
                }
            case 3:
                D2.h hVar3 = (D2.h) ((C2.l) obj).f576i;
                SQLiteDatabase sQLiteDatabaseA3 = hVar3.a();
                sQLiteDatabaseA3.beginTransaction();
                try {
                    sQLiteDatabaseA3.compileStatement("DELETE FROM log_event_dropped").execute();
                    sQLiteDatabaseA3.compileStatement("UPDATE global_log_event_state SET last_metrics_upload_ms=" + hVar3.f802s.n()).execute();
                    sQLiteDatabaseA3.setTransactionSuccessful();
                    return null;
                } finally {
                    sQLiteDatabaseA3.endTransaction();
                }
            default:
                C2.m mVar = (C2.m) obj;
                Iterator it = ((Iterable) ((D2.h) mVar.f578b).e(new A0.c(7))).iterator();
                while (it.hasNext()) {
                    mVar.f579c.a((p135w2.i) it.next(), 1, false);
                }
                return null;
        }
    }

    @Override // G0.A
    public int e(Object obj) {
        C0427o c0427o = (C0427o) this.f349s;
        G0.n nVar = (G0.n) obj;
        String str = nVar.f1335b;
        return ((str.equals(c0427o.f8396m) || str.equals(B.b(c0427o))) && nVar.c(c0427o, false)) ? 1 : 0;
    }

    public void f(C0442f c0442f) {
        N.a(X2.a.v(c0442f), (c5.b) this.f349s);
    }

    public void g(C0442f c0442f) {
        c5.b bVar = (c5.b) this.f349s;
        A5.h.e(c0442f, "result");
        N.a(new C0364k(X2.a.v(c0442f), StringUtils.EMPTY), bVar);
    }

    public void h(C0442f c0442f) {
        c5.b bVar = (c5.b) this.f349s;
        A5.h.e(c0442f, "result");
        N.a(new C0367n(X2.a.v(c0442f), StringUtils.EMPTY), bVar);
    }

    @Override // p091o3.e
    public void i(Exception exc) {
        p000a.a.h((c5.b) this.f349s, new p033f5.a(p033f5.b.f5806u, exc.getMessage(), null));
    }

    public void j(C0442f c0442f, List list) {
        N.a(new F(X2.a.v(c0442f), X2.a.x(list)), (c5.b) this.f349s);
    }

    public void k(p086n4.a aVar) {
        C0359f c0359f = (C0359f) this.f349s;
        JSONObject jSONObject = (JSONObject) aVar.f7949s;
        String strOptString = jSONObject.optString("originalExternalTransactionId");
        if (strOptString.isEmpty()) {
            strOptString = null;
        }
        String strOptString2 = jSONObject.optString("externalTransactionToken");
        A5.h.d(strOptString2, "getExternalTransactionToken(...)");
        ArrayList arrayList = (ArrayList) aVar.t;
        A5.h.d(arrayList, "getProducts(...)");
        ArrayList arrayList2 = new ArrayList(p081m5.g.x0(arrayList));
        int size = arrayList.size();
        int i6 = 0;
        while (i6 < size) {
            Object obj = arrayList.get(i6);
            i6++;
            p103q2.o oVar = (p103q2.o) obj;
            A5.h.e(oVar, "product");
            String str = oVar.f8635a;
            A5.h.d(str, "getId(...)");
            String str2 = oVar.f8637c;
            String str3 = oVar.f8636b;
            A5.h.d(str3, "getType(...)");
            boolean zEquals = str3.equals("inapp");
            p047h5.A a5 = p047h5.A.t;
            if (!zEquals && str3.equals("subs")) {
                a5 = p047h5.A.f6090u;
            }
            arrayList2.add(new M(str, str2, a5));
        }
        L l6 = new L(strOptString, arrayList2, strOptString2);
        C0016q c0016q = new C0016q(new j(7), 5);
        c0359f.getClass();
        String strX = T.x("dev.flutter.pigeon.in_app_purchase_android.InAppPurchaseCallbackApi.userSelectedalternativeBilling", StringUtils.EMPTY);
        new v(c0359f.f6152a, strX, (W4.m) C0359f.f6151b.getValue(), null).O(G.G(l6), new C0358e(c0016q, strX, 2));
    }

    @Override // W4.c
    public void m(Object obj) {
        b bVar = (b) this.f349s;
        boolean z6 = false;
        if (obj != null) {
            try {
                z6 = ((JSONObject) obj).getBoolean("handled");
            } catch (JSONException e6) {
                Log.e("KeyEventChannel", "Unable to unpack JSON message: " + e6);
            }
        }
        ((K0.d) bVar.f349s).c(z6);
    }

    @Override // W4.o
    public void onMethodCall(W4.n nVar, p pVar) {
        MainActivity mainActivity = (MainActivity) this.f349s;
        int i6 = MainActivity.f5086w;
        A5.h.e(nVar, "call");
        String str = nVar.f3729a;
        if (A5.h.a(str, "save")) {
            Object obj = nVar.f3730b;
            new p099p5.a(new c(mainActivity, obj instanceof byte[] ? (byte[]) obj : null, (V4.h) pVar, 0)).start();
        } else if (!A5.h.a(str, "clear")) {
            ((V4.h) pVar).b();
        } else {
            new File(mainActivity.getFilesDir(), "widget-avatar.jpg").delete();
            ((V4.h) pVar).a(Boolean.TRUE);
        }
    }

    @Override // p091o3.d
    public void p(p091o3.i iVar) {
        int i6 = this.r;
        Object obj = this.f349s;
        switch (i6) {
            case 16:
                p010b5.i iVar2 = (p010b5.i) obj;
                HashMap map = p010b5.d.t;
                if (iVar.h()) {
                    switch (iVar2.f4583a) {
                        case 0:
                            ArrayList arrayList = iVar2.f4584b;
                            arrayList.add(0, null);
                            iVar2.f4585c.m(arrayList);
                            break;
                        case 1:
                            ArrayList arrayList2 = iVar2.f4584b;
                            arrayList2.add(0, null);
                            iVar2.f4585c.m(arrayList2);
                            break;
                        default:
                            ArrayList arrayList3 = iVar2.f4584b;
                            arrayList3.add(0, null);
                            iVar2.f4585c.m(arrayList3);
                            break;
                    }
                } else {
                    iVar2.a(iVar.e());
                    break;
                }
                break;
            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                p010b5.i iVar3 = (p010b5.i) obj;
                HashMap map2 = p010b5.d.t;
                if (iVar.h()) {
                    Object objF = iVar.f();
                    switch (iVar3.f4583a) {
                        case 3:
                            ArrayList arrayList4 = iVar3.f4584b;
                            arrayList4.add(0, (p010b5.g) objF);
                            iVar3.f4585c.m(arrayList4);
                            break;
                        case 4:
                            ArrayList arrayList5 = iVar3.f4584b;
                            arrayList5.add(0, (List) objF);
                            iVar3.f4585c.m(arrayList5);
                            break;
                        default:
                            ArrayList arrayList6 = iVar3.f4584b;
                            arrayList6.add(0, (p010b5.f) objF);
                            iVar3.f4585c.m(arrayList6);
                            break;
                    }
                } else {
                    iVar3.a(iVar.e());
                    break;
                }
                break;
            default:
                V4.h hVar = (V4.h) obj;
                if (!iVar.h()) {
                    Exception excE = iVar.e();
                    String message = excE != null ? excE.getMessage() : null;
                    HashMap map3 = new HashMap();
                    map3.put("code", "unknown");
                    if (excE != null) {
                        map3.put("message", excE.getMessage());
                    } else {
                        map3.put("message", "An unknown error has occurred.");
                    }
                    hVar.c("firebase_messaging", message, map3);
                } else {
                    hVar.a(iVar.f());
                }
                break;
        }
    }

    public /* synthetic */ b(Object obj, int i6) {
        this.r = i6;
        this.f349s = obj;
    }
}
