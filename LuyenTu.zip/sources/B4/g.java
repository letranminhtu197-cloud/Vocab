package B4;

import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import java.util.ArrayList;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class g implements TextToSpeech.OnInitListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f355a;

    @Override // android.speech.tts.TextToSpeech.OnInitListener
    public final void onInit(final int i6) {
        switch (this.f355a) {
            case 0:
                TextToSpeech textToSpeech = i.f356a;
                new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: B4.h
                    @Override // java.lang.Runnable
                    public final void run() {
                        TextToSpeech textToSpeech2;
                        ArrayList arrayList = i.f359d;
                        int i7 = 0;
                        boolean z6 = i6 == 0;
                        i.f357b = z6;
                        if (z6) {
                            TextToSpeech textToSpeech3 = i.f356a;
                            if (textToSpeech3 != null) {
                                textToSpeech3.setLanguage(Locale.US);
                            }
                            String str = i.f358c;
                            if (str != null && (textToSpeech2 = i.f356a) != null) {
                                textToSpeech2.speak(str, 0, null, "lt-widget");
                            }
                        }
                        i.f358c = null;
                        int size = arrayList.size();
                        while (i7 < size) {
                            Object obj = arrayList.get(i7);
                            i7++;
                            ((p154z5.a) obj).b();
                        }
                        arrayList.clear();
                    }
                });
                break;
            default:
                TextToSpeech textToSpeech2 = i.f356a;
                new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: B4.h
                    @Override // java.lang.Runnable
                    public final void run() {
                        TextToSpeech textToSpeech3;
                        ArrayList arrayList = i.f359d;
                        int i7 = 0;
                        boolean z6 = i6 == 0;
                        i.f357b = z6;
                        if (z6) {
                            TextToSpeech textToSpeech4 = i.f356a;
                            if (textToSpeech4 != null) {
                                textToSpeech4.setLanguage(Locale.US);
                            }
                            String str = i.f358c;
                            if (str != null && (textToSpeech3 = i.f356a) != null) {
                                textToSpeech3.speak(str, 0, null, "lt-widget");
                            }
                        }
                        i.f358c = null;
                        int size = arrayList.size();
                        while (i7 < size) {
                            Object obj = arrayList.get(i7);
                            i7++;
                            ((p154z5.a) obj).b();
                        }
                        arrayList.clear();
                    }
                });
                break;
        }
    }
}
