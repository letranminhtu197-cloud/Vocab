package B4;

import android.speech.tts.TextToSpeech;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public abstract class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static TextToSpeech f356a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static boolean f357b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static String f358c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final ArrayList f359d = new ArrayList();
}
