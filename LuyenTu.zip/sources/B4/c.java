package B4;

import C1.B;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import com.luyentu.mobile.MainActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.util.concurrent.Executor;
import p018d2.y;
import p044h2.p;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class c implements p154z5.a {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ Object f350s;
    public final /* synthetic */ Object t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ Object f351u;

    public /* synthetic */ c(Object obj, Object obj2, Object obj3, int i6) {
        this.r = i6;
        this.f350s = obj;
        this.t = obj2;
        this.f351u = obj3;
    }

    /* JADX WARN: Code duplicated, block: B:30:0x009d  */
    @Override // p154z5.a
    public final Object b() {
        boolean zCompress;
        int i6 = this.r;
        p074l5.l lVar = p074l5.l.f7746a;
        Object obj = this.f351u;
        Object obj2 = this.t;
        Object obj3 = this.f350s;
        switch (i6) {
            case 0:
                MainActivity mainActivity = (MainActivity) obj3;
                byte[] bArr = (byte[]) obj2;
                V4.h hVar = (V4.h) obj;
                int i7 = MainActivity.f5086w;
                mainActivity.getClass();
                int i8 = 0;
                if (bArr == null || bArr.length == 0) {
                    zCompress = false;
                } else {
                    BitmapFactory.Options options = new BitmapFactory.Options();
                    options.inJustDecodeBounds = true;
                    BitmapFactory.decodeByteArray(bArr, 0, bArr.length, options);
                    if (options.outWidth <= 0 || options.outHeight <= 0) {
                        zCompress = false;
                    } else {
                        BitmapFactory.Options options2 = new BitmapFactory.Options();
                        int i9 = 1;
                        while (true) {
                            int i10 = i9 * 2;
                            if (Math.max(options.outWidth, options.outHeight) / i10 >= 600) {
                                i9 = i10;
                            } else {
                                options2.inSampleSize = i9;
                                Bitmap bitmapDecodeByteArray = BitmapFactory.decodeByteArray(bArr, 0, bArr.length, options2);
                                if (bitmapDecodeByteArray == null) {
                                    zCompress = false;
                                } else {
                                    int iMax = Math.max(bitmapDecodeByteArray.getWidth(), bitmapDecodeByteArray.getHeight());
                                    if (iMax > 600) {
                                        float f4 = 600.0f / iMax;
                                        int width = (int) (bitmapDecodeByteArray.getWidth() * f4);
                                        if (width < 1) {
                                            width = 1;
                                        }
                                        int height = (int) (bitmapDecodeByteArray.getHeight() * f4);
                                        if (height < 1) {
                                            height = 1;
                                        }
                                        bitmapDecodeByteArray = Bitmap.createScaledBitmap(bitmapDecodeByteArray, width, height, true);
                                    }
                                    A5.h.b(bitmapDecodeByteArray);
                                    try {
                                        FileOutputStream fileOutputStream = new FileOutputStream(new File(mainActivity.getFilesDir(), "widget-avatar.jpg"));
                                        try {
                                            zCompress = bitmapDecodeByteArray.compress(Bitmap.CompressFormat.JPEG, 85, fileOutputStream);
                                            fileOutputStream.close();
                                        } catch (Throwable th) {
                                            try {
                                                throw th;
                                            } catch (Throwable th2) {
                                                p000a.a.e(fileOutputStream, th);
                                                throw th2;
                                            }
                                        }
                                    } catch (Exception unused) {
                                        zCompress = false;
                                    }
                                }
                            }
                        }
                    }
                }
                mainActivity.runOnUiThread(new d(hVar, zCompress, i8));
                return lVar;
            case 1:
                ((Executor) obj3).execute(new B((L.d) obj2, obj, 15));
                return lVar;
            case 2:
                ((Executor) obj3).execute(new B((L.d) obj2, (L.l) obj, 16));
                return lVar;
            case 3:
                ((Executor) obj3).execute(new R.b((L.d) obj2, (M.e) obj, 1));
                return lVar;
            default:
                ConnectivityManager connectivityManager = (ConnectivityManager) obj2;
                p044h2.d dVar = (p044h2.d) obj;
                if (((A5.m) obj3).r) {
                    y.e().a(p.f6026a, "NetworkRequestConstraintController unregister callback");
                    connectivityManager.unregisterNetworkCallback(dVar);
                }
                return lVar;
        }
    }
}
