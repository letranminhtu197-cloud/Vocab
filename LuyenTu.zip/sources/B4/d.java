package B4;

import P0.x;
import com.luyentu.mobile.MainActivity;
import p117t0.s;
import p140x0.C0495q;
import p140x0.C0503z;
import p140x0.SurfaceHolderCallbackC0500w;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class d implements Runnable {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ boolean f352s;
    public final /* synthetic */ Object t;

    public /* synthetic */ d(Object obj, boolean z6, int i6) {
        this.r = i6;
        this.t = obj;
        this.f352s = z6;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i6 = this.r;
        boolean z6 = this.f352s;
        Object obj = this.t;
        switch (i6) {
            case 0:
                int i7 = MainActivity.f5086w;
                ((V4.h) obj).a(Boolean.valueOf(z6));
                break;
            case 1:
                W4.h hVar = ((C4.b) obj).y;
                if (hVar != null) {
                    hVar.a(Boolean.valueOf(z6));
                }
                break;
            default:
                SurfaceHolderCallbackC0500w surfaceHolderCallbackC0500w = ((x) obj).f2978b;
                int i8 = s.f9002a;
                C0503z c0503z = surfaceHolderCallbackC0500w.f9979a;
                if (c0503z.f10001T != z6) {
                    c0503z.f10001T = z6;
                    c0503z.f10018l.e(23, new C0495q(2, z6));
                    break;
                }
                break;
        }
    }
}
