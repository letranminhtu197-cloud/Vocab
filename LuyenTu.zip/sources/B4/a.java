package B4;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import com.google.crypto.tink.shaded.protobuf.T;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.apache.tika.metadata.HttpHeaders;
import org.apache.tika.utils.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final AtomicBoolean f348a = new AtomicBoolean(false);

    public static String a() throws NoSuchAlgorithmException, InvalidKeyException {
        String strValueOf = String.valueOf(System.currentTimeMillis());
        Mac mac = Mac.getInstance("HmacSHA256");
        Charset charset = I5.a.f1645a;
        byte[] bytes = "luyentu-anti-scrape-2026".getBytes(charset);
        A5.h.d(bytes, "getBytes(...)");
        mac.init(new SecretKeySpec(bytes, "HmacSHA256"));
        byte[] bytes2 = strValueOf.getBytes(charset);
        A5.h.d(bytes2, "getBytes(...)");
        byte[] bArrDoFinal = mac.doFinal(bytes2);
        A5.h.d(bArrDoFinal, "doFinal(...)");
        StringBuilder sb = new StringBuilder();
        sb.append((CharSequence) StringUtils.EMPTY);
        int i6 = 0;
        for (byte b6 : bArrDoFinal) {
            i6++;
            if (i6 > 1) {
                sb.append((CharSequence) StringUtils.EMPTY);
            }
            sb.append((CharSequence) String.format("%02x", Arrays.copyOf(new Object[]{Byte.valueOf(b6)}, 1)));
        }
        sb.append((CharSequence) StringUtils.EMPTY);
        return T.y(strValueOf, ".", I5.d.G0(sb.toString(), 16));
    }

    /* JADX WARN: Code duplicated, block: B:160:0x0214 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:164:0x01ff A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:76:0x01d4  */
    /* JADX WARN: Code duplicated, block: B:90:0x0201 A[EDGE_INSN: B:90:0x0201->B:92:0x020b BREAK  A[LOOP:4: B:75:0x01d2->B:88:0x01f9]] */
    /* JADX WARN: Code duplicated, block: B:91:0x0206 A[EDGE_INSN: B:91:0x0206->B:92:0x020b BREAK  A[LOOP:4: B:75:0x01d2->B:88:0x01f9]] */
    /* JADX WARN: Code duplicated, block: B:93:0x020d  */
    public static void b(Context context) throws JSONException {
        JSONArray jSONArray;
        String str;
        String str2;
        JSONArray jSONArray2;
        JSONObject jSONObjectOptJSONObject;
        String str3;
        String str4;
        String str5;
        JSONArray jSONArray3;
        boolean zC;
        String str6;
        String str7;
        int i6;
        boolean z6;
        String str8;
        int i7;
        Integer numValueOf;
        int i8;
        int i9;
        int iDigit;
        int i10;
        String str9 = "[]";
        String str10 = "lt_widget_answer_queue";
        A5.h.e(context, "context");
        SharedPreferences sharedPreferences = context.getSharedPreferences("HomeWidgetPreferences", 0);
        String str11 = "getSharedPreferences(...)";
        A5.h.d(sharedPreferences, "getSharedPreferences(...)");
        String str12 = null;
        String string = sharedPreferences.getString("lt_widget_api_base", null);
        String string2 = string != null ? I5.d.H0(string).toString() : null;
        if (string2 == null) {
            string2 = StringUtils.EMPTY;
        }
        if (string2.length() == 0) {
            return;
        }
        try {
            A4.b bVar = new A4.b(context, 13);
            bVar.w(new KeyGenParameterSpec.Builder("_androidx_security_master_key_", 3).setEncryptionPaddings("NoPadding").setBlockModes("GCM").setKeySize(256).build());
            String string3 = K1.b.a(context, "FlutterSecureStorage", bVar.j()).getString("VGhpcyBpcyB0aGUgcHJlZml4IGZvciBhIHNlY3VyZSBzdG9yYWdlCg_accessToken", null);
            if (string3 != null && string3.length() > 0) {
                str12 = string3;
            }
        } catch (Throwable unused) {
        }
        if (str12 == null) {
            return;
        }
        try {
            SharedPreferences sharedPreferences2 = context.getSharedPreferences("HomeWidgetPreferences", 0);
            A5.h.d(sharedPreferences2, "getSharedPreferences(...)");
            String string4 = sharedPreferences2.getString("lt_widget_answer_queue", "[]");
            if (string4 == null) {
                string4 = "[]";
            }
            jSONArray = new JSONArray(string4);
        } catch (JSONException unused2) {
            jSONArray = new JSONArray();
        }
        if (jSONArray.length() == 0) {
            return;
        }
        int length = jSONArray.length();
        int i11 = 0;
        while (true) {
            String str13 = "learned";
            if (i11 >= length) {
                LinkedHashMap linkedHashMap = new LinkedHashMap();
                int length2 = jSONArray.length();
                int i12 = 0;
                while (true) {
                    str = "path";
                    if (i12 >= length2) {
                        break;
                    }
                    JSONObject jSONObjectOptJSONObject2 = jSONArray.optJSONObject(i12);
                    if (jSONObjectOptJSONObject2 != null) {
                        String str14 = jSONObjectOptJSONObject2.optString("path") + "|" + jSONObjectOptJSONObject2.optBoolean("learned");
                        Object linkedHashMap2 = linkedHashMap.get(str14);
                        if (linkedHashMap2 == null) {
                            linkedHashMap2 = new LinkedHashMap();
                            linkedHashMap.put(str14, linkedHashMap2);
                        }
                        ((Map) linkedHashMap2).put(jSONObjectOptJSONObject2.optString("id"), jSONObjectOptJSONObject2);
                    }
                    i12++;
                    length2 = length2;
                }
                Iterator it = linkedHashMap.values().iterator();
                while (it.hasNext()) {
                    Object next = it.next();
                    A5.h.d(next, "next(...)");
                    LinkedHashMap linkedHashMap3 = (LinkedHashMap) next;
                    Collection collectionValues = linkedHashMap3.values();
                    Iterator it2 = it;
                    A5.h.d(collectionValues, "<get-values>(...)");
                    Object objA0 = p081m5.f.A0(collectionValues);
                    A5.h.d(objA0, "first(...)");
                    JSONObject jSONObject = (JSONObject) objA0;
                    boolean zOptBoolean = jSONObject.optBoolean(str13);
                    String strOptString = jSONObject.optString(str);
                    A5.h.b(strOptString);
                    String str15 = str13;
                    String str16 = str;
                    if (strOptString.length() == 0) {
                        JSONArray jSONArray4 = new JSONArray();
                        Iterator it3 = linkedHashMap3.values().iterator();
                        while (it3.hasNext()) {
                            Iterator it4 = it3;
                            Object next2 = it4.next();
                            A5.h.d(next2, "next(...)");
                            String strOptString2 = ((JSONObject) next2).optString("id");
                            JSONArray jSONArray5 = jSONArray;
                            A5.h.d(strOptString2, "optString(...)");
                            p000a.a.c(10);
                            int length3 = strOptString2.length();
                            if (length3 == 0) {
                                str6 = str9;
                                str7 = str10;
                            } else {
                                str6 = str9;
                                str7 = str10;
                                char cCharAt = strOptString2.charAt(0);
                                int i13 = -2147483647;
                                if (A5.h.f(cCharAt, 48) >= 0) {
                                    i6 = 0;
                                } else if (length3 != 1) {
                                    if (cCharAt != '+') {
                                        if (cCharAt == '-') {
                                            i13 = Integer.MIN_VALUE;
                                            i6 = 1;
                                            z6 = true;
                                        }
                                        numValueOf = null;
                                        if (numValueOf != null) {
                                            jSONArray4.put(numValueOf.intValue());
                                        }
                                        it3 = it4;
                                        jSONArray = jSONArray5;
                                        str9 = str6;
                                        str10 = str7;
                                        str11 = str8;
                                    } else {
                                        i6 = 1;
                                    }
                                    str8 = str11;
                                    i7 = 0;
                                    int i14 = -59652323;
                                    while (true) {
                                        if (i6 < length3) {
                                            if (z6) {
                                                numValueOf = Integer.valueOf(i7);
                                                break;
                                            } else {
                                                numValueOf = Integer.valueOf(-i7);
                                                break;
                                            }
                                        }
                                        i8 = length3;
                                        i9 = i6;
                                        iDigit = Character.digit((int) strOptString2.charAt(i6), 10);
                                        if (iDigit < 0 || ((i7 < i14 && (i14 != -59652323 || i7 < (i14 = i13 / 10))) || (i10 = i7 * 10) < i13 + iDigit)) {
                                            numValueOf = null;
                                            break;
                                        } else {
                                            i7 = i10 - iDigit;
                                            i6 = i9 + 1;
                                            length3 = i8;
                                        }
                                    }
                                    if (numValueOf != null) {
                                        jSONArray4.put(numValueOf.intValue());
                                    }
                                    it3 = it4;
                                    jSONArray = jSONArray5;
                                    str9 = str6;
                                    str10 = str7;
                                    str11 = str8;
                                }
                                z6 = false;
                                str8 = str11;
                                i7 = 0;
                                int i15 = -59652323;
                                while (true) {
                                    if (i6 < length3) {
                                        if (z6) {
                                            numValueOf = Integer.valueOf(i7);
                                            break;
                                        } else {
                                            numValueOf = Integer.valueOf(-i7);
                                            break;
                                        }
                                    }
                                    i8 = length3;
                                    i9 = i6;
                                    iDigit = Character.digit((int) strOptString2.charAt(i6), 10);
                                    if (iDigit < 0) {
                                        i7 = i10 - iDigit;
                                        i6 = i9 + 1;
                                        length3 = i8;
                                    }
                                    numValueOf = null;
                                    break;
                                }
                                if (numValueOf != null) {
                                    jSONArray4.put(numValueOf.intValue());
                                }
                                it3 = it4;
                                jSONArray = jSONArray5;
                                str9 = str6;
                                str10 = str7;
                                str11 = str8;
                            }
                            str8 = str11;
                            numValueOf = null;
                            if (numValueOf != null) {
                                jSONArray4.put(numValueOf.intValue());
                            }
                            it3 = it4;
                            jSONArray = jSONArray5;
                            str9 = str6;
                            str10 = str7;
                            str11 = str8;
                        }
                        str3 = str9;
                        str4 = str10;
                        str5 = str11;
                        jSONArray3 = jSONArray;
                        if (jSONArray4.length() != 0) {
                            String strConcat = string2.concat("/vocabularies/progress/bulk");
                            JSONObject jSONObjectPut = new JSONObject().put("vocabularyIds", jSONArray4).put("isLearned", zOptBoolean);
                            A5.h.d(jSONObjectPut, "put(...)");
                            zC = c("PATCH", strConcat, jSONObjectPut, str12);
                        } else {
                            continue;
                        }
                        it = it2;
                        str13 = str15;
                        str = str16;
                        jSONArray = jSONArray3;
                        str9 = str3;
                        str10 = str4;
                        str11 = str5;
                    } else {
                        str3 = str9;
                        str4 = str10;
                        str5 = str11;
                        jSONArray3 = jSONArray;
                        JSONArray jSONArray6 = new JSONArray();
                        for (Object obj : linkedHashMap3.values()) {
                            A5.h.d(obj, "next(...)");
                            jSONArray6.put(((JSONObject) obj).optString("id"));
                        }
                        JSONObject jSONObjectPut2 = new JSONObject().put("vocabularyIds", jSONArray6).put("isLearned", zOptBoolean).put("skipActivityLog", true);
                        A5.h.d(jSONObjectPut2, "put(...)");
                        zC = c("POST", string2 + "/paths/" + strOptString + "/progress/bulk", jSONObjectPut2, str12);
                    }
                    if (!zC) {
                        return;
                    }
                    it = it2;
                    str13 = str15;
                    str = str16;
                    jSONArray = jSONArray3;
                    str9 = str3;
                    str10 = str4;
                    str11 = str5;
                }
                String str17 = str9;
                String str18 = str10;
                String str19 = str11;
                JSONArray jSONArray7 = jSONArray;
                int i16 = 0;
                SharedPreferences sharedPreferences3 = context.getSharedPreferences("HomeWidgetPreferences", 0);
                A5.h.d(sharedPreferences3, str19);
                try {
                    SharedPreferences sharedPreferences4 = context.getSharedPreferences("HomeWidgetPreferences", 0);
                    A5.h.d(sharedPreferences4, str19);
                    str2 = str18;
                    try {
                        String string5 = sharedPreferences4.getString(str2, str17);
                        if (string5 == null) {
                            string5 = str17;
                        }
                        jSONArray2 = new JSONArray(string5);
                    } catch (JSONException unused3) {
                        jSONArray2 = new JSONArray();
                    }
                } catch (JSONException unused4) {
                    str2 = str18;
                }
                if (jSONArray2.length() >= jSONArray7.length()) {
                    int length4 = jSONArray7.length();
                    while (i16 < length4) {
                        JSONArray jSONArray8 = jSONArray7;
                        JSONObject jSONObjectOptJSONObject3 = jSONArray8.optJSONObject(i16);
                        if (jSONObjectOptJSONObject3 != null && (jSONObjectOptJSONObject = jSONArray2.optJSONObject(i16)) != null && A5.h.a(jSONObjectOptJSONObject.optString("id"), jSONObjectOptJSONObject3.optString("id")) && jSONObjectOptJSONObject.optDouble("at", -1.0d) == jSONObjectOptJSONObject3.optDouble("at", -1.0d)) {
                            i16++;
                            jSONArray7 = jSONArray8;
                        }
                    }
                    JSONArray jSONArray9 = new JSONArray();
                    int length5 = jSONArray2.length();
                    for (int length6 = jSONArray7.length(); length6 < length5; length6++) {
                        jSONArray9.put(jSONArray2.opt(length6));
                    }
                    sharedPreferences3.edit().putString(str2, jSONArray9.toString()).apply();
                }
                c("POST", string2.concat("/activity/log"), new JSONObject(), str12);
                return;
            }
            JSONObject jSONObjectOptJSONObject4 = jSONArray.optJSONObject(i11);
            if (jSONObjectOptJSONObject4 == null || !jSONObjectOptJSONObject4.has("learned")) {
                return;
            } else {
                i11++;
            }
        }
    }

    public static boolean c(String str, String str2, JSONObject jSONObject, String str3) {
        try {
            URLConnection uRLConnectionOpenConnection = new URL(str2).openConnection();
            A5.h.c(uRLConnectionOpenConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
            HttpURLConnection httpURLConnection = (HttpURLConnection) uRLConnectionOpenConnection;
            try {
                try {
                    httpURLConnection.setRequestMethod(str);
                } catch (Throwable th) {
                    httpURLConnection.disconnect();
                    throw th;
                }
            } catch (ProtocolException unused) {
                Field declaredField = HttpURLConnection.class.getDeclaredField("method");
                declaredField.setAccessible(true);
                declaredField.set(httpURLConnection, str);
            }
            httpURLConnection.setConnectTimeout(5000);
            httpURLConnection.setReadTimeout(8000);
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setRequestProperty(HttpHeaders.CONTENT_TYPE, "application/json");
            httpURLConnection.setRequestProperty("Authorization", "Bearer ".concat(str3));
            httpURLConnection.setRequestProperty("X-App-Token", a());
            OutputStream outputStream = httpURLConnection.getOutputStream();
            try {
                String string = jSONObject.toString();
                A5.h.d(string, "toString(...)");
                byte[] bytes = string.getBytes(I5.a.f1645a);
                A5.h.d(bytes, "getBytes(...)");
                outputStream.write(bytes);
                outputStream.close();
                int responseCode = httpURLConnection.getResponseCode();
                boolean z6 = 200 <= responseCode && responseCode < 300;
                httpURLConnection.disconnect();
                return z6;
            } catch (Throwable th2) {
                try {
                    throw th2;
                } catch (Throwable th3) {
                    p000a.a.e(outputStream, th2);
                    throw th3;
                }
            }
        } catch (Throwable unused2) {
            return false;
        }
    }
}
