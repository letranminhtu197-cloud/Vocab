package B4;

import com.google.crypto.tink.shaded.protobuf.T;

/* JADX INFO: loaded from: classes.dex */
public final class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f369a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f370b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f371c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f372d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f373e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final String f374f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final String f375g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f376h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final String f377i;

    public n(String str, String str2, String str3, String str4, String str5, String str6, String str7, int i6, String str8) {
        this.f369a = str;
        this.f370b = str2;
        this.f371c = str3;
        this.f372d = str4;
        this.f373e = str5;
        this.f374f = str6;
        this.f375g = str7;
        this.f376h = i6;
        this.f377i = str8;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof n)) {
            return false;
        }
        n nVar = (n) obj;
        return A5.h.a(this.f369a, nVar.f369a) && A5.h.a(this.f370b, nVar.f370b) && A5.h.a(this.f371c, nVar.f371c) && A5.h.a(this.f372d, nVar.f372d) && A5.h.a(this.f373e, nVar.f373e) && A5.h.a(this.f374f, nVar.f374f) && A5.h.a(this.f375g, nVar.f375g) && this.f376h == nVar.f376h && A5.h.a(this.f377i, nVar.f377i);
    }

    public final int hashCode() {
        return this.f377i.hashCode() + ((Integer.hashCode(this.f376h) + T.w(T.w(T.w(T.w(T.w(T.w(this.f369a.hashCode() * 31, 31, this.f370b), 31, this.f371c), 31, this.f372d), 31, this.f373e), 31, this.f374f), 31, this.f375g)) * 31);
    }

    public final String toString() {
        StringBuilder sbP = T.p("Word(id=", this.f369a, ", term=", this.f370b, ", meaning=");
        A3.a.r(sbP, this.f371c, ", pronunciation=", this.f372d, ", partOfSpeech=");
        A3.a.r(sbP, this.f373e, ", example=", this.f374f, ", exampleTranslation=");
        sbP.append(this.f375g);
        sbP.append(", srsLevel=");
        sbP.append(this.f376h);
        sbP.append(", pathId=");
        return T.m(sbP, this.f377i, ")");
    }
}
