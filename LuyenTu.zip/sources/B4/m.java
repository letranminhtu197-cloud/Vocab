package B4;

import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f367a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f368b;

    public m(int i6, Set set) {
        this.f367a = i6;
        this.f368b = set;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof m)) {
            return false;
        }
        m mVar = (m) obj;
        return this.f367a == mVar.f367a && this.f368b.equals(mVar.f368b);
    }

    public final int hashCode() {
        return this.f368b.hashCode() + (Integer.hashCode(this.f367a) * 31);
    }

    public final String toString() {
        return "Streak(streak=" + this.f367a + ", activeDates=" + this.f368b + ")";
    }
}
