package B4;

import C1.C0008i;
import android.app.Activity;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.WorkDatabase_Impl;
import com.google.crypto.tink.shaded.protobuf.T;
import com.luyentu.mobile.WordWidgetProvider;
import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import org.apache.tika.fork.ContentHandlerProxy;
import p015d.r;
import p015d.t;
import p018d2.C0289b;
import p025e2.AbstractC0303g;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class o implements p154z5.a {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ Object f378s;

    public /* synthetic */ o(Object obj, int i6) {
        this.r = i6;
        this.f378s = obj;
    }

    /* JADX WARN: Code duplicated, block: B:33:0x00c1  */
    /* JADX WARN: Code duplicated, block: B:37:0x00d7  */
    /* JADX WARN: Code duplicated, block: B:42:0x00e4  */
    /* JADX WARN: Instruction removed from duplicated block: B:42:0x00e4, please report this as an issue */
    @Override // p154z5.a
    public final Object b() {
        N1.f fVar;
        WorkDatabase workDatabase;
        C0289b c0289b;
        boolean zA;
        int i6 = this.r;
        boolean z6 = true;
        p074l5.l lVar = p074l5.l.f7746a;
        Object obj = this.f378s;
        switch (i6) {
            case 0:
                BroadcastReceiver.PendingResult pendingResult = (BroadcastReceiver.PendingResult) obj;
                int i7 = WordWidgetProvider.f5090a;
                try {
                    pendingResult.finish();
                    break;
                } catch (IllegalStateException unused) {
                }
                return lVar;
            case 1:
                WorkDatabase_Impl workDatabase_Impl = ((C0008i) obj).f487a;
                if (workDatabase_Impl.k() && !workDatabase_Impl.m()) {
                    z6 = false;
                }
                return Boolean.valueOf(z6);
            case 2:
                return ((A4.b) obj).d(":memory:");
            case 3:
                B2.d dVar = (B2.d) obj;
                Context context = (Activity) dVar.f325s;
                if (context == null) {
                    context = (Context) dVar.r;
                }
                return T.i(context.getPackageName(), ".flutter.share_provider");
            case 4:
                N1.g gVar = (N1.g) obj;
                String str = gVar.f2639s;
                if (str == null || !gVar.f2640u) {
                    fVar = new N1.f(gVar.r, gVar.f2639s, new A0.i(11, (byte) 0), gVar.t, gVar.f2641v);
                } else {
                    Context context2 = gVar.r;
                    A5.h.e(context2, "context");
                    File noBackupFilesDir = context2.getNoBackupFilesDir();
                    A5.h.d(noBackupFilesDir, "getNoBackupFilesDir(...)");
                    fVar = new N1.f(gVar.r, new File(noBackupFilesDir, str).getAbsolutePath(), new A0.i(11, (byte) 0), gVar.t, gVar.f2641v);
                }
                fVar.setWriteAheadLoggingEnabled(gVar.f2643x);
                return fVar;
            case 5:
                return new r((t) obj);
            case 6:
                p025e2.m mVar = (p025e2.m) obj;
                String str2 = p078m2.b.f7804a;
                p025e2.t tVar = mVar.f5462u;
                HashSet hashSet = new HashSet();
                hashSet.addAll(mVar.y);
                HashSet hashSetG0 = p025e2.m.g0(mVar);
                Iterator it = hashSet.iterator();
                do {
                    if (!it.hasNext()) {
                        hashSet.removeAll(mVar.y);
                        z6 = false;
                    }
                    if (!z6) {
                        throw new IllegalStateException("WorkContinuation has cycles (" + mVar + ")");
                    }
                    workDatabase = tVar.f5480c;
                    c0289b = tVar.f5479b;
                    workDatabase.b();
                    try {
                        p078m2.g.b(workDatabase, c0289b, mVar);
                        zA = p078m2.b.a(mVar);
                        workDatabase.o();
                        workDatabase.f();
                        if (zA) {
                            AbstractC0303g.b(c0289b, tVar.f5480c, tVar.f5482e);
                        }
                        return lVar;
                    } catch (Throwable th) {
                        workDatabase.f();
                        throw th;
                    }
                } while (!hashSetG0.contains((String) it.next()));
                if (!z6) {
                    throw new IllegalStateException("WorkContinuation has cycles (" + mVar + ")");
                }
                workDatabase = tVar.f5480c;
                c0289b = tVar.f5479b;
                workDatabase.b();
                p078m2.g.b(workDatabase, c0289b, mVar);
                zA = p078m2.b.a(mVar);
                workDatabase.o();
                workDatabase.f();
                if (zA) {
                    AbstractC0303g.b(c0289b, tVar.f5480c, tVar.f5482e);
                }
                return lVar;
            case 7:
                p025e2.t tVar2 = (p025e2.t) obj;
                WorkDatabase workDatabase2 = tVar2.f5480c;
                Context context3 = tVar2.f5478a;
                String str3 = p037g2.c.f5882w;
                if (Build.VERSION.SDK_INT >= 34) {
                    p037g2.a.b(context3).cancelAll();
                }
                JobScheduler jobScheduler = (JobScheduler) context3.getSystemService("jobscheduler");
                ArrayList arrayListC = p037g2.c.c(context3, jobScheduler);
                if (arrayListC != null && !arrayListC.isEmpty()) {
                    int size = arrayListC.size();
                    int i8 = 0;
                    while (i8 < size) {
                        Object obj2 = arrayListC.get(i8);
                        i8++;
                        p037g2.c.b(jobScheduler, ((JobInfo) obj2).getId());
                    }
                }
                ((Number) X2.a.I(workDatabase2.v().f7708a, false, true, new j(18))).intValue();
                AbstractC0303g.b(tVar2.f5479b, workDatabase2, tVar2.f5482e);
                return lVar;
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                ((p154z5.a) obj).b();
                return lVar;
            default:
                Activity activity = (Activity) obj;
                Intent launchIntentForPackage = activity.getPackageManager().getLaunchIntentForPackage(activity.getPackageName());
                if (launchIntentForPackage != null) {
                    launchIntentForPackage.setPackage(null);
                }
                if (launchIntentForPackage != null) {
                    launchIntentForPackage.setFlags(67108864);
                }
                activity.startActivity(launchIntentForPackage);
                return lVar;
        }
    }
}
