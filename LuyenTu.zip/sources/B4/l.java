package B4;

import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f365a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f366b;

    public l(int i6, List list) {
        this.f365a = list;
        this.f366b = i6;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof l)) {
            return false;
        }
        l lVar = (l) obj;
        return this.f365a.equals(lVar.f365a) && this.f366b == lVar.f366b;
    }

    public final int hashCode() {
        return Integer.hashCode(this.f366b) + (this.f365a.hashCode() * 31);
    }

    public final String toString() {
        return "Payload(words=" + this.f365a + ", dueCount=" + this.f366b + ")";
    }
}
