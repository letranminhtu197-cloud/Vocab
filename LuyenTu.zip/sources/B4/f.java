package B4;

import H.C0028g;
import K5.Y;
import W4.p;
import android.content.SharedPreferences;
import android.util.Log;
import androidx.lifecycle.C0198u;
import androidx.lifecycle.EnumC0190l;
import androidx.lifecycle.F;
import com.google.firebase.messaging.FirebaseMessaging;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.parser.external.ExternalParser;
import org.apache.tika.pipes.PipesServer;
import org.apache.tika.utils.XMLReaderUtils;
import p030f0.C0319l;
import p053i4.H;
import p068l.C0405s;
import p140x0.C0490l;
import p140x0.G;
import p140x0.Z;
import p150z0.E;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class f implements Runnable {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ Object f354s;

    public /* synthetic */ f(Object obj, int i6) {
        this.r = i6;
        this.f354s = obj;
    }

    @Override // java.lang.Runnable
    public final void run() {
        boolean zIsEmpty;
        switch (this.r) {
            case 0:
                ((e) this.f354s).b();
                return;
            case 1:
                C2.m mVar = (C2.m) this.f354s;
                ((D2.h) mVar.f580d).o(new b(mVar, 4));
                return;
            case 2:
                ((C4.i) this.f354s).f614b.b();
                return;
            case 3:
                ((p066k4.c) this.f354s).I();
                return;
            case 4:
                F4.e eVar = (F4.e) this.f354s;
                ArrayList arrayList = eVar.f1245f;
                while (!arrayList.isEmpty() && eVar.f1251l == null) {
                    ((G4.d) arrayList.get(0)).f1432a.run();
                    arrayList.remove(0);
                }
                return;
            case 5:
                G0.g gVar = (G0.g) this.f354s;
                synchronized (gVar.f1313a) {
                    try {
                        if (gVar.f1325m) {
                            return;
                        }
                        long j6 = gVar.f1324l - 1;
                        gVar.f1324l = j6;
                        if (j6 > 0) {
                            return;
                        }
                        if (j6 >= 0) {
                            gVar.a();
                            return;
                        }
                        IllegalStateException illegalStateException = new IllegalStateException();
                        synchronized (gVar.f1313a) {
                            gVar.f1326n = illegalStateException;
                            break;
                        }
                        return;
                    } catch (Throwable th) {
                        throw th;
                    }
                }
            case 6:
                N4.h hVar = (N4.h) this.f354s;
                ExecutorService executorService = hVar.f2699a;
                ConcurrentLinkedQueue concurrentLinkedQueue = hVar.f2700b;
                AtomicBoolean atomicBoolean = hVar.f2701c;
                if (atomicBoolean.compareAndSet(false, true)) {
                    int i6 = 6;
                    try {
                        Runnable runnable = (Runnable) concurrentLinkedQueue.poll();
                        if (runnable != null) {
                            runnable.run();
                        }
                        if (zIsEmpty) {
                            return;
                        } else {
                            return;
                        }
                    } finally {
                        atomicBoolean.set(false);
                        if (!concurrentLinkedQueue.isEmpty()) {
                            executorService.execute(new f(hVar, i6));
                        }
                    }
                    break;
                }
                return;
            case 7:
                P0.f fVar = (P0.f) this.f354s;
                int i7 = fVar.f2875k - 1;
                fVar.f2875k = i7;
                if (i7 > 0) {
                    return;
                }
                if (i7 < 0) {
                    throw new IllegalStateException(String.valueOf(fVar.f2875k));
                }
                fVar.f2867c.a();
                return;
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                C0028g c0028g = ((p053i4.n) ((Map.Entry) this.f354s).getKey()).f6340a;
                if (c0028g.e()) {
                    FirebaseMessaging firebaseMessaging = (FirebaseMessaging) c0028g.f1490e;
                    M4.i iVar = FirebaseMessaging.f5062l;
                    firebaseMessaging.k();
                    return;
                }
                return;
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                ((Q4.d) ((Q4.b) this.f354s).t).f3252f.prefetchDefaultFontManager();
                return;
            case 10:
                ((S.c) this.f354s).c().i(new M.d("Failed to launch the selector UI. Hint: ensure the `context` parameter is an Activity-based context."));
                return;
            case 11:
                ((U.b) this.f354s).d().i(new M.d("Failed to launch the selector UI. Hint: ensure the `context` parameter is an Activity-based context."));
                return;
            case 12:
                F f4 = (F) this.f354s;
                C0198u c0198u = f4.f4433w;
                if (f4.f4430s == 0) {
                    f4.t = true;
                    c0198u.e(EnumC0190l.ON_PAUSE);
                }
                if (f4.r == 0 && f4.t) {
                    c0198u.e(EnumC0190l.ON_STOP);
                    f4.f4431u = true;
                    return;
                }
                return;
            case 13:
                p015d.j jVar = (p015d.j) this.f354s;
                Runnable runnable2 = jVar.f5106s;
                if (runnable2 != null) {
                    runnable2.run();
                    jVar.f5106s = null;
                    return;
                }
                return;
            case 14:
                p015d.n.a((p015d.n) this.f354s);
                return;
            case 15:
                Y y = (Y) this.f354s;
                if (y != null) {
                    y.d(null);
                    return;
                }
                return;
            case 16:
                C0319l c0319l = (C0319l) this.f354s;
                A5.h.e(c0319l, "this$0");
                A5.h.e(null, "$operation");
                c0319l.a(null);
                return;
            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                B2.d dVar = (B2.d) this.f354s;
                synchronized (((ArrayDeque) dVar.f326u)) {
                    SharedPreferences.Editor editorEdit = ((SharedPreferences) dVar.r).edit();
                    String str = (String) dVar.f325s;
                    StringBuilder sb = new StringBuilder();
                    Iterator it = ((ArrayDeque) dVar.f326u).iterator();
                    while (it.hasNext()) {
                        sb.append((String) it.next());
                        sb.append((String) dVar.t);
                    }
                    editorEdit.putString(str, sb.toString()).commit();
                    break;
                }
                return;
            case 18:
                H h7 = (H) this.f354s;
                Log.w("FirebaseMessaging", "Service took too long to process intent: " + h7.f6302a.getAction() + " finishing.");
                h7.f6303b.d(null);
                return;
            case 19:
                ((io.flutter.plugin.platform.k) this.f354s).d(false);
                return;
            case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
                if (((p009b4.a) ((p073l4.j) this.f354s).f7729a.r).get() != null) {
                    throw new ClassCastException();
                }
                return;
            case 21:
                ExternalParser.lambda$ignoreStream$0((InputStream) this.f354s);
                return;
            case 22:
                Z z6 = (Z) this.f354s;
                try {
                    synchronized (z6) {
                    }
                    try {
                        z6.f9852a.c(z6.f9855d, z6.f9856e);
                        return;
                    } finally {
                        z6.b(true);
                    }
                } catch (C0490l e6) {
                    p117t0.a.m("ExoPlayerImplInternal", "Unexpected error delivering message on external thread.", e6);
                    throw new RuntimeException(e6);
                }
            case 23:
                y0.d dVar2 = (y0.d) this.f354s;
                dVar2.L(dVar2.G(), 1028, new y0.b(18));
                dVar2.f10450w.d();
                return;
            case 24:
                ((C0405s) this.f354s).getClass();
                return;
            case 25:
                E e7 = (E) this.f354s;
                if (e7.f10625k0 >= 300000) {
                    ((p150z0.H) e7.f10632s.r).f10649g1 = true;
                    e7.f10625k0 = 0L;
                    return;
                }
                return;
            default:
                ((p) this.f354s).b();
                return;
        }
    }

    public /* synthetic */ f(Object obj, Object obj2, int i6) {
        this.r = i6;
        this.f354s = obj;
    }

    public /* synthetic */ f(p073l4.j jVar, String str, p080m4.f fVar) {
        this.r = 20;
        this.f354s = jVar;
    }

    public /* synthetic */ f(G g7, Z z6) {
        this.r = 22;
        this.f354s = z6;
    }
}
