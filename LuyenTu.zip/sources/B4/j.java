package B4;

import C1.C0000a;
import C1.x;
import K5.AbstractC0114s;
import android.util.Log;
import com.google.android.gms.internal.play_billing.AbstractC0252u0;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.metadata.TikaCoreProperties;
import org.apache.tika.pipes.PipesServer;
import p018d2.C0292e;
import p018d2.E;
import p018d2.EnumC0288a;
import p018d2.F;
import p018d2.G;
import p018d2.z;
import p047h5.N;
import p071l2.p;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class j implements p154z5.c {
    public final /* synthetic */ int r;

    public /* synthetic */ j(int i6) {
        this.r = i6;
    }

    private final Object c(Object obj) throws Exception {
        L1.a aVar = (L1.a) obj;
        A5.h.e(aVar, "_connection");
        L1.c cVarI = aVar.I("SELECT * FROM workspec WHERE state=0 ORDER BY last_enqueue_time LIMIT ?");
        try {
            cVarI.c(200, 1);
            int iQ = AbstractC0252u0.q(cVarI, "id");
            int iQ2 = AbstractC0252u0.q(cVarI, "state");
            int iQ3 = AbstractC0252u0.q(cVarI, "worker_class_name");
            int iQ4 = AbstractC0252u0.q(cVarI, "input_merger_class_name");
            int iQ5 = AbstractC0252u0.q(cVarI, "input");
            int iQ6 = AbstractC0252u0.q(cVarI, "output");
            int iQ7 = AbstractC0252u0.q(cVarI, "initial_delay");
            int iQ8 = AbstractC0252u0.q(cVarI, "interval_duration");
            int iQ9 = AbstractC0252u0.q(cVarI, "flex_duration");
            int iQ10 = AbstractC0252u0.q(cVarI, "run_attempt_count");
            int iQ11 = AbstractC0252u0.q(cVarI, "backoff_policy");
            int iQ12 = AbstractC0252u0.q(cVarI, "backoff_delay_duration");
            int iQ13 = AbstractC0252u0.q(cVarI, "last_enqueue_time");
            int iQ14 = AbstractC0252u0.q(cVarI, "minimum_retention_duration");
            int iQ15 = AbstractC0252u0.q(cVarI, "schedule_requested_at");
            int iQ16 = AbstractC0252u0.q(cVarI, "run_in_foreground");
            int iQ17 = AbstractC0252u0.q(cVarI, "out_of_quota_policy");
            int iQ18 = AbstractC0252u0.q(cVarI, "period_count");
            int iQ19 = AbstractC0252u0.q(cVarI, "generation");
            int iQ20 = AbstractC0252u0.q(cVarI, "next_schedule_time_override");
            int iQ21 = AbstractC0252u0.q(cVarI, "next_schedule_time_override_generation");
            int iQ22 = AbstractC0252u0.q(cVarI, "stop_reason");
            int iQ23 = AbstractC0252u0.q(cVarI, "trace_tag");
            int iQ24 = AbstractC0252u0.q(cVarI, "backoff_on_system_interruptions");
            int iQ25 = AbstractC0252u0.q(cVarI, "required_network_type");
            int iQ26 = AbstractC0252u0.q(cVarI, "required_network_request");
            int iQ27 = AbstractC0252u0.q(cVarI, "requires_charging");
            int iQ28 = AbstractC0252u0.q(cVarI, "requires_device_idle");
            int iQ29 = AbstractC0252u0.q(cVarI, "requires_battery_not_low");
            int iQ30 = AbstractC0252u0.q(cVarI, "requires_storage_not_low");
            int iQ31 = AbstractC0252u0.q(cVarI, "trigger_content_update_delay");
            int iQ32 = AbstractC0252u0.q(cVarI, "trigger_max_content_delay");
            int iQ33 = AbstractC0252u0.q(cVarI, "content_uri_triggers");
            ArrayList arrayList = new ArrayList();
            while (cVarI.E()) {
                String strM = cVarI.m(iQ);
                int i6 = iQ13;
                int i7 = iQ14;
                F fD = G.D((int) cVarI.getLong(iQ2));
                String strM2 = cVarI.m(iQ3);
                String strM3 = cVarI.m(iQ4);
                byte[] blob = cVarI.getBlob(iQ5);
                p018d2.j jVar = p018d2.j.f5273b;
                p018d2.j jVarF = android.support.v4.media.session.b.F(blob);
                p018d2.j jVarF2 = android.support.v4.media.session.b.F(cVarI.getBlob(iQ6));
                long j6 = cVarI.getLong(iQ7);
                long j7 = cVarI.getLong(iQ8);
                long j8 = cVarI.getLong(iQ9);
                int i8 = (int) cVarI.getLong(iQ10);
                int i9 = iQ;
                int i10 = iQ2;
                EnumC0288a enumC0288aA = G.A((int) cVarI.getLong(iQ11));
                long j9 = cVarI.getLong(iQ12);
                long j10 = cVarI.getLong(i6);
                long j11 = cVarI.getLong(i7);
                int i11 = iQ15;
                long j12 = cVarI.getLong(i11);
                iQ15 = i11;
                int i12 = iQ16;
                int i13 = iQ3;
                boolean z6 = ((int) cVarI.getLong(i12)) != 0;
                int i14 = iQ17;
                int i15 = iQ4;
                E eC = G.C((int) cVarI.getLong(i14));
                int i16 = iQ18;
                int i17 = (int) cVarI.getLong(i16);
                int i18 = iQ19;
                int i19 = (int) cVarI.getLong(i18);
                int i20 = iQ20;
                long j13 = cVarI.getLong(i20);
                int i21 = iQ21;
                int i22 = (int) cVarI.getLong(i21);
                iQ21 = i21;
                iQ22 = iQ22;
                int i23 = (int) cVarI.getLong(iQ22);
                int i24 = iQ23;
                Boolean boolValueOf = null;
                String strM4 = cVarI.isNull(i24) ? null : cVarI.m(i24);
                int i25 = iQ24;
                Integer numValueOf = cVarI.isNull(i25) ? null : Integer.valueOf((int) cVarI.getLong(i25));
                if (numValueOf != null) {
                    boolValueOf = Boolean.valueOf(numValueOf.intValue() != 0);
                }
                Boolean bool = boolValueOf;
                int i26 = iQ25;
                z zVarB = G.B((int) cVarI.getLong(i26));
                int i27 = iQ26;
                p078m2.f fVarB0 = G.b0(cVarI.getBlob(i27));
                int i28 = iQ27;
                boolean z7 = ((int) cVarI.getLong(i28)) != 0;
                int i29 = iQ28;
                boolean z8 = ((int) cVarI.getLong(i29)) != 0;
                int i30 = iQ29;
                boolean z9 = ((int) cVarI.getLong(i30)) != 0;
                iQ29 = i30;
                int i31 = iQ30;
                int i32 = iQ31;
                int i33 = iQ32;
                iQ31 = i32;
                int i34 = iQ33;
                arrayList.add(new p(strM, fD, strM2, strM3, jVarF, jVarF2, j6, j7, j8, new C0292e(fVarB0, zVarB, z7, z8, z9, ((int) cVarI.getLong(i31)) != 0, cVarI.getLong(i32), cVarI.getLong(i33), G.c(cVarI.getBlob(i34))), i8, enumC0288aA, j9, j10, j11, j12, z6, eC, i17, i19, j13, i22, i23, strM4, bool));
                iQ28 = i29;
                iQ4 = i15;
                iQ17 = i14;
                iQ18 = i16;
                iQ19 = i18;
                iQ20 = i20;
                iQ23 = i24;
                iQ24 = i25;
                iQ25 = i26;
                iQ26 = i27;
                iQ27 = i28;
                iQ33 = i34;
                iQ32 = i33;
                iQ30 = i31;
                iQ = i9;
                iQ3 = i13;
                iQ13 = i6;
                iQ14 = i7;
                iQ2 = i10;
                iQ16 = i12;
            }
            return arrayList;
        } finally {
            cVarI.close();
        }
    }

    @Override // p154z5.c
    public final Object a(Object obj) throws Exception {
        Boolean boolValueOf;
        Boolean boolValueOf2;
        Boolean boolValueOf3;
        boolean z6;
        int i6 = this.r;
        p074l5.l lVar = p074l5.l.f7746a;
        switch (i6) {
            case 0:
                n nVar = (n) obj;
                A5.h.e(nVar, "it");
                return nVar.f369a + TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER + nVar.f376h;
            case 1:
                A5.h.e((C0000a) obj, "config");
                throw new p074l5.f(0);
            case 2:
                L1.c cVar = (L1.c) obj;
                A5.h.e(cVar, "it");
                return Boolean.valueOf(cVar.E());
            case 3:
                L1.c cVar2 = (L1.c) obj;
                A5.h.e(cVar2, "statement");
                p087n5.i iVar = new p087n5.i();
                while (cVar2.E()) {
                    iVar.add(Integer.valueOf((int) cVar2.getLong(0)));
                }
                return h6.h.k(iVar);
            case 4:
                q5.f fVar = (q5.f) obj;
                if (fVar instanceof AbstractC0114s) {
                    return (AbstractC0114s) fVar;
                }
                return null;
            case 5:
                Map.Entry entry = (Map.Entry) obj;
                A5.h.e(entry, "<destruct>");
                String str = (String) entry.getKey();
                Object value = entry.getValue();
                StringBuilder sb = new StringBuilder();
                sb.append(str);
                sb.append(" : ");
                if (value instanceof Object[]) {
                    value = Arrays.toString((Object[]) value);
                    A5.h.d(value, "toString(...)");
                }
                sb.append(value);
                return sb.toString();
            case 6:
                p051i2.e eVar = (p051i2.e) obj;
                A5.h.e(eVar, "it");
                return eVar.getClass().getSimpleName();
            case 7:
                Throwable th = ((N) obj).f6144c;
                if (th != null) {
                    Log.e("IN_APP_PURCHASE", "userSelectedalternativeBilling handler error: " + th);
                }
                return lVar;
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                Throwable th2 = ((N) obj).f6144c;
                if (th2 != null) {
                    Log.e("IN_APP_PURCHASE", "onBillingServiceDisconnected handler error: " + th2);
                }
                return lVar;
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                Throwable th3 = ((N) obj).f6144c;
                if (th3 != null) {
                    Log.e("IN_APP_PURCHASE", "onPurchaseUpdated handler error: " + th3);
                }
                return lVar;
            case 10:
                L1.a aVar = (L1.a) obj;
                A5.h.e(aVar, "_connection");
                L1.c cVarI = aVar.I("SELECT DISTINCT work_spec_id FROM SystemIdInfo");
                try {
                    ArrayList arrayList = new ArrayList();
                    while (cVarI.E()) {
                        arrayList.add(cVarI.m(0));
                    }
                    cVarI.close();
                    return arrayList;
                } catch (Throwable th4) {
                    cVarI.close();
                    throw th4;
                }
            case 11:
                L1.a aVar2 = (L1.a) obj;
                A5.h.e(aVar2, "_connection");
                L1.c cVarI2 = aVar2.I("DELETE FROM WorkProgress");
                try {
                    cVarI2.E();
                    return lVar;
                } finally {
                    cVarI2.close();
                }
            case 12:
                L1.a aVar3 = (L1.a) obj;
                A5.h.e(aVar3, "_connection");
                L1.c cVarI3 = aVar3.I("SELECT * FROM workspec WHERE state=0 AND schedule_requested_at<>-1");
                try {
                    int iQ = AbstractC0252u0.q(cVarI3, "id");
                    int iQ2 = AbstractC0252u0.q(cVarI3, "state");
                    int iQ3 = AbstractC0252u0.q(cVarI3, "worker_class_name");
                    int iQ4 = AbstractC0252u0.q(cVarI3, "input_merger_class_name");
                    int iQ5 = AbstractC0252u0.q(cVarI3, "input");
                    int iQ6 = AbstractC0252u0.q(cVarI3, "output");
                    int iQ7 = AbstractC0252u0.q(cVarI3, "initial_delay");
                    int iQ8 = AbstractC0252u0.q(cVarI3, "interval_duration");
                    int iQ9 = AbstractC0252u0.q(cVarI3, "flex_duration");
                    int iQ10 = AbstractC0252u0.q(cVarI3, "run_attempt_count");
                    int iQ11 = AbstractC0252u0.q(cVarI3, "backoff_policy");
                    int iQ12 = AbstractC0252u0.q(cVarI3, "backoff_delay_duration");
                    int iQ13 = AbstractC0252u0.q(cVarI3, "last_enqueue_time");
                    int iQ14 = AbstractC0252u0.q(cVarI3, "minimum_retention_duration");
                    int iQ15 = AbstractC0252u0.q(cVarI3, "schedule_requested_at");
                    int iQ16 = AbstractC0252u0.q(cVarI3, "run_in_foreground");
                    int iQ17 = AbstractC0252u0.q(cVarI3, "out_of_quota_policy");
                    int iQ18 = AbstractC0252u0.q(cVarI3, "period_count");
                    int iQ19 = AbstractC0252u0.q(cVarI3, "generation");
                    int iQ20 = AbstractC0252u0.q(cVarI3, "next_schedule_time_override");
                    int iQ21 = AbstractC0252u0.q(cVarI3, "next_schedule_time_override_generation");
                    int iQ22 = AbstractC0252u0.q(cVarI3, "stop_reason");
                    int iQ23 = AbstractC0252u0.q(cVarI3, "trace_tag");
                    int iQ24 = AbstractC0252u0.q(cVarI3, "backoff_on_system_interruptions");
                    int iQ25 = AbstractC0252u0.q(cVarI3, "required_network_type");
                    int iQ26 = AbstractC0252u0.q(cVarI3, "required_network_request");
                    int iQ27 = AbstractC0252u0.q(cVarI3, "requires_charging");
                    int iQ28 = AbstractC0252u0.q(cVarI3, "requires_device_idle");
                    int iQ29 = AbstractC0252u0.q(cVarI3, "requires_battery_not_low");
                    int iQ30 = AbstractC0252u0.q(cVarI3, "requires_storage_not_low");
                    int iQ31 = AbstractC0252u0.q(cVarI3, "trigger_content_update_delay");
                    int iQ32 = AbstractC0252u0.q(cVarI3, "trigger_max_content_delay");
                    int iQ33 = AbstractC0252u0.q(cVarI3, "content_uri_triggers");
                    ArrayList arrayList2 = new ArrayList();
                    while (cVarI3.E()) {
                        String strM = cVarI3.m(iQ);
                        int i7 = iQ14;
                        int i8 = iQ13;
                        F fD = G.D((int) cVarI3.getLong(iQ2));
                        String strM2 = cVarI3.m(iQ3);
                        String strM3 = cVarI3.m(iQ4);
                        byte[] blob = cVarI3.getBlob(iQ5);
                        p018d2.j jVar = p018d2.j.f5273b;
                        p018d2.j jVarF = android.support.v4.media.session.b.F(blob);
                        p018d2.j jVarF2 = android.support.v4.media.session.b.F(cVarI3.getBlob(iQ6));
                        long j6 = cVarI3.getLong(iQ7);
                        long j7 = cVarI3.getLong(iQ8);
                        long j8 = cVarI3.getLong(iQ9);
                        int i9 = (int) cVarI3.getLong(iQ10);
                        int i10 = iQ3;
                        int i11 = iQ2;
                        EnumC0288a enumC0288aA = G.A((int) cVarI3.getLong(iQ11));
                        long j9 = cVarI3.getLong(iQ12);
                        long j10 = cVarI3.getLong(i8);
                        long j11 = cVarI3.getLong(i7);
                        int i12 = iQ15;
                        long j12 = cVarI3.getLong(i12);
                        iQ15 = i12;
                        int i13 = iQ16;
                        int i14 = iQ;
                        boolean z7 = ((int) cVarI3.getLong(i13)) != 0;
                        int i15 = iQ4;
                        int i16 = iQ17;
                        E eC = G.C((int) cVarI3.getLong(i16));
                        iQ17 = i16;
                        int i17 = iQ18;
                        int i18 = (int) cVarI3.getLong(i17);
                        iQ18 = i17;
                        int i19 = iQ19;
                        int i20 = (int) cVarI3.getLong(i19);
                        int i21 = iQ20;
                        long j13 = cVarI3.getLong(i21);
                        int i22 = iQ21;
                        int i23 = (int) cVarI3.getLong(i22);
                        int i24 = iQ22;
                        int i25 = (int) cVarI3.getLong(i24);
                        int i26 = iQ23;
                        String strM4 = cVarI3.isNull(i26) ? null : cVarI3.m(i26);
                        int i27 = iQ24;
                        Integer numValueOf = cVarI3.isNull(i27) ? null : Integer.valueOf((int) cVarI3.getLong(i27));
                        if (numValueOf != null) {
                            boolValueOf = Boolean.valueOf(numValueOf.intValue() != 0);
                        } else {
                            boolValueOf = null;
                        }
                        int i28 = iQ25;
                        z zVarB = G.B((int) cVarI3.getLong(i28));
                        int i29 = iQ26;
                        p078m2.f fVarB0 = G.b0(cVarI3.getBlob(i29));
                        int i30 = iQ27;
                        boolean z8 = ((int) cVarI3.getLong(i30)) != 0;
                        int i31 = iQ28;
                        boolean z9 = ((int) cVarI3.getLong(i31)) != 0;
                        int i32 = iQ29;
                        boolean z10 = ((int) cVarI3.getLong(i32)) != 0;
                        iQ29 = i32;
                        int i33 = iQ30;
                        int i34 = iQ31;
                        int i35 = iQ32;
                        iQ31 = i34;
                        int i36 = iQ33;
                        iQ33 = i36;
                        arrayList2.add(new p(strM, fD, strM2, strM3, jVarF, jVarF2, j6, j7, j8, new C0292e(fVarB0, zVarB, z8, z9, z10, ((int) cVarI3.getLong(i33)) != 0, cVarI3.getLong(i34), cVarI3.getLong(i35), G.c(cVarI3.getBlob(i36))), i9, enumC0288aA, j9, j10, j11, j12, z7, eC, i18, i20, j13, i23, i25, strM4, boolValueOf));
                        iQ26 = i29;
                        iQ = i14;
                        iQ16 = i13;
                        iQ19 = i19;
                        iQ21 = i22;
                        iQ22 = i24;
                        iQ23 = i26;
                        iQ24 = i27;
                        iQ25 = i28;
                        iQ32 = i35;
                        iQ30 = i33;
                        iQ2 = i11;
                        iQ4 = i15;
                        iQ20 = i21;
                        iQ27 = i30;
                        iQ13 = i8;
                        iQ3 = i10;
                        iQ28 = i31;
                        iQ14 = i7;
                        break;
                    }
                    return arrayList2;
                } finally {
                    cVarI3.close();
                }
            case 13:
                L1.a aVar4 = (L1.a) obj;
                A5.h.e(aVar4, "_connection");
                L1.c cVarI4 = aVar4.I("SELECT * FROM workspec WHERE state=1");
                try {
                    int iQ34 = AbstractC0252u0.q(cVarI4, "id");
                    int iQ35 = AbstractC0252u0.q(cVarI4, "state");
                    int iQ36 = AbstractC0252u0.q(cVarI4, "worker_class_name");
                    int iQ37 = AbstractC0252u0.q(cVarI4, "input_merger_class_name");
                    int iQ38 = AbstractC0252u0.q(cVarI4, "input");
                    int iQ39 = AbstractC0252u0.q(cVarI4, "output");
                    int iQ40 = AbstractC0252u0.q(cVarI4, "initial_delay");
                    int iQ41 = AbstractC0252u0.q(cVarI4, "interval_duration");
                    int iQ42 = AbstractC0252u0.q(cVarI4, "flex_duration");
                    int iQ43 = AbstractC0252u0.q(cVarI4, "run_attempt_count");
                    int iQ44 = AbstractC0252u0.q(cVarI4, "backoff_policy");
                    int iQ45 = AbstractC0252u0.q(cVarI4, "backoff_delay_duration");
                    int iQ46 = AbstractC0252u0.q(cVarI4, "last_enqueue_time");
                    int iQ47 = AbstractC0252u0.q(cVarI4, "minimum_retention_duration");
                    int iQ48 = AbstractC0252u0.q(cVarI4, "schedule_requested_at");
                    int iQ49 = AbstractC0252u0.q(cVarI4, "run_in_foreground");
                    int iQ50 = AbstractC0252u0.q(cVarI4, "out_of_quota_policy");
                    int iQ51 = AbstractC0252u0.q(cVarI4, "period_count");
                    int iQ52 = AbstractC0252u0.q(cVarI4, "generation");
                    int iQ53 = AbstractC0252u0.q(cVarI4, "next_schedule_time_override");
                    int iQ54 = AbstractC0252u0.q(cVarI4, "next_schedule_time_override_generation");
                    int iQ55 = AbstractC0252u0.q(cVarI4, "stop_reason");
                    int iQ56 = AbstractC0252u0.q(cVarI4, "trace_tag");
                    int iQ57 = AbstractC0252u0.q(cVarI4, "backoff_on_system_interruptions");
                    int iQ58 = AbstractC0252u0.q(cVarI4, "required_network_type");
                    int iQ59 = AbstractC0252u0.q(cVarI4, "required_network_request");
                    int iQ60 = AbstractC0252u0.q(cVarI4, "requires_charging");
                    int iQ61 = AbstractC0252u0.q(cVarI4, "requires_device_idle");
                    int iQ62 = AbstractC0252u0.q(cVarI4, "requires_battery_not_low");
                    int iQ63 = AbstractC0252u0.q(cVarI4, "requires_storage_not_low");
                    int iQ64 = AbstractC0252u0.q(cVarI4, "trigger_content_update_delay");
                    int iQ65 = AbstractC0252u0.q(cVarI4, "trigger_max_content_delay");
                    int iQ66 = AbstractC0252u0.q(cVarI4, "content_uri_triggers");
                    ArrayList arrayList3 = new ArrayList();
                    while (cVarI4.E()) {
                        String strM5 = cVarI4.m(iQ34);
                        int i37 = iQ47;
                        int i38 = iQ46;
                        F fD2 = G.D((int) cVarI4.getLong(iQ35));
                        String strM6 = cVarI4.m(iQ36);
                        String strM7 = cVarI4.m(iQ37);
                        byte[] blob2 = cVarI4.getBlob(iQ38);
                        p018d2.j jVar2 = p018d2.j.f5273b;
                        p018d2.j jVarF3 = android.support.v4.media.session.b.F(blob2);
                        p018d2.j jVarF4 = android.support.v4.media.session.b.F(cVarI4.getBlob(iQ39));
                        long j14 = cVarI4.getLong(iQ40);
                        long j15 = cVarI4.getLong(iQ41);
                        long j16 = cVarI4.getLong(iQ42);
                        int i39 = (int) cVarI4.getLong(iQ43);
                        int i40 = iQ36;
                        int i41 = iQ35;
                        EnumC0288a enumC0288aA2 = G.A((int) cVarI4.getLong(iQ44));
                        long j17 = cVarI4.getLong(iQ45);
                        long j18 = cVarI4.getLong(i38);
                        long j19 = cVarI4.getLong(i37);
                        int i42 = iQ48;
                        long j20 = cVarI4.getLong(i42);
                        int i43 = iQ34;
                        int i44 = iQ49;
                        boolean z11 = ((int) cVarI4.getLong(i44)) != 0;
                        int i45 = iQ37;
                        int i46 = iQ50;
                        E eC2 = G.C((int) cVarI4.getLong(i46));
                        iQ49 = i44;
                        iQ50 = i46;
                        int i47 = iQ51;
                        int i48 = (int) cVarI4.getLong(i47);
                        iQ51 = i47;
                        int i49 = iQ52;
                        int i50 = (int) cVarI4.getLong(i49);
                        int i51 = iQ53;
                        long j21 = cVarI4.getLong(i51);
                        int i52 = iQ54;
                        int i53 = (int) cVarI4.getLong(i52);
                        iQ54 = i52;
                        iQ55 = iQ55;
                        int i54 = (int) cVarI4.getLong(iQ55);
                        iQ56 = iQ56;
                        String strM8 = cVarI4.isNull(iQ56) ? null : cVarI4.m(iQ56);
                        int i55 = iQ57;
                        Integer numValueOf2 = cVarI4.isNull(i55) ? null : Integer.valueOf((int) cVarI4.getLong(i55));
                        if (numValueOf2 != null) {
                            boolValueOf2 = Boolean.valueOf(numValueOf2.intValue() != 0);
                        } else {
                            boolValueOf2 = null;
                        }
                        int i56 = iQ58;
                        z zVarB2 = G.B((int) cVarI4.getLong(i56));
                        int i57 = iQ59;
                        p078m2.f fVarB1 = G.b0(cVarI4.getBlob(i57));
                        iQ57 = i55;
                        iQ58 = i56;
                        int i58 = iQ60;
                        boolean z12 = ((int) cVarI4.getLong(i58)) != 0;
                        int i59 = iQ61;
                        boolean z13 = ((int) cVarI4.getLong(i59)) != 0;
                        iQ60 = i58;
                        int i60 = iQ62;
                        boolean z14 = ((int) cVarI4.getLong(i60)) != 0;
                        iQ61 = i59;
                        iQ62 = i60;
                        int i61 = iQ63;
                        int i62 = iQ64;
                        int i63 = iQ65;
                        int i64 = iQ66;
                        iQ64 = i62;
                        arrayList3.add(new p(strM5, fD2, strM6, strM7, jVarF3, jVarF4, j14, j15, j16, new C0292e(fVarB1, zVarB2, z12, z13, z14, ((int) cVarI4.getLong(i61)) != 0, cVarI4.getLong(i62), cVarI4.getLong(i63), G.c(cVarI4.getBlob(i64))), i39, enumC0288aA2, j17, j18, j19, j20, z11, eC2, i48, i50, j21, i53, i54, strM8, boolValueOf2));
                        iQ65 = i63;
                        iQ63 = i61;
                        iQ66 = i64;
                        iQ37 = i45;
                        iQ52 = i49;
                        iQ53 = i51;
                        iQ47 = i37;
                        iQ35 = i41;
                        iQ36 = i40;
                        iQ59 = i57;
                        iQ34 = i43;
                        iQ48 = i42;
                        iQ46 = i38;
                        break;
                    }
                    return arrayList3;
                } finally {
                    cVarI4.close();
                }
            case 14:
                L1.a aVar5 = (L1.a) obj;
                A5.h.e(aVar5, "_connection");
                L1.c cVarI5 = aVar5.I("SELECT * FROM workspec WHERE state=0 AND schedule_requested_at=-1 AND LENGTH(content_uri_triggers)<>0 ORDER BY last_enqueue_time");
                try {
                    int iQ67 = AbstractC0252u0.q(cVarI5, "id");
                    int iQ68 = AbstractC0252u0.q(cVarI5, "state");
                    int iQ69 = AbstractC0252u0.q(cVarI5, "worker_class_name");
                    int iQ70 = AbstractC0252u0.q(cVarI5, "input_merger_class_name");
                    int iQ71 = AbstractC0252u0.q(cVarI5, "input");
                    int iQ72 = AbstractC0252u0.q(cVarI5, "output");
                    int iQ73 = AbstractC0252u0.q(cVarI5, "initial_delay");
                    int iQ74 = AbstractC0252u0.q(cVarI5, "interval_duration");
                    int iQ75 = AbstractC0252u0.q(cVarI5, "flex_duration");
                    int iQ76 = AbstractC0252u0.q(cVarI5, "run_attempt_count");
                    int iQ77 = AbstractC0252u0.q(cVarI5, "backoff_policy");
                    int iQ78 = AbstractC0252u0.q(cVarI5, "backoff_delay_duration");
                    int iQ79 = AbstractC0252u0.q(cVarI5, "last_enqueue_time");
                    int iQ80 = AbstractC0252u0.q(cVarI5, "minimum_retention_duration");
                    int iQ81 = AbstractC0252u0.q(cVarI5, "schedule_requested_at");
                    int iQ82 = AbstractC0252u0.q(cVarI5, "run_in_foreground");
                    int iQ83 = AbstractC0252u0.q(cVarI5, "out_of_quota_policy");
                    int iQ84 = AbstractC0252u0.q(cVarI5, "period_count");
                    int iQ85 = AbstractC0252u0.q(cVarI5, "generation");
                    int iQ86 = AbstractC0252u0.q(cVarI5, "next_schedule_time_override");
                    int iQ87 = AbstractC0252u0.q(cVarI5, "next_schedule_time_override_generation");
                    int iQ88 = AbstractC0252u0.q(cVarI5, "stop_reason");
                    int iQ89 = AbstractC0252u0.q(cVarI5, "trace_tag");
                    int iQ90 = AbstractC0252u0.q(cVarI5, "backoff_on_system_interruptions");
                    int iQ91 = AbstractC0252u0.q(cVarI5, "required_network_type");
                    int iQ92 = AbstractC0252u0.q(cVarI5, "required_network_request");
                    int iQ93 = AbstractC0252u0.q(cVarI5, "requires_charging");
                    int iQ94 = AbstractC0252u0.q(cVarI5, "requires_device_idle");
                    int iQ95 = AbstractC0252u0.q(cVarI5, "requires_battery_not_low");
                    int iQ96 = AbstractC0252u0.q(cVarI5, "requires_storage_not_low");
                    int iQ97 = AbstractC0252u0.q(cVarI5, "trigger_content_update_delay");
                    int iQ98 = AbstractC0252u0.q(cVarI5, "trigger_max_content_delay");
                    int iQ99 = AbstractC0252u0.q(cVarI5, "content_uri_triggers");
                    ArrayList arrayList4 = new ArrayList();
                    while (cVarI5.E()) {
                        String strM9 = cVarI5.m(iQ67);
                        int i65 = iQ80;
                        int i66 = iQ79;
                        F fD3 = G.D((int) cVarI5.getLong(iQ68));
                        String strM10 = cVarI5.m(iQ69);
                        String strM11 = cVarI5.m(iQ70);
                        byte[] blob3 = cVarI5.getBlob(iQ71);
                        p018d2.j jVar3 = p018d2.j.f5273b;
                        p018d2.j jVarF5 = android.support.v4.media.session.b.F(blob3);
                        p018d2.j jVarF6 = android.support.v4.media.session.b.F(cVarI5.getBlob(iQ72));
                        long j22 = cVarI5.getLong(iQ73);
                        long j23 = cVarI5.getLong(iQ74);
                        long j24 = cVarI5.getLong(iQ75);
                        int i67 = (int) cVarI5.getLong(iQ76);
                        int i68 = iQ69;
                        int i69 = iQ68;
                        EnumC0288a enumC0288aA3 = G.A((int) cVarI5.getLong(iQ77));
                        long j25 = cVarI5.getLong(iQ78);
                        long j26 = cVarI5.getLong(i66);
                        long j27 = cVarI5.getLong(i65);
                        int i70 = iQ81;
                        long j28 = cVarI5.getLong(i70);
                        int i71 = iQ67;
                        int i72 = iQ82;
                        boolean z15 = ((int) cVarI5.getLong(i72)) != 0;
                        int i73 = iQ70;
                        int i74 = iQ83;
                        E eC3 = G.C((int) cVarI5.getLong(i74));
                        iQ82 = i72;
                        iQ83 = i74;
                        int i75 = iQ84;
                        int i76 = (int) cVarI5.getLong(i75);
                        iQ84 = i75;
                        int i77 = iQ85;
                        int i78 = (int) cVarI5.getLong(i77);
                        int i79 = iQ86;
                        long j29 = cVarI5.getLong(i79);
                        int i80 = iQ87;
                        int i81 = (int) cVarI5.getLong(i80);
                        iQ87 = i80;
                        iQ88 = iQ88;
                        int i82 = (int) cVarI5.getLong(iQ88);
                        iQ89 = iQ89;
                        String strM12 = cVarI5.isNull(iQ89) ? null : cVarI5.m(iQ89);
                        int i83 = iQ90;
                        Integer numValueOf3 = cVarI5.isNull(i83) ? null : Integer.valueOf((int) cVarI5.getLong(i83));
                        if (numValueOf3 != null) {
                            boolValueOf3 = Boolean.valueOf(numValueOf3.intValue() != 0);
                        } else {
                            boolValueOf3 = null;
                        }
                        int i84 = iQ91;
                        z zVarB3 = G.B((int) cVarI5.getLong(i84));
                        int i85 = iQ92;
                        p078m2.f fVarB2 = G.b0(cVarI5.getBlob(i85));
                        iQ90 = i83;
                        iQ91 = i84;
                        int i86 = iQ93;
                        boolean z16 = ((int) cVarI5.getLong(i86)) != 0;
                        int i87 = iQ94;
                        boolean z17 = ((int) cVarI5.getLong(i87)) != 0;
                        iQ93 = i86;
                        int i88 = iQ95;
                        boolean z18 = ((int) cVarI5.getLong(i88)) != 0;
                        iQ94 = i87;
                        iQ95 = i88;
                        int i89 = iQ96;
                        int i90 = iQ97;
                        int i91 = iQ98;
                        int i92 = iQ99;
                        iQ97 = i90;
                        arrayList4.add(new p(strM9, fD3, strM10, strM11, jVarF5, jVarF6, j22, j23, j24, new C0292e(fVarB2, zVarB3, z16, z17, z18, ((int) cVarI5.getLong(i89)) != 0, cVarI5.getLong(i90), cVarI5.getLong(i91), G.c(cVarI5.getBlob(i92))), i67, enumC0288aA3, j25, j26, j27, j28, z15, eC3, i76, i78, j29, i81, i82, strM12, boolValueOf3));
                        iQ98 = i91;
                        iQ96 = i89;
                        iQ99 = i92;
                        iQ70 = i73;
                        iQ85 = i77;
                        iQ86 = i79;
                        iQ80 = i65;
                        iQ68 = i69;
                        iQ69 = i68;
                        iQ92 = i85;
                        iQ67 = i71;
                        iQ81 = i70;
                        iQ79 = i66;
                        break;
                    }
                    return arrayList4;
                } finally {
                    cVarI5.close();
                }
            case 15:
                L1.a aVar6 = (L1.a) obj;
                A5.h.e(aVar6, "_connection");
                L1.c cVarI6 = aVar6.I("Select COUNT(*) FROM workspec WHERE LENGTH(content_uri_triggers)<>0 AND state NOT IN (2, 3, 5)");
                try {
                    int i93 = cVarI6.E() ? (int) cVarI6.getLong(0) : 0;
                    cVarI6.close();
                    return Integer.valueOf(i93);
                } catch (Throwable th5) {
                    cVarI6.close();
                    throw th5;
                }
            case 16:
                L1.a aVar7 = (L1.a) obj;
                A5.h.e(aVar7, "_connection");
                L1.c cVarI7 = aVar7.I("SELECT COUNT(*) > 0 FROM workspec WHERE state NOT IN (2, 3, 5) LIMIT 1");
                try {
                    if (cVarI7.E()) {
                        z6 = ((int) cVarI7.getLong(0)) != 0;
                    } else {
                        z6 = false;
                    }
                    cVarI7.close();
                    return Boolean.valueOf(z6);
                } catch (Throwable th6) {
                    cVarI7.close();
                    throw th6;
                }
            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                return c(obj);
            default:
                L1.a aVar8 = (L1.a) obj;
                A5.h.e(aVar8, "_connection");
                L1.c cVarI8 = aVar8.I("UPDATE workspec SET schedule_requested_at=-1 WHERE state NOT IN (2, 3, 5)");
                try {
                    cVarI8.E();
                    return Integer.valueOf(android.support.v4.media.session.b.K(aVar8));
                } finally {
                    cVarI8.close();
                }
        }
    }

    public /* synthetic */ j(x xVar) {
        this.r = 1;
    }
}
