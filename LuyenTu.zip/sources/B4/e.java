package B4;

import C1.B;
import android.net.ConnectivityManager;
import androidx.work.impl.WorkDatabase;
import java.util.LinkedHashMap;
import java.util.UUID;
import java.util.concurrent.Executor;
import p018d2.y;
import p025e2.AbstractC0303g;
import p025e2.t;
import p044h2.p;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class e implements p154z5.a {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ Object f353s;
    public final /* synthetic */ Object t;

    public /* synthetic */ e(Object obj, Object obj2, int i6) {
        this.r = i6;
        this.f353s = obj;
        this.t = obj2;
    }

    @Override // p154z5.a
    public final Object b() {
        switch (this.r) {
            case 0:
                A5.m mVar = (A5.m) this.f353s;
                o oVar = (o) this.t;
                if (!mVar.r) {
                    mVar.r = true;
                    oVar.b();
                }
                return p074l5.l.f7746a;
            case 1:
                ((p154z5.c) this.f353s).a(((A5.n) this.t).r);
                break;
            case 2:
                ((Executor) this.f353s).execute(new Q.b((L.d) this.t, 7));
                break;
            case 3:
                S.c cVar = (S.c) this.f353s;
                cVar.d().execute(new B(cVar, (L.l) this.t, 20));
                break;
            case 4:
                U.b bVar = (U.b) this.f353s;
                bVar.e().execute(new B(bVar, (L.l) this.t, 24));
                break;
            case 5:
                L5.c cVar2 = (L5.c) this.f353s;
                ConnectivityManager connectivityManager = (ConnectivityManager) this.t;
                synchronized (p044h2.k.f6014b) {
                    LinkedHashMap linkedHashMap = p044h2.k.f6015c;
                    linkedHashMap.remove(cVar2);
                    if (linkedHashMap.isEmpty()) {
                        y.e().a(p.f6026a, "NetworkRequestConstraintController unregister shared callback");
                        connectivityManager.unregisterNetworkCallback(p044h2.k.f6013a);
                        p044h2.k.f6018f = null;
                        p044h2.k.f6016d = null;
                        p044h2.k.f6017e = false;
                    }
                    break;
                }
                break;
            case 6:
                p051i2.c cVar3 = (p051i2.c) this.f353s;
                p051i2.a aVar = (p051i2.a) this.t;
                p058j2.e eVar = cVar3.f6267a;
                eVar.getClass();
                synchronized (eVar.f7101c) {
                    if (eVar.f7102d.remove(aVar) && eVar.f7102d.isEmpty()) {
                        eVar.d();
                    }
                    break;
                }
                break;
            default:
                t tVar = (t) this.f353s;
                UUID uuid = (UUID) this.t;
                WorkDatabase workDatabase = tVar.f5480c;
                A5.h.d(workDatabase, "getWorkDatabase(...)");
                workDatabase.b();
                try {
                    String string = uuid.toString();
                    A5.h.d(string, "toString(...)");
                    p078m2.g.a(tVar, string);
                    workDatabase.o();
                    workDatabase.f();
                    AbstractC0303g.b(tVar.f5479b, tVar.f5480c, tVar.f5482e);
                } catch (Throwable th) {
                    workDatabase.f();
                    throw th;
                }
                break;
        }
        return p074l5.l.f7746a;
    }
}
