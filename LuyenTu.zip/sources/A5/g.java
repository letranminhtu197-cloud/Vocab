package A5;

import com.google.crypto.tink.shaded.protobuf.T;

/* JADX INFO: loaded from: classes.dex */
public abstract class g extends c implements f, G5.a, p074l5.a {

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final int f187x;
    public final int y;

    public g(int i6, Class cls, String str, String str2, int i7) {
        this(i6, b.r, cls, str, str2, i7, 0);
    }

    @Override // A5.c
    public final G5.a c() {
        o.f191a.getClass();
        return this;
    }

    @Override // A5.f
    public final int d() {
        return this.f187x;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof g) {
            g gVar = (g) obj;
            return this.f182u.equals(gVar.f182u) && this.f183v.equals(gVar.f183v) && this.y == gVar.y && this.f187x == gVar.f187x && h.a(this.f181s, gVar.f181s) && e().equals(gVar.e());
        }
        if (!(obj instanceof g)) {
            return false;
        }
        G5.a aVar = this.r;
        if (aVar == null) {
            c();
            this.r = this;
            aVar = this;
        }
        return obj.equals(aVar);
    }

    public final int hashCode() {
        e();
        return this.f183v.hashCode() + T.w(e().hashCode() * 31, 31, this.f182u);
    }

    public final String toString() {
        G5.a aVar = this.r;
        if (aVar == null) {
            c();
            this.r = this;
            aVar = this;
        }
        if (aVar != this) {
            return aVar.toString();
        }
        String str = this.f182u;
        return "<init>".equals(str) ? "constructor (Kotlin reflection is not available)" : T.j("function ", str, " (Kotlin reflection is not available)");
    }

    public g(int i6, Object obj, Class cls, String str, String str2, int i7, int i8) {
        super(obj, cls, str, str2, (i7 & 1) == 1);
        this.f187x = i6;
        this.y = 0;
    }
}
