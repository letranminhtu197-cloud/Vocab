package A5;

import K5.C0119x;

/* JADX INFO: loaded from: classes.dex */
public final class k extends l implements G5.c, p154z5.e {
    @Override // A5.c
    public final G5.a c() {
        o.f191a.getClass();
        return this;
    }

    @Override // p154z5.e
    public final Object g(Object obj, Object obj2) {
        i();
        throw null;
    }

    public final void i() {
        if (this.f190x) {
            throw new UnsupportedOperationException("Kotlin reflection is not yet supported for synthetic Java properties. Please follow/upvote https://youtrack.jetbrains.com/issue/KT-55980");
        }
        G5.a aVarH = h();
        if (aVarH == this) {
            throw new C0119x("Kotlin reflection implementation is not found at runtime. Make sure you have kotlin-reflect.jar in the classpath");
        }
        ((k) ((G5.c) aVarH)).i();
    }
}
