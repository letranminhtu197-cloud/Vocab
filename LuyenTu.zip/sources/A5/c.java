package A5;

import java.io.Serializable;

/* JADX INFO: loaded from: classes.dex */
public abstract class c implements G5.a, Serializable {
    public transient G5.a r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final Object f181s;
    public final Class t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final String f182u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final String f183v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final boolean f184w;

    public c(Object obj, Class cls, String str, String str2, boolean z6) {
        this.f181s = obj;
        this.t = cls;
        this.f182u = str;
        this.f183v = str2;
        this.f184w = z6;
    }

    public abstract G5.a c();

    public final d e() {
        boolean z6 = this.f184w;
        Class cls = this.t;
        if (!z6) {
            return o.a(cls);
        }
        o.f191a.getClass();
        return new j(cls);
    }
}
