package A5;

/* JADX INFO: loaded from: classes.dex */
public final class j implements d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Class f189a;

    public j(Class cls) {
        this.f189a = cls;
    }

    @Override // A5.d
    public final Class a() {
        return this.f189a;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof j) {
            return h.a(this.f189a, ((j) obj).f189a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f189a.hashCode();
    }

    public final String toString() {
        return this.f189a.toString() + " (Kotlin reflection is not available)";
    }
}
