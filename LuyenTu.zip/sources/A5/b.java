package A5;

import java.io.Serializable;

/* JADX INFO: loaded from: classes.dex */
public final class b implements Serializable {
    public static final b r = new b();
}
