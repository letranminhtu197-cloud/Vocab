package A5;

/* JADX INFO: loaded from: classes.dex */
public interface f extends p074l5.a {
    int d();
}
