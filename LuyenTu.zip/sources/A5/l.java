package A5;

import com.google.crypto.tink.shaded.protobuf.T;

/* JADX INFO: loaded from: classes.dex */
public abstract class l extends c implements G5.c {

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final boolean f190x;

    public l(Object obj, Class cls, String str, String str2, int i6) {
        super(obj, cls, str, str2, (i6 & 1) == 1);
        this.f190x = false;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof l) {
            l lVar = (l) obj;
            return e().equals(lVar.e()) && this.f182u.equals(lVar.f182u) && this.f183v.equals(lVar.f183v) && h.a(this.f181s, lVar.f181s);
        }
        if (obj instanceof G5.c) {
            return obj.equals(h());
        }
        return false;
    }

    public final G5.a h() {
        if (this.f190x) {
            return this;
        }
        G5.a aVar = this.r;
        if (aVar != null) {
            return aVar;
        }
        G5.a aVarC = c();
        this.r = aVarC;
        return aVarC;
    }

    public final int hashCode() {
        return this.f183v.hashCode() + T.w(e().hashCode() * 31, 31, this.f182u);
    }

    public final String toString() {
        G5.a aVarH = h();
        return aVarH != this ? aVarH.toString() : T.m(new StringBuilder("property "), this.f182u, " (Kotlin reflection is not available)");
    }
}
