package A5;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* JADX INFO: loaded from: classes.dex */
public final class a implements Iterator, B5.a {
    public final Object[] r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f180s;

    public a(Object[] objArr) {
        this.r = objArr;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f180s < this.r.length;
    }

    @Override // java.util.Iterator
    public final Object next() {
        try {
            Object[] objArr = this.r;
            int i6 = this.f180s;
            this.f180s = i6 + 1;
            return objArr[i6];
        } catch (ArrayIndexOutOfBoundsException e6) {
            this.f180s--;
            throw new NoSuchElementException(e6.getMessage());
        }
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
