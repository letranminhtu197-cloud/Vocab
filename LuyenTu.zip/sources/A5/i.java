package A5;

import java.io.Serializable;

/* JADX INFO: loaded from: classes.dex */
public abstract class i implements f, Serializable {
    public final int r;

    public i(int i6) {
        this.r = i6;
    }

    @Override // A5.f
    public final int d() {
        return this.r;
    }

    public final String toString() {
        o.f191a.getClass();
        String strA = p.a(this);
        h.d(strA, "renderLambdaToString(...)");
        return strA;
    }
}
