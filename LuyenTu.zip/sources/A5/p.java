package A5;

/* JADX INFO: loaded from: classes.dex */
public final class p {
    public static String a(f fVar) {
        String string = fVar.getClass().getGenericInterfaces()[0].toString();
        return string.startsWith("kotlin.jvm.functions.") ? string.substring(21) : string;
    }
}
