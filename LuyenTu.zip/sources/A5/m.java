package A5;

import java.io.Serializable;

/* JADX INFO: loaded from: classes.dex */
public final class m implements Serializable {
    public boolean r;

    public final String toString() {
        return String.valueOf(this.r);
    }
}
