package A5;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import p018d2.G;
import p081m5.r;

/* JADX INFO: loaded from: classes.dex */
public final class e implements G5.b, d {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Map f185b;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Class f186a;

    static {
        List listK = p081m5.e.K(new Class[]{p154z5.a.class, p154z5.c.class, p154z5.e.class, p154z5.f.class, p154z5.g.class, p110s.a.class, p154z5.h.class, p110s.a.class, p110s.a.class, p110s.a.class, p110s.a.class, p110s.a.class, p154z5.b.class, p110s.a.class, p110s.a.class, p110s.a.class, p110s.a.class, p110s.a.class, p110s.a.class, p110s.a.class, p110s.a.class, p110s.a.class, p154z5.d.class});
        ArrayList arrayList = new ArrayList(p081m5.g.x0(listK));
        int i6 = 0;
        for (Object obj : listK) {
            int i7 = i6 + 1;
            if (i6 < 0) {
                G.Z();
                throw null;
            }
            arrayList.add(new p074l5.g((Class) obj, Integer.valueOf(i6)));
            i6 = i7;
        }
        f185b = r.b0(arrayList);
    }

    public e(Class cls) {
        h.e(cls, "jClass");
        this.f186a = cls;
    }

    @Override // A5.d
    public final Class a() {
        return this.f186a;
    }

    public final String b() {
        String strB;
        Class cls = this.f186a;
        h.e(cls, "jClass");
        String strConcat = null;
        if (cls.isAnonymousClass() || cls.isLocalClass()) {
            return null;
        }
        if (!cls.isArray()) {
            String strB2 = q.b(cls.getName());
            return strB2 == null ? cls.getCanonicalName() : strB2;
        }
        Class<?> componentType = cls.getComponentType();
        if (componentType.isPrimitive() && (strB = q.b(componentType.getName())) != null) {
            strConcat = strB.concat("Array");
        }
        return strConcat == null ? "kotlin.Array" : strConcat;
    }

    public final String c() {
        String strD;
        Class cls = this.f186a;
        h.e(cls, "jClass");
        String strConcat = null;
        if (cls.isAnonymousClass()) {
            return null;
        }
        if (!cls.isLocalClass()) {
            if (!cls.isArray()) {
                String strD2 = q.d(cls.getName());
                return strD2 == null ? cls.getSimpleName() : strD2;
            }
            Class<?> componentType = cls.getComponentType();
            if (componentType.isPrimitive() && (strD = q.d(componentType.getName())) != null) {
                strConcat = strD.concat("Array");
            }
            return strConcat == null ? "Array" : strConcat;
        }
        String simpleName = cls.getSimpleName();
        Method enclosingMethod = cls.getEnclosingMethod();
        if (enclosingMethod != null) {
            return I5.d.E0(simpleName, enclosingMethod.getName() + '$');
        }
        Constructor<?> enclosingConstructor = cls.getEnclosingConstructor();
        if (enclosingConstructor != null) {
            return I5.d.E0(simpleName, enclosingConstructor.getName() + '$');
        }
        int iIndexOf = simpleName.indexOf(36, 0);
        if (iIndexOf == -1) {
            return simpleName;
        }
        String strSubstring = simpleName.substring(iIndexOf + 1, simpleName.length());
        h.d(strSubstring, "substring(...)");
        return strSubstring;
    }

    public final boolean d(Object obj) {
        Class clsC = this.f186a;
        h.e(clsC, "jClass");
        Map map = f185b;
        h.c(map, "null cannot be cast to non-null type kotlin.collections.Map<K of kotlin.collections.MapsKt__MapsKt.get, V of kotlin.collections.MapsKt__MapsKt.get>");
        Integer num = (Integer) map.get(clsC);
        if (num != null) {
            return q.c(num.intValue(), obj);
        }
        if (clsC.isPrimitive()) {
            clsC = X2.a.C(o.a(clsC));
        }
        return clsC.isInstance(obj);
    }

    public final boolean equals(Object obj) {
        return (obj instanceof e) && X2.a.C(this).equals(X2.a.C((G5.b) obj));
    }

    public final int hashCode() {
        return X2.a.C(this).hashCode();
    }

    public final String toString() {
        return this.f186a.toString() + " (Kotlin reflection is not available)";
    }
}
