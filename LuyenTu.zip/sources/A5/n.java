package A5;

import java.io.Serializable;

/* JADX INFO: loaded from: classes.dex */
public final class n implements Serializable {
    public Object r;

    public final String toString() {
        return String.valueOf(this.r);
    }
}
