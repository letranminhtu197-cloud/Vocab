package A4;

import java.security.spec.AlgorithmParameterSpec;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;

/* JADX INFO: loaded from: classes.dex */
public final class f extends d {
    @Override // A4.d
    public final String D() {
        return "VGhpcyBpcyB0aGUga2V5IGZvcihBIHNlY3XyZZBzdG9yYWdlIEFFUyBLZXkK";
    }

    @Override // A4.d
    public final Cipher E() {
        return Cipher.getInstance("AES/GCM/NoPadding");
    }

    @Override // A4.d
    public final int G() {
        return 12;
    }

    @Override // A4.d
    public final AlgorithmParameterSpec H(byte[] bArr) {
        return new GCMParameterSpec(128, bArr);
    }
}
