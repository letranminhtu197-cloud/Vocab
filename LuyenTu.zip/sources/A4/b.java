package A4;

import A5.h;
import C1.C0018t;
import E0.l;
import E0.p;
import G0.C0021b;
import G0.j;
import J0.X;
import L4.u;
import L4.v;
import L4.w;
import M2.g;
import M4.i;
import N0.q;
import R0.m;
import W4.n;
import W4.o;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.media.MediaCodec;
import android.net.Uri;
import android.os.Bundle;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Messenger;
import android.os.RemoteException;
import android.os.Trace;
import android.security.keystore.KeyGenParameterSpec;
import android.util.Log;
import android.util.LongSparseArray;
import android.util.SparseIntArray;
import android.view.KeyEvent;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.internal.BasePendingResult;
import com.google.crypto.tink.shaded.protobuf.T;
import com.luyentu.mobile.R;
import dev.fluttercommunity.plus.share.SharePlusPendingIntent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.math.BigInteger;
import java.nio.channels.FileChannel;
import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.ProviderException;
import java.security.cert.CertificateException;
import java.security.spec.AlgorithmParameterSpec;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.PriorityQueue;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.security.auth.x500.X500Principal;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.utils.StringUtils;
import org.apache.tika.utils.XMLReaderUtils;
import p018d2.G;
import p101q0.C;
import p101q0.C0427o;
import p117t0.s;

/* JADX INFO: loaded from: classes.dex */
public class b implements L1.b, p146y2.b, p, j, q, o, w, p091o3.a, p091o3.d {

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static b f173u;
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public Object f174s;
    public Object t;

    public /* synthetic */ b(Object obj, Object obj2, int i6) {
        this.r = i6;
        this.f174s = obj;
        this.t = obj2;
    }

    public Key A(byte[] bArr) throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        String str = (String) this.f174s;
        Key key = keyStore.getKey(str, null);
        if (key == null) {
            throw new Exception(T.x("No key found under alias: ", str));
        }
        if (!(key instanceof PrivateKey)) {
            throw new Exception("Not an instance of a PrivateKey");
        }
        Cipher cipherO = o();
        cipherO.init(4, (PrivateKey) key, m());
        return cipherO.unwrap(bArr, "AES", 3);
    }

    public void B(boolean z6, Status status) {
        HashMap map;
        HashMap map2;
        synchronized (((Map) this.f174s)) {
            map = new HashMap((Map) this.f174s);
        }
        synchronized (((Map) this.t)) {
            map2 = new HashMap((Map) this.t);
        }
        for (Map.Entry entry : map.entrySet()) {
            if (z6 || ((Boolean) entry.getValue()).booleanValue()) {
                ((BasePendingResult) entry.getKey()).h0(status);
            }
        }
        for (Map.Entry entry2 : map2.entrySet()) {
            if (z6 || ((Boolean) entry2.getValue()).booleanValue()) {
                ((p091o3.j) entry2.getKey()).c(new O2.e(status));
            }
        }
    }

    @Override // L4.w
    public void a(KeyEvent keyEvent, K0.d dVar) {
        int action = keyEvent.getAction();
        if (action != 0 && action != 1) {
            dVar.c(false);
            return;
        }
        Character chA = ((v) this.t).a(keyEvent.getUnicodeChar());
        boolean z6 = action != 0;
        i iVar = (i) this.f174s;
        B4.b bVar = new B4.b(dVar, 7);
        p053i4.v vVar = (p053i4.v) iVar.f2508s;
        HashMap map = new HashMap();
        map.put("type", z6 ? "keyup" : "keydown");
        map.put("keymap", "android");
        map.put("flags", Integer.valueOf(keyEvent.getFlags()));
        map.put("plainCodePoint", Integer.valueOf(keyEvent.getUnicodeChar(0)));
        map.put("codePoint", Integer.valueOf(keyEvent.getUnicodeChar()));
        map.put("keyCode", Integer.valueOf(keyEvent.getKeyCode()));
        map.put("scanCode", Integer.valueOf(keyEvent.getScanCode()));
        map.put("metaState", Integer.valueOf(keyEvent.getMetaState()));
        map.put("character", chA.toString());
        map.put(ClimateForcast.SOURCE, Integer.valueOf(keyEvent.getSource()));
        map.put("deviceId", Integer.valueOf(keyEvent.getDeviceId()));
        map.put("repeatCount", Integer.valueOf(keyEvent.getRepeatCount()));
        vVar.O(map, new B4.b(bVar, 14));
    }

    public void b(Object obj, String str) {
        int length = str.length();
        String strValueOf = String.valueOf(obj);
        StringBuilder sb = new StringBuilder(length + 1 + strValueOf.length());
        sb.append(str);
        sb.append("=");
        sb.append(strValueOf);
        ((ArrayList) this.f174s).add(sb.toString());
    }

    @Override // E0.p
    public q c(l lVar, E0.i iVar) {
        return new b(((p) this.f174s).c(lVar, iVar), (List) this.t, 10);
    }

    @Override // L1.b
    public L1.a d(String str) {
        FileChannel fileChannel;
        FileChannel fileChannel2;
        h.e(str, "fileName");
        C0018t c0018t = (C0018t) this.t;
        if (!str.equals(":memory:")) {
            str = c0018t.f510c.f462a.getDatabasePath(str).getAbsolutePath();
            h.b(str);
        }
        boolean z6 = true;
        D1.a aVar = new D1.a(str, (c0018t.f508a || c0018t.f509b || str.equals(":memory:")) ? false : true);
        ReentrantLock reentrantLock = aVar.f787a;
        reentrantLock.lock();
        b bVar = aVar.f788b;
        if (bVar != null) {
            try {
                bVar.r();
            } catch (Throwable th) {
                th = th;
                z6 = false;
            }
        }
        try {
            try {
                if (c0018t.f509b) {
                    throw new IllegalStateException("Recursive database initialization detected. Did you try to use the database instance during initialization? Maybe in one of the callbacks?");
                }
                L1.a aVarD = ((L1.b) this.f174s).d(str);
                if (c0018t.f508a) {
                    if (c0018t.f510c.f468g == C1.v.t) {
                        G.v(aVarD, "PRAGMA synchronous = NORMAL");
                    } else {
                        G.v(aVarD, "PRAGMA synchronous = FULL");
                    }
                    C0018t.b(aVarD);
                    c0018t.f511d.d(aVarD);
                } else {
                    try {
                        c0018t.f509b = true;
                        C0018t.a(c0018t, aVarD);
                        c0018t.f509b = false;
                    } catch (Throwable th2) {
                        c0018t.f509b = false;
                        throw th2;
                    }
                }
                if (bVar != null && (fileChannel2 = (FileChannel) bVar.t) != null) {
                    try {
                        fileChannel2.close();
                        bVar.t = null;
                    } catch (Throwable th3) {
                        bVar.t = null;
                        throw th3;
                    }
                }
                reentrantLock.unlock();
                return aVarD;
            } catch (Throwable th4) {
                th = th4;
            }
        } catch (Throwable th5) {
            if (bVar != null && (fileChannel = (FileChannel) bVar.t) != null) {
                try {
                    fileChannel.close();
                } finally {
                    bVar.t = null;
                }
            }
            throw th5;
        }
        th = th4;
        try {
            if (z6) {
                throw th;
            }
            throw new IllegalStateException("Unable to open database '" + str + "'. Was a proper path / name used in Room's database builder?", th);
        } catch (Throwable th6) {
            reentrantLock.unlock();
            throw th6;
        }
    }

    public boolean e() {
        synchronized (this) {
            if (((AtomicBoolean) this.t).get()) {
                return false;
            }
            ((AtomicInteger) this.f174s).incrementAndGet();
            return true;
        }
    }

    @Override // p091o3.a
    public Object f(p091o3.i iVar) {
        Bundle bundle;
        M2.b bVar = (M2.b) this.f174s;
        Bundle bundle2 = (Bundle) this.t;
        bVar.getClass();
        return (iVar.h() && (bundle = (Bundle) iVar.f()) != null && bundle.containsKey("google.messenger")) ? bVar.a(bundle2).m(M2.h.t, M2.d.f2436u) : iVar;
    }

    @Override // N0.q
    public Object g(Uri uri, p128v0.j jVar) {
        I0.a aVar = (I0.a) ((q) this.f174s).g(uri, jVar);
        List list = (List) this.t;
        return (list == null || list.isEmpty()) ? aVar : (I0.a) aVar.a(list);
    }

    @Override // p067k5.a
    public Object get() {
        Z3.e eVar = new Z3.e(15);
        Z3.e eVar2 = new Z3.e(14);
        Object obj = ((p067k5.a) this.f174s).get();
        p067k5.a aVar = (p067k5.a) this.t;
        return new D2.h(eVar, eVar2, D2.a.f789f, (D2.j) obj, aVar);
    }

    @Override // E0.p
    public q i() {
        return new b(((p) this.f174s).i(), (List) this.t, 10);
    }

    public K1.d j() {
        KeyGenParameterSpec keyGenParameterSpec = (KeyGenParameterSpec) this.t;
        if (keyGenParameterSpec == null) {
            throw new IllegalArgumentException("build() called before setKeyGenParameterSpec or setKeyScheme.");
        }
        Object obj = K1.e.f2057a;
        if (keyGenParameterSpec.getKeySize() != 256) {
            throw new IllegalArgumentException("invalid key size, want 256 bits got " + keyGenParameterSpec.getKeySize() + " bits");
        }
        if (!Arrays.equals(keyGenParameterSpec.getBlockModes(), new String[]{"GCM"})) {
            throw new IllegalArgumentException("invalid block mode, want GCM got " + Arrays.toString(keyGenParameterSpec.getBlockModes()));
        }
        if (keyGenParameterSpec.getPurposes() != 3) {
            throw new IllegalArgumentException("invalid purposes mode, want PURPOSE_ENCRYPT | PURPOSE_DECRYPT got " + keyGenParameterSpec.getPurposes());
        }
        if (!Arrays.equals(keyGenParameterSpec.getEncryptionPaddings(), new String[]{"NoPadding"})) {
            throw new IllegalArgumentException("invalid padding mode, want NoPadding got " + Arrays.toString(keyGenParameterSpec.getEncryptionPaddings()));
        }
        if (keyGenParameterSpec.isUserAuthenticationRequired() && keyGenParameterSpec.getUserAuthenticationValidityDurationSeconds() < 1) {
            throw new IllegalArgumentException("per-operation authentication is not supported (UserAuthenticationValidityDurationSeconds must be >0)");
        }
        synchronized (K1.e.f2057a) {
            String keystoreAlias = keyGenParameterSpec.getKeystoreAlias();
            KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
            keyStore.load(null);
            if (!keyStore.containsAlias(keystoreAlias)) {
                try {
                    KeyGenerator keyGenerator = KeyGenerator.getInstance("AES", "AndroidKeyStore");
                    keyGenerator.init(keyGenParameterSpec);
                    keyGenerator.generateKey();
                } catch (ProviderException e6) {
                    throw new GeneralSecurityException(e6.getMessage(), e6);
                }
            }
        }
        return new K1.d(keyGenParameterSpec.getKeystoreAlias(), (KeyGenParameterSpec) this.t);
    }

    @Override // G0.j
    /* JADX INFO: renamed from: k, reason: merged with bridge method [inline-methods] */
    public G0.c h(G0.i iVar) throws Exception {
        MediaCodec mediaCodecCreateByCodecName;
        G0.l iVar2;
        int i6;
        String str = iVar.f1329a.f1334a;
        G0.c cVar = null;
        try {
            Trace.beginSection("createCodec:" + str);
            mediaCodecCreateByCodecName = MediaCodec.createByCodecName(str);
            try {
                C0427o c0427o = iVar.f1331c;
                int i7 = s.f9002a;
                if (i7 >= 34 && (i7 >= 35 || C.k(c0427o.f8396m))) {
                    iVar2 = new i(mediaCodecCreateByCodecName, 5);
                    i6 = 4;
                } else {
                    iVar2 = new G0.f(mediaCodecCreateByCodecName, (HandlerThread) ((C0021b) this.t).get());
                    i6 = 0;
                }
                G0.c cVar2 = new G0.c(mediaCodecCreateByCodecName, (HandlerThread) ((C0021b) this.f174s).get(), iVar2);
                try {
                    Trace.endSection();
                    G0.c.g(cVar2, iVar.f1330b, iVar.f1332d, iVar.f1333e, i6);
                    return cVar2;
                } catch (Exception e6) {
                    e = e6;
                    cVar = cVar2;
                    if (cVar != null) {
                        cVar.release();
                    } else if (mediaCodecCreateByCodecName != null) {
                        mediaCodecCreateByCodecName.release();
                    }
                    throw e;
                }
            } catch (Exception e7) {
                e = e7;
            }
        } catch (Exception e8) {
            e = e8;
            mediaCodecCreateByCodecName = null;
        }
    }

    public String l() {
        return ((Context) this.t).getPackageName() + ".FlutterSecureStoragePluginKey";
    }

    public AlgorithmParameterSpec m() {
        return null;
    }

    public R0.p n(Object... objArr) {
        Constructor constructorB;
        synchronized (((AtomicBoolean) this.t)) {
            if (!((AtomicBoolean) this.t).get()) {
                try {
                    constructorB = ((m) this.f174s).b();
                } catch (ClassNotFoundException unused) {
                    ((AtomicBoolean) this.t).set(true);
                    constructorB = null;
                } catch (Exception e6) {
                    throw new RuntimeException("Error instantiating extension", e6);
                }
            }
            constructorB = null;
        }
        if (constructorB == null) {
            return null;
        }
        try {
            return (R0.p) constructorB.newInstance(objArr);
        } catch (Exception e7) {
            throw new IllegalStateException("Unexpected error creating extractor", e7);
        }
    }

    public Cipher o() {
        return Cipher.getInstance("RSA/ECB/PKCS1Padding", "AndroidKeyStoreBCWorkaround");
    }

    @Override // W4.o
    public void onMethodCall(n nVar, W4.p pVar) {
        V4.h hVar;
        switch (this.r) {
            case 11:
                I4.b bVar = (I4.b) this.t;
                h.e(nVar, "call");
                Object obj = nVar.f3730b;
                if (!(obj instanceof Map)) {
                    throw new IllegalArgumentException("Map arguments expected");
                }
                bVar.getClass();
                AtomicBoolean atomicBoolean = bVar.f1644s;
                if (!atomicBoolean.compareAndSet(true, false) && (hVar = bVar.r) != null) {
                    hVar.a("dev.fluttercommunity.plus/share/unavailable");
                }
                SharePlusPendingIntent.f5382a = StringUtils.EMPTY;
                atomicBoolean.set(false);
                bVar.r = (V4.h) pVar;
                try {
                    if (!h.a(nVar.f3729a, "share")) {
                        ((V4.h) pVar).b();
                        return;
                    }
                    B2.d dVar = (B2.d) this.f174s;
                    h.b(obj);
                    dVar.k((Map) obj);
                    return;
                } catch (Throwable th) {
                    bVar.f1644s.set(true);
                    bVar.r = null;
                    ((V4.h) pVar).c("Share failed", th.getMessage(), th);
                    return;
                }
            default:
                A0.i iVar = (A0.i) this.t;
                if (((d) iVar.f64s) == null) {
                    ((V4.h) pVar).a((Map) this.f174s);
                    return;
                }
                String str = nVar.f3729a;
                str.getClass();
                if (!str.equals("getKeyboardState")) {
                    ((V4.h) pVar).b();
                    return;
                }
                try {
                    this.f174s = Collections.unmodifiableMap(((u) ((w[]) ((d) iVar.f64s).f176s)[0]).f2309s);
                    break;
                } catch (IllegalStateException e6) {
                    ((V4.h) pVar).c("error", e6.getMessage(), null);
                }
                ((V4.h) pVar).a((Map) this.f174s);
                return;
        }
    }

    @Override // p091o3.d
    public void p(p091o3.i iVar) {
        ((Map) ((b) this.t).t).remove((p091o3.j) this.f174s);
    }

    public String q(String str) {
        String str2 = (String) this.f174s;
        Resources resources = (Resources) this.t;
        int identifier = resources.getIdentifier(str, "string", str2);
        if (identifier == 0) {
            return null;
        }
        return resources.getString(identifier);
    }

    public void r() throws IOException {
        String str = (String) this.f174s;
        if (((FileChannel) this.t) != null) {
            return;
        }
        try {
            File file = new File(str);
            File parentFile = file.getParentFile();
            if (parentFile != null) {
                parentFile.mkdirs();
            }
            FileChannel channel = new FileOutputStream(file).getChannel();
            this.t = channel;
            if (channel != null) {
                channel.lock();
            }
        } catch (Throwable th) {
            FileChannel fileChannel = (FileChannel) this.t;
            if (fileChannel != null) {
                fileChannel.close();
            }
            this.t = null;
            throw new IllegalStateException(T.j("Unable to lock file: '", str, "'."), th);
        }
    }

    public KeyGenParameterSpec s(Calendar calendar, Calendar calendar2) {
        String str = (String) this.f174s;
        return new KeyGenParameterSpec.Builder(str, 3).setCertificateSubject(new X500Principal(T.x("CN=", str))).setDigests("SHA-256").setBlockModes("ECB").setEncryptionPaddings("PKCS1Padding").setCertificateSerialNumber(BigInteger.valueOf(1L)).setCertificateNotBefore(calendar.getTime()).setCertificateNotAfter(calendar2.getTime()).build();
    }

    public void t(E.h hVar) {
        D.c cVar = (D.c) this.t;
        K2.i iVar = (K2.i) this.f174s;
        int i6 = hVar.f886b;
        if (i6 == 0) {
            cVar.execute(new E.a(iVar, hVar.f885a, 0));
        } else {
            cVar.execute(new E.b(iVar, i6));
        }
    }

    public String toString() {
        switch (this.r) {
            case 22:
                StringBuilder sb = new StringBuilder(100);
                sb.append(this.t.getClass().getSimpleName());
                sb.append('{');
                ArrayList arrayList = (ArrayList) this.f174s;
                int size = arrayList.size();
                for (int i6 = 0; i6 < size; i6++) {
                    sb.append((String) arrayList.get(i6));
                    if (i6 < size - 1) {
                        sb.append(", ");
                    }
                }
                sb.append('}');
                return sb.toString();
            default:
                return super.toString();
        }
    }

    public void u(D3.m mVar) throws GeneralSecurityException {
        HashMap map = (HashMap) this.f174s;
        D3.n nVar = new D3.n(mVar.f827a, E3.f.class);
        if (!map.containsKey(nVar)) {
            map.put(nVar, mVar);
            return;
        }
        D3.m mVar2 = (D3.m) map.get(nVar);
        if (mVar2.equals(mVar) && mVar.equals(mVar2)) {
            return;
        }
        throw new GeneralSecurityException("Attempt to register non-equal PrimitiveConstructor object for already existing object of type: " + nVar);
    }

    public void v(p136w3.m mVar) throws GeneralSecurityException {
        HashMap map = (HashMap) this.t;
        if (mVar == null) {
            throw new NullPointerException("wrapper must be non-null");
        }
        Class clsC = mVar.c();
        if (!map.containsKey(clsC)) {
            map.put(clsC, mVar);
            return;
        }
        p136w3.m mVar2 = (p136w3.m) map.get(clsC);
        if (mVar2.equals(mVar) && mVar.equals(mVar2)) {
            return;
        }
        throw new GeneralSecurityException("Attempt to register non-equal PrimitiveWrapper object or input class object for already existing object of type" + clsC);
    }

    public void w(KeyGenParameterSpec keyGenParameterSpec) {
        String str = (String) this.f174s;
        if (str.equals(K1.c.a(keyGenParameterSpec))) {
            this.t = keyGenParameterSpec;
        } else {
            StringBuilder sbO = T.o("KeyGenParamSpec's key alias does not match provided alias (", str, " vs ");
            sbO.append(K1.c.a(keyGenParameterSpec));
            throw new IllegalArgumentException(sbO.toString());
        }
    }

    public void x(Locale locale) {
        Locale.setDefault(locale);
        Context context = (Context) this.t;
        Configuration configuration = context.getResources().getConfiguration();
        configuration.setLocale(locale);
        context.createConfigurationContext(configuration);
    }

    public R0.G y(int i6) {
        int i7 = 0;
        while (true) {
            int[] iArr = (int[]) this.f174s;
            if (i7 >= iArr.length) {
                p117t0.a.l("BaseMediaChunkOutput", "Unmatched track of type: " + i6);
                return new R0.o();
            }
            if (i6 == iArr[i7]) {
                return ((X[]) this.t)[i7];
            }
            i7++;
        }
    }

    public void z() {
        synchronized (this) {
            ((AtomicInteger) this.f174s).decrementAndGet();
            if (((AtomicInteger) this.f174s).get() < 0) {
                throw new IllegalStateException("Unbalanced call to unblock() detected.");
            }
        }
    }

    public /* synthetic */ b(Object obj, Object obj2, int i6, boolean z6) {
        this.r = i6;
        this.t = obj;
        this.f174s = obj2;
    }

    public b(IBinder iBinder) throws RemoteException {
        this.r = 16;
        String interfaceDescriptor = iBinder.getInterfaceDescriptor();
        if (Objects.equals(interfaceDescriptor, "android.os.IMessenger")) {
            this.f174s = new Messenger(iBinder);
            this.t = null;
        } else if (Objects.equals(interfaceDescriptor, "com.google.android.gms.iid.IMessengerCompat")) {
            this.t = new g(iBinder);
            this.f174s = null;
        } else {
            Log.w("MessengerIpcClient", "Invalid interface descriptor: ".concat(String.valueOf(interfaceDescriptor)));
            throw new RemoteException();
        }
    }

    public /* synthetic */ b(Object obj) {
        this.r = 22;
        this.t = obj;
        this.f174s = new ArrayList();
    }

    public b(String str, p025e2.v vVar, O2.d dVar) {
        this.r = 18;
        this.f174s = str;
        this.t = vVar;
    }

    public b(B2.d dVar, I4.b bVar) {
        this.r = 11;
        h.e(bVar, "manager");
        this.f174s = dVar;
        this.t = bVar;
    }

    public b(i iVar) {
        this.r = 14;
        this.t = new v();
        this.f174s = iVar;
    }

    public b(A0.i iVar) {
        this.r = 28;
        this.t = iVar;
        this.f174s = new HashMap();
    }

    public b(Context context, int i6) throws NoSuchAlgorithmException, IOException, KeyStoreException, CertificateException {
        this.r = i6;
        switch (i6) {
            case 13:
                context.getApplicationContext();
                this.f174s = "_androidx_security_master_key_";
                return;
            case 23:
                Q2.q.f(context);
                Resources resources = context.getResources();
                this.t = resources;
                this.f174s = resources.getResourcePackageName(R.string.common_google_play_services_unknown_issue);
                return;
            default:
                this.t = context;
                String strL = l();
                this.f174s = strL;
                KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
                keyStore.load(null);
                if (keyStore.getKey(strL, null) == null) {
                    Locale locale = Locale.getDefault();
                    try {
                        x(Locale.ENGLISH);
                        Calendar calendar = Calendar.getInstance();
                        Calendar calendar2 = Calendar.getInstance();
                        calendar2.add(1, 25);
                        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA", "AndroidKeyStore");
                        keyPairGenerator.initialize(s(calendar, calendar2));
                        keyPairGenerator.generateKeyPair();
                        return;
                    } finally {
                        x(locale);
                    }
                }
                return;
        }
    }

    public b(String str) {
        this.r = 3;
        this.f174s = str.concat(".lck");
    }

    public b(C1.w wVar) {
        this.r = 2;
        this.f174s = new AtomicInteger(0);
        this.t = new AtomicBoolean(false);
    }

    public b(int i6, byte b6) {
        this.r = i6;
        switch (i6) {
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                break;
            case 15:
                this.f174s = new LongSparseArray();
                this.t = new PriorityQueue();
                break;
            case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
                this.f174s = Collections.synchronizedMap(new WeakHashMap());
                this.t = Collections.synchronizedMap(new WeakHashMap());
                break;
            case 24:
                N2.d dVar = N2.d.f2653c;
                this.f174s = new SparseIntArray();
                this.t = dVar;
                break;
            case 27:
                this.f174s = new ReentrantLock();
                this.t = new LinkedHashMap();
                break;
            default:
                this.f174s = new HashMap();
                this.t = new HashMap();
                break;
        }
    }

    public b(D3.o oVar) {
        this.r = 5;
        this.f174s = new HashMap(oVar.f831a);
        this.t = new HashMap(oVar.f832b);
    }

    public b(C0018t c0018t, L1.b bVar) {
        this.r = 1;
        h.e(bVar, "actual");
        this.t = c0018t;
        this.f174s = bVar;
    }

    public b(N4.b bVar) {
        this.r = 29;
        p066k4.c cVar = new p066k4.c(this, 15);
        W4.q qVar = new W4.q(bVar, "flutter/localization", W4.l.f3728a, null);
        this.f174s = qVar;
        qVar.b(cVar);
    }

    public b(int i6) {
        this.r = 8;
        C0021b c0021b = new C0021b(i6, 0);
        C0021b c0021b2 = new C0021b(i6, 1);
        this.f174s = c0021b;
        this.t = c0021b2;
    }

    public b(m mVar) {
        this.r = 25;
        this.f174s = mVar;
        this.t = new AtomicBoolean(false);
    }
}
