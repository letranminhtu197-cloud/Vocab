package A4;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import com.google.crypto.tink.shaded.protobuf.T;
import java.math.BigInteger;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.MGF1ParameterSpec;
import java.util.Calendar;
import javax.crypto.Cipher;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource;
import javax.security.auth.x500.X500Principal;

/* JADX INFO: loaded from: classes.dex */
public final class c extends b {
    @Override // A4.b
    public final String l() {
        return ((Context) this.t).getPackageName() + ".FlutterSecureStoragePluginKeyOAEP";
    }

    @Override // A4.b
    public final AlgorithmParameterSpec m() {
        return new OAEPParameterSpec("SHA-256", "MGF1", MGF1ParameterSpec.SHA1, PSource.PSpecified.DEFAULT);
    }

    @Override // A4.b
    public final Cipher o() {
        return Cipher.getInstance("RSA/ECB/OAEPPadding", "AndroidKeyStoreBCWorkaround");
    }

    @Override // A4.b
    public final KeyGenParameterSpec s(Calendar calendar, Calendar calendar2) {
        String str = (String) this.f174s;
        return new KeyGenParameterSpec.Builder(str, 3).setCertificateSubject(new X500Principal(T.x("CN=", str))).setDigests("SHA-256").setBlockModes("ECB").setEncryptionPaddings("OAEPPadding").setCertificateSerialNumber(BigInteger.valueOf(1L)).setCertificateNotBefore(calendar.getTime()).setCertificateNotAfter(calendar2.getTime()).build();
    }
}
