package A4;

/* JADX INFO: loaded from: classes.dex */
public enum e {
    AES_CBC_PKCS7Padding(new A0.c(3), 1),
    /* JADX INFO: Fake field, exist only in values array */
    AES_GCM_NoPadding(new A0.c(4), 23);

    public final A0.c r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final int f179s;

    e(A0.c cVar, int i6) {
        this.r = cVar;
        this.f179s = i6;
    }
}
