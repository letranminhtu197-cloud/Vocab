package A4;

/* JADX INFO: loaded from: classes.dex */
public enum a {
    RSA_ECB_PKCS1Padding(new A0.c(1), 1),
    /* JADX INFO: Fake field, exist only in values array */
    RSA_ECB_OAEPwithSHA_256andMGF1Padding(new A0.c(2), 23);

    public final A0.c r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final int f172s;

    a(A0.c cVar, int i6) {
        this.r = cVar;
        this.f172s = i6;
    }
}
