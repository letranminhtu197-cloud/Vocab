package A4;

import A0.i;
import E3.j;
import G0.C0020a;
import G0.k;
import J0.P;
import J0.i0;
import K.h;
import L4.t;
import L4.w;
import L4.x;
import L4.y;
import M4.m;
import N4.g;
import Q4.d;
import R0.n;
import R0.p;
import W4.o;
import W4.q;
import W4.r;
import a2.l;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaCodec;
import android.media.MediaFormat;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcel;
import android.text.Selection;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Surface;
import android.view.inputmethod.EditorInfo;
import androidx.lifecycle.AbstractServiceC0199v;
import androidx.lifecycle.C0198u;
import androidx.lifecycle.EnumC0190l;
import androidx.lifecycle.Q;
import com.google.android.gms.internal.play_billing.C0236m;
import io.flutter.embedding.engine.FlutterJNI;
import io.flutter.plugins.firebase.messaging.FlutterFirebaseMessagingBackgroundService;
import io.flutter.view.FlutterCallbackInformation;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyStore;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.spec.AlgorithmParameterSpec;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.UUID;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.ReentrantLock;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.metadata.HttpHeaders;
import org.apache.tika.utils.StringUtils;
import p018d2.C0292e;
import p018d2.E;
import p018d2.EnumC0288a;
import p018d2.F;
import p018d2.G;
import p053i4.u;
import p053i4.v;
import p108r3.A;
import p108r3.AbstractC0460q;
import p108r3.C;
import p108r3.C0468z;
import p108r3.T;
import p117t0.s;
import p141x1.D;

/* JADX INFO: loaded from: classes.dex */
public class d implements p146y2.b, o, k, H3.a, p091o3.d, W4.d {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static d f175v;
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public Object f176s;
    public Object t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public Object f177u;

    public /* synthetic */ d(int i6, boolean z6) {
        this.r = i6;
    }

    public static d L() {
        if (f175v == null) {
            m mVar = new m(0);
            K4.a aVar = new K4.a();
            aVar.f2082a = 0;
            ExecutorService executorServiceNewCachedThreadPool = Executors.newCachedThreadPool(aVar);
            FlutterJNI flutterJNI = new FlutterJNI();
            Q4.d dVar = new Q4.d();
            dVar.f3247a = false;
            dVar.f3248b = false;
            dVar.f3252f = flutterJNI;
            dVar.f3253g = executorServiceNewCachedThreadPool;
            d dVar2 = new d(13, false);
            dVar2.f176s = dVar;
            dVar2.t = mVar;
            dVar2.f177u = executorServiceNewCachedThreadPool;
            f175v = dVar2;
        }
        return f175v;
    }

    public void A(Object obj, ByteArrayOutputStream byteArrayOutputStream) {
        HashMap map = (HashMap) this.f176s;
        X3.f fVar = new X3.f(byteArrayOutputStream, map, (HashMap) this.t, (U3.d) this.f177u);
        U3.d dVar = (U3.d) map.get(obj.getClass());
        if (dVar != null) {
            dVar.a(obj, fVar);
        } else {
            throw new U3.b("No encoder for " + obj.getClass());
        }
    }

    public byte[] B(byte[] bArr) throws BadPaddingException, IllegalBlockSizeException, InvalidKeyException, InvalidAlgorithmParameterException {
        int iG = G();
        byte[] bArr2 = new byte[iG];
        ((SecureRandom) this.t).nextBytes(bArr2);
        AlgorithmParameterSpec algorithmParameterSpecH = H(bArr2);
        Cipher cipher = (Cipher) this.f176s;
        cipher.init(1, (Key) this.f177u, algorithmParameterSpecH);
        byte[] bArrDoFinal = cipher.doFinal(bArr);
        byte[] bArr3 = new byte[bArrDoFinal.length + iG];
        System.arraycopy(bArr2, 0, bArr3, 0, iG);
        System.arraycopy(bArrDoFinal, 0, bArr3, iG, bArrDoFinal.length);
        return bArr3;
    }

    public void C(Intent intent, CountDownLatch countDownLatch) {
        if (((M4.b) this.f177u) == null) {
            Log.i("FLTFireBGExecutor", "A background message could not be handled in Dart as no onBackgroundMessage handler has been registered.");
            return;
        }
        p021d5.b bVar = countDownLatch != null ? new p021d5.b(countDownLatch) : null;
        byte[] byteArrayExtra = intent.getByteArrayExtra("notification");
        if (byteArrayExtra == null) {
            Log.e("FLTFireBGExecutor", "RemoteMessage byte array not found in Intent.");
            return;
        }
        Parcel parcelObtain = Parcel.obtain();
        try {
            parcelObtain.unmarshall(byteArrayExtra, 0, byteArrayExtra.length);
            parcelObtain.setDataPosition(0);
            HashMap mapI = p000a.a.I(u.CREATOR.createFromParcel(parcelObtain));
            q qVar = (q) this.t;
            y yVar = new y();
            yVar.put("userCallbackHandle", Long.valueOf(X2.a.f3809c.getSharedPreferences("io.flutter.firebase.messaging.callback", 0).getLong("user_callback_handle", 0L)));
            yVar.put("message", mapI);
            qVar.a("MessagingBackground#onMessage", yVar, bVar);
        } finally {
            parcelObtain.recycle();
        }
    }

    public String D() {
        return "VGhpcyBpcyB0aGUga2V5IGZvciBhIHNlY3VyZSBzdG9yYWdlIEFFUyBLZXkK";
    }

    public Cipher E() {
        return Cipher.getInstance("AES/CBC/PKCS7Padding");
    }

    public long F() {
        R0.k kVar = (R0.k) this.f177u;
        if (kVar != null) {
            return kVar.f3354u;
        }
        return -1L;
    }

    public int G() {
        return 16;
    }

    public AlgorithmParameterSpec H(byte[] bArr) {
        return new IvParameterSpec(bArr);
    }

    public boolean I(KeyEvent keyEvent) {
        w[] wVarArr = (w[]) this.f176s;
        if (((HashSet) this.t).remove(keyEvent)) {
            return false;
        }
        if (wVarArr.length <= 0) {
            N(keyEvent);
            return true;
        }
        h hVar = new h();
        hVar.f1971d = this;
        hVar.f1968a = ((w[]) this.f176s).length;
        hVar.f1969b = false;
        hVar.f1970c = keyEvent;
        for (w wVar : wVarArr) {
            wVar.a(keyEvent, new K0.d(hVar));
        }
        return true;
    }

    public boolean J() throws IOException {
        String strTrim;
        ArrayDeque arrayDeque = (ArrayDeque) this.t;
        if (((String) this.f177u) == null) {
            if (!arrayDeque.isEmpty()) {
                String str = (String) arrayDeque.poll();
                str.getClass();
                this.f177u = str;
                return true;
            }
            do {
                String line = ((BufferedReader) this.f176s).readLine();
                this.f177u = line;
                if (line == null) {
                    return false;
                }
                strTrim = line.trim();
                this.f177u = strTrim;
            } while (strTrim.isEmpty());
        }
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:66:0x00ed  */
    public void K(p128v0.h hVar, Uri uri, Map map, long j6, long j7, P p6) throws i0 {
        p[] pVarArr;
        R0.k kVar = new R0.k(hVar, j6, j7);
        this.f177u = kVar;
        if (((p) this.t) != null) {
            return;
        }
        n nVar = (n) this.f176s;
        synchronized (nVar) {
            try {
                int[] iArr = n.f3358f;
                ArrayList arrayList = new ArrayList(21);
                List list = (List) map.get(HttpHeaders.CONTENT_TYPE);
                int iL = h6.h.L((list == null || list.isEmpty()) ? null : (String) list.get(0));
                if (iL != -1) {
                    nVar.a(iL, arrayList);
                }
                int iM = h6.h.M(uri);
                if (iM != -1 && iM != iL) {
                    nVar.a(iM, arrayList);
                }
                for (int i6 = 0; i6 < 21; i6++) {
                    int i7 = iArr[i6];
                    if (i7 != iL && i7 != iM) {
                        nVar.a(i7, arrayList);
                    }
                }
                pVarArr = new p[arrayList.size()];
                for (int i8 = 0; i8 < arrayList.size(); i8++) {
                    p nVar2 = (p) arrayList.get(i8);
                    if (!(nVar2.a() instanceof p070l1.k) && !(nVar2.a() instanceof p070l1.n) && !(nVar2.a() instanceof D) && !(nVar2.a() instanceof T0.b) && !(nVar2.a() instanceof p057j1.d)) {
                        nVar2 = new p089o1.n(nVar2, nVar.f3365e);
                    }
                    pVarArr[i8] = nVar2;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        int length = pVarArr.length;
        A a5 = C.f8765s;
        AbstractC0460q.c("expectedSize", length);
        C0468z c0468z = new C0468z(length);
        boolean z6 = true;
        if (pVarArr.length == 1) {
            this.t = pVarArr[0];
        } else {
            for (p pVar : pVarArr) {
                try {
                    if (pVar.l(kVar)) {
                        this.t = pVar;
                        kVar.f3356w = 0;
                        break;
                    }
                    c0468z.c(pVar.f());
                    boolean z7 = ((p) this.t) != null || kVar.f3354u == j6;
                    p117t0.a.h(z7);
                    kVar.f3356w = 0;
                } catch (EOFException unused) {
                    if (((p) this.t) != null || kVar.f3354u == j6) {
                    }
                } catch (Throwable th2) {
                    if (((p) this.t) == null && kVar.f3354u != j6) {
                        z6 = false;
                    }
                    p117t0.a.h(z6);
                    kVar.f3356w = 0;
                    throw th2;
                }
                p117t0.a.h(z7);
                kVar.f3356w = 0;
            }
            if (((p) this.t) == null) {
                StringBuilder sb = new StringBuilder("None of the available extractors (");
                P5.u uVar = new P5.u(", ", 1);
                Iterator it = AbstractC0460q.n(C.p(pVarArr), new A0.c(16)).iterator();
                StringBuilder sb2 = new StringBuilder();
                uVar.a(sb2, it);
                sb.append(sb2.toString());
                sb.append(") could read the stream.");
                String string = sb.toString();
                T tF = c0468z.f();
                i0 i0Var = new i0(string, null, false, 1);
                C.n(tF);
                throw i0Var;
            }
        }
        ((p) this.t).k(p6);
    }

    public String M() {
        if (!J()) {
            throw new NoSuchElementException();
        }
        String str = (String) this.f177u;
        this.f177u = null;
        return str;
    }

    /* JADX WARN: Code duplicated, block: B:31:0x008e  */
    /* JADX WARN: Code duplicated, block: B:38:0x00ae  */
    public void N(KeyEvent keyEvent) {
        io.flutter.plugin.editing.c cVar;
        int selectionStart;
        int selectionEnd;
        int unicodeChar;
        int iMin;
        int iMax;
        HashSet hashSet = (HashSet) this.t;
        x xVar = (x) this.f177u;
        if (xVar != null) {
            L4.p pVar = (L4.p) xVar;
            io.flutter.plugin.editing.k kVar = pVar.C;
            boolean zE = false;
            if (kVar.f6469b.isAcceptingText() && (cVar = kVar.f6477j) != null) {
                io.flutter.plugin.editing.f fVar = cVar.f6436d;
                if (keyEvent.getAction() == 0) {
                    if (keyEvent.getKeyCode() == 21) {
                        zE = cVar.d(true, keyEvent.isShiftPressed());
                    } else if (keyEvent.getKeyCode() == 22) {
                        zE = cVar.d(false, keyEvent.isShiftPressed());
                    } else if (keyEvent.getKeyCode() == 19) {
                        zE = cVar.e(true, keyEvent.isShiftPressed());
                    } else if (keyEvent.getKeyCode() == 20) {
                        zE = cVar.e(false, keyEvent.isShiftPressed());
                    } else if (keyEvent.getKeyCode() == 66 || keyEvent.getKeyCode() == 160) {
                        EditorInfo editorInfo = cVar.f6437e;
                        if ((editorInfo.inputType & 131072) == 0) {
                            cVar.performEditorAction(editorInfo.imeOptions & 255);
                        } else {
                            selectionStart = Selection.getSelectionStart(fVar);
                            selectionEnd = Selection.getSelectionEnd(fVar);
                            unicodeChar = keyEvent.getUnicodeChar();
                            if (selectionStart >= 0 && selectionEnd >= 0 && unicodeChar != 0) {
                                iMin = Math.min(selectionStart, selectionEnd);
                                iMax = Math.max(selectionStart, selectionEnd);
                                cVar.beginBatchEdit();
                                if (iMin != iMax) {
                                    fVar.delete(iMin, iMax);
                                }
                                fVar.insert(iMin, (CharSequence) String.valueOf((char) unicodeChar));
                                int i6 = iMin + 1;
                                cVar.setSelection(i6, i6);
                                cVar.endBatchEdit();
                            }
                        }
                        zE = true;
                    } else {
                        selectionStart = Selection.getSelectionStart(fVar);
                        selectionEnd = Selection.getSelectionEnd(fVar);
                        unicodeChar = keyEvent.getUnicodeChar();
                        if (selectionStart >= 0) {
                            iMin = Math.min(selectionStart, selectionEnd);
                            iMax = Math.max(selectionStart, selectionEnd);
                            cVar.beginBatchEdit();
                            if (iMin != iMax) {
                                fVar.delete(iMin, iMax);
                            }
                            fVar.insert(iMin, (CharSequence) String.valueOf((char) unicodeChar));
                            int i7 = iMin + 1;
                            cVar.setSelection(i7, i7);
                            cVar.endBatchEdit();
                            zE = true;
                        }
                    }
                }
            }
            if (zE) {
                return;
            }
            hashSet.add(keyEvent);
            pVar.getRootView().dispatchKeyEvent(keyEvent);
            if (hashSet.remove(keyEvent)) {
                Log.w("KeyboardManager", "A redispatched key event was consumed before reaching KeyboardManager");
            }
        }
    }

    public void O(Activity activity, X1.k kVar) {
        WeakHashMap weakHashMap = (WeakHashMap) this.f177u;
        A5.h.e(activity, "activity");
        ReentrantLock reentrantLock = (ReentrantLock) this.t;
        reentrantLock.lock();
        try {
            if (kVar.equals((X1.k) weakHashMap.get(activity))) {
                reentrantLock.unlock();
                return;
            }
            reentrantLock.unlock();
            for (l lVar : ((a2.m) ((i) this.f176s).f64s).f4023b) {
                if (lVar.f4017a.equals(activity)) {
                    lVar.f4019c = kVar;
                    lVar.f4018b.accept(kVar);
                }
            }
        } catch (Throwable th) {
            reentrantLock.unlock();
            throw th;
        }
    }

    public void P(EnumC0190l enumC0190l) {
        Q q4 = (Q) this.f177u;
        if (q4 != null) {
            q4.run();
        }
        Q q6 = new Q((C0198u) this.f176s, enumC0190l);
        this.f177u = q6;
        ((Handler) this.t).postAtFrontOfQueue(q6);
    }

    public void Q(int i6) throws InvalidAlgorithmParameterException {
        if (i6 != 16 && i6 != 32) {
            throw new InvalidAlgorithmParameterException(String.format("Invalid key size %d; only 128-bit and 256-bit AES keys are supported", Integer.valueOf(i6 * 8)));
        }
        this.f176s = Integer.valueOf(i6);
    }

    public void R(W4.i iVar) {
        ((W4.f) this.f176s).j((String) this.t, iVar == null ? null : new d(this, iVar));
    }

    public void S(final long j6, final K2.i iVar) {
        if (((M4.b) this.f177u) != null) {
            Log.e("FLTFireBGExecutor", "Background isolate already started.");
            return;
        }
        final Q4.d dVar = (Q4.d) L().f176s;
        final Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() { // from class: d5.a
            @Override // java.lang.Runnable
            public final void run() {
                Context context = X2.a.f3809c;
                d dVar2 = dVar;
                dVar2.d(context);
                Context context2 = X2.a.f3809c;
                t tVar = new t(this.r, dVar2, iVar, j6);
                if (Looper.myLooper() != Looper.getMainLooper()) {
                    throw new IllegalStateException("ensureInitializationComplete must be called on the main thread");
                }
                if (dVar2.f3249c == null) {
                    throw new IllegalStateException("ensureInitializationComplete must be called after startInitialization");
                }
                boolean z6 = dVar2.f3248b;
                Handler handler2 = handler;
                if (z6) {
                    handler2.post(tVar);
                } else {
                    dVar2.f3253g.execute(new Q4.a(dVar2, context2, handler2, tVar, 0));
                }
            }
        });
    }

    @Override // G0.k
    public void a(int i6, p134w0.b bVar, long j6, int i7) {
        ((MediaCodec) this.f176s).queueSecureInputBuffer(i6, 0, bVar.f9567i, j6, i7);
    }

    @Override // G0.k
    public void b(Bundle bundle) {
        ((MediaCodec) this.f176s).setParameters(bundle);
    }

    @Override // G0.k
    public void c(int i6, int i7, long j6, int i8) {
        ((MediaCodec) this.f176s).queueInputBuffer(i6, 0, i7, j6, i8);
    }

    @Override // G0.k
    public int d(MediaCodec.BufferInfo bufferInfo) {
        int iDequeueOutputBuffer;
        MediaCodec mediaCodec = (MediaCodec) this.f176s;
        do {
            iDequeueOutputBuffer = mediaCodec.dequeueOutputBuffer(bufferInfo, 0L);
            if (iDequeueOutputBuffer == -3 && s.f9002a < 21) {
                this.f177u = mediaCodec.getOutputBuffers();
            }
        } while (iDequeueOutputBuffer == -3);
        return iDequeueOutputBuffer;
    }

    @Override // G0.k
    public void e(long j6, int i6) {
        ((MediaCodec) this.f176s).releaseOutputBuffer(i6, j6);
    }

    @Override // G0.k
    public void flush() {
        ((MediaCodec) this.f176s).flush();
    }

    @Override // W4.d
    public void g(ByteBuffer byteBuffer, g gVar) throws Throwable {
        AtomicReference atomicReference = (AtomicReference) this.t;
        W4.i iVar = (W4.i) this.f176s;
        d dVar = (d) this.f177u;
        String str = (String) dVar.t;
        r rVar = (r) dVar.f177u;
        W4.n nVarE = rVar.e(byteBuffer);
        String str2 = nVarE.f3729a;
        Object obj = nVarE.f3730b;
        if (!str2.equals("listen")) {
            if (!str2.equals("cancel")) {
                gVar.a(null);
                return;
            }
            if (((W4.g) atomicReference.getAndSet(null)) == null) {
                gVar.a(rVar.c("error", "No active stream to cancel", null));
                return;
            }
            try {
                iVar.onCancel(obj);
                gVar.a(rVar.a(null));
                return;
            } catch (RuntimeException e6) {
                Log.e("EventChannel#" + str, "Failed to close event stream", e6);
                gVar.a(rVar.c("error", e6.getMessage(), null));
                return;
            }
        }
        W4.h hVar = new W4.h(this);
        if (((W4.g) atomicReference.getAndSet(hVar)) != null) {
            try {
                iVar.onCancel(null);
            } catch (RuntimeException e7) {
                Log.e("EventChannel#" + str, "Failed to close existing event stream", e7);
            }
        }
        try {
            iVar.onListen(obj, hVar);
            gVar.a(rVar.a(null));
        } catch (RuntimeException e8) {
            atomicReference.set(null);
            Log.e("EventChannel#" + str, "Failed to open event stream", e8);
            gVar.a(rVar.c("error", e8.getMessage(), null));
        }
    }

    @Override // p067k5.a
    public Object get() {
        return new C2.d((Context) ((p067k5.a) this.f176s).get(), (D2.d) ((p067k5.a) this.t).get(), (C2.b) ((Z3.e) this.f177u).get());
    }

    @Override // G0.k
    public void h(int i6, boolean z6) {
        ((MediaCodec) this.f176s).releaseOutputBuffer(i6, z6);
    }

    @Override // G0.k
    public void i(P0.l lVar, Handler handler) {
        ((MediaCodec) this.f176s).setOnFrameRenderedListener(new C0020a(this, lVar, 1), handler);
    }

    @Override // G0.k
    public void j(int i6) {
        ((MediaCodec) this.f176s).setVideoScalingMode(i6);
    }

    @Override // G0.k
    public MediaFormat k() {
        return ((MediaCodec) this.f176s).getOutputFormat();
    }

    @Override // G0.k
    public ByteBuffer l(int i6) {
        return s.f9002a >= 21 ? ((MediaCodec) this.f176s).getInputBuffer(i6) : ((ByteBuffer[]) this.t)[i6];
    }

    @Override // G0.k
    public void m(Surface surface) {
        ((MediaCodec) this.f176s).setOutputSurface(surface);
    }

    @Override // G0.k
    public ByteBuffer n(int i6) {
        return s.f9002a >= 21 ? ((MediaCodec) this.f176s).getOutputBuffer(i6) : ((ByteBuffer[]) this.f177u)[i6];
    }

    @Override // G0.k
    public int o() {
        return ((MediaCodec) this.f176s).dequeueInputBuffer(0L);
    }

    @Override // W4.o
    public void onMethodCall(W4.n nVar, W4.p pVar) {
        switch (this.r) {
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                HashMap map = (HashMap) this.f177u;
                String str = nVar.f3729a;
                str.getClass();
                switch (str) {
                    case "init":
                        String str2 = (String) nVar.a("id");
                        if (map.containsKey(str2)) {
                            ((V4.h) pVar).c(com.google.crypto.tink.shaded.protobuf.T.j("Platform player ", str2, " already exists"), null, null);
                            return;
                        } else {
                            map.put(str2, new E4.b((Context) this.f176s, (W4.f) this.t, str2, (Map) nVar.a("audioLoadConfiguration"), (List) nVar.a("androidAudioEffects"), (Boolean) nVar.a("androidOffloadSchedulingEnabled")));
                            ((V4.h) pVar).a(null);
                            return;
                        }
                    case "disposePlayer":
                        String str3 = (String) nVar.a("id");
                        E4.b bVar = (E4.b) map.get(str3);
                        if (bVar != null) {
                            bVar.H();
                            map.remove(str3);
                        }
                        ((V4.h) pVar).a(new HashMap());
                        return;
                    case "disposeAllPlayers":
                        z();
                        ((V4.h) pVar).a(new HashMap());
                        return;
                    default:
                        ((V4.h) pVar).b();
                        return;
                }
            default:
                if (!nVar.f3729a.equals("MessagingBackground#initialized")) {
                    ((V4.h) pVar).b();
                    return;
                }
                ((AtomicBoolean) this.f176s).set(true);
                List list = FlutterFirebaseMessagingBackgroundService.y;
                Log.i("FLTFireMsgService", "FlutterFirebaseMessagingBackgroundService started!");
                List list2 = FlutterFirebaseMessagingBackgroundService.y;
                synchronized (list2) {
                    try {
                        Iterator it = list2.iterator();
                        while (it.hasNext()) {
                            FlutterFirebaseMessagingBackgroundService.f6528z.C((Intent) it.next(), null);
                        }
                        FlutterFirebaseMessagingBackgroundService.y.clear();
                    } catch (Throwable th) {
                        throw th;
                    }
                    break;
                }
                ((V4.h) pVar).a(Boolean.TRUE);
                return;
        }
    }

    @Override // p091o3.d
    public void p(p091o3.i iVar) {
        M2.b bVar = (M2.b) this.f176s;
        String str = (String) this.t;
        ScheduledFuture scheduledFuture = (ScheduledFuture) this.f177u;
        synchronized (bVar.f2427a) {
            bVar.f2427a.remove(str);
        }
        scheduledFuture.cancel(false);
    }

    @Override // H3.a
    public byte[] q(byte[] bArr, int i6) throws GeneralSecurityException {
        byte[] bArrG0;
        if (i6 > 16) {
            throw new InvalidAlgorithmParameterException("outputLength too large, max is 16 bytes");
        }
        if (!A3.a.d(1)) {
            throw new GeneralSecurityException("Can not use AES-CMAC in FIPS-mode.");
        }
        Cipher cipher = (Cipher) J3.i.f1928b.f1930a.k("AES/ECB/NoPadding");
        cipher.init(1, (SecretKeySpec) this.f176s);
        int iMax = Math.max(1, (int) Math.ceil(((double) bArr.length) / 16.0d));
        if (iMax * 16 == bArr.length) {
            bArrG0 = G.f0(bArr, (iMax - 1) * 16, (byte[]) this.t, 0, 16);
        } else {
            byte[] bArrCopyOfRange = Arrays.copyOfRange(bArr, (iMax - 1) * 16, bArr.length);
            if (bArrCopyOfRange.length >= 16) {
                throw new IllegalArgumentException("x must be smaller than a block.");
            }
            byte[] bArrCopyOf = Arrays.copyOf(bArrCopyOfRange, 16);
            bArrCopyOf[bArrCopyOfRange.length] = -128;
            bArrG0 = G.g0(bArrCopyOf, (byte[]) this.f177u);
        }
        byte[] bArrDoFinal = new byte[16];
        for (int i7 = 0; i7 < iMax - 1; i7++) {
            bArrDoFinal = cipher.doFinal(G.f0(bArrDoFinal, 0, bArr, i7 * 16, 16));
        }
        return Arrays.copyOf(cipher.doFinal(G.g0(bArrG0, bArrDoFinal)), i6);
    }

    public B3.a r() throws GeneralSecurityException {
        i iVar;
        B3.f fVar = (B3.f) this.f176s;
        if (fVar == null || (iVar = (i) this.t) == null) {
            throw new IllegalArgumentException("Cannot build without parameters and/or key material");
        }
        if (fVar.f336b != ((K3.a) iVar.f64s).f2081a.length) {
            throw new GeneralSecurityException("Key size mismatch");
        }
        B3.e eVar = fVar.f337c;
        B3.e eVar2 = B3.e.f334d;
        if (eVar != eVar2 && ((Integer) this.f177u) == null) {
            throw new GeneralSecurityException("Cannot create key without ID requirement with parameters with ID requirement");
        }
        if (eVar == eVar2 && ((Integer) this.f177u) != null) {
            throw new GeneralSecurityException("Cannot create key with ID requirement with parameters without ID requirement");
        }
        if (eVar == eVar2) {
            K3.a.a(new byte[0]);
        } else if (eVar == B3.e.f333c) {
            K3.a.a(ByteBuffer.allocate(5).put((byte) 0).putInt(((Integer) this.f177u).intValue()).array());
        } else {
            if (eVar != B3.e.f332b) {
                throw new IllegalStateException("Unknown AesSivParameters.Variant: " + ((B3.f) this.f176s).f337c);
            }
            K3.a.a(ByteBuffer.allocate(5).put((byte) 1).putInt(((Integer) this.f177u).intValue()).array());
        }
        return new B3.a();
    }

    @Override // G0.k
    public void release() {
        MediaCodec mediaCodec = (MediaCodec) this.f176s;
        this.t = null;
        this.f177u = null;
        try {
            int i6 = s.f9002a;
            if (i6 >= 30 && i6 < 33) {
                mediaCodec.stop();
            }
        } finally {
            mediaCodec.release();
        }
    }

    public E3.a s() throws GeneralSecurityException {
        i iVar;
        K3.a aVarA;
        E3.d dVar = (E3.d) this.f176s;
        if (dVar == null || (iVar = (i) this.t) == null) {
            throw new GeneralSecurityException("Cannot build without parameters and/or key material");
        }
        if (dVar.f1121b != ((K3.a) iVar.f64s).f2081a.length) {
            throw new GeneralSecurityException("Key size mismatch");
        }
        E3.c cVar = dVar.f1123d;
        E3.c cVar2 = E3.c.f1110f;
        if (cVar != cVar2 && ((Integer) this.f177u) == null) {
            throw new GeneralSecurityException("Cannot create key without ID requirement with parameters with ID requirement");
        }
        if (cVar == cVar2 && ((Integer) this.f177u) != null) {
            throw new GeneralSecurityException("Cannot create key with ID requirement with parameters without ID requirement");
        }
        if (cVar == cVar2) {
            aVarA = K3.a.a(new byte[0]);
        } else if (cVar == E3.c.f1109e || cVar == E3.c.f1108d) {
            aVarA = K3.a.a(ByteBuffer.allocate(5).put((byte) 0).putInt(((Integer) this.f177u).intValue()).array());
        } else {
            if (cVar != E3.c.f1107c) {
                throw new IllegalStateException("Unknown AesCmacParametersParameters.Variant: " + ((E3.d) this.f176s).f1123d);
            }
            aVarA = K3.a.a(ByteBuffer.allocate(5).put((byte) 1).putInt(((Integer) this.f177u).intValue()).array());
        }
        return new E3.a((E3.d) this.f176s, aVarA);
    }

    public E3.d t() throws GeneralSecurityException {
        Integer num = (Integer) this.f176s;
        if (num == null) {
            throw new GeneralSecurityException("key size not set");
        }
        if (((Integer) this.t) == null) {
            throw new GeneralSecurityException("tag size not set");
        }
        if (((E3.c) this.f177u) != null) {
            return new E3.d(num.intValue(), ((Integer) this.t).intValue(), (E3.c) this.f177u);
        }
        throw new GeneralSecurityException("variant not set");
    }

    public String toString() {
        switch (this.r) {
            case 16:
                StringBuilder sb = new StringBuilder("DartCallback( bundle path: ");
                sb.append((String) this.t);
                sb.append(", library path: ");
                FlutterCallbackInformation flutterCallbackInformation = (FlutterCallbackInformation) this.f177u;
                sb.append(flutterCallbackInformation.callbackLibraryPath);
                sb.append(", function: ");
                return com.google.crypto.tink.shaded.protobuf.T.m(sb, flutterCallbackInformation.callbackName, " )");
            case 25:
                StringBuilder sb2 = new StringBuilder(32);
                sb2.append((String) this.f176s);
                sb2.append('{');
                C0236m c0236m = ((C0236m) this.t).f4892b;
                String str = StringUtils.EMPTY;
                while (c0236m != null) {
                    Object obj = c0236m.f4891a;
                    sb2.append(str);
                    if (obj == null || !obj.getClass().isArray()) {
                        sb2.append(obj);
                    } else {
                        String strDeepToString = Arrays.deepToString(new Object[]{obj});
                        sb2.append((CharSequence) strDeepToString, 1, strDeepToString.length() - 1);
                    }
                    c0236m = c0236m.f4892b;
                    str = ", ";
                }
                sb2.append('}');
                return sb2.toString();
            default:
                return super.toString();
        }
    }

    public E3.i u() throws GeneralSecurityException {
        i iVar;
        K3.a aVarA;
        j jVar = (j) this.f176s;
        if (jVar == null || (iVar = (i) this.t) == null) {
            throw new GeneralSecurityException("Cannot build without parameters and/or key material");
        }
        if (jVar.f1131b != ((K3.a) iVar.f64s).f2081a.length) {
            throw new GeneralSecurityException("Key size mismatch");
        }
        E3.c cVar = jVar.f1133d;
        E3.c cVar2 = E3.c.o;
        if (cVar != cVar2 && ((Integer) this.f177u) == null) {
            throw new GeneralSecurityException("Cannot create key without ID requirement with parameters with ID requirement");
        }
        if (cVar == cVar2 && ((Integer) this.f177u) != null) {
            throw new GeneralSecurityException("Cannot create key with ID requirement with parameters without ID requirement");
        }
        if (cVar == cVar2) {
            aVarA = K3.a.a(new byte[0]);
        } else if (cVar == E3.c.f1118n || cVar == E3.c.f1117m) {
            aVarA = K3.a.a(ByteBuffer.allocate(5).put((byte) 0).putInt(((Integer) this.f177u).intValue()).array());
        } else {
            if (cVar != E3.c.f1116l) {
                throw new IllegalStateException("Unknown HmacParameters.Variant: " + ((j) this.f176s).f1133d);
            }
            aVarA = K3.a.a(ByteBuffer.allocate(5).put((byte) 1).putInt(((Integer) this.f177u).intValue()).array());
        }
        return new E3.i((j) this.f176s, aVarA);
    }

    public p018d2.A v() {
        p018d2.A a5 = new p018d2.A((UUID) this.f176s, (p071l2.p) this.t, (LinkedHashSet) this.f177u);
        C0292e c0292e = ((p071l2.p) this.t).f7695j;
        boolean z6 = c0292e.b() || c0292e.f5262e || c0292e.f5260c || c0292e.f5261d;
        p071l2.p pVar = (p071l2.p) this.t;
        if (pVar.f7701q) {
            if (z6) {
                throw new IllegalArgumentException("Expedited jobs only support network and storage constraints");
            }
            if (pVar.f7692g > 0) {
                throw new IllegalArgumentException("Expedited jobs cannot be delayed");
            }
        }
        String str = pVar.f7706x;
        if (str == null) {
            List listD0 = I5.d.D0(pVar.f7688c, new String[]{"."});
            String strG0 = listD0.size() == 1 ? (String) listD0.get(0) : (String) p081m5.f.F0(listD0);
            if (strG0.length() > 127) {
                strG0 = I5.d.G0(strG0, 127);
            }
            pVar.f7706x = strG0;
        } else if (str.length() > 127) {
            ((p071l2.p) this.t).f7706x = I5.d.G0(str, 127);
        }
        UUID uuidRandomUUID = UUID.randomUUID();
        A5.h.d(uuidRandomUUID, "randomUUID(...)");
        this.f176s = uuidRandomUUID;
        String string = uuidRandomUUID.toString();
        A5.h.d(string, "toString(...)");
        p071l2.p pVar2 = (p071l2.p) this.t;
        A5.h.e(pVar2, "other");
        this.t = new p071l2.p(string, pVar2.f7687b, pVar2.f7688c, pVar2.f7689d, new p018d2.j(pVar2.f7690e), new p018d2.j(pVar2.f7691f), pVar2.f7692g, pVar2.f7693h, pVar2.f7694i, new C0292e(pVar2.f7695j), pVar2.f7696k, pVar2.f7697l, pVar2.f7698m, pVar2.f7699n, pVar2.o, pVar2.f7700p, pVar2.f7701q, pVar2.r, pVar2.f7702s, pVar2.f7703u, pVar2.f7704v, pVar2.f7705w, pVar2.f7706x, pVar2.y, 524288);
        return a5;
    }

    public String w(String str, long j6, int i6, long j7) {
        ArrayList arrayList = (ArrayList) this.f176s;
        ArrayList arrayList2 = (ArrayList) this.f177u;
        ArrayList arrayList3 = (ArrayList) this.t;
        StringBuilder sb = new StringBuilder();
        for (int i7 = 0; i7 < arrayList3.size(); i7++) {
            sb.append((String) arrayList.get(i7));
            if (((Integer) arrayList3.get(i7)).intValue() == 1) {
                sb.append(str);
            } else if (((Integer) arrayList3.get(i7)).intValue() == 2) {
                sb.append(String.format(Locale.US, (String) arrayList2.get(i7), Long.valueOf(j6)));
            } else if (((Integer) arrayList3.get(i7)).intValue() == 3) {
                sb.append(String.format(Locale.US, (String) arrayList2.get(i7), Integer.valueOf(i6)));
            } else if (((Integer) arrayList3.get(i7)).intValue() == 4) {
                sb.append(String.format(Locale.US, (String) arrayList2.get(i7), Long.valueOf(j7)));
            }
        }
        sb.append((String) arrayList.get(arrayList3.size()));
        return sb.toString();
    }

    public void x(int i6, io.flutter.view.e eVar) {
        ((FlutterJNI) this.t).dispatchSemanticsAction(i6, eVar);
    }

    public void y(int i6, io.flutter.view.e eVar, Serializable serializable) {
        ((FlutterJNI) this.t).dispatchSemanticsAction(i6, eVar, serializable);
    }

    public void z() {
        HashMap map = (HashMap) this.f177u;
        ArrayList arrayList = new ArrayList(map.values());
        int size = arrayList.size();
        int i6 = 0;
        while (i6 < size) {
            Object obj = arrayList.get(i6);
            i6++;
            ((E4.b) obj).H();
        }
        map.clear();
    }

    public /* synthetic */ d(Object obj, Object obj2, Object obj3, int i6) {
        this.r = i6;
        this.f176s = obj;
        this.t = obj2;
        this.f177u = obj3;
    }

    public d(String str) {
        this.r = 25;
        C0236m c0236m = new C0236m();
        this.t = c0236m;
        this.f177u = c0236m;
        this.f176s = str;
    }

    public d(Context context, W4.f fVar) {
        this.r = 8;
        this.f177u = new HashMap();
        this.f176s = context;
        this.t = fVar;
    }

    public d(Context context, b bVar) throws Exception {
        this.r = 0;
        this.t = new SecureRandom();
        String strD = D();
        SharedPreferences sharedPreferences = context.getSharedPreferences("FlutterSecureKeyStorage", 0);
        SharedPreferences.Editor editorEdit = sharedPreferences.edit();
        String string = sharedPreferences.getString(strD, null);
        this.f176s = E();
        if (string != null) {
            try {
                this.f177u = bVar.A(Base64.decode(string, 0));
                return;
            } catch (Exception e6) {
                Log.e("StorageCipher18Impl", "unwrap key failed", e6);
            }
        }
        byte[] bArr = new byte[16];
        ((SecureRandom) this.t).nextBytes(bArr);
        SecretKeySpec secretKeySpec = new SecretKeySpec(bArr, "AES");
        this.f177u = secretKeySpec;
        bVar.getClass();
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        String str = (String) bVar.f174s;
        Certificate certificate = keyStore.getCertificate(str);
        if (certificate != null) {
            PublicKey publicKey = certificate.getPublicKey();
            if (publicKey != null) {
                Cipher cipherO = bVar.o();
                cipherO.init(3, publicKey, bVar.m());
                editorEdit.putString(strD, Base64.encodeToString(cipherO.wrap(secretKeySpec), 0));
                editorEdit.apply();
                return;
            }
            throw new Exception(com.google.crypto.tink.shaded.protobuf.T.x("No key found under alias: ", str));
        }
        throw new Exception(com.google.crypto.tink.shaded.protobuf.T.x("No certificate found under alias: ", str));
    }

    public d(AbstractServiceC0199v abstractServiceC0199v) {
        this.r = 24;
        this.f176s = new C0198u(abstractServiceC0199v);
        this.t = new Handler();
    }

    public d(W4.f fVar, String str) {
        this.r = 21;
        W4.x xVar = W4.x.f3738a;
        this.f176s = fVar;
        this.t = str;
        this.f177u = xVar;
    }

    public d(byte[] bArr) throws GeneralSecurityException {
        this.r = 12;
        J3.n.a(bArr.length);
        SecretKeySpec secretKeySpec = new SecretKeySpec(bArr, "AES");
        this.f176s = secretKeySpec;
        if (A3.a.d(1)) {
            Cipher cipher = (Cipher) J3.i.f1928b.f1930a.k("AES/ECB/NoPadding");
            cipher.init(1, secretKeySpec);
            byte[] bArrM = android.support.v4.media.session.b.m(cipher.doFinal(new byte[16]));
            this.t = bArrM;
            this.f177u = android.support.v4.media.session.b.m(bArrM);
            return;
        }
        throw new GeneralSecurityException("Can not use AES-CMAC in FIPS-mode.");
    }

    public d(n nVar) {
        this.r = 11;
        this.f176s = nVar;
    }

    public d(Class cls) {
        this.r = 26;
        UUID uuidRandomUUID = UUID.randomUUID();
        A5.h.d(uuidRandomUUID, "randomUUID(...)");
        this.f176s = uuidRandomUUID;
        String string = ((UUID) this.f176s).toString();
        A5.h.d(string, "toString(...)");
        this.t = new p071l2.p(string, (F) null, cls.getName(), (String) null, (p018d2.j) null, (p018d2.j) null, 0L, 0L, 0L, (C0292e) null, 0, (EnumC0288a) null, 0L, 0L, 0L, 0L, false, (E) null, 0, 0L, 0, 0, (String) null, (Boolean) null, 33554426);
        String[] strArr = {cls.getName()};
        LinkedHashSet linkedHashSet = new LinkedHashSet(p081m5.r.Y(1));
        linkedHashSet.add(strArr[0]);
        this.f177u = linkedHashSet;
    }

    public d(p015d.e eVar) {
        this.r = 10;
        this.t = new CopyOnWriteArrayList();
        this.f177u = new HashMap();
        this.f176s = eVar;
    }

    public d(MediaCodec mediaCodec) {
        this.r = 9;
        this.f176s = mediaCodec;
        if (s.f9002a < 21) {
            this.t = mediaCodec.getInputBuffers();
            this.f177u = mediaCodec.getOutputBuffers();
        }
    }

    public d(N4.b bVar, FlutterJNI flutterJNI) {
        this.r = 18;
        i iVar = new i(this, 14);
        v vVar = new v(bVar, "flutter/accessibility", W4.w.f3735a, null);
        this.f176s = vVar;
        vVar.P(iVar);
        this.t = flutterJNI;
    }

    public d(x xVar) {
        this.r = 14;
        this.t = new HashSet();
        this.f177u = xVar;
        L4.p pVar = (L4.p) xVar;
        this.f176s = new w[]{new L4.u(pVar.getBinaryMessenger()), new b(new M4.i(pVar.getBinaryMessenger()))};
        new i(pVar.getBinaryMessenger()).f64s = this;
    }

    public d(int i6) {
        this.r = i6;
        switch (i6) {
            case 27:
                this.f176s = new AtomicBoolean(false);
                break;
            default:
                this.f176s = new ConcurrentLinkedQueue();
                break;
        }
    }

    public d(d dVar, W4.i iVar) {
        this.r = 20;
        this.f177u = dVar;
        this.t = new AtomicReference(null);
        this.f176s = iVar;
    }

    public d(io.flutter.plugins.firebase.messaging.a aVar) {
        this.r = 28;
        this.f177u = aVar;
        this.f176s = Executors.newSingleThreadExecutor();
        this.t = new Handler(Looper.getMainLooper());
    }

    public d(i iVar) {
        this.r = 23;
        this.f176s = iVar;
        this.t = new ReentrantLock();
        this.f177u = new WeakHashMap();
    }

    public d(ArrayDeque arrayDeque, BufferedReader bufferedReader) {
        this.r = 4;
        this.t = arrayDeque;
        this.f176s = bufferedReader;
    }
}
