package B0;

import java.util.ArrayList;
import p101q0.C0427o;
import p108r3.C;

/* JADX INFO: loaded from: classes.dex */
public final class k extends m implements A0.l {

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final n f244w;

    public k(C0427o c0427o, C c2, n nVar, ArrayList arrayList) {
        super(c0427o, c2, nVar, arrayList);
        this.f244w = nVar;
    }

    @Override // B0.m
    public final String a() {
        return null;
    }

    @Override // A0.l
    public final long c(long j6) {
        return this.f244w.g(j6);
    }

    @Override // A0.l
    public final long d(long j6, long j7) {
        return this.f244w.f(j6, j7);
    }

    @Override // B0.m
    public final j e() {
        return null;
    }

    @Override // A0.l
    public final long g(long j6, long j7) {
        return this.f244w.e(j6, j7);
    }

    @Override // A0.l
    public final long j(long j6, long j7) {
        return this.f244w.c(j6, j7);
    }

    @Override // A0.l
    public final long m(long j6, long j7) {
        n nVar = this.f244w;
        if (nVar.f252f != null) {
            return -9223372036854775807L;
        }
        long jB = nVar.b(j6, j7) + nVar.c(j6, j7);
        return (nVar.e(jB, j6) + nVar.g(jB)) - nVar.f255i;
    }

    @Override // A0.l
    public final j n(long j6) {
        return this.f244w.h(this, j6);
    }

    @Override // A0.l
    public final boolean q() {
        return this.f244w.i();
    }

    @Override // A0.l
    public final long s() {
        return this.f244w.f250d;
    }

    @Override // A0.l
    public final long w(long j6) {
        return this.f244w.d(j6);
    }

    @Override // A0.l
    public final long x(long j6, long j7) {
        return this.f244w.b(j6, j7);
    }

    @Override // B0.m
    public final A0.l b() {
        return this;
    }
}
