package B0;

/* JADX INFO: loaded from: classes.dex */
public final class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f224a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f225b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f226c;

    public f(String str, String str2, String str3) {
        this.f224a = str;
        this.f225b = str2;
        this.f226c = str3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && f.class == obj.getClass()) {
            f fVar = (f) obj;
            if (p117t0.s.a(this.f224a, fVar.f224a) && p117t0.s.a(this.f225b, fVar.f225b) && p117t0.s.a(this.f226c, fVar.f226c)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        int iHashCode = this.f224a.hashCode() * 31;
        String str = this.f225b;
        int iHashCode2 = (iHashCode + (str != null ? str.hashCode() : 0)) * 31;
        String str2 = this.f226c;
        return iHashCode2 + (str2 != null ? str2.hashCode() : 0);
    }
}
