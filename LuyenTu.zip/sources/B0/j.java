package B0;

import org.apache.tika.utils.StringUtils;

/* JADX INFO: loaded from: classes.dex */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f240a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f241b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f242c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f243d;

    public j(long j6, long j7, String str) {
        this.f242c = str == null ? StringUtils.EMPTY : str;
        this.f240a = j6;
        this.f241b = j7;
    }

    public final j a(j jVar, String str) {
        j jVar2;
        long j6;
        String strU = p117t0.a.u(str, this.f242c);
        if (jVar != null) {
            long j7 = jVar.f241b;
            if (strU.equals(p117t0.a.u(str, jVar.f242c))) {
                long j8 = this.f241b;
                if (j8 != -1) {
                    j6 = j7;
                    long j9 = this.f240a;
                    jVar2 = null;
                    if (j9 + j8 == jVar.f240a) {
                        return new j(j9, j6 != -1 ? j8 + j6 : -1L, strU);
                    }
                } else {
                    jVar2 = null;
                    j6 = j7;
                }
                if (j6 == -1) {
                    return jVar2;
                }
                long j10 = jVar.f240a;
                if (j10 + j6 == this.f240a) {
                    return new j(j10, j8 != -1 ? j6 + j8 : -1L, strU);
                }
                return jVar2;
            }
        }
        return null;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && j.class == obj.getClass()) {
            j jVar = (j) obj;
            if (this.f240a == jVar.f240a && this.f241b == jVar.f241b && this.f242c.equals(jVar.f242c)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        if (this.f243d == 0) {
            this.f243d = this.f242c.hashCode() + ((((527 + ((int) this.f240a)) * 31) + ((int) this.f241b)) * 31);
        }
        return this.f243d;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("RangedUri(referenceUri=");
        sb.append(this.f242c);
        sb.append(", start=");
        sb.append(this.f240a);
        sb.append(", length=");
        return A3.a.n(sb, this.f241b, ")");
    }
}
