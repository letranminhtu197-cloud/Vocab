package B0;

import java.math.RoundingMode;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public abstract class n extends s {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f250d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f251e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final List f252f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final long f253g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final long f254h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final long f255i;

    public n(j jVar, long j6, long j7, long j8, long j9, List list, long j10, long j11, long j12) {
        super(jVar, j6, j7);
        this.f250d = j8;
        this.f251e = j9;
        this.f252f = list;
        this.f255i = j10;
        this.f253g = j11;
        this.f254h = j12;
    }

    public final long b(long j6, long j7) {
        long jD = d(j6);
        return jD != -1 ? jD : (int) (f((j7 - this.f254h) + this.f255i, j6) - c(j6, j7));
    }

    public final long c(long j6, long j7) {
        long jD = d(j6);
        long j8 = this.f250d;
        if (jD == -1) {
            long j9 = this.f253g;
            if (j9 != -9223372036854775807L) {
                return Math.max(j8, f((j7 - this.f254h) - j9, j6));
            }
        }
        return j8;
    }

    public abstract long d(long j6);

    public final long e(long j6, long j7) {
        long j8 = this.f265b;
        long j9 = this.f250d;
        List list = this.f252f;
        if (list != null) {
            return (((q) list.get((int) (j6 - j9))).f261b * 1000000) / j8;
        }
        long jD = d(j7);
        return (jD == -1 || j6 != (j9 + jD) - 1) ? (this.f251e * 1000000) / j8 : j7 - g(j6);
    }

    public final long f(long j6, long j7) {
        long jD = d(j7);
        long j8 = this.f250d;
        if (jD != 0) {
            if (this.f252f != null) {
                long j9 = (jD + j8) - 1;
                long j10 = j8;
                while (j10 <= j9) {
                    long j11 = ((j9 - j10) / 2) + j10;
                    long jG = g(j11);
                    if (jG < j6) {
                        j10 = j11 + 1;
                    } else {
                        if (jG <= j6) {
                            return j11;
                        }
                        j9 = j11 - 1;
                    }
                }
                return j10 == j8 ? j10 : j9;
            }
            long j12 = (j6 / ((this.f251e * 1000000) / this.f265b)) + j8;
            if (j12 >= j8) {
                return jD == -1 ? j12 : Math.min(j12, (j8 + jD) - 1);
            }
        }
        return j8;
    }

    public final long g(long j6) {
        long j7 = this.f250d;
        List list = this.f252f;
        long j8 = list != null ? ((q) list.get((int) (j6 - j7))).f260a - this.f266c : (j6 - j7) * this.f251e;
        int i6 = p117t0.s.f9002a;
        return p117t0.s.P(j8, 1000000L, this.f265b, RoundingMode.FLOOR);
    }

    public abstract j h(k kVar, long j6);

    public boolean i() {
        return this.f252f != null;
    }
}
