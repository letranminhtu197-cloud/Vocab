package B0;

import android.net.Uri;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Pair;
import android.util.Xml;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.metadata.HttpHeaders;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;
import org.xml.sax.helpers.DefaultHandler;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;
import org.xmlpull.v1.XmlSerializer;
import p101q0.AbstractC0419g;
import p101q0.C0423k;
import p101q0.C0424l;
import p101q0.C0426n;
import p101q0.C0427o;
import p101q0.C0428p;
import p101q0.D;
import p108r3.A;
import p108r3.AbstractC0460q;
import p108r3.C;
import p108r3.T;

/* JADX INFO: loaded from: classes.dex */
public final class e extends DefaultHandler implements N0.q {

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final Pattern f221s = Pattern.compile("(\\d+)(?:/(\\d+))?");
    public static final Pattern t = Pattern.compile("CC([1-4])=.*");

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final Pattern f222u = Pattern.compile("([1-9]|[1-5][0-9]|6[0-3])=.*");

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final int[] f223v = {-1, 1, 2, 3, 4, 5, 6, 8, 2, 3, 4, 7, 8, 24, 8, 12, 10, 12, 14, 12, 14};
    public final XmlPullParserFactory r;

    public e() {
        try {
            this.r = XmlPullParserFactory.newInstance();
        } catch (XmlPullParserException e6) {
            throw new RuntimeException("Couldn't create XmlPullParserFactory instance", e6);
        }
    }

    public static long a(ArrayList arrayList, long j6, long j7, int i6, long j8) {
        int i7;
        if (i6 >= 0) {
            i7 = i6 + 1;
        } else {
            int i8 = p117t0.s.f9002a;
            i7 = (int) ((((j8 - j6) + j7) - 1) / j7);
        }
        for (int i9 = 0; i9 < i7; i9++) {
            arrayList.add(new q(j6, j7));
            j6 += j7;
        }
        return j6;
    }

    public static void b(XmlPullParser xmlPullParser) throws XmlPullParserException, IOException {
        if (xmlPullParser.getEventType() == 2) {
            int i6 = 1;
            while (i6 != 0) {
                xmlPullParser.next();
                if (xmlPullParser.getEventType() == 2) {
                    i6++;
                } else if (xmlPullParser.getEventType() == 3) {
                    i6--;
                }
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:45:0x0087 A[PHI: r0
  0x0087: PHI (r0v19 int) = (r0v5 int), (r0v22 int) binds: [B:96:0x0118, B:43:0x0083] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:56:0x00a7  */
    public static int c(XmlPullParser xmlPullParser) throws XmlPullParserException, IOException {
        int iBitCount;
        String attributeValue = xmlPullParser.getAttributeValue(null, "schemeIdUri");
        if (attributeValue == null) {
            attributeValue = null;
        }
        attributeValue.getClass();
        int i6 = 6;
        byte b6 = 4;
        int i7 = -1;
        switch (attributeValue) {
            case "urn:dts:dash:audio_channel_configuration:2012":
            case "tag:dts.com,2014:dash:audio_channel_configuration:2012":
                String attributeValue2 = xmlPullParser.getAttributeValue(null, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
                iBitCount = attributeValue2 == null ? -1 : Integer.parseInt(attributeValue2);
                if (iBitCount > 0 && iBitCount < 33) {
                    i7 = iBitCount;
                    break;
                }
                break;
            case "urn:mpeg:dash:23003:3:audio_channel_configuration:2011":
                String attributeValue3 = xmlPullParser.getAttributeValue(null, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
                if (attributeValue3 != null) {
                    i7 = Integer.parseInt(attributeValue3);
                    break;
                }
                break;
            case "tag:dolby.com,2014:dash:audio_channel_configuration:2011":
            case "urn:dolby:dash:audio_channel_configuration:2011":
                String attributeValue4 = xmlPullParser.getAttributeValue(null, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
                if (attributeValue4 != null) {
                    String strP = p000a.a.P(attributeValue4);
                    strP.getClass();
                    switch (strP.hashCode()) {
                        case 1596796:
                            b6 = !strP.equals("4000") ? (byte) -1 : (byte) 0;
                            break;
                        case 2937391:
                            b6 = !strP.equals("a000") ? (byte) -1 : (byte) 1;
                            break;
                        case 3094034:
                            b6 = !strP.equals("f800") ? (byte) -1 : (byte) 2;
                            break;
                        case 3094035:
                            b6 = !strP.equals("f801") ? (byte) -1 : (byte) 3;
                            break;
                        case 3133436:
                            if (!strP.equals("fa01")) {
                                b6 = -1;
                            }
                            break;
                        default:
                            b6 = -1;
                            break;
                    }
                    switch (b6) {
                        case 0:
                            i6 = 1;
                            break;
                        case 1:
                            i6 = 2;
                            break;
                        case 2:
                            i6 = 5;
                            break;
                        case 3:
                            break;
                        case 4:
                            i6 = 8;
                            break;
                        default:
                            i6 = -1;
                            break;
                    }
                } else {
                    i6 = -1;
                }
                i7 = i6;
                break;
            case "urn:mpeg:mpegB:cicp:ChannelConfiguration":
                String attributeValue5 = xmlPullParser.getAttributeValue(null, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
                int i8 = attributeValue5 == null ? -1 : Integer.parseInt(attributeValue5);
                if (i8 >= 0) {
                    int[] iArr = f223v;
                    if (i8 < iArr.length) {
                        i7 = iArr[i8];
                    }
                    break;
                }
                break;
            case "tag:dts.com,2018:uhd:audio_channel_configuration":
                String attributeValue6 = xmlPullParser.getAttributeValue(null, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
                if (attributeValue6 != null && (iBitCount = Integer.bitCount(Integer.parseInt(attributeValue6, 16))) != 0) {
                    i7 = iBitCount;
                    break;
                }
                break;
        }
        do {
            xmlPullParser.next();
        } while (!p117t0.a.q(xmlPullParser, "AudioChannelConfiguration"));
        return i7;
    }

    public static long d(XmlPullParser xmlPullParser, long j6) {
        String attributeValue = xmlPullParser.getAttributeValue(null, "availabilityTimeOffset");
        if (attributeValue == null) {
            return j6;
        }
        if ("INF".equals(attributeValue)) {
            return Long.MAX_VALUE;
        }
        return (long) (Float.parseFloat(attributeValue) * 1000000.0f);
    }

    public static ArrayList e(XmlPullParser xmlPullParser, ArrayList arrayList, boolean z6) throws XmlPullParserException, IOException {
        String attributeValue = xmlPullParser.getAttributeValue(null, "dvb:priority");
        int i6 = attributeValue != null ? Integer.parseInt(attributeValue) : z6 ? 1 : Integer.MIN_VALUE;
        String attributeValue2 = xmlPullParser.getAttributeValue(null, "dvb:weight");
        int i7 = attributeValue2 != null ? Integer.parseInt(attributeValue2) : 1;
        String attributeValue3 = xmlPullParser.getAttributeValue(null, "serviceLocation");
        String text = StringUtils.EMPTY;
        do {
            xmlPullParser.next();
            if (xmlPullParser.getEventType() == 4) {
                text = xmlPullParser.getText();
            } else {
                b(xmlPullParser);
            }
        } while (!p117t0.a.q(xmlPullParser, "BaseURL"));
        if (text != null && p117t0.a.o(text)[0] != -1) {
            if (attributeValue3 == null) {
                attributeValue3 = text;
            }
            return AbstractC0460q.k(new b(i6, i7, text, attributeValue3));
        }
        ArrayList arrayList2 = new ArrayList();
        for (int i8 = 0; i8 < arrayList.size(); i8++) {
            b bVar = (b) arrayList.get(i8);
            String strU = p117t0.a.u(bVar.f198a, text);
            String str = attributeValue3 == null ? strU : attributeValue3;
            if (z6) {
                i6 = bVar.f200c;
                i7 = bVar.f201d;
                str = bVar.f199b;
            }
            arrayList2.add(new b(i6, i7, strU, str));
        }
        return arrayList2;
    }

    /* JADX WARN: Code duplicated, block: B:52:0x00c1  */
    /* JADX WARN: Code duplicated, block: B:81:0x013d A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:82:0x013f  */
    /* JADX WARN: Code duplicated, block: B:89:0x0162  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r8v12 */
    /* JADX WARN: Type inference failed for: r8v13 */
    /* JADX WARN: Type inference failed for: r8v2 */
    /* JADX WARN: Type inference failed for: r8v26 */
    /* JADX WARN: Type inference failed for: r8v27 */
    /* JADX WARN: Type inference failed for: r8v28 */
    /* JADX WARN: Type inference failed for: r8v29 */
    /* JADX WARN: Type inference failed for: r8v3 */
    /* JADX WARN: Type inference failed for: r8v30 */
    /* JADX WARN: Type inference failed for: r8v31 */
    /* JADX WARN: Type inference failed for: r8v4, types: [byte[]] */
    /* JADX WARN: Type inference failed for: r9v0 */
    /* JADX WARN: Type inference failed for: r9v1 */
    /* JADX WARN: Type inference failed for: r9v15 */
    /* JADX WARN: Type inference failed for: r9v16 */
    /* JADX WARN: Type inference failed for: r9v17 */
    /* JADX WARN: Type inference failed for: r9v18 */
    /* JADX WARN: Type inference failed for: r9v19 */
    /* JADX WARN: Type inference failed for: r9v2 */
    /* JADX WARN: Type inference failed for: r9v20 */
    /* JADX WARN: Type inference failed for: r9v4, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r9v9 */
    public static Pair f(XmlPullParser xmlPullParser) throws XmlPullParserException, IOException {
        String attributeValue;
        UUID uuid;
        UUID uuid2;
        ?? text;
        ?? A2;
        UUID uuid3;
        String attributeValue2;
        String attributeValue3 = xmlPullParser.getAttributeValue(null, "schemeIdUri");
        if (attributeValue3 != null) {
            String strP = p000a.a.P(attributeValue3);
            strP.getClass();
            switch (strP) {
                case "urn:uuid:e2719d58-a985-b3c9-781a-b030af78d30e":
                    uuid = AbstractC0419g.f8327c;
                    attributeValue = null;
                    uuid2 = null;
                    text = uuid2;
                    A2 = uuid2;
                    break;
                case "urn:uuid:9a04f079-9840-4286-ab92-e65be0885f95":
                    uuid = AbstractC0419g.f8329e;
                    attributeValue = null;
                    uuid2 = null;
                    text = uuid2;
                    A2 = uuid2;
                    break;
                case "urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed":
                    uuid = AbstractC0419g.f8328d;
                    attributeValue = null;
                    uuid2 = null;
                    text = uuid2;
                    A2 = uuid2;
                    break;
                case "urn:mpeg:dash:mp4protection:2011":
                    attributeValue = xmlPullParser.getAttributeValue(null, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
                    int attributeCount = xmlPullParser.getAttributeCount();
                    int i6 = 0;
                    while (true) {
                        if (i6 >= attributeCount) {
                            attributeValue2 = null;
                        } else {
                            String attributeName = xmlPullParser.getAttributeName(i6);
                            int iIndexOf = attributeName.indexOf(58);
                            if (iIndexOf != -1) {
                                attributeName = attributeName.substring(iIndexOf + 1);
                            }
                            if (attributeName.equals("default_KID")) {
                                attributeValue2 = xmlPullParser.getAttributeValue(i6);
                            } else {
                                i6++;
                            }
                        }
                    }
                    if (!TextUtils.isEmpty(attributeValue2) && !"00000000-0000-0000-0000-000000000000".equals(attributeValue2)) {
                        String[] strArrSplit = attributeValue2.split("\\s+");
                        UUID[] uuidArr = new UUID[strArrSplit.length];
                        for (int i7 = 0; i7 < strArrSplit.length; i7++) {
                            uuidArr[i7] = UUID.fromString(strArrSplit[i7]);
                        }
                        uuid = AbstractC0419g.f8326b;
                        text = 0;
                        A2 = p070l1.q.a(uuid, uuidArr, null);
                        break;
                    } else {
                        p117t0.a.x("MpdParser", "Ignoring <ContentProtection> with schemeIdUri=\"urn:mpeg:dash:mp4protection:2011\" (ClearKey) due to missing required default_KID attribute.");
                        uuid = null;
                        uuid2 = uuid;
                        text = uuid2;
                        A2 = uuid2;
                        break;
                    }
                    break;
                default:
                    attributeValue = null;
                    uuid = null;
                    uuid2 = uuid;
                    text = uuid2;
                    A2 = uuid2;
                    break;
            }
        } else {
            attributeValue = null;
            uuid = null;
            uuid2 = uuid;
            text = uuid2;
            A2 = uuid2;
        }
        do {
            xmlPullParser.next();
            if ((p117t0.a.r(xmlPullParser, "clearkey:Laurl") || p117t0.a.r(xmlPullParser, "dashif:Laurl")) && xmlPullParser.next() == 4) {
                A2 = A2;
                text = xmlPullParser.getText();
            } else if (p117t0.a.r(xmlPullParser, "ms:laurl")) {
                A2 = A2;
                text = xmlPullParser.getAttributeValue(null, "licenseUrl");
            } else if (A2 == 0 && xmlPullParser.getEventType() == 2) {
                String name = xmlPullParser.getName();
                int iIndexOf2 = name.indexOf(58);
                if (iIndexOf2 != -1) {
                    name = name.substring(iIndexOf2 + 1);
                }
                if (name.equals("pssh") && xmlPullParser.next() == 4) {
                    byte[] bArrDecode = Base64.decode(xmlPullParser.getText(), 0);
                    A0.i iVarH = p070l1.q.h(bArrDecode);
                    UUID uuid4 = iVarH == null ? null : (UUID) iVarH.f64s;
                    if (uuid4 == null) {
                        p117t0.a.x("MpdParser", "Skipping malformed cenc:pssh data");
                        uuid = uuid4;
                        A2 = 0;
                        text = text;
                    } else {
                        UUID uuid5 = uuid4;
                        A2 = bArrDecode;
                        uuid = uuid5;
                        text = text;
                    }
                } else if (A2 == 0) {
                    uuid3 = AbstractC0419g.f8329e;
                    if (!uuid3.equals(uuid)) {
                        b(xmlPullParser);
                        A2 = A2;
                        text = text;
                    } else {
                        b(xmlPullParser);
                        A2 = A2;
                        text = text;
                    }
                } else {
                    b(xmlPullParser);
                    A2 = A2;
                    text = text;
                }
            } else if (A2 == 0) {
                uuid3 = AbstractC0419g.f8329e;
                if (!uuid3.equals(uuid) && p117t0.a.r(xmlPullParser, "mspr:pro") && xmlPullParser.next() == 4) {
                    A2 = p070l1.q.a(uuid3, null, Base64.decode(xmlPullParser.getText(), 0));
                    text = text;
                } else {
                    b(xmlPullParser);
                    A2 = A2;
                    text = text;
                }
            } else {
                b(xmlPullParser);
                A2 = A2;
                text = text;
            }
        } while (!p117t0.a.q(xmlPullParser, "ContentProtection"));
        return Pair.create(attributeValue, uuid != null ? new C0423k(uuid, text, "video/mp4", A2) : null);
    }

    public static int h(XmlPullParser xmlPullParser) {
        String attributeValue = xmlPullParser.getAttributeValue(null, "contentType");
        if (TextUtils.isEmpty(attributeValue)) {
            return -1;
        }
        if ("audio".equals(attributeValue)) {
            return 1;
        }
        if ("video".equals(attributeValue)) {
            return 2;
        }
        if ("text".equals(attributeValue)) {
            return 3;
        }
        return "image".equals(attributeValue) ? 4 : -1;
    }

    public static f i(XmlPullParser xmlPullParser, String str) throws XmlPullParserException, IOException {
        String attributeValue = xmlPullParser.getAttributeValue(null, "schemeIdUri");
        if (attributeValue == null) {
            attributeValue = StringUtils.EMPTY;
        }
        String attributeValue2 = xmlPullParser.getAttributeValue(null, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
        if (attributeValue2 == null) {
            attributeValue2 = null;
        }
        String attributeValue3 = xmlPullParser.getAttributeValue(null, "id");
        String str2 = attributeValue3 != null ? attributeValue3 : null;
        do {
            xmlPullParser.next();
        } while (!p117t0.a.q(xmlPullParser, str));
        return new f(attributeValue, attributeValue2, str2);
    }

    public static long j(XmlPullParser xmlPullParser, String str, long j6) {
        String attributeValue = xmlPullParser.getAttributeValue(null, str);
        if (attributeValue == null) {
            return j6;
        }
        Matcher matcher = p117t0.s.f9010i.matcher(attributeValue);
        if (!matcher.matches()) {
            return (long) (Double.parseDouble(attributeValue) * 3600.0d * 1000.0d);
        }
        boolean zIsEmpty = TextUtils.isEmpty(matcher.group(1));
        String strGroup = matcher.group(3);
        double d6 = strGroup != null ? Double.parseDouble(strGroup) * 3.1556908E7d : 0.0d;
        String strGroup2 = matcher.group(5);
        double d7 = d6 + (strGroup2 != null ? Double.parseDouble(strGroup2) * 2629739.0d : 0.0d);
        String strGroup3 = matcher.group(7);
        double d8 = d7 + (strGroup3 != null ? Double.parseDouble(strGroup3) * 86400.0d : 0.0d);
        String strGroup4 = matcher.group(10);
        double d9 = d8 + (strGroup4 != null ? Double.parseDouble(strGroup4) * 3600.0d : 0.0d);
        String strGroup5 = matcher.group(12);
        double d10 = d9 + (strGroup5 != null ? Double.parseDouble(strGroup5) * 60.0d : 0.0d);
        String strGroup6 = matcher.group(14);
        long j7 = (long) ((d10 + (strGroup6 != null ? Double.parseDouble(strGroup6) : 0.0d)) * 1000.0d);
        return !zIsEmpty ? -j7 : j7;
    }

    public static float k(XmlPullParser xmlPullParser, float f4) {
        String attributeValue = xmlPullParser.getAttributeValue(null, "frameRate");
        if (attributeValue != null) {
            Matcher matcher = f221s.matcher(attributeValue);
            if (matcher.matches()) {
                int i6 = Integer.parseInt(matcher.group(1));
                String strGroup = matcher.group(2);
                return !TextUtils.isEmpty(strGroup) ? i6 / Integer.parseInt(strGroup) : i6;
            }
        }
        return f4;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:290:0x08a9 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:291:0x08ab  */
    /* JADX WARN: Code duplicated, block: B:292:0x08ad  */
    /* JADX WARN: Code duplicated, block: B:294:0x08b5  */
    /* JADX WARN: Code duplicated, block: B:301:0x08cb  */
    /* JADX WARN: Code duplicated, block: B:303:0x08d1 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:305:0x08d4  */
    /* JADX WARN: Code duplicated, block: B:307:0x08dc  */
    /* JADX WARN: Code duplicated, block: B:313:0x08ee  */
    /* JADX WARN: Code duplicated, block: B:318:0x08fb  */
    /* JADX WARN: Code duplicated, block: B:321:0x0909  */
    /* JADX WARN: Code duplicated, block: B:323:0x0915  */
    /* JADX WARN: Code duplicated, block: B:324:0x0918  */
    /* JADX WARN: Code duplicated, block: B:327:0x0921  */
    /* JADX WARN: Code duplicated, block: B:330:0x092c  */
    /* JADX WARN: Code duplicated, block: B:345:0x096a  */
    /* JADX WARN: Code duplicated, block: B:349:0x0977  */
    /* JADX WARN: Code duplicated, block: B:351:0x0989  */
    /* JADX WARN: Code duplicated, block: B:353:0x098d  */
    /* JADX WARN: Code duplicated, block: B:354:0x098f  */
    /* JADX WARN: Code duplicated, block: B:365:0x09b5  */
    /* JADX WARN: Code duplicated, block: B:367:0x09c5  */
    /* JADX WARN: Code duplicated, block: B:368:0x09ce  */
    /* JADX WARN: Code duplicated, block: B:373:0x09dd  */
    /* JADX WARN: Code duplicated, block: B:375:0x09f5  */
    /* JADX WARN: Code duplicated, block: B:377:0x09fd  */
    /* JADX WARN: Code duplicated, block: B:379:0x0a07 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:380:0x0a09  */
    /* JADX WARN: Code duplicated, block: B:381:0x0a0b  */
    /* JADX WARN: Code duplicated, block: B:383:0x0a12  */
    /* JADX WARN: Code duplicated, block: B:384:0x0a14  */
    /* JADX WARN: Code duplicated, block: B:387:0x0a1d  */
    /* JADX WARN: Code duplicated, block: B:388:0x0a1f  */
    /* JADX WARN: Code duplicated, block: B:391:0x0a28  */
    /* JADX WARN: Code duplicated, block: B:392:0x0a2a  */
    /* JADX WARN: Code duplicated, block: B:395:0x0a33  */
    /* JADX WARN: Code duplicated, block: B:396:0x0a35  */
    /* JADX WARN: Code duplicated, block: B:399:0x0a3e  */
    /* JADX WARN: Code duplicated, block: B:400:0x0a41  */
    /* JADX WARN: Code duplicated, block: B:403:0x0a4a  */
    /* JADX WARN: Code duplicated, block: B:406:0x0a4f  */
    /* JADX WARN: Code duplicated, block: B:407:0x0a52  */
    /* JADX WARN: Code duplicated, block: B:408:0x0a55  */
    /* JADX WARN: Code duplicated, block: B:409:0x0a57  */
    /* JADX WARN: Code duplicated, block: B:410:0x0a5a  */
    /* JADX WARN: Code duplicated, block: B:411:0x0a5d  */
    /* JADX WARN: Code duplicated, block: B:416:0x0a80  */
    /* JADX WARN: Code duplicated, block: B:418:0x0a90  */
    /* JADX WARN: Code duplicated, block: B:421:0x0a9b  */
    /* JADX WARN: Code duplicated, block: B:422:0x0a9e  */
    /* JADX WARN: Code duplicated, block: B:427:0x0ab0  */
    /* JADX WARN: Code duplicated, block: B:434:0x0af6  */
    /* JADX WARN: Code duplicated, block: B:435:0x0aff  */
    /* JADX WARN: Code duplicated, block: B:438:0x0b04  */
    /* JADX WARN: Code duplicated, block: B:439:0x0b0d  */
    /* JADX WARN: Code duplicated, block: B:442:0x0b16  */
    /* JADX WARN: Code duplicated, block: B:443:0x0b24  */
    /* JADX WARN: Code duplicated, block: B:445:0x0b2e  */
    /* JADX WARN: Code duplicated, block: B:446:0x0b36  */
    /* JADX WARN: Code duplicated, block: B:448:0x0b3c  */
    /* JADX WARN: Code duplicated, block: B:450:0x0b46  */
    /* JADX WARN: Code duplicated, block: B:453:0x0b4e  */
    /* JADX WARN: Code duplicated, block: B:455:0x0b60 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:461:0x0b87  */
    /* JADX WARN: Code duplicated, block: B:463:0x0b8f  */
    /* JADX WARN: Code duplicated, block: B:466:0x0b97  */
    /* JADX WARN: Code duplicated, block: B:468:0x0ba9 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:474:0x0bcd  */
    /* JADX WARN: Code duplicated, block: B:476:0x0bd1  */
    /* JADX WARN: Code duplicated, block: B:478:0x0bd7  */
    /* JADX WARN: Code duplicated, block: B:481:0x0be2  */
    /* JADX WARN: Code duplicated, block: B:482:0x0be5  */
    /* JADX WARN: Code duplicated, block: B:485:0x0bfe  */
    /* JADX WARN: Code duplicated, block: B:487:0x0c07  */
    /* JADX WARN: Code duplicated, block: B:490:0x0c1c  */
    /* JADX WARN: Code duplicated, block: B:492:0x0c20  */
    /* JADX WARN: Code duplicated, block: B:494:0x0c23 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:495:0x0c25  */
    /* JADX WARN: Code duplicated, block: B:496:0x0c27  */
    /* JADX WARN: Code duplicated, block: B:499:0x0c4f A[LOOP:11: B:244:0x0676->B:499:0x0c4f, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:533:0x0e29  */
    /* JADX WARN: Code duplicated, block: B:538:0x0e42  */
    /* JADX WARN: Code duplicated, block: B:541:0x0e4c  */
    /* JADX WARN: Code duplicated, block: B:544:0x0e61  */
    /* JADX WARN: Code duplicated, block: B:547:0x0e69  */
    /* JADX WARN: Code duplicated, block: B:556:0x0e92  */
    /* JADX WARN: Code duplicated, block: B:559:0x0e9a  */
    /* JADX WARN: Code duplicated, block: B:564:0x0ec1  */
    /* JADX WARN: Code duplicated, block: B:568:0x0ed4  */
    /* JADX WARN: Code duplicated, block: B:571:0x0edf  */
    /* JADX WARN: Code duplicated, block: B:574:0x0ee7  */
    /* JADX WARN: Code duplicated, block: B:591:0x0f25  */
    /* JADX WARN: Code duplicated, block: B:594:0x0f3f  */
    /* JADX WARN: Code duplicated, block: B:595:0x0f47  */
    /* JADX WARN: Code duplicated, block: B:597:0x0f4b  */
    /* JADX WARN: Code duplicated, block: B:603:0x0f98 A[LOOP:5: B:159:0x0402->B:603:0x0f98, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:714:0x134c  */
    /* JADX WARN: Code duplicated, block: B:716:0x1350  */
    /* JADX WARN: Code duplicated, block: B:718:0x1354 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:720:0x1357  */
    /* JADX WARN: Code duplicated, block: B:724:0x1365  */
    /* JADX WARN: Code duplicated, block: B:726:0x1375  */
    /* JADX WARN: Code duplicated, block: B:728:0x137c A[LOOP:1: B:45:0x00cd->B:728:0x137c, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:734:0x0f63 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:736:0x1348 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:740:0x0e18 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:744:0x0e88 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:751:0x0f1a A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:759:0x08a3 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:761:0x095d A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:767:0x09a2 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:775:0x0ace A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:777:0x0bcd A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:780:0x0b82 A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:782:0x0bcd A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:785:0x0bca A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:787:0x08ab A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:791:0x08ab A[SYNTHETIC] */
    /* JADX WARN: Multi-variable type inference failed */
    public static c l(XmlPullParser xmlPullParser, Uri uri) throws XmlPullParserException, IOException {
        int i6;
        boolean z6;
        int i7;
        long j6;
        long j7;
        int i8;
        long j8;
        String str;
        ArrayList arrayList;
        String str2;
        ArrayList arrayList2;
        String str3;
        String str4;
        long j9;
        long j10;
        ByteArrayOutputStream byteArrayOutputStream;
        String str5;
        String str6;
        long j11;
        ByteArrayOutputStream byteArrayOutputStream2;
        ArrayList arrayList3;
        int i9;
        String str7;
        ArrayList arrayList4;
        long j12;
        String str8;
        ArrayList arrayList5;
        long j13;
        long j14;
        ArrayList arrayList6;
        String str9;
        String str10;
        int i10;
        float f4;
        int i11;
        String str11;
        String str12;
        String str13;
        String str14;
        String str15;
        long j15;
        String str16;
        String str17;
        long j16;
        ArrayList arrayList7;
        long j17;
        ArrayList arrayList8;
        s sVarR;
        int i12;
        String str18;
        String strC;
        String str19;
        String[] strArrR;
        int length;
        int i13;
        String strC2;
        ArrayList arrayList9;
        String str20;
        int i14;
        int i15;
        ArrayList arrayList10;
        int iN;
        int i16;
        int i17;
        int i18;
        ArrayList arrayList11;
        int i19;
        Pair pairCreate;
        C0426n c0426n;
        int iIntValue;
        int iIntValue2;
        int i20;
        int i21;
        String str21;
        int i22;
        int i23;
        String str22;
        s rVar;
        ArrayList arrayList12;
        int iG;
        int i24;
        boolean z7;
        f fVar;
        String str23;
        String[] strArrSplit;
        int i25;
        f fVar2;
        String str24;
        String str25;
        int i26;
        int iN2;
        f fVar3;
        int i27;
        f fVar4;
        String str26;
        int i28;
        int i29;
        String str27;
        String[] strArrR2;
        int length2;
        int i30;
        ArrayList arrayList13;
        int i31;
        C0426n c0426nA;
        String str28;
        String str29;
        ArrayList arrayList14;
        String str30;
        long j18;
        ArrayList arrayList15;
        C0427o c0427o;
        C c2;
        s sVar;
        m kVar;
        int i32;
        String str31;
        int i33;
        C0423k c0423k;
        int size;
        C0423k c0423k2;
        int i34;
        C0423k c0423k3;
        C0423k c0423k4;
        int i35 = 0;
        String[] strArrSplit2 = new String[0];
        String str32 = null;
        String attributeValue = xmlPullParser.getAttributeValue(null, "profiles");
        if (attributeValue != null) {
            strArrSplit2 = attributeValue.split(",");
        }
        int length3 = strArrSplit2.length;
        int i36 = 0;
        while (true) {
            i6 = 1;
            if (i36 >= length3) {
                z6 = false;
                break;
            }
            if (strArrSplit2[i36].startsWith("urn:dvb:dash:profile:dvb-dash:")) {
                z6 = true;
                break;
            }
            i36++;
        }
        String attributeValue2 = xmlPullParser.getAttributeValue(null, "availabilityStartTime");
        long j19 = -9223372036854775807L;
        long jK = attributeValue2 == null ? -9223372036854775807L : p117t0.s.K(attributeValue2);
        long j20 = j(xmlPullParser, "mediaPresentationDuration", -9223372036854775807L);
        long j21 = j(xmlPullParser, "minBufferTime", -9223372036854775807L);
        boolean zEquals = "dynamic".equals(xmlPullParser.getAttributeValue(null, "type"));
        long j22 = zEquals ? j(xmlPullParser, "minimumUpdatePeriod", -9223372036854775807L) : -9223372036854775807L;
        long j23 = zEquals ? j(xmlPullParser, "timeShiftBufferDepth", -9223372036854775807L) : -9223372036854775807L;
        long j24 = zEquals ? j(xmlPullParser, "suggestedPresentationDelay", -9223372036854775807L) : -9223372036854775807L;
        String attributeValue3 = xmlPullParser.getAttributeValue(null, "publishTime");
        long jK2 = attributeValue3 == null ? -9223372036854775807L : p117t0.s.K(attributeValue3);
        long jD = zEquals ? 0L : -9223372036854775807L;
        ArrayList arrayListK = AbstractC0460q.k(new b(z6 ? 1 : Integer.MIN_VALUE, 1, uri.toString(), uri.toString()));
        ArrayList arrayList16 = new ArrayList();
        ArrayList arrayList17 = new ArrayList();
        long j25 = zEquals ? -9223372036854775807L : 0L;
        int i37 = 0;
        int i38 = 0;
        i iVar = null;
        u uVar = null;
        Uri uriV = null;
        t tVar = null;
        while (true) {
            xmlPullParser.next();
            String str33 = "BaseURL";
            if (p117t0.a.r(xmlPullParser, "BaseURL")) {
                if (i37 == 0) {
                    jD = d(xmlPullParser, jD);
                    i37 = i6;
                }
                arrayList17.addAll(e(xmlPullParser, arrayListK, z6));
                arrayListK = arrayListK;
                j25 = j25;
                z6 = z6;
                i8 = i35;
                i7 = i6;
                arrayList16 = arrayList16;
                j6 = j19;
            } else {
                i7 = i6;
                j6 = j19;
                String str34 = "lang";
                if (p117t0.a.r(xmlPullParser, "ProgramInformation")) {
                    String attributeValue4 = xmlPullParser.getAttributeValue(str32, "moreInformationURL");
                    String str35 = attributeValue4 == null ? str32 : attributeValue4;
                    String attributeValue5 = xmlPullParser.getAttributeValue(str32, "lang");
                    String str36 = attributeValue5 == null ? str32 : attributeValue5;
                    String strNextText = str32;
                    String strNextText2 = strNextText;
                    String strNextText3 = strNextText2;
                    while (true) {
                        xmlPullParser.next();
                        if (p117t0.a.r(xmlPullParser, "Title")) {
                            strNextText = xmlPullParser.nextText();
                        } else if (p117t0.a.r(xmlPullParser, "Source")) {
                            strNextText2 = xmlPullParser.nextText();
                        } else if (p117t0.a.r(xmlPullParser, "Copyright")) {
                            strNextText3 = xmlPullParser.nextText();
                        } else {
                            b(xmlPullParser);
                        }
                        String str37 = strNextText;
                        String str38 = strNextText2;
                        String str39 = strNextText3;
                        if (p117t0.a.q(xmlPullParser, "ProgramInformation")) {
                            iVar = new i(str37, str38, str39, str35, str36);
                        } else {
                            strNextText = str37;
                            strNextText2 = str38;
                            strNextText3 = str39;
                        }
                    }
                } else {
                    String str40 = "schemeIdUri";
                    if (p117t0.a.r(xmlPullParser, "UTCTiming")) {
                        arrayListK = arrayListK;
                        j25 = j25;
                        uVar = new u(xmlPullParser.getAttributeValue(str32, "schemeIdUri"), 0, xmlPullParser.getAttributeValue(str32, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR));
                        z6 = z6;
                        i8 = 0;
                        arrayList16 = arrayList16;
                        j6 = j6;
                    } else if (p117t0.a.r(xmlPullParser, HttpHeaders.LOCATION)) {
                        uriV = p117t0.a.v(uri.toString(), xmlPullParser.nextText());
                    } else if (p117t0.a.r(xmlPullParser, "ServiceDescription")) {
                        long j26 = j6;
                        long j27 = j26;
                        long j28 = j27;
                        float f7 = -3.4028235E38f;
                        float f8 = -3.4028235E38f;
                        while (true) {
                            xmlPullParser.next();
                            if (p117t0.a.r(xmlPullParser, "Latency")) {
                                arrayListK = arrayListK;
                                String attributeValue6 = xmlPullParser.getAttributeValue(null, "target");
                                j26 = attributeValue6 == null ? j6 : Long.parseLong(attributeValue6);
                                String attributeValue7 = xmlPullParser.getAttributeValue(null, "min");
                                j27 = attributeValue7 == null ? j6 : Long.parseLong(attributeValue7);
                                String attributeValue8 = xmlPullParser.getAttributeValue(null, "max");
                                j28 = attributeValue8 == null ? j6 : Long.parseLong(attributeValue8);
                            } else {
                                arrayListK = arrayListK;
                                if (p117t0.a.r(xmlPullParser, "PlaybackRate")) {
                                    String attributeValue9 = xmlPullParser.getAttributeValue(null, "min");
                                    f7 = attributeValue9 == null ? -3.4028235E38f : Float.parseFloat(attributeValue9);
                                    String attributeValue10 = xmlPullParser.getAttributeValue(null, "max");
                                    f8 = attributeValue10 == null ? -3.4028235E38f : Float.parseFloat(attributeValue10);
                                }
                            }
                            long j29 = j26;
                            long j30 = jD;
                            long j31 = j27;
                            long j32 = j23;
                            long j33 = j28;
                            if (p117t0.a.q(xmlPullParser, "ServiceDescription")) {
                                t tVar2 = new t();
                                tVar2.f267a = j29;
                                tVar2.f268b = j31;
                                tVar2.f269c = j33;
                                tVar2.f270d = f7;
                                tVar2.f271e = f8;
                                z6 = z6;
                                j7 = j32;
                                tVar = tVar2;
                                j25 = j25;
                                arrayList16 = arrayList16;
                                j6 = j6;
                                jD = j30;
                                i8 = 0;
                                arrayList17 = arrayList17;
                            } else {
                                j28 = j33;
                                j23 = j32;
                                arrayListK = arrayListK;
                                j27 = j31;
                                jD = j30;
                                j26 = j29;
                            }
                        }
                    } else {
                        arrayListK = arrayListK;
                        long j34 = jD;
                        long j35 = j23;
                        if (p117t0.a.r(xmlPullParser, "Period") && i38 == 0) {
                            ArrayList arrayList18 = !arrayList17.isEmpty() ? arrayList17 : arrayListK;
                            String str41 = "id";
                            String attributeValue11 = xmlPullParser.getAttributeValue(null, "id");
                            long j36 = j(xmlPullParser, "start", j25);
                            String str42 = "duration";
                            long j37 = jK != j6 ? jK + j36 : j6;
                            long j38 = j(xmlPullParser, "duration", j6);
                            ArrayList arrayList19 = new ArrayList();
                            ArrayList arrayList20 = new ArrayList();
                            ArrayList arrayList21 = new ArrayList();
                            long j39 = j6;
                            String str43 = MimeTypesReaderMetKeys.MATCH_VALUE_ATTR;
                            Object obj = "Period";
                            long jD2 = j34;
                            int i39 = 0;
                            s sVarR2 = null;
                            while (true) {
                                xmlPullParser.next();
                                if (p117t0.a.r(xmlPullParser, str33)) {
                                    if (i39 == 0) {
                                        jD2 = d(xmlPullParser, jD2);
                                        i39 = i7;
                                    }
                                    arrayList21.addAll(e(xmlPullParser, arrayList18, z6));
                                    arrayList17 = arrayList17;
                                    j10 = j38;
                                    arrayList = arrayList18;
                                    str2 = str34;
                                    str4 = str41;
                                    j25 = j25;
                                    str33 = str33;
                                    str3 = str42;
                                    arrayList2 = arrayList21;
                                    j8 = jD2;
                                    str = str40;
                                    arrayList16 = arrayList16;
                                    j9 = j37;
                                    j6 = -9223372036854775807L;
                                    i8 = 0;
                                    z6 = z6;
                                    j7 = j35;
                                } else {
                                    j8 = jD2;
                                    str = str40;
                                    if (p117t0.a.r(xmlPullParser, "AdaptationSet")) {
                                        if (arrayList21.isEmpty()) {
                                            arrayList3 = arrayList18;
                                            arrayList = arrayList3;
                                        } else {
                                            arrayList = arrayList18;
                                            arrayList3 = arrayList21;
                                        }
                                        String attributeValue12 = xmlPullParser.getAttributeValue(null, str41);
                                        long j40 = attributeValue12 == null ? -1L : Long.parseLong(attributeValue12);
                                        int iH = h(xmlPullParser);
                                        String str44 = "SegmentTemplate";
                                        String str45 = "mimeType";
                                        String attributeValue13 = xmlPullParser.getAttributeValue(null, "mimeType");
                                        String str46 = "AdaptationSet";
                                        String attributeValue14 = xmlPullParser.getAttributeValue(null, "codecs");
                                        arrayList17 = arrayList17;
                                        String attributeValue15 = xmlPullParser.getAttributeValue(null, "width");
                                        int i40 = attributeValue15 == null ? -1 : Integer.parseInt(attributeValue15);
                                        j25 = j25;
                                        String attributeValue16 = xmlPullParser.getAttributeValue(null, "height");
                                        int i41 = attributeValue16 == null ? -1 : Integer.parseInt(attributeValue16);
                                        float fK = k(xmlPullParser, -1.0f);
                                        String str47 = str42;
                                        String attributeValue17 = xmlPullParser.getAttributeValue(null, "audioSamplingRate");
                                        int i42 = attributeValue17 == null ? -1 : Integer.parseInt(attributeValue17);
                                        String attributeValue18 = xmlPullParser.getAttributeValue(null, str34);
                                        arrayList2 = arrayList21;
                                        String attributeValue19 = xmlPullParser.getAttributeValue(null, "label");
                                        ArrayList arrayList22 = new ArrayList();
                                        ArrayList arrayList23 = new ArrayList();
                                        String str48 = attributeValue19;
                                        ArrayList arrayList24 = new ArrayList();
                                        ArrayList arrayList25 = new ArrayList();
                                        String str49 = "SegmentList";
                                        ArrayList arrayList26 = new ArrayList();
                                        String str50 = "SegmentBase";
                                        ArrayList arrayList27 = new ArrayList();
                                        String str51 = "audioSamplingRate";
                                        ArrayList arrayList28 = new ArrayList();
                                        float f9 = fK;
                                        ArrayList arrayList29 = new ArrayList();
                                        ArrayList arrayList30 = new ArrayList();
                                        String str52 = "height";
                                        String str53 = str41;
                                        String str54 = "codecs";
                                        String str55 = "width";
                                        s sVarR3 = sVarR2;
                                        long j41 = j39;
                                        long jD3 = j8;
                                        int i43 = iH;
                                        String str56 = attributeValue18;
                                        int i44 = 0;
                                        String str57 = null;
                                        int iC = -1;
                                        while (true) {
                                            xmlPullParser.next();
                                            if (p117t0.a.r(xmlPullParser, str33)) {
                                                if (i44 == 0) {
                                                    jD3 = d(xmlPullParser, jD3);
                                                    i44 = i7;
                                                }
                                                jD3 = jD3;
                                                arrayList30.addAll(e(xmlPullParser, arrayList3, z6));
                                            } else {
                                                jD3 = jD3;
                                                if (p117t0.a.r(xmlPullParser, "ContentProtection")) {
                                                    Pair pairF = f(xmlPullParser);
                                                    Object obj2 = pairF.first;
                                                    if (obj2 != null) {
                                                        str57 = (String) obj2;
                                                    }
                                                    Object obj3 = pairF.second;
                                                    if (obj3 != null) {
                                                        arrayList23.add((C0423k) obj3);
                                                    }
                                                } else if (p117t0.a.r(xmlPullParser, "ContentComponent")) {
                                                    String attributeValue20 = xmlPullParser.getAttributeValue(null, str34);
                                                    if (str56 == null) {
                                                        str56 = attributeValue20;
                                                    } else if (attributeValue20 != null) {
                                                        p117t0.a.h(str56.equals(attributeValue20));
                                                    }
                                                    int iH2 = h(xmlPullParser);
                                                    if (i43 == -1) {
                                                        i43 = iH2;
                                                    } else if (iH2 != -1) {
                                                        p117t0.a.h(i43 == iH2 ? i7 : 0);
                                                    }
                                                    String str58 = str46;
                                                    i43 = i43;
                                                    str10 = str58;
                                                    str56 = str56;
                                                    jD3 = jD3;
                                                    i8 = 0;
                                                    arrayList30 = arrayList30;
                                                    arrayList4 = arrayList28;
                                                    str9 = str34;
                                                    arrayList6 = arrayList22;
                                                    j12 = j37;
                                                    str8 = str51;
                                                    long j42 = j35;
                                                    arrayList3 = arrayList3;
                                                    z6 = z6;
                                                    j10 = j38;
                                                    arrayList17 = arrayList17;
                                                    arrayList5 = arrayList25;
                                                    arrayList16 = arrayList16;
                                                    j13 = j42;
                                                } else {
                                                    if (p117t0.a.r(xmlPullParser, "Role")) {
                                                        arrayList26.add(i(xmlPullParser, "Role"));
                                                        i9 = i43;
                                                    } else {
                                                        String str59 = "AudioChannelConfiguration";
                                                        if (p117t0.a.r(xmlPullParser, "AudioChannelConfiguration")) {
                                                            str10 = str46;
                                                            iC = c(xmlPullParser);
                                                            str56 = str56;
                                                            jD3 = jD3;
                                                            i8 = 0;
                                                            arrayList30 = arrayList30;
                                                            arrayList4 = arrayList28;
                                                            str9 = str34;
                                                            arrayList6 = arrayList22;
                                                            j12 = j37;
                                                            str8 = str51;
                                                            long j43 = j35;
                                                            arrayList3 = arrayList3;
                                                            z6 = z6;
                                                            j10 = j38;
                                                            arrayList17 = arrayList17;
                                                            arrayList5 = arrayList25;
                                                            arrayList16 = arrayList16;
                                                            j13 = j43;
                                                        } else {
                                                            i9 = i43;
                                                            if (p117t0.a.r(xmlPullParser, "Accessibility")) {
                                                                arrayList25.add(i(xmlPullParser, "Accessibility"));
                                                            } else if (p117t0.a.r(xmlPullParser, "EssentialProperty")) {
                                                                arrayList27.add(i(xmlPullParser, "EssentialProperty"));
                                                            } else {
                                                                arrayList26 = arrayList26;
                                                                if (p117t0.a.r(xmlPullParser, "SupplementalProperty")) {
                                                                    arrayList28.add(i(xmlPullParser, "SupplementalProperty"));
                                                                    arrayList27 = arrayList27;
                                                                    str45 = str45;
                                                                    arrayList19 = arrayList19;
                                                                    arrayList20 = arrayList20;
                                                                    str44 = str44;
                                                                    str7 = str46;
                                                                    str47 = str47;
                                                                    str48 = str48;
                                                                    arrayList24 = arrayList24;
                                                                    str49 = str49;
                                                                    str50 = str50;
                                                                    f9 = f9;
                                                                    arrayList29 = arrayList29;
                                                                    str55 = str55;
                                                                    str53 = str53;
                                                                    j14 = j41;
                                                                    i8 = 0;
                                                                    arrayList30 = arrayList30;
                                                                    arrayList4 = arrayList28;
                                                                    str9 = str34;
                                                                    arrayList6 = arrayList22;
                                                                    j12 = j37;
                                                                    str8 = str51;
                                                                    long j44 = j35;
                                                                    arrayList3 = arrayList3;
                                                                    z6 = z6;
                                                                    j10 = j38;
                                                                    arrayList17 = arrayList17;
                                                                    arrayList5 = arrayList25;
                                                                    arrayList16 = arrayList16;
                                                                    j13 = j44;
                                                                    i9 = i9;
                                                                    j41 = j14;
                                                                    i43 = i9;
                                                                    str10 = str7;
                                                                } else {
                                                                    String str60 = "SupplementalProperty";
                                                                    String str61 = "Representation";
                                                                    String str62 = "InbandEventStream";
                                                                    if (p117t0.a.r(xmlPullParser, "Representation")) {
                                                                        ArrayList arrayList31 = !arrayList30.isEmpty() ? arrayList30 : arrayList3;
                                                                        String str63 = str34;
                                                                        String str64 = "ContentProtection";
                                                                        String str65 = str53;
                                                                        String str66 = "EssentialProperty";
                                                                        String attributeValue21 = xmlPullParser.getAttributeValue(null, str65);
                                                                        str53 = str65;
                                                                        String attributeValue22 = xmlPullParser.getAttributeValue(null, "bandwidth");
                                                                        int i45 = attributeValue22 == null ? -1 : Integer.parseInt(attributeValue22);
                                                                        String attributeValue23 = xmlPullParser.getAttributeValue(null, str45);
                                                                        String str67 = str54;
                                                                        int i46 = i45;
                                                                        String str68 = attributeValue23 == null ? attributeValue13 : attributeValue23;
                                                                        String attributeValue24 = xmlPullParser.getAttributeValue(null, str67);
                                                                        str54 = str67;
                                                                        str55 = str55;
                                                                        String str69 = attributeValue24 == null ? attributeValue14 : attributeValue24;
                                                                        String attributeValue25 = xmlPullParser.getAttributeValue(null, str55);
                                                                        if (attributeValue25 == null) {
                                                                            str52 = str52;
                                                                            i10 = i40;
                                                                        } else {
                                                                            str52 = str52;
                                                                            i10 = Integer.parseInt(attributeValue25);
                                                                        }
                                                                        String attributeValue26 = xmlPullParser.getAttributeValue(null, str52);
                                                                        if (attributeValue26 == null) {
                                                                            f4 = f9;
                                                                            i11 = i41;
                                                                        } else {
                                                                            f4 = f9;
                                                                            i11 = Integer.parseInt(attributeValue26);
                                                                        }
                                                                        int i47 = i10;
                                                                        float fK2 = k(xmlPullParser, f4);
                                                                        f9 = f4;
                                                                        String str70 = str51;
                                                                        String attributeValue27 = xmlPullParser.getAttributeValue(null, str70);
                                                                        int i48 = attributeValue27 == null ? i42 : Integer.parseInt(attributeValue27);
                                                                        ArrayList arrayList32 = new ArrayList();
                                                                        ArrayList arrayList33 = new ArrayList();
                                                                        ArrayList arrayList34 = new ArrayList(arrayList27);
                                                                        arrayList27 = arrayList27;
                                                                        ArrayList arrayList35 = new ArrayList(arrayList28);
                                                                        ArrayList arrayList36 = new ArrayList();
                                                                        int i49 = i48;
                                                                        str8 = str70;
                                                                        String str71 = str56;
                                                                        arrayList23 = arrayList23;
                                                                        s sVarP = sVarR3;
                                                                        long j45 = j41;
                                                                        int iC2 = iC;
                                                                        long jD4 = jD3;
                                                                        int i50 = 0;
                                                                        String str72 = null;
                                                                        while (true) {
                                                                            xmlPullParser.next();
                                                                            if (p117t0.a.r(xmlPullParser, str33)) {
                                                                                if (i50 == 0) {
                                                                                    jD4 = d(xmlPullParser, jD4);
                                                                                    i50 = i7;
                                                                                }
                                                                                str11 = attributeValue21;
                                                                                arrayList36.addAll(e(xmlPullParser, arrayList31, z6));
                                                                            } else {
                                                                                str11 = attributeValue21;
                                                                                if (p117t0.a.r(xmlPullParser, str59)) {
                                                                                    iC2 = c(xmlPullParser);
                                                                                } else {
                                                                                    String str73 = str50;
                                                                                    if (p117t0.a.r(xmlPullParser, str73)) {
                                                                                        str50 = str73;
                                                                                        sVarP = p(xmlPullParser, (r) sVarP);
                                                                                    } else {
                                                                                        String str74 = str49;
                                                                                        if (p117t0.a.r(xmlPullParser, str74)) {
                                                                                            long jD5 = d(xmlPullParser, j45);
                                                                                            str12 = str74;
                                                                                            long j46 = j37;
                                                                                            str13 = str73;
                                                                                            str14 = str66;
                                                                                            str15 = str11;
                                                                                            long j47 = j35;
                                                                                            long j48 = j38;
                                                                                            str16 = str64;
                                                                                            j15 = j48;
                                                                                            j17 = jD5;
                                                                                            j16 = jD4;
                                                                                            j12 = j46;
                                                                                            arrayList4 = arrayList28;
                                                                                            str17 = str44;
                                                                                            str62 = str62;
                                                                                            str61 = str61;
                                                                                            sVarR = q(xmlPullParser, (o) sVarP, j46, j48, jD4, jD5, j47);
                                                                                            arrayList8 = arrayList35;
                                                                                            i12 = iC2;
                                                                                            z6 = z6;
                                                                                            str18 = str72;
                                                                                            j13 = j47;
                                                                                            arrayList7 = arrayList32;
                                                                                        } else {
                                                                                            str12 = str74;
                                                                                            long j49 = jD4;
                                                                                            String str75 = str44;
                                                                                            str13 = str73;
                                                                                            str14 = str66;
                                                                                            str15 = str11;
                                                                                            j12 = j37;
                                                                                            long j50 = j35;
                                                                                            ArrayList arrayList37 = arrayList28;
                                                                                            j15 = j38;
                                                                                            str16 = str64;
                                                                                            if (p117t0.a.r(xmlPullParser, str75)) {
                                                                                                j13 = j50;
                                                                                                long jD6 = d(xmlPullParser, j45);
                                                                                                str17 = str75;
                                                                                                z6 = z6;
                                                                                                j16 = j49;
                                                                                                arrayList4 = arrayList37;
                                                                                                j17 = jD6;
                                                                                                sVarR = r(xmlPullParser, (p) sVarP, arrayList37, j12, j15, j16, jD6, j13);
                                                                                                arrayList7 = arrayList32;
                                                                                            } else {
                                                                                                str17 = str75;
                                                                                                arrayList4 = arrayList37;
                                                                                                j16 = j49;
                                                                                                z6 = z6;
                                                                                                j13 = j50;
                                                                                                if (p117t0.a.r(xmlPullParser, str16)) {
                                                                                                    Pair pairF2 = f(xmlPullParser);
                                                                                                    Object obj4 = pairF2.first;
                                                                                                    if (obj4 != null) {
                                                                                                        str72 = (String) obj4;
                                                                                                    }
                                                                                                    Object obj5 = pairF2.second;
                                                                                                    if (obj5 != null) {
                                                                                                        arrayList7 = arrayList32;
                                                                                                        arrayList7.add((C0423k) obj5);
                                                                                                    } else {
                                                                                                        arrayList7 = arrayList32;
                                                                                                    }
                                                                                                    j17 = j45;
                                                                                                    sVarR = sVarP;
                                                                                                } else {
                                                                                                    str62 = str62;
                                                                                                    arrayList7 = arrayList32;
                                                                                                    if (p117t0.a.r(xmlPullParser, str62)) {
                                                                                                        j17 = j45;
                                                                                                        arrayList33.add(i(xmlPullParser, str62));
                                                                                                    } else {
                                                                                                        j17 = j45;
                                                                                                        ArrayList arrayList38 = arrayList33;
                                                                                                        if (p117t0.a.r(xmlPullParser, str14)) {
                                                                                                            arrayList34.add(i(xmlPullParser, str14));
                                                                                                            arrayList33 = arrayList38;
                                                                                                        } else {
                                                                                                            String str76 = str60;
                                                                                                            if (p117t0.a.r(xmlPullParser, str76)) {
                                                                                                                arrayList33 = arrayList38;
                                                                                                                f fVarI = i(xmlPullParser, str76);
                                                                                                                str60 = str76;
                                                                                                                arrayList8 = arrayList35;
                                                                                                                arrayList8.add(fVarI);
                                                                                                            } else {
                                                                                                                str60 = str76;
                                                                                                                arrayList33 = arrayList38;
                                                                                                                arrayList8 = arrayList35;
                                                                                                                b(xmlPullParser);
                                                                                                            }
                                                                                                        }
                                                                                                        j12 = j12;
                                                                                                        str61 = str61;
                                                                                                        sVarR = sVarP;
                                                                                                    }
                                                                                                    arrayList8 = arrayList35;
                                                                                                    j12 = j12;
                                                                                                    str61 = str61;
                                                                                                    sVarR = sVarP;
                                                                                                }
                                                                                                i12 = iC2;
                                                                                                str18 = str72;
                                                                                            }
                                                                                            arrayList8 = arrayList35;
                                                                                            i12 = iC2;
                                                                                            str18 = str72;
                                                                                        }
                                                                                    }
                                                                                    if (p117t0.a.q(xmlPullParser, str61)) {
                                                                                        if (p101q0.C.h(str68)) {
                                                                                            if (str69 == null) {
                                                                                                strC2 = null;
                                                                                            } else {
                                                                                                strArrR2 = p117t0.s.R(str69);
                                                                                                length2 = strArrR2.length;
                                                                                                i30 = 0;
                                                                                                while (true) {
                                                                                                    if (i30 >= length2) {
                                                                                                        strC2 = null;
                                                                                                    } else {
                                                                                                        strC2 = p101q0.C.c(strArrR2[i30]);
                                                                                                        if (strC2 != null || !p101q0.C.h(strC2)) {
                                                                                                            i30++;
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                            strC = strC2;
                                                                                            str19 = str68;
                                                                                        } else if (p101q0.C.k(str68)) {
                                                                                            if (str69 == null) {
                                                                                                strC2 = null;
                                                                                            } else {
                                                                                                strArrR = p117t0.s.R(str69);
                                                                                                length = strArrR.length;
                                                                                                i13 = 0;
                                                                                                while (true) {
                                                                                                    if (i13 >= length) {
                                                                                                        strC2 = null;
                                                                                                    } else {
                                                                                                        strC2 = p101q0.C.c(strArrR[i13]);
                                                                                                        if (strC2 != null || !p101q0.C.k(strC2)) {
                                                                                                            i13++;
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                            strC = strC2;
                                                                                            str19 = str68;
                                                                                        } else if (p101q0.C.j(str68) && !p101q0.C.i(str68)) {
                                                                                            str19 = str68;
                                                                                            if ("application/mp4".equals(str19)) {
                                                                                                strC = p101q0.C.c(str69);
                                                                                                if ("text/vtt".equals(strC)) {
                                                                                                    strC = "application/x-mp4-vtt";
                                                                                                }
                                                                                            } else {
                                                                                                strC = null;
                                                                                            }
                                                                                        } else {
                                                                                            strC = str68;
                                                                                            str19 = strC;
                                                                                        }
                                                                                        if ("audio/eac3".equals(strC)) {
                                                                                            i29 = 0;
                                                                                            while (true) {
                                                                                                str20 = "ec+3";
                                                                                                if (i29 < arrayList8.size()) {
                                                                                                    f fVar5 = (f) arrayList8.get(i29);
                                                                                                    str27 = fVar5.f224a;
                                                                                                    String str77 = fVar5.f225b;
                                                                                                    arrayList9 = arrayList8;
                                                                                                    if (("tag:dolby.com,2018:dash:EC3_ExtensionType:2018".equals(str27) || !"JOC".equals(str77)) && !("tag:dolby.com,2014:dash:DolbyDigitalPlusExtensionType:2014".equals(str27) && "ec+3".equals(str77))) {
                                                                                                        i29++;
                                                                                                        arrayList8 = arrayList9;
                                                                                                    } else {
                                                                                                        strC = "audio/eac3-joc";
                                                                                                    }
                                                                                                } else {
                                                                                                    arrayList9 = arrayList8;
                                                                                                    strC = "audio/eac3";
                                                                                                }
                                                                                            }
                                                                                            if (!"audio/eac3-joc".equals(strC)) {
                                                                                            }
                                                                                            i14 = 0;
                                                                                            i15 = 0;
                                                                                            while (i15 < arrayList26.size()) {
                                                                                                ArrayList arrayList39 = arrayList26;
                                                                                                fVar4 = (f) arrayList39.get(i15);
                                                                                                String str78 = str19;
                                                                                                if (!p000a.a.o("urn:mpeg:dash:role:2011", fVar4.f224a)) {
                                                                                                    str26 = fVar4.f225b;
                                                                                                    if (str26 == null && (str26.equals("forced_subtitle") || str26.equals("forced-subtitle"))) {
                                                                                                        i28 = 2;
                                                                                                    } else {
                                                                                                        i28 = 0;
                                                                                                    }
                                                                                                    i14 |= i28;
                                                                                                }
                                                                                                i15++;
                                                                                                arrayList26 = arrayList39;
                                                                                                str19 = str78;
                                                                                            }
                                                                                            String str79 = str19;
                                                                                            arrayList10 = arrayList26;
                                                                                            iN = 0;
                                                                                            for (i16 = 0; i16 < arrayList10.size(); i16++) {
                                                                                                fVar3 = (f) arrayList10.get(i16);
                                                                                                i27 = iN;
                                                                                                if (p000a.a.o("urn:mpeg:dash:role:2011", fVar3.f224a)) {
                                                                                                    iN = i27 | n(fVar3.f225b);
                                                                                                } else {
                                                                                                    iN = i27;
                                                                                                }
                                                                                            }
                                                                                            int i51 = iN;
                                                                                            i17 = 0;
                                                                                            i18 = 0;
                                                                                            while (i18 < arrayList25.size()) {
                                                                                                ArrayList arrayList40 = arrayList25;
                                                                                                i25 = i17;
                                                                                                fVar2 = (f) arrayList40.get(i18);
                                                                                                long j51 = j15;
                                                                                                str24 = fVar2.f224a;
                                                                                                str25 = fVar2.f225b;
                                                                                                if (p000a.a.o("urn:mpeg:dash:role:2011", str24)) {
                                                                                                    iN2 = n(str25);
                                                                                                } else {
                                                                                                    if (p000a.a.o("urn:tva:metadata:cs:AudioPurposeCS:2007", fVar2.f224a)) {
                                                                                                        i17 = i25;
                                                                                                    } else if (str25 == null) {
                                                                                                        switch (str25.hashCode()) {
                                                                                                            case 49:
                                                                                                                if (str25.equals("1")) {
                                                                                                                    i26 = 0;
                                                                                                                } else {
                                                                                                                    i26 = -1;
                                                                                                                }
                                                                                                                break;
                                                                                                            case 50:
                                                                                                                if (str25.equals("2")) {
                                                                                                                    i26 = i7;
                                                                                                                } else {
                                                                                                                    i26 = -1;
                                                                                                                }
                                                                                                                break;
                                                                                                            case 51:
                                                                                                                if (str25.equals("3")) {
                                                                                                                    i26 = 2;
                                                                                                                } else {
                                                                                                                    i26 = -1;
                                                                                                                }
                                                                                                                break;
                                                                                                            case 52:
                                                                                                                if (str25.equals("4")) {
                                                                                                                    i26 = 3;
                                                                                                                } else {
                                                                                                                    i26 = -1;
                                                                                                                }
                                                                                                                break;
                                                                                                            case 53:
                                                                                                            default:
                                                                                                                i26 = -1;
                                                                                                                break;
                                                                                                            case 54:
                                                                                                                if (str25.equals("6")) {
                                                                                                                    i26 = 4;
                                                                                                                } else {
                                                                                                                    i26 = -1;
                                                                                                                }
                                                                                                                break;
                                                                                                        }
                                                                                                        switch (i26) {
                                                                                                            case 0:
                                                                                                                iN2 = 512;
                                                                                                                break;
                                                                                                            case 1:
                                                                                                                iN2 = 2048;
                                                                                                                break;
                                                                                                            case 2:
                                                                                                                iN2 = 4;
                                                                                                                break;
                                                                                                            case 3:
                                                                                                                iN2 = 8;
                                                                                                                break;
                                                                                                            case 4:
                                                                                                                iN2 = i7;
                                                                                                                break;
                                                                                                            default:
                                                                                                                iN2 = 0;
                                                                                                                break;
                                                                                                        }
                                                                                                    } else {
                                                                                                        iN2 = 0;
                                                                                                    }
                                                                                                    i18++;
                                                                                                    arrayList25 = arrayList40;
                                                                                                    j15 = j51;
                                                                                                }
                                                                                                i17 = i25 | iN2;
                                                                                                i18++;
                                                                                                arrayList25 = arrayList40;
                                                                                                j15 = j51;
                                                                                            }
                                                                                            long j52 = j15;
                                                                                            arrayList11 = arrayList25;
                                                                                            int iO = i51 | i17 | o(arrayList34) | o(arrayList9);
                                                                                            i19 = 0;
                                                                                            while (true) {
                                                                                                if (i19 < arrayList34.size()) {
                                                                                                    fVar = (f) arrayList34.get(i19);
                                                                                                    if ((p000a.a.o("http://dashif.org/thumbnail_tile", fVar.f224a) || p000a.a.o("http://dashif.org/guidelines/thumbnail_tile", fVar.f224a)) && (str23 = fVar.f225b) != null) {
                                                                                                        int i52 = p117t0.s.f9002a;
                                                                                                        strArrSplit = str23.split("x", -1);
                                                                                                        if (strArrSplit.length == 2) {
                                                                                                            i8 = 0;
                                                                                                            try {
                                                                                                                pairCreate = Pair.create(Integer.valueOf(Integer.parseInt(strArrSplit[0])), Integer.valueOf(Integer.parseInt(strArrSplit[i7])));
                                                                                                            } catch (NumberFormatException unused) {
                                                                                                                continue;
                                                                                                                i19++;
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                    i19++;
                                                                                                } else {
                                                                                                    i8 = 0;
                                                                                                    pairCreate = null;
                                                                                                }
                                                                                            }
                                                                                            c0426n = new C0426n();
                                                                                            c0426n.f8352a = str15;
                                                                                            c0426n.f8362k = p101q0.C.l(str79);
                                                                                            c0426n.f8363l = p101q0.C.l(strC);
                                                                                            c0426n.f8360i = str20;
                                                                                            c0426n.f8359h = i46;
                                                                                            c0426n.f8356e = i14;
                                                                                            c0426n.f8357f = iO;
                                                                                            String str80 = str71;
                                                                                            c0426n.f8355d = str80;
                                                                                            if (pairCreate != null) {
                                                                                                iIntValue = ((Integer) pairCreate.first).intValue();
                                                                                            } else {
                                                                                                iIntValue = -1;
                                                                                            }
                                                                                            c0426n.f8349G = iIntValue;
                                                                                            if (pairCreate != null) {
                                                                                                iIntValue2 = ((Integer) pairCreate.second).intValue();
                                                                                            } else {
                                                                                                iIntValue2 = -1;
                                                                                            }
                                                                                            c0426n.f8350H = iIntValue2;
                                                                                            if (p101q0.C.k(strC)) {
                                                                                                c0426n.r = i47;
                                                                                                c0426n.f8368s = i11;
                                                                                                c0426n.t = fK2;
                                                                                            } else {
                                                                                                i20 = i11;
                                                                                                if (p101q0.C.h(strC)) {
                                                                                                    c0426n.f8373z = i12;
                                                                                                    c0426n.f8344A = i49;
                                                                                                } else if (p101q0.C.j(strC)) {
                                                                                                    if ("application/cea-608".equals(strC)) {
                                                                                                        i23 = i8;
                                                                                                        while (true) {
                                                                                                            if (i23 < arrayList11.size()) {
                                                                                                                f fVar6 = (f) arrayList11.get(i23);
                                                                                                                str22 = fVar6.f224a;
                                                                                                                String str81 = fVar6.f225b;
                                                                                                                if (!"urn:scte:dash:cc:cea-608:2015".equals(str22) && str81 != null) {
                                                                                                                    Matcher matcher = t.matcher(str81);
                                                                                                                    if (matcher.matches()) {
                                                                                                                        i22 = Integer.parseInt(matcher.group(i7));
                                                                                                                    } else {
                                                                                                                        p117t0.a.x("MpdParser", "Unable to parse CEA-608 channel number from: ".concat(str81));
                                                                                                                    }
                                                                                                                }
                                                                                                                i23++;
                                                                                                                i7 = 1;
                                                                                                            } else {
                                                                                                                i22 = -1;
                                                                                                            }
                                                                                                        }
                                                                                                    } else if ("application/cea-708".equals(strC)) {
                                                                                                        i21 = i8;
                                                                                                        while (true) {
                                                                                                            if (i21 < arrayList11.size()) {
                                                                                                                f fVar7 = (f) arrayList11.get(i21);
                                                                                                                str21 = fVar7.f224a;
                                                                                                                String str82 = fVar7.f225b;
                                                                                                                if (!"urn:scte:dash:cc:cea-708:2015".equals(str21) && str82 != null) {
                                                                                                                    Matcher matcher2 = f222u.matcher(str82);
                                                                                                                    if (matcher2.matches()) {
                                                                                                                        i22 = Integer.parseInt(matcher2.group(1));
                                                                                                                    } else {
                                                                                                                        p117t0.a.x("MpdParser", "Unable to parse CEA-708 service block number from: ".concat(str82));
                                                                                                                    }
                                                                                                                }
                                                                                                                i21++;
                                                                                                            } else {
                                                                                                                i22 = -1;
                                                                                                            }
                                                                                                        }
                                                                                                    } else {
                                                                                                        i22 = -1;
                                                                                                    }
                                                                                                    c0426n.f8347E = i22;
                                                                                                } else if (p101q0.C.i(strC)) {
                                                                                                    c0426n.r = i47;
                                                                                                    c0426n.f8368s = i20;
                                                                                                }
                                                                                            }
                                                                                            C0427o c0427o2 = new C0427o(c0426n);
                                                                                            if (sVarR != null) {
                                                                                                rVar = sVarR;
                                                                                            } else {
                                                                                                rVar = new r(null, 1L, 0L, 0L, 0L);
                                                                                            }
                                                                                            if (arrayList36.isEmpty()) {
                                                                                                arrayList12 = arrayList31;
                                                                                            } else {
                                                                                                arrayList12 = arrayList36;
                                                                                            }
                                                                                            d dVar = new d(c0427o2, arrayList12, rVar, str18, arrayList7, arrayList33, arrayList34, arrayList9);
                                                                                            iG = p101q0.C.g(c0427o2.f8396m);
                                                                                            i24 = i9;
                                                                                            if (i24 == -1) {
                                                                                                i24 = iG;
                                                                                            } else if (iG != -1) {
                                                                                                if (i24 == iG) {
                                                                                                    z7 = 1;
                                                                                                } else {
                                                                                                    z7 = i8;
                                                                                                }
                                                                                                p117t0.a.h(z7);
                                                                                            }
                                                                                            ArrayList arrayList41 = arrayList29;
                                                                                            arrayList41.add(dVar);
                                                                                            str56 = str80;
                                                                                            arrayList26 = arrayList10;
                                                                                            arrayList5 = arrayList11;
                                                                                            i43 = i24;
                                                                                            j10 = j52;
                                                                                            jD3 = jD3;
                                                                                            arrayList6 = arrayList22;
                                                                                            arrayList24 = arrayList24;
                                                                                            str9 = str63;
                                                                                            str50 = str13;
                                                                                            str49 = str12;
                                                                                            str10 = str46;
                                                                                            str44 = str17;
                                                                                            arrayList29 = arrayList41;
                                                                                        } else {
                                                                                            arrayList9 = arrayList8;
                                                                                        }
                                                                                        str20 = str69;
                                                                                        i14 = 0;
                                                                                        i15 = 0;
                                                                                        while (i15 < arrayList26.size()) {
                                                                                            ArrayList arrayList310 = arrayList26;
                                                                                            fVar4 = (f) arrayList310.get(i15);
                                                                                            String str710 = str19;
                                                                                            if (!p000a.a.o("urn:mpeg:dash:role:2011", fVar4.f224a)) {
                                                                                                str26 = fVar4.f225b;
                                                                                                if (str26 == null) {
                                                                                                    i28 = 0;
                                                                                                } else {
                                                                                                    i28 = 2;
                                                                                                }
                                                                                                i14 |= i28;
                                                                                            }
                                                                                            i15++;
                                                                                            arrayList26 = arrayList310;
                                                                                            str19 = str710;
                                                                                        }
                                                                                        String str711 = str19;
                                                                                        arrayList10 = arrayList26;
                                                                                        iN = 0;
                                                                                        while (i16 < arrayList10.size()) {
                                                                                            fVar3 = (f) arrayList10.get(i16);
                                                                                            i27 = iN;
                                                                                            if (p000a.a.o("urn:mpeg:dash:role:2011", fVar3.f224a)) {
                                                                                                iN = i27 | n(fVar3.f225b);
                                                                                            } else {
                                                                                                iN = i27;
                                                                                            }
                                                                                        }
                                                                                        int i53 = iN;
                                                                                        i17 = 0;
                                                                                        i18 = 0;
                                                                                        while (i18 < arrayList25.size()) {
                                                                                            ArrayList arrayList42 = arrayList25;
                                                                                            i25 = i17;
                                                                                            fVar2 = (f) arrayList42.get(i18);
                                                                                            long j53 = j15;
                                                                                            str24 = fVar2.f224a;
                                                                                            str25 = fVar2.f225b;
                                                                                            if (p000a.a.o("urn:mpeg:dash:role:2011", str24)) {
                                                                                                iN2 = n(str25);
                                                                                            } else {
                                                                                                if (p000a.a.o("urn:tva:metadata:cs:AudioPurposeCS:2007", fVar2.f224a)) {
                                                                                                    i17 = i25;
                                                                                                } else if (str25 == null) {
                                                                                                    switch (str25.hashCode()) {
                                                                                                        case 49:
                                                                                                            if (str25.equals("1")) {
                                                                                                                i26 = -1;
                                                                                                            } else {
                                                                                                                i26 = 0;
                                                                                                            }
                                                                                                            break;
                                                                                                        case 50:
                                                                                                            if (str25.equals("2")) {
                                                                                                                i26 = -1;
                                                                                                            } else {
                                                                                                                i26 = i7;
                                                                                                            }
                                                                                                            break;
                                                                                                        case 51:
                                                                                                            if (str25.equals("3")) {
                                                                                                                i26 = -1;
                                                                                                            } else {
                                                                                                                i26 = 2;
                                                                                                            }
                                                                                                            break;
                                                                                                        case 52:
                                                                                                            if (str25.equals("4")) {
                                                                                                                i26 = -1;
                                                                                                            } else {
                                                                                                                i26 = 3;
                                                                                                            }
                                                                                                            break;
                                                                                                        case 53:
                                                                                                        default:
                                                                                                            i26 = -1;
                                                                                                            break;
                                                                                                        case 54:
                                                                                                            if (str25.equals("6")) {
                                                                                                                i26 = -1;
                                                                                                            } else {
                                                                                                                i26 = 4;
                                                                                                            }
                                                                                                            break;
                                                                                                    }
                                                                                                    switch (i26) {
                                                                                                        case 0:
                                                                                                            iN2 = 512;
                                                                                                            break;
                                                                                                        case 1:
                                                                                                            iN2 = 2048;
                                                                                                            break;
                                                                                                        case 2:
                                                                                                            iN2 = 4;
                                                                                                            break;
                                                                                                        case 3:
                                                                                                            iN2 = 8;
                                                                                                            break;
                                                                                                        case 4:
                                                                                                            iN2 = i7;
                                                                                                            break;
                                                                                                        default:
                                                                                                            iN2 = 0;
                                                                                                            break;
                                                                                                    }
                                                                                                } else {
                                                                                                    iN2 = 0;
                                                                                                }
                                                                                                i18++;
                                                                                                arrayList25 = arrayList42;
                                                                                                j15 = j53;
                                                                                            }
                                                                                            i17 = i25 | iN2;
                                                                                            i18++;
                                                                                            arrayList25 = arrayList42;
                                                                                            j15 = j53;
                                                                                        }
                                                                                        long j54 = j15;
                                                                                        arrayList11 = arrayList25;
                                                                                        int iO2 = i53 | i17 | o(arrayList34) | o(arrayList9);
                                                                                        i19 = 0;
                                                                                        while (true) {
                                                                                            if (i19 < arrayList34.size()) {
                                                                                                fVar = (f) arrayList34.get(i19);
                                                                                                if (p000a.a.o("http://dashif.org/thumbnail_tile", fVar.f224a)) {
                                                                                                    int i54 = p117t0.s.f9002a;
                                                                                                    strArrSplit = str23.split("x", -1);
                                                                                                    if (strArrSplit.length == 2) {
                                                                                                        i8 = 0;
                                                                                                        pairCreate = Pair.create(Integer.valueOf(Integer.parseInt(strArrSplit[0])), Integer.valueOf(Integer.parseInt(strArrSplit[i7])));
                                                                                                    }
                                                                                                } else {
                                                                                                    int i55 = p117t0.s.f9002a;
                                                                                                    strArrSplit = str23.split("x", -1);
                                                                                                    if (strArrSplit.length == 2) {
                                                                                                        i8 = 0;
                                                                                                        pairCreate = Pair.create(Integer.valueOf(Integer.parseInt(strArrSplit[0])), Integer.valueOf(Integer.parseInt(strArrSplit[i7])));
                                                                                                    }
                                                                                                }
                                                                                                i19++;
                                                                                            } else {
                                                                                                i8 = 0;
                                                                                                pairCreate = null;
                                                                                            }
                                                                                        }
                                                                                        c0426n = new C0426n();
                                                                                        c0426n.f8352a = str15;
                                                                                        c0426n.f8362k = p101q0.C.l(str711);
                                                                                        c0426n.f8363l = p101q0.C.l(strC);
                                                                                        c0426n.f8360i = str20;
                                                                                        c0426n.f8359h = i46;
                                                                                        c0426n.f8356e = i14;
                                                                                        c0426n.f8357f = iO2;
                                                                                        String str83 = str71;
                                                                                        c0426n.f8355d = str83;
                                                                                        if (pairCreate != null) {
                                                                                            iIntValue = ((Integer) pairCreate.first).intValue();
                                                                                        } else {
                                                                                            iIntValue = -1;
                                                                                        }
                                                                                        c0426n.f8349G = iIntValue;
                                                                                        if (pairCreate != null) {
                                                                                            iIntValue2 = ((Integer) pairCreate.second).intValue();
                                                                                        } else {
                                                                                            iIntValue2 = -1;
                                                                                        }
                                                                                        c0426n.f8350H = iIntValue2;
                                                                                        if (p101q0.C.k(strC)) {
                                                                                            c0426n.r = i47;
                                                                                            c0426n.f8368s = i11;
                                                                                            c0426n.t = fK2;
                                                                                        } else {
                                                                                            i20 = i11;
                                                                                            if (p101q0.C.h(strC)) {
                                                                                                c0426n.f8373z = i12;
                                                                                                c0426n.f8344A = i49;
                                                                                            } else if (p101q0.C.j(strC)) {
                                                                                                if ("application/cea-608".equals(strC)) {
                                                                                                    i23 = i8;
                                                                                                    while (true) {
                                                                                                        if (i23 < arrayList11.size()) {
                                                                                                            f fVar8 = (f) arrayList11.get(i23);
                                                                                                            str22 = fVar8.f224a;
                                                                                                            String str84 = fVar8.f225b;
                                                                                                            if (!"urn:scte:dash:cc:cea-608:2015".equals(str22)) {
                                                                                                            }
                                                                                                            i23++;
                                                                                                            i7 = 1;
                                                                                                        } else {
                                                                                                            i22 = -1;
                                                                                                        }
                                                                                                    }
                                                                                                } else if ("application/cea-708".equals(strC)) {
                                                                                                    i21 = i8;
                                                                                                    while (true) {
                                                                                                        if (i21 < arrayList11.size()) {
                                                                                                            f fVar9 = (f) arrayList11.get(i21);
                                                                                                            str21 = fVar9.f224a;
                                                                                                            String str85 = fVar9.f225b;
                                                                                                            if (!"urn:scte:dash:cc:cea-708:2015".equals(str21)) {
                                                                                                            }
                                                                                                            i21++;
                                                                                                        } else {
                                                                                                            i22 = -1;
                                                                                                        }
                                                                                                    }
                                                                                                } else {
                                                                                                    i22 = -1;
                                                                                                }
                                                                                                c0426n.f8347E = i22;
                                                                                            } else if (p101q0.C.i(strC)) {
                                                                                                c0426n.r = i47;
                                                                                                c0426n.f8368s = i20;
                                                                                            }
                                                                                        }
                                                                                        C0427o c0427o3 = new C0427o(c0426n);
                                                                                        if (sVarR != null) {
                                                                                            rVar = sVarR;
                                                                                        } else {
                                                                                            rVar = new r(null, 1L, 0L, 0L, 0L);
                                                                                        }
                                                                                        if (arrayList36.isEmpty()) {
                                                                                            arrayList12 = arrayList36;
                                                                                        } else {
                                                                                            arrayList12 = arrayList31;
                                                                                        }
                                                                                        d dVar2 = new d(c0427o3, arrayList12, rVar, str18, arrayList7, arrayList33, arrayList34, arrayList9);
                                                                                        iG = p101q0.C.g(c0427o3.f8396m);
                                                                                        i24 = i9;
                                                                                        if (i24 == -1) {
                                                                                            i24 = iG;
                                                                                        } else if (iG != -1) {
                                                                                            if (i24 == iG) {
                                                                                                z7 = 1;
                                                                                            } else {
                                                                                                z7 = i8;
                                                                                            }
                                                                                            p117t0.a.h(z7);
                                                                                        }
                                                                                        ArrayList arrayList43 = arrayList29;
                                                                                        arrayList43.add(dVar2);
                                                                                        str56 = str83;
                                                                                        arrayList26 = arrayList10;
                                                                                        arrayList5 = arrayList11;
                                                                                        i43 = i24;
                                                                                        j10 = j54;
                                                                                        jD3 = jD3;
                                                                                        arrayList6 = arrayList22;
                                                                                        arrayList24 = arrayList24;
                                                                                        str9 = str63;
                                                                                        str50 = str13;
                                                                                        str49 = str12;
                                                                                        str10 = str46;
                                                                                        str44 = str17;
                                                                                        arrayList29 = arrayList43;
                                                                                    } else {
                                                                                        long j55 = j15;
                                                                                        arrayList35 = arrayList8;
                                                                                        iC2 = i12;
                                                                                        str61 = str61;
                                                                                        jD4 = j16;
                                                                                        str62 = str62;
                                                                                        arrayList32 = arrayList7;
                                                                                        str66 = str14;
                                                                                        str64 = str16;
                                                                                        arrayList36 = arrayList36;
                                                                                        arrayList16 = arrayList16;
                                                                                        arrayList3 = arrayList3;
                                                                                        str59 = str59;
                                                                                        str8 = str8;
                                                                                        arrayList28 = arrayList4;
                                                                                        j45 = j17;
                                                                                        j37 = j12;
                                                                                        arrayList30 = arrayList30;
                                                                                        str54 = str54;
                                                                                        str72 = str18;
                                                                                        str33 = str33;
                                                                                        arrayList31 = arrayList31;
                                                                                        arrayList20 = arrayList20;
                                                                                        str48 = str48;
                                                                                        arrayList22 = arrayList22;
                                                                                        arrayList23 = arrayList23;
                                                                                        arrayList24 = arrayList24;
                                                                                        str71 = str71;
                                                                                        attributeValue21 = str15;
                                                                                        i46 = i46;
                                                                                        i49 = i49;
                                                                                        str63 = str63;
                                                                                        str50 = str13;
                                                                                        str49 = str12;
                                                                                        str46 = str46;
                                                                                        str47 = str47;
                                                                                        str53 = str53;
                                                                                        i7 = 1;
                                                                                        sVarP = sVarR;
                                                                                        str44 = str17;
                                                                                        arrayList17 = arrayList17;
                                                                                        j38 = j55;
                                                                                        str52 = str52;
                                                                                        arrayList29 = arrayList29;
                                                                                        str55 = str55;
                                                                                        arrayList19 = arrayList19;
                                                                                        z6 = z6;
                                                                                        j35 = j13;
                                                                                        arrayList25 = arrayList25;
                                                                                    }
                                                                                }
                                                                            }
                                                                            j17 = j45;
                                                                            str17 = str44;
                                                                            str12 = str49;
                                                                            str13 = str50;
                                                                            str14 = str66;
                                                                            str62 = str62;
                                                                            str61 = str61;
                                                                            sVarR = sVarP;
                                                                            arrayList8 = arrayList35;
                                                                            i12 = iC2;
                                                                            str15 = str11;
                                                                            arrayList4 = arrayList28;
                                                                            j12 = j37;
                                                                            str18 = str72;
                                                                            arrayList7 = arrayList32;
                                                                            j16 = jD4;
                                                                            z6 = z6;
                                                                            j15 = j38;
                                                                            j13 = j35;
                                                                            str16 = str64;
                                                                            if (p117t0.a.q(xmlPullParser, str61)) {
                                                                                if (p101q0.C.h(str68)) {
                                                                                    if (str69 == null) {
                                                                                        strC2 = null;
                                                                                    } else {
                                                                                        strArrR2 = p117t0.s.R(str69);
                                                                                        length2 = strArrR2.length;
                                                                                        i30 = 0;
                                                                                        while (true) {
                                                                                            if (i30 >= length2) {
                                                                                                strC2 = null;
                                                                                            } else {
                                                                                                strC2 = p101q0.C.c(strArrR2[i30]);
                                                                                                if (strC2 != null) {
                                                                                                }
                                                                                                i30++;
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                    strC = strC2;
                                                                                    str19 = str68;
                                                                                } else if (p101q0.C.k(str68)) {
                                                                                    if (str69 == null) {
                                                                                        strC2 = null;
                                                                                    } else {
                                                                                        strArrR = p117t0.s.R(str69);
                                                                                        length = strArrR.length;
                                                                                        i13 = 0;
                                                                                        while (true) {
                                                                                            if (i13 >= length) {
                                                                                                strC2 = null;
                                                                                            } else {
                                                                                                strC2 = p101q0.C.c(strArrR[i13]);
                                                                                                if (strC2 != null) {
                                                                                                }
                                                                                                i13++;
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                    strC = strC2;
                                                                                    str19 = str68;
                                                                                } else if (p101q0.C.j(str68)) {
                                                                                    strC = str68;
                                                                                    str19 = strC;
                                                                                } else {
                                                                                    str19 = str68;
                                                                                    if ("application/mp4".equals(str19)) {
                                                                                        strC = p101q0.C.c(str69);
                                                                                        if ("text/vtt".equals(strC)) {
                                                                                            strC = "application/x-mp4-vtt";
                                                                                        }
                                                                                    } else {
                                                                                        strC = null;
                                                                                    }
                                                                                }
                                                                                if ("audio/eac3".equals(strC)) {
                                                                                    i29 = 0;
                                                                                    while (true) {
                                                                                        str20 = "ec+3";
                                                                                        if (i29 < arrayList8.size()) {
                                                                                            f fVar10 = (f) arrayList8.get(i29);
                                                                                            str27 = fVar10.f224a;
                                                                                            String str712 = fVar10.f225b;
                                                                                            arrayList9 = arrayList8;
                                                                                            if ("tag:dolby.com,2018:dash:EC3_ExtensionType:2018".equals(str27)) {
                                                                                                i29++;
                                                                                                arrayList8 = arrayList9;
                                                                                            } else {
                                                                                                i29++;
                                                                                                arrayList8 = arrayList9;
                                                                                            }
                                                                                            strC = "audio/eac3-joc";
                                                                                        } else {
                                                                                            arrayList9 = arrayList8;
                                                                                            strC = "audio/eac3";
                                                                                        }
                                                                                    }
                                                                                    if (!"audio/eac3-joc".equals(strC)) {
                                                                                    }
                                                                                    i14 = 0;
                                                                                    i15 = 0;
                                                                                    while (i15 < arrayList26.size()) {
                                                                                        ArrayList arrayList311 = arrayList26;
                                                                                        fVar4 = (f) arrayList311.get(i15);
                                                                                        String str713 = str19;
                                                                                        if (!p000a.a.o("urn:mpeg:dash:role:2011", fVar4.f224a)) {
                                                                                            str26 = fVar4.f225b;
                                                                                            if (str26 == null) {
                                                                                                i28 = 0;
                                                                                            } else {
                                                                                                i28 = 2;
                                                                                            }
                                                                                            i14 |= i28;
                                                                                        }
                                                                                        i15++;
                                                                                        arrayList26 = arrayList311;
                                                                                        str19 = str713;
                                                                                    }
                                                                                    String str714 = str19;
                                                                                    arrayList10 = arrayList26;
                                                                                    iN = 0;
                                                                                    while (i16 < arrayList10.size()) {
                                                                                        fVar3 = (f) arrayList10.get(i16);
                                                                                        i27 = iN;
                                                                                        if (p000a.a.o("urn:mpeg:dash:role:2011", fVar3.f224a)) {
                                                                                            iN = i27 | n(fVar3.f225b);
                                                                                        } else {
                                                                                            iN = i27;
                                                                                        }
                                                                                    }
                                                                                    int i56 = iN;
                                                                                    i17 = 0;
                                                                                    i18 = 0;
                                                                                    while (i18 < arrayList25.size()) {
                                                                                        ArrayList arrayList44 = arrayList25;
                                                                                        i25 = i17;
                                                                                        fVar2 = (f) arrayList44.get(i18);
                                                                                        long j56 = j15;
                                                                                        str24 = fVar2.f224a;
                                                                                        str25 = fVar2.f225b;
                                                                                        if (p000a.a.o("urn:mpeg:dash:role:2011", str24)) {
                                                                                            iN2 = n(str25);
                                                                                        } else {
                                                                                            if (p000a.a.o("urn:tva:metadata:cs:AudioPurposeCS:2007", fVar2.f224a)) {
                                                                                                i17 = i25;
                                                                                            } else if (str25 == null) {
                                                                                                switch (str25.hashCode()) {
                                                                                                    case 49:
                                                                                                        if (str25.equals("1")) {
                                                                                                            i26 = -1;
                                                                                                        } else {
                                                                                                            i26 = 0;
                                                                                                        }
                                                                                                        break;
                                                                                                    case 50:
                                                                                                        if (str25.equals("2")) {
                                                                                                            i26 = -1;
                                                                                                        } else {
                                                                                                            i26 = i7;
                                                                                                        }
                                                                                                        break;
                                                                                                    case 51:
                                                                                                        if (str25.equals("3")) {
                                                                                                            i26 = -1;
                                                                                                        } else {
                                                                                                            i26 = 2;
                                                                                                        }
                                                                                                        break;
                                                                                                    case 52:
                                                                                                        if (str25.equals("4")) {
                                                                                                            i26 = -1;
                                                                                                        } else {
                                                                                                            i26 = 3;
                                                                                                        }
                                                                                                        break;
                                                                                                    case 53:
                                                                                                    default:
                                                                                                        i26 = -1;
                                                                                                        break;
                                                                                                    case 54:
                                                                                                        if (str25.equals("6")) {
                                                                                                            i26 = -1;
                                                                                                        } else {
                                                                                                            i26 = 4;
                                                                                                        }
                                                                                                        break;
                                                                                                }
                                                                                                switch (i26) {
                                                                                                    case 0:
                                                                                                        iN2 = 512;
                                                                                                        break;
                                                                                                    case 1:
                                                                                                        iN2 = 2048;
                                                                                                        break;
                                                                                                    case 2:
                                                                                                        iN2 = 4;
                                                                                                        break;
                                                                                                    case 3:
                                                                                                        iN2 = 8;
                                                                                                        break;
                                                                                                    case 4:
                                                                                                        iN2 = i7;
                                                                                                        break;
                                                                                                    default:
                                                                                                        iN2 = 0;
                                                                                                        break;
                                                                                                }
                                                                                            } else {
                                                                                                iN2 = 0;
                                                                                            }
                                                                                            i18++;
                                                                                            arrayList25 = arrayList44;
                                                                                            j15 = j56;
                                                                                        }
                                                                                        i17 = i25 | iN2;
                                                                                        i18++;
                                                                                        arrayList25 = arrayList44;
                                                                                        j15 = j56;
                                                                                    }
                                                                                    long j57 = j15;
                                                                                    arrayList11 = arrayList25;
                                                                                    int iO3 = i56 | i17 | o(arrayList34) | o(arrayList9);
                                                                                    i19 = 0;
                                                                                    while (true) {
                                                                                        if (i19 < arrayList34.size()) {
                                                                                            fVar = (f) arrayList34.get(i19);
                                                                                            if (p000a.a.o("http://dashif.org/thumbnail_tile", fVar.f224a)) {
                                                                                                int i57 = p117t0.s.f9002a;
                                                                                                strArrSplit = str23.split("x", -1);
                                                                                                if (strArrSplit.length == 2) {
                                                                                                    i8 = 0;
                                                                                                    pairCreate = Pair.create(Integer.valueOf(Integer.parseInt(strArrSplit[0])), Integer.valueOf(Integer.parseInt(strArrSplit[i7])));
                                                                                                }
                                                                                            } else {
                                                                                                int i58 = p117t0.s.f9002a;
                                                                                                strArrSplit = str23.split("x", -1);
                                                                                                if (strArrSplit.length == 2) {
                                                                                                    i8 = 0;
                                                                                                    pairCreate = Pair.create(Integer.valueOf(Integer.parseInt(strArrSplit[0])), Integer.valueOf(Integer.parseInt(strArrSplit[i7])));
                                                                                                }
                                                                                            }
                                                                                            i19++;
                                                                                        } else {
                                                                                            i8 = 0;
                                                                                            pairCreate = null;
                                                                                        }
                                                                                    }
                                                                                    c0426n = new C0426n();
                                                                                    c0426n.f8352a = str15;
                                                                                    c0426n.f8362k = p101q0.C.l(str714);
                                                                                    c0426n.f8363l = p101q0.C.l(strC);
                                                                                    c0426n.f8360i = str20;
                                                                                    c0426n.f8359h = i46;
                                                                                    c0426n.f8356e = i14;
                                                                                    c0426n.f8357f = iO3;
                                                                                    String str86 = str71;
                                                                                    c0426n.f8355d = str86;
                                                                                    if (pairCreate != null) {
                                                                                        iIntValue = ((Integer) pairCreate.first).intValue();
                                                                                    } else {
                                                                                        iIntValue = -1;
                                                                                    }
                                                                                    c0426n.f8349G = iIntValue;
                                                                                    if (pairCreate != null) {
                                                                                        iIntValue2 = ((Integer) pairCreate.second).intValue();
                                                                                    } else {
                                                                                        iIntValue2 = -1;
                                                                                    }
                                                                                    c0426n.f8350H = iIntValue2;
                                                                                    if (p101q0.C.k(strC)) {
                                                                                        c0426n.r = i47;
                                                                                        c0426n.f8368s = i11;
                                                                                        c0426n.t = fK2;
                                                                                    } else {
                                                                                        i20 = i11;
                                                                                        if (p101q0.C.h(strC)) {
                                                                                            c0426n.f8373z = i12;
                                                                                            c0426n.f8344A = i49;
                                                                                        } else if (p101q0.C.j(strC)) {
                                                                                            if ("application/cea-608".equals(strC)) {
                                                                                                i23 = i8;
                                                                                                while (true) {
                                                                                                    if (i23 < arrayList11.size()) {
                                                                                                        f fVar11 = (f) arrayList11.get(i23);
                                                                                                        str22 = fVar11.f224a;
                                                                                                        String str87 = fVar11.f225b;
                                                                                                        if (!"urn:scte:dash:cc:cea-608:2015".equals(str22)) {
                                                                                                        }
                                                                                                        i23++;
                                                                                                        i7 = 1;
                                                                                                    } else {
                                                                                                        i22 = -1;
                                                                                                    }
                                                                                                }
                                                                                            } else if ("application/cea-708".equals(strC)) {
                                                                                                i21 = i8;
                                                                                                while (true) {
                                                                                                    if (i21 < arrayList11.size()) {
                                                                                                        f fVar12 = (f) arrayList11.get(i21);
                                                                                                        str21 = fVar12.f224a;
                                                                                                        String str88 = fVar12.f225b;
                                                                                                        if (!"urn:scte:dash:cc:cea-708:2015".equals(str21)) {
                                                                                                        }
                                                                                                        i21++;
                                                                                                    } else {
                                                                                                        i22 = -1;
                                                                                                    }
                                                                                                }
                                                                                            } else {
                                                                                                i22 = -1;
                                                                                            }
                                                                                            c0426n.f8347E = i22;
                                                                                        } else if (p101q0.C.i(strC)) {
                                                                                            c0426n.r = i47;
                                                                                            c0426n.f8368s = i20;
                                                                                        }
                                                                                    }
                                                                                    C0427o c0427o4 = new C0427o(c0426n);
                                                                                    if (sVarR != null) {
                                                                                        rVar = sVarR;
                                                                                    } else {
                                                                                        rVar = new r(null, 1L, 0L, 0L, 0L);
                                                                                    }
                                                                                    if (arrayList36.isEmpty()) {
                                                                                        arrayList12 = arrayList36;
                                                                                    } else {
                                                                                        arrayList12 = arrayList31;
                                                                                    }
                                                                                    d dVar3 = new d(c0427o4, arrayList12, rVar, str18, arrayList7, arrayList33, arrayList34, arrayList9);
                                                                                    iG = p101q0.C.g(c0427o4.f8396m);
                                                                                    i24 = i9;
                                                                                    if (i24 == -1) {
                                                                                        i24 = iG;
                                                                                    } else if (iG != -1) {
                                                                                        if (i24 == iG) {
                                                                                            z7 = 1;
                                                                                        } else {
                                                                                            z7 = i8;
                                                                                        }
                                                                                        p117t0.a.h(z7);
                                                                                    }
                                                                                    ArrayList arrayList45 = arrayList29;
                                                                                    arrayList45.add(dVar3);
                                                                                    str56 = str86;
                                                                                    arrayList26 = arrayList10;
                                                                                    arrayList5 = arrayList11;
                                                                                    i43 = i24;
                                                                                    j10 = j57;
                                                                                    jD3 = jD3;
                                                                                    arrayList6 = arrayList22;
                                                                                    arrayList24 = arrayList24;
                                                                                    str9 = str63;
                                                                                    str50 = str13;
                                                                                    str49 = str12;
                                                                                    str10 = str46;
                                                                                    str44 = str17;
                                                                                    arrayList29 = arrayList45;
                                                                                } else {
                                                                                    arrayList9 = arrayList8;
                                                                                }
                                                                                str20 = str69;
                                                                                i14 = 0;
                                                                                i15 = 0;
                                                                                while (i15 < arrayList26.size()) {
                                                                                    ArrayList arrayList312 = arrayList26;
                                                                                    fVar4 = (f) arrayList312.get(i15);
                                                                                    String str715 = str19;
                                                                                    if (!p000a.a.o("urn:mpeg:dash:role:2011", fVar4.f224a)) {
                                                                                        str26 = fVar4.f225b;
                                                                                        if (str26 == null) {
                                                                                            i28 = 0;
                                                                                        } else {
                                                                                            i28 = 2;
                                                                                        }
                                                                                        i14 |= i28;
                                                                                    }
                                                                                    i15++;
                                                                                    arrayList26 = arrayList312;
                                                                                    str19 = str715;
                                                                                }
                                                                                String str716 = str19;
                                                                                arrayList10 = arrayList26;
                                                                                iN = 0;
                                                                                while (i16 < arrayList10.size()) {
                                                                                    fVar3 = (f) arrayList10.get(i16);
                                                                                    i27 = iN;
                                                                                    if (p000a.a.o("urn:mpeg:dash:role:2011", fVar3.f224a)) {
                                                                                        iN = i27 | n(fVar3.f225b);
                                                                                    } else {
                                                                                        iN = i27;
                                                                                    }
                                                                                }
                                                                                int i59 = iN;
                                                                                i17 = 0;
                                                                                i18 = 0;
                                                                                while (i18 < arrayList25.size()) {
                                                                                    ArrayList arrayList46 = arrayList25;
                                                                                    i25 = i17;
                                                                                    fVar2 = (f) arrayList46.get(i18);
                                                                                    long j58 = j15;
                                                                                    str24 = fVar2.f224a;
                                                                                    str25 = fVar2.f225b;
                                                                                    if (p000a.a.o("urn:mpeg:dash:role:2011", str24)) {
                                                                                        iN2 = n(str25);
                                                                                    } else {
                                                                                        if (p000a.a.o("urn:tva:metadata:cs:AudioPurposeCS:2007", fVar2.f224a)) {
                                                                                            i17 = i25;
                                                                                        } else if (str25 == null) {
                                                                                            switch (str25.hashCode()) {
                                                                                                case 49:
                                                                                                    if (str25.equals("1")) {
                                                                                                        i26 = -1;
                                                                                                    } else {
                                                                                                        i26 = 0;
                                                                                                    }
                                                                                                    break;
                                                                                                case 50:
                                                                                                    if (str25.equals("2")) {
                                                                                                        i26 = -1;
                                                                                                    } else {
                                                                                                        i26 = i7;
                                                                                                    }
                                                                                                    break;
                                                                                                case 51:
                                                                                                    if (str25.equals("3")) {
                                                                                                        i26 = -1;
                                                                                                    } else {
                                                                                                        i26 = 2;
                                                                                                    }
                                                                                                    break;
                                                                                                case 52:
                                                                                                    if (str25.equals("4")) {
                                                                                                        i26 = -1;
                                                                                                    } else {
                                                                                                        i26 = 3;
                                                                                                    }
                                                                                                    break;
                                                                                                case 53:
                                                                                                default:
                                                                                                    i26 = -1;
                                                                                                    break;
                                                                                                case 54:
                                                                                                    if (str25.equals("6")) {
                                                                                                        i26 = -1;
                                                                                                    } else {
                                                                                                        i26 = 4;
                                                                                                    }
                                                                                                    break;
                                                                                            }
                                                                                            switch (i26) {
                                                                                                case 0:
                                                                                                    iN2 = 512;
                                                                                                    break;
                                                                                                case 1:
                                                                                                    iN2 = 2048;
                                                                                                    break;
                                                                                                case 2:
                                                                                                    iN2 = 4;
                                                                                                    break;
                                                                                                case 3:
                                                                                                    iN2 = 8;
                                                                                                    break;
                                                                                                case 4:
                                                                                                    iN2 = i7;
                                                                                                    break;
                                                                                                default:
                                                                                                    iN2 = 0;
                                                                                                    break;
                                                                                            }
                                                                                        } else {
                                                                                            iN2 = 0;
                                                                                        }
                                                                                        i18++;
                                                                                        arrayList25 = arrayList46;
                                                                                        j15 = j58;
                                                                                    }
                                                                                    i17 = i25 | iN2;
                                                                                    i18++;
                                                                                    arrayList25 = arrayList46;
                                                                                    j15 = j58;
                                                                                }
                                                                                long j59 = j15;
                                                                                arrayList11 = arrayList25;
                                                                                int iO4 = i59 | i17 | o(arrayList34) | o(arrayList9);
                                                                                i19 = 0;
                                                                                while (true) {
                                                                                    if (i19 < arrayList34.size()) {
                                                                                        fVar = (f) arrayList34.get(i19);
                                                                                        if (p000a.a.o("http://dashif.org/thumbnail_tile", fVar.f224a)) {
                                                                                            int i510 = p117t0.s.f9002a;
                                                                                            strArrSplit = str23.split("x", -1);
                                                                                            if (strArrSplit.length == 2) {
                                                                                                i8 = 0;
                                                                                                pairCreate = Pair.create(Integer.valueOf(Integer.parseInt(strArrSplit[0])), Integer.valueOf(Integer.parseInt(strArrSplit[i7])));
                                                                                            }
                                                                                        } else {
                                                                                            int i511 = p117t0.s.f9002a;
                                                                                            strArrSplit = str23.split("x", -1);
                                                                                            if (strArrSplit.length == 2) {
                                                                                                i8 = 0;
                                                                                                pairCreate = Pair.create(Integer.valueOf(Integer.parseInt(strArrSplit[0])), Integer.valueOf(Integer.parseInt(strArrSplit[i7])));
                                                                                            }
                                                                                        }
                                                                                        i19++;
                                                                                    } else {
                                                                                        i8 = 0;
                                                                                        pairCreate = null;
                                                                                    }
                                                                                }
                                                                                c0426n = new C0426n();
                                                                                c0426n.f8352a = str15;
                                                                                c0426n.f8362k = p101q0.C.l(str716);
                                                                                c0426n.f8363l = p101q0.C.l(strC);
                                                                                c0426n.f8360i = str20;
                                                                                c0426n.f8359h = i46;
                                                                                c0426n.f8356e = i14;
                                                                                c0426n.f8357f = iO4;
                                                                                String str89 = str71;
                                                                                c0426n.f8355d = str89;
                                                                                if (pairCreate != null) {
                                                                                    iIntValue = ((Integer) pairCreate.first).intValue();
                                                                                } else {
                                                                                    iIntValue = -1;
                                                                                }
                                                                                c0426n.f8349G = iIntValue;
                                                                                if (pairCreate != null) {
                                                                                    iIntValue2 = ((Integer) pairCreate.second).intValue();
                                                                                } else {
                                                                                    iIntValue2 = -1;
                                                                                }
                                                                                c0426n.f8350H = iIntValue2;
                                                                                if (p101q0.C.k(strC)) {
                                                                                    c0426n.r = i47;
                                                                                    c0426n.f8368s = i11;
                                                                                    c0426n.t = fK2;
                                                                                } else {
                                                                                    i20 = i11;
                                                                                    if (p101q0.C.h(strC)) {
                                                                                        c0426n.f8373z = i12;
                                                                                        c0426n.f8344A = i49;
                                                                                    } else if (p101q0.C.j(strC)) {
                                                                                        if ("application/cea-608".equals(strC)) {
                                                                                            i23 = i8;
                                                                                            while (true) {
                                                                                                if (i23 < arrayList11.size()) {
                                                                                                    f fVar13 = (f) arrayList11.get(i23);
                                                                                                    str22 = fVar13.f224a;
                                                                                                    String str810 = fVar13.f225b;
                                                                                                    if (!"urn:scte:dash:cc:cea-608:2015".equals(str22)) {
                                                                                                    }
                                                                                                    i23++;
                                                                                                    i7 = 1;
                                                                                                } else {
                                                                                                    i22 = -1;
                                                                                                }
                                                                                            }
                                                                                        } else if ("application/cea-708".equals(strC)) {
                                                                                            i21 = i8;
                                                                                            while (true) {
                                                                                                if (i21 < arrayList11.size()) {
                                                                                                    f fVar14 = (f) arrayList11.get(i21);
                                                                                                    str21 = fVar14.f224a;
                                                                                                    String str811 = fVar14.f225b;
                                                                                                    if (!"urn:scte:dash:cc:cea-708:2015".equals(str21)) {
                                                                                                    }
                                                                                                    i21++;
                                                                                                } else {
                                                                                                    i22 = -1;
                                                                                                }
                                                                                            }
                                                                                        } else {
                                                                                            i22 = -1;
                                                                                        }
                                                                                        c0426n.f8347E = i22;
                                                                                    } else if (p101q0.C.i(strC)) {
                                                                                        c0426n.r = i47;
                                                                                        c0426n.f8368s = i20;
                                                                                    }
                                                                                }
                                                                                C0427o c0427o5 = new C0427o(c0426n);
                                                                                if (sVarR != null) {
                                                                                    rVar = sVarR;
                                                                                } else {
                                                                                    rVar = new r(null, 1L, 0L, 0L, 0L);
                                                                                }
                                                                                if (arrayList36.isEmpty()) {
                                                                                    arrayList12 = arrayList36;
                                                                                } else {
                                                                                    arrayList12 = arrayList31;
                                                                                }
                                                                                d dVar4 = new d(c0427o5, arrayList12, rVar, str18, arrayList7, arrayList33, arrayList34, arrayList9);
                                                                                iG = p101q0.C.g(c0427o5.f8396m);
                                                                                i24 = i9;
                                                                                if (i24 == -1) {
                                                                                    i24 = iG;
                                                                                } else if (iG != -1) {
                                                                                    if (i24 == iG) {
                                                                                        z7 = 1;
                                                                                    } else {
                                                                                        z7 = i8;
                                                                                    }
                                                                                    p117t0.a.h(z7);
                                                                                }
                                                                                ArrayList arrayList47 = arrayList29;
                                                                                arrayList47.add(dVar4);
                                                                                str56 = str89;
                                                                                arrayList26 = arrayList10;
                                                                                arrayList5 = arrayList11;
                                                                                i43 = i24;
                                                                                j10 = j59;
                                                                                jD3 = jD3;
                                                                                arrayList6 = arrayList22;
                                                                                arrayList24 = arrayList24;
                                                                                str9 = str63;
                                                                                str50 = str13;
                                                                                str49 = str12;
                                                                                str10 = str46;
                                                                                str44 = str17;
                                                                                arrayList29 = arrayList47;
                                                                            } else {
                                                                                long j510 = j15;
                                                                                arrayList35 = arrayList8;
                                                                                iC2 = i12;
                                                                                str61 = str61;
                                                                                jD4 = j16;
                                                                                str62 = str62;
                                                                                arrayList32 = arrayList7;
                                                                                str66 = str14;
                                                                                str64 = str16;
                                                                                arrayList36 = arrayList36;
                                                                                arrayList16 = arrayList16;
                                                                                arrayList3 = arrayList3;
                                                                                str59 = str59;
                                                                                str8 = str8;
                                                                                arrayList28 = arrayList4;
                                                                                j45 = j17;
                                                                                j37 = j12;
                                                                                arrayList30 = arrayList30;
                                                                                str54 = str54;
                                                                                str72 = str18;
                                                                                str33 = str33;
                                                                                arrayList31 = arrayList31;
                                                                                arrayList20 = arrayList20;
                                                                                str48 = str48;
                                                                                arrayList22 = arrayList22;
                                                                                arrayList23 = arrayList23;
                                                                                arrayList24 = arrayList24;
                                                                                str71 = str71;
                                                                                attributeValue21 = str15;
                                                                                i46 = i46;
                                                                                i49 = i49;
                                                                                str63 = str63;
                                                                                str50 = str13;
                                                                                str49 = str12;
                                                                                str46 = str46;
                                                                                str47 = str47;
                                                                                str53 = str53;
                                                                                i7 = 1;
                                                                                sVarP = sVarR;
                                                                                str44 = str17;
                                                                                arrayList17 = arrayList17;
                                                                                j38 = j510;
                                                                                str52 = str52;
                                                                                arrayList29 = arrayList29;
                                                                                str55 = str55;
                                                                                arrayList19 = arrayList19;
                                                                                z6 = z6;
                                                                                j35 = j13;
                                                                                arrayList25 = arrayList25;
                                                                            }
                                                                        }
                                                                    } else {
                                                                        String str90 = str34;
                                                                        String str91 = str56;
                                                                        arrayList23 = arrayList23;
                                                                        str33 = str33;
                                                                        arrayList27 = arrayList27;
                                                                        str45 = str45;
                                                                        arrayList19 = arrayList19;
                                                                        arrayList20 = arrayList20;
                                                                        String str92 = str44;
                                                                        str7 = str46;
                                                                        str47 = str47;
                                                                        ArrayList arrayList48 = arrayList22;
                                                                        str48 = str48;
                                                                        ArrayList arrayList49 = arrayList24;
                                                                        String str93 = str49;
                                                                        String str94 = str50;
                                                                        f9 = f9;
                                                                        str55 = str55;
                                                                        str53 = str53;
                                                                        i8 = 0;
                                                                        arrayList30 = arrayList30;
                                                                        arrayList4 = arrayList28;
                                                                        j12 = j37;
                                                                        str8 = str51;
                                                                        ArrayList arrayList50 = arrayList29;
                                                                        long j60 = j38;
                                                                        arrayList17 = arrayList17;
                                                                        arrayList5 = arrayList25;
                                                                        arrayList16 = arrayList16;
                                                                        long j61 = j35;
                                                                        arrayList3 = arrayList3;
                                                                        z6 = z6;
                                                                        j13 = j61;
                                                                        if (p117t0.a.r(xmlPullParser, str94)) {
                                                                            sVarR3 = p(xmlPullParser, (r) sVarR3);
                                                                            str56 = str91;
                                                                            arrayList29 = arrayList50;
                                                                            i43 = i9;
                                                                            j10 = j60;
                                                                            jD3 = jD3;
                                                                            arrayList24 = arrayList49;
                                                                            str9 = str90;
                                                                            str49 = str93;
                                                                            str10 = str7;
                                                                            str44 = str92;
                                                                            str50 = str94;
                                                                            arrayList6 = arrayList48;
                                                                        } else {
                                                                            str49 = str93;
                                                                            if (p117t0.a.r(xmlPullParser, str49)) {
                                                                                long jD7 = d(xmlPullParser, j41);
                                                                                str56 = str91;
                                                                                arrayList29 = arrayList50;
                                                                                sVarR3 = q(xmlPullParser, (o) sVarR3, j12, j60, jD3, jD7, j13);
                                                                                j13 = j13;
                                                                                j10 = j60;
                                                                                j41 = jD7;
                                                                                i43 = i9;
                                                                                str50 = str94;
                                                                                jD3 = jD3;
                                                                                arrayList6 = arrayList48;
                                                                                arrayList24 = arrayList49;
                                                                                str9 = str90;
                                                                                str10 = str7;
                                                                                str44 = str92;
                                                                            } else {
                                                                                str56 = str91;
                                                                                arrayList29 = arrayList50;
                                                                                j10 = j60;
                                                                                long j62 = j41;
                                                                                if (p117t0.a.r(xmlPullParser, str92)) {
                                                                                    long jD8 = d(xmlPullParser, j62);
                                                                                    str44 = str92;
                                                                                    str50 = str94;
                                                                                    sVarR3 = r(xmlPullParser, (p) sVarR3, arrayList4, j12, j10, jD3, jD8, j13);
                                                                                    j41 = jD8;
                                                                                    i43 = i9;
                                                                                    arrayList6 = arrayList48;
                                                                                    arrayList24 = arrayList49;
                                                                                    str9 = str90;
                                                                                } else {
                                                                                    str44 = str92;
                                                                                    ArrayList arrayList51 = arrayList4;
                                                                                    str50 = str94;
                                                                                    if (p117t0.a.r(xmlPullParser, "InbandEventStream")) {
                                                                                        i9 = i9;
                                                                                        arrayList24 = arrayList49;
                                                                                        arrayList24.add(i(xmlPullParser, "InbandEventStream"));
                                                                                        arrayList4 = arrayList51;
                                                                                        j14 = j62;
                                                                                        arrayList6 = arrayList48;
                                                                                        str9 = str90;
                                                                                    } else {
                                                                                        arrayList24 = arrayList49;
                                                                                        if (p117t0.a.r(xmlPullParser, "Label")) {
                                                                                            i9 = i9;
                                                                                            str9 = str90;
                                                                                            String attributeValue28 = xmlPullParser.getAttributeValue(null, str9);
                                                                                            String text = StringUtils.EMPTY;
                                                                                            while (true) {
                                                                                                xmlPullParser.next();
                                                                                                arrayList4 = arrayList51;
                                                                                                j14 = j62;
                                                                                                if (xmlPullParser.getEventType() == 4) {
                                                                                                    text = xmlPullParser.getText();
                                                                                                } else {
                                                                                                    b(xmlPullParser);
                                                                                                }
                                                                                                if (p117t0.a.q(xmlPullParser, "Label")) {
                                                                                                    arrayList6 = arrayList48;
                                                                                                    arrayList6.add(new C0428p(attributeValue28, text));
                                                                                                } else {
                                                                                                    arrayList51 = arrayList4;
                                                                                                    j62 = j14;
                                                                                                }
                                                                                            }
                                                                                        } else {
                                                                                            arrayList4 = arrayList51;
                                                                                            j14 = j62;
                                                                                            arrayList6 = arrayList48;
                                                                                            str9 = str90;
                                                                                            if (xmlPullParser.getEventType() == 2) {
                                                                                                i9 = i9;
                                                                                                b(xmlPullParser);
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                    i9 = i9;
                                                                                    j41 = j14;
                                                                                    i43 = i9;
                                                                                }
                                                                                str10 = str7;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                    arrayList26 = arrayList26;
                                                    arrayList27 = arrayList27;
                                                    str45 = str45;
                                                    arrayList19 = arrayList19;
                                                    arrayList20 = arrayList20;
                                                    str44 = str44;
                                                    str7 = str46;
                                                    str47 = str47;
                                                    str48 = str48;
                                                    arrayList24 = arrayList24;
                                                    str49 = str49;
                                                    str50 = str50;
                                                    f9 = f9;
                                                    arrayList29 = arrayList29;
                                                    str55 = str55;
                                                    str53 = str53;
                                                    j14 = j41;
                                                    i8 = 0;
                                                    arrayList30 = arrayList30;
                                                    arrayList4 = arrayList28;
                                                    str9 = str34;
                                                    arrayList6 = arrayList22;
                                                    j12 = j37;
                                                    str8 = str51;
                                                    long j410 = j35;
                                                    arrayList3 = arrayList3;
                                                    z6 = z6;
                                                    j10 = j38;
                                                    arrayList17 = arrayList17;
                                                    arrayList5 = arrayList25;
                                                    arrayList16 = arrayList16;
                                                    j13 = j410;
                                                    i9 = i9;
                                                    j41 = j14;
                                                    i43 = i9;
                                                    str10 = str7;
                                                }
                                                if (p117t0.a.q(xmlPullParser, str10)) {
                                                    arrayList13 = new ArrayList(arrayList29.size());
                                                    i31 = i8;
                                                    while (i31 < arrayList29.size()) {
                                                        d dVar5 = (d) arrayList29.get(i31);
                                                        c0426nA = dVar5.f215a.a();
                                                        str28 = str48;
                                                        if (str28 == null && arrayList6.isEmpty()) {
                                                            c0426nA.f8353b = str28;
                                                        } else {
                                                            c0426nA.f8354c = C.n(arrayList6);
                                                        }
                                                        str29 = dVar5.f218d;
                                                        if (str29 == null) {
                                                            str29 = str57;
                                                        }
                                                        arrayList14 = dVar5.f219e;
                                                        ArrayList arrayList52 = arrayList6;
                                                        ArrayList arrayList53 = arrayList23;
                                                        arrayList14.addAll(arrayList53);
                                                        long j63 = j10;
                                                        if (arrayList14.isEmpty()) {
                                                            str30 = str9;
                                                            str48 = str28;
                                                            j18 = j13;
                                                        } else {
                                                            i32 = i8;
                                                            while (true) {
                                                                if (i32 < arrayList14.size()) {
                                                                    c0423k4 = (C0423k) arrayList14.get(i32);
                                                                    str30 = str9;
                                                                    if (AbstractC0419g.f8327c.equals(c0423k4.f8338s) || (str31 = c0423k4.t) == null) {
                                                                        i32++;
                                                                        str9 = str30;
                                                                    } else {
                                                                        arrayList14.remove(i32);
                                                                    }
                                                                } else {
                                                                    str30 = str9;
                                                                    str31 = null;
                                                                }
                                                            }
                                                            if (str31 != null) {
                                                                i33 = i8;
                                                                while (i33 < arrayList14.size()) {
                                                                    c0423k = (C0423k) arrayList14.get(i33);
                                                                    String str95 = str28;
                                                                    if (!AbstractC0419g.f8326b.equals(c0423k.f8338s) && c0423k.t == null) {
                                                                        arrayList14.set(i33, new C0423k(AbstractC0419g.f8327c, str31, c0423k.f8339u, c0423k.f8340v));
                                                                    }
                                                                    i33++;
                                                                    j13 = j13;
                                                                    str28 = str95;
                                                                }
                                                            }
                                                            str48 = str28;
                                                            j18 = j13;
                                                            for (size = arrayList14.size() - 1; size >= 0; size--) {
                                                                c0423k2 = (C0423k) arrayList14.get(size);
                                                                if (c0423k2.f8340v != null) {
                                                                    for (i34 = i8; i34 < arrayList14.size(); i34++) {
                                                                        c0423k3 = (C0423k) arrayList14.get(i34);
                                                                        if (c0423k3.f8340v == null && c0423k2.f8340v == null) {
                                                                            UUID uuid = c0423k2.f8338s;
                                                                            c0423k3.getClass();
                                                                            UUID uuid2 = AbstractC0419g.f8325a;
                                                                            UUID uuid3 = c0423k3.f8338s;
                                                                            if (((uuid2.equals(uuid3) || uuid.equals(uuid3)) ? 1 : i8) != 0) {
                                                                                arrayList14.remove(size);
                                                                                break;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            c0426nA.f8366p = new C0424l(str29, arrayList14);
                                                        }
                                                        arrayList15 = dVar5.f220f;
                                                        arrayList15.addAll(arrayList24);
                                                        c0427o = new C0427o(c0426nA);
                                                        c2 = dVar5.f216b;
                                                        sVar = dVar5.f217c;
                                                        if (sVar instanceof r) {
                                                            kVar = new l(c0427o, c2, (r) sVar, arrayList15);
                                                        } else {
                                                            if (sVar instanceof n) {
                                                                throw new IllegalArgumentException("segmentBase must be of type SingleSegmentBase or MultiSegmentBase");
                                                            }
                                                            kVar = new k(c0427o, c2, (n) sVar, arrayList15);
                                                        }
                                                        arrayList13.add(kVar);
                                                        i31++;
                                                        j13 = j18;
                                                        j10 = j63;
                                                        str9 = str30;
                                                        arrayList23 = arrayList53;
                                                        arrayList6 = arrayList52;
                                                    }
                                                    str2 = str9;
                                                    i7 = 1;
                                                    ArrayList arrayList54 = arrayList19;
                                                    arrayList54.add(new a(j40, i43, arrayList13, arrayList5, arrayList27, arrayList4));
                                                    arrayList19 = arrayList54;
                                                    j7 = j13;
                                                    j9 = j12;
                                                    arrayList20 = arrayList20;
                                                    str3 = str47;
                                                    str4 = str53;
                                                } else {
                                                    long j64 = j13;
                                                    i7 = 1;
                                                    int i60 = i43;
                                                    str46 = str10;
                                                    i43 = i60;
                                                    arrayList24 = arrayList24;
                                                    arrayList29 = arrayList29;
                                                    str50 = str50;
                                                    arrayList16 = arrayList16;
                                                    z6 = z6;
                                                    str51 = str8;
                                                    str55 = str55;
                                                    arrayList28 = arrayList4;
                                                    arrayList25 = arrayList5;
                                                    j37 = j12;
                                                    str45 = str45;
                                                    f9 = f9;
                                                    arrayList27 = arrayList27;
                                                    str33 = str33;
                                                    arrayList19 = arrayList19;
                                                    arrayList20 = arrayList20;
                                                    str48 = str48;
                                                    arrayList23 = arrayList23;
                                                    str47 = str47;
                                                    str53 = str53;
                                                    str44 = str44;
                                                    arrayList22 = arrayList6;
                                                    str34 = str9;
                                                    arrayList17 = arrayList17;
                                                    arrayList30 = arrayList30;
                                                    j38 = j10;
                                                    str49 = str49;
                                                    arrayList3 = arrayList3;
                                                    j35 = j64;
                                                    arrayList26 = arrayList26;
                                                    str56 = str56;
                                                }
                                            }
                                            str10 = str46;
                                            str56 = str56;
                                            jD3 = jD3;
                                            i8 = 0;
                                            arrayList30 = arrayList30;
                                            arrayList4 = arrayList28;
                                            str9 = str34;
                                            arrayList6 = arrayList22;
                                            j12 = j37;
                                            str8 = str51;
                                            long j411 = j35;
                                            arrayList3 = arrayList3;
                                            z6 = z6;
                                            j10 = j38;
                                            arrayList17 = arrayList17;
                                            arrayList5 = arrayList25;
                                            arrayList16 = arrayList16;
                                            j13 = j411;
                                            if (p117t0.a.q(xmlPullParser, str10)) {
                                                arrayList13 = new ArrayList(arrayList29.size());
                                                i31 = i8;
                                                while (i31 < arrayList29.size()) {
                                                    d dVar6 = (d) arrayList29.get(i31);
                                                    c0426nA = dVar6.f215a.a();
                                                    str28 = str48;
                                                    if (str28 == null) {
                                                        c0426nA.f8354c = C.n(arrayList6);
                                                    } else {
                                                        c0426nA.f8354c = C.n(arrayList6);
                                                    }
                                                    str29 = dVar6.f218d;
                                                    if (str29 == null) {
                                                        str29 = str57;
                                                    }
                                                    arrayList14 = dVar6.f219e;
                                                    ArrayList arrayList55 = arrayList6;
                                                    ArrayList arrayList56 = arrayList23;
                                                    arrayList14.addAll(arrayList56);
                                                    long j65 = j10;
                                                    if (arrayList14.isEmpty()) {
                                                        i32 = i8;
                                                        while (true) {
                                                            if (i32 < arrayList14.size()) {
                                                                c0423k4 = (C0423k) arrayList14.get(i32);
                                                                str30 = str9;
                                                                if (AbstractC0419g.f8327c.equals(c0423k4.f8338s)) {
                                                                }
                                                                i32++;
                                                                str9 = str30;
                                                            } else {
                                                                str30 = str9;
                                                                str31 = null;
                                                            }
                                                        }
                                                        if (str31 != null) {
                                                            i33 = i8;
                                                            while (i33 < arrayList14.size()) {
                                                                c0423k = (C0423k) arrayList14.get(i33);
                                                                String str96 = str28;
                                                                if (!AbstractC0419g.f8326b.equals(c0423k.f8338s)) {
                                                                }
                                                                i33++;
                                                                j13 = j13;
                                                                str28 = str96;
                                                            }
                                                        }
                                                        str48 = str28;
                                                        j18 = j13;
                                                        while (size >= 0) {
                                                            c0423k2 = (C0423k) arrayList14.get(size);
                                                            if (c0423k2.f8340v != null) {
                                                                while (i34 < arrayList14.size()) {
                                                                    c0423k3 = (C0423k) arrayList14.get(i34);
                                                                    if (c0423k3.f8340v == null) {
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        c0426nA.f8366p = new C0424l(str29, arrayList14);
                                                    } else {
                                                        str30 = str9;
                                                        str48 = str28;
                                                        j18 = j13;
                                                    }
                                                    arrayList15 = dVar6.f220f;
                                                    arrayList15.addAll(arrayList24);
                                                    c0427o = new C0427o(c0426nA);
                                                    c2 = dVar6.f216b;
                                                    sVar = dVar6.f217c;
                                                    if (sVar instanceof r) {
                                                        kVar = new l(c0427o, c2, (r) sVar, arrayList15);
                                                    } else {
                                                        if (sVar instanceof n) {
                                                            throw new IllegalArgumentException("segmentBase must be of type SingleSegmentBase or MultiSegmentBase");
                                                        }
                                                        kVar = new k(c0427o, c2, (n) sVar, arrayList15);
                                                    }
                                                    arrayList13.add(kVar);
                                                    i31++;
                                                    j13 = j18;
                                                    j10 = j65;
                                                    str9 = str30;
                                                    arrayList23 = arrayList56;
                                                    arrayList6 = arrayList55;
                                                }
                                                str2 = str9;
                                                i7 = 1;
                                                ArrayList arrayList57 = arrayList19;
                                                arrayList57.add(new a(j40, i43, arrayList13, arrayList5, arrayList27, arrayList4));
                                                arrayList19 = arrayList57;
                                                j7 = j13;
                                                j9 = j12;
                                                arrayList20 = arrayList20;
                                                str3 = str47;
                                                str4 = str53;
                                            } else {
                                                long j66 = j13;
                                                i7 = 1;
                                                int i61 = i43;
                                                str46 = str10;
                                                i43 = i61;
                                                arrayList24 = arrayList24;
                                                arrayList29 = arrayList29;
                                                str50 = str50;
                                                arrayList16 = arrayList16;
                                                z6 = z6;
                                                str51 = str8;
                                                str55 = str55;
                                                arrayList28 = arrayList4;
                                                arrayList25 = arrayList5;
                                                j37 = j12;
                                                str45 = str45;
                                                f9 = f9;
                                                arrayList27 = arrayList27;
                                                str33 = str33;
                                                arrayList19 = arrayList19;
                                                arrayList20 = arrayList20;
                                                str48 = str48;
                                                arrayList23 = arrayList23;
                                                str47 = str47;
                                                str53 = str53;
                                                str44 = str44;
                                                arrayList22 = arrayList6;
                                                str34 = str9;
                                                arrayList17 = arrayList17;
                                                arrayList30 = arrayList30;
                                                j38 = j10;
                                                str49 = str49;
                                                arrayList3 = arrayList3;
                                                j35 = j66;
                                                arrayList26 = arrayList26;
                                                str56 = str56;
                                            }
                                        }
                                    } else {
                                        arrayList = arrayList18;
                                        str2 = str34;
                                        String str97 = str41;
                                        j25 = j25;
                                        str33 = str33;
                                        String str98 = str42;
                                        arrayList2 = arrayList21;
                                        long j67 = j38;
                                        long j68 = j35;
                                        long j69 = j37;
                                        ArrayList arrayList58 = arrayList20;
                                        i8 = 0;
                                        arrayList17 = arrayList17;
                                        z6 = z6;
                                        arrayList16 = arrayList16;
                                        ArrayList arrayList59 = arrayList19;
                                        if (p117t0.a.r(xmlPullParser, "EventStream")) {
                                            String attributeValue29 = xmlPullParser.getAttributeValue(null, str);
                                            String str99 = attributeValue29 == null ? StringUtils.EMPTY : attributeValue29;
                                            str43 = str43;
                                            String attributeValue30 = xmlPullParser.getAttributeValue(null, str43);
                                            String str100 = attributeValue30 == null ? StringUtils.EMPTY : attributeValue30;
                                            String attributeValue31 = xmlPullParser.getAttributeValue(null, "timescale");
                                            long j70 = attributeValue31 == null ? 1L : Long.parseLong(attributeValue31);
                                            String attributeValue32 = xmlPullParser.getAttributeValue(null, "presentationTimeOffset");
                                            long j71 = attributeValue32 == null ? 0L : Long.parseLong(attributeValue32);
                                            ArrayList arrayList60 = new ArrayList();
                                            ByteArrayOutputStream byteArrayOutputStream3 = new ByteArrayOutputStream(512);
                                            while (true) {
                                                xmlPullParser.next();
                                                if (p117t0.a.r(xmlPullParser, "Event")) {
                                                    str6 = str97;
                                                    String attributeValue33 = xmlPullParser.getAttributeValue(null, str6);
                                                    long j72 = attributeValue33 == null ? 0L : Long.parseLong(attributeValue33);
                                                    str5 = str98;
                                                    String attributeValue34 = xmlPullParser.getAttributeValue(null, str5);
                                                    long j73 = attributeValue34 == null ? -9223372036854775807L : Long.parseLong(attributeValue34);
                                                    String attributeValue35 = xmlPullParser.getAttributeValue(null, "presentationTime");
                                                    long j74 = attributeValue35 == null ? 0L : Long.parseLong(attributeValue35);
                                                    int i62 = p117t0.s.f9002a;
                                                    RoundingMode roundingMode = RoundingMode.FLOOR;
                                                    long jP = p117t0.s.P(j73, 1000L, j70, roundingMode);
                                                    long jP2 = p117t0.s.P(j74 - j71, 1000000L, j70, roundingMode);
                                                    String attributeValue36 = xmlPullParser.getAttributeValue(null, "messageData");
                                                    if (attributeValue36 == null) {
                                                        attributeValue36 = null;
                                                    }
                                                    byteArrayOutputStream3.reset();
                                                    XmlSerializer xmlSerializerNewSerializer = Xml.newSerializer();
                                                    xmlSerializerNewSerializer.setOutput(byteArrayOutputStream3, p104q3.d.f8663c.name());
                                                    xmlPullParser.nextToken();
                                                    while (!p117t0.a.q(xmlPullParser, "Event")) {
                                                        switch (xmlPullParser.getEventType()) {
                                                            case 0:
                                                                j71 = j71;
                                                                byteArrayOutputStream2 = byteArrayOutputStream3;
                                                                xmlSerializerNewSerializer.startDocument(null, Boolean.FALSE);
                                                                break;
                                                            case 1:
                                                                j71 = j71;
                                                                byteArrayOutputStream2 = byteArrayOutputStream3;
                                                                xmlSerializerNewSerializer.endDocument();
                                                                break;
                                                            case 2:
                                                                xmlSerializerNewSerializer.startTag(xmlPullParser.getNamespace(), xmlPullParser.getName());
                                                                int i63 = 0;
                                                                while (i63 < xmlPullParser.getAttributeCount()) {
                                                                    xmlSerializerNewSerializer.attribute(xmlPullParser.getAttributeNamespace(i63), xmlPullParser.getAttributeName(i63), xmlPullParser.getAttributeValue(i63));
                                                                    i63++;
                                                                    byteArrayOutputStream3 = byteArrayOutputStream3;
                                                                }
                                                                byteArrayOutputStream2 = byteArrayOutputStream3;
                                                                break;
                                                            case 3:
                                                                xmlSerializerNewSerializer.endTag(xmlPullParser.getNamespace(), xmlPullParser.getName());
                                                                byteArrayOutputStream2 = byteArrayOutputStream3;
                                                                break;
                                                            case 4:
                                                                xmlSerializerNewSerializer.text(xmlPullParser.getText());
                                                                byteArrayOutputStream2 = byteArrayOutputStream3;
                                                                break;
                                                            case 5:
                                                                xmlSerializerNewSerializer.cdsect(xmlPullParser.getText());
                                                                byteArrayOutputStream2 = byteArrayOutputStream3;
                                                                break;
                                                            case 6:
                                                                xmlSerializerNewSerializer.entityRef(xmlPullParser.getText());
                                                                byteArrayOutputStream2 = byteArrayOutputStream3;
                                                                break;
                                                            case 7:
                                                                xmlSerializerNewSerializer.ignorableWhitespace(xmlPullParser.getText());
                                                                byteArrayOutputStream2 = byteArrayOutputStream3;
                                                                break;
                                                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                                                xmlSerializerNewSerializer.processingInstruction(xmlPullParser.getText());
                                                                byteArrayOutputStream2 = byteArrayOutputStream3;
                                                                break;
                                                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                                                xmlSerializerNewSerializer.comment(xmlPullParser.getText());
                                                                byteArrayOutputStream2 = byteArrayOutputStream3;
                                                                break;
                                                            case 10:
                                                                xmlSerializerNewSerializer.docdecl(xmlPullParser.getText());
                                                                byteArrayOutputStream2 = byteArrayOutputStream3;
                                                                break;
                                                            default:
                                                                byteArrayOutputStream2 = byteArrayOutputStream3;
                                                                break;
                                                        }
                                                        xmlPullParser.nextToken();
                                                        byteArrayOutputStream3 = byteArrayOutputStream2;
                                                        j71 = j71;
                                                    }
                                                    j11 = j71;
                                                    byteArrayOutputStream = byteArrayOutputStream3;
                                                    xmlSerializerNewSerializer.flush();
                                                    byte[] byteArray = byteArrayOutputStream.toByteArray();
                                                    Long lValueOf = Long.valueOf(jP2);
                                                    if (attributeValue36 != null) {
                                                        byteArray = attributeValue36.getBytes(p104q3.d.f8663c);
                                                    }
                                                    arrayList60.add(Pair.create(lValueOf, new p012c1.a(str99, str100, jP, j72, byteArray)));
                                                } else {
                                                    byteArrayOutputStream = byteArrayOutputStream3;
                                                    str5 = str98;
                                                    str6 = str97;
                                                    j11 = j71;
                                                    b(xmlPullParser);
                                                }
                                                if (p117t0.a.q(xmlPullParser, "EventStream")) {
                                                    long[] jArr = new long[arrayList60.size()];
                                                    p012c1.a[] aVarArr = new p012c1.a[arrayList60.size()];
                                                    for (int i64 = 0; i64 < arrayList60.size(); i64++) {
                                                        Pair pair = (Pair) arrayList60.get(i64);
                                                        jArr[i64] = ((Long) pair.first).longValue();
                                                        aVarArr[i64] = (p012c1.a) pair.second;
                                                    }
                                                    arrayList58.add(new g(str99, str100, jArr, aVarArr));
                                                    arrayList20 = arrayList58;
                                                    str4 = str6;
                                                    arrayList19 = arrayList59;
                                                    str3 = str5;
                                                    str = str;
                                                    j7 = j68;
                                                    j9 = j69;
                                                    j10 = j67;
                                                } else {
                                                    str99 = str99;
                                                    str100 = str100;
                                                    str97 = str6;
                                                    str98 = str5;
                                                    byteArrayOutputStream3 = byteArrayOutputStream;
                                                    str43 = str43;
                                                    j71 = j11;
                                                    j70 = j70;
                                                }
                                            }
                                        } else {
                                            str3 = str98;
                                            if (p117t0.a.r(xmlPullParser, "SegmentBase")) {
                                                sVarR2 = p(xmlPullParser, null);
                                                arrayList20 = arrayList58;
                                                str4 = str97;
                                                arrayList19 = arrayList59;
                                                str = str;
                                                j7 = j68;
                                                j9 = j69;
                                                j10 = j67;
                                                j6 = -9223372036854775807L;
                                            } else if (p117t0.a.r(xmlPullParser, "SegmentList")) {
                                                long jD9 = d(xmlPullParser, -9223372036854775807L);
                                                arrayList20 = arrayList58;
                                                str4 = str97;
                                                str = str;
                                                j6 = -9223372036854775807L;
                                                sVarR2 = q(xmlPullParser, null, j69, j67, j8, jD9, j68);
                                                j10 = j67;
                                                j9 = j69;
                                                j39 = jD9;
                                                arrayList19 = arrayList59;
                                                j7 = j68;
                                            } else {
                                                arrayList20 = arrayList58;
                                                str4 = str97;
                                                j9 = j69;
                                                j10 = j67;
                                                j6 = -9223372036854775807L;
                                                if (p117t0.a.r(xmlPullParser, "SegmentTemplate")) {
                                                    str = str;
                                                    long jD10 = d(xmlPullParser, -9223372036854775807L);
                                                    A a5 = C.f8765s;
                                                    arrayList19 = arrayList59;
                                                    j7 = j68;
                                                    sVarR2 = r(xmlPullParser, null, T.f8782v, j9, j10, j8, jD10, j7);
                                                    j39 = jD10;
                                                } else {
                                                    arrayList19 = arrayList59;
                                                    j7 = j68;
                                                    if (p117t0.a.r(xmlPullParser, "AssetIdentifier")) {
                                                        str = str;
                                                        i(xmlPullParser, "AssetIdentifier");
                                                    } else {
                                                        str = str;
                                                        b(xmlPullParser);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    j6 = -9223372036854775807L;
                                }
                                if (p117t0.a.q(xmlPullParser, obj)) {
                                    Pair pairCreate2 = Pair.create(new h(attributeValue11, j36, arrayList19, arrayList20), Long.valueOf(j10));
                                    h hVar = (h) pairCreate2.first;
                                    if (hVar.f232b != j6) {
                                        long jLongValue = ((Long) pairCreate2.second).longValue();
                                        long j75 = jLongValue == j6 ? j6 : jLongValue + hVar.f232b;
                                        arrayList16 = arrayList16;
                                        arrayList16.add(hVar);
                                        j25 = j75;
                                    } else {
                                        if (!zEquals) {
                                            throw D.b("Unable to determine start of period " + arrayList16.size(), null);
                                        }
                                        i38 = i7;
                                        arrayList16 = arrayList16;
                                    }
                                } else {
                                    z6 = z6;
                                    j35 = j7;
                                    obj = obj;
                                    j37 = j9;
                                    arrayList16 = arrayList16;
                                    str40 = str;
                                    arrayList18 = arrayList;
                                    j25 = j25;
                                    str42 = str3;
                                    arrayList21 = arrayList2;
                                    str41 = str4;
                                    str34 = str2;
                                    str33 = str33;
                                    arrayList17 = arrayList17;
                                    j38 = j10;
                                    jD2 = j8;
                                }
                            }
                        } else {
                            z6 = z6;
                            j7 = j35;
                            j25 = j25;
                            arrayList16 = arrayList16;
                            j6 = j6;
                            i8 = 0;
                            arrayList17 = arrayList17;
                            b(xmlPullParser);
                        }
                        jD = j34;
                    }
                    if (p117t0.a.q(xmlPullParser, "MPD")) {
                        if (j20 == j6) {
                            if (j25 != j6) {
                                j20 = j25;
                            } else if (!zEquals) {
                                throw D.b("Unable to determine duration of static manifest.", null);
                            }
                        }
                        if (arrayList16.isEmpty()) {
                            throw D.b("No periods found.", null);
                        }
                        return new c(jK, j20, j21, zEquals, j22, j7, j24, jK2, iVar, uVar, tVar, uriV, arrayList16);
                    }
                    arrayList16 = arrayList16;
                    j23 = j7;
                    j19 = j6;
                    i6 = i7;
                    i35 = i8;
                    arrayList17 = arrayList17;
                    z6 = z6;
                    arrayListK = arrayListK;
                    j25 = j25;
                    str32 = null;
                }
                i8 = 0;
            }
            j7 = j23;
            if (p117t0.a.q(xmlPullParser, "MPD")) {
                if (j20 == j6) {
                    if (j25 != j6) {
                        j20 = j25;
                    } else if (!zEquals) {
                        throw D.b("Unable to determine duration of static manifest.", null);
                    }
                }
                if (arrayList16.isEmpty()) {
                    return new c(jK, j20, j21, zEquals, j22, j7, j24, jK2, iVar, uVar, tVar, uriV, arrayList16);
                }
                throw D.b("No periods found.", null);
            }
            arrayList16 = arrayList16;
            j23 = j7;
            j19 = j6;
            i6 = i7;
            i35 = i8;
            arrayList17 = arrayList17;
            z6 = z6;
            arrayListK = arrayListK;
            j25 = j25;
            str32 = null;
        }
    }

    public static j m(XmlPullParser xmlPullParser, String str, String str2) {
        long j6;
        String attributeValue = xmlPullParser.getAttributeValue(null, str);
        String attributeValue2 = xmlPullParser.getAttributeValue(null, str2);
        long j7 = -1;
        if (attributeValue2 != null) {
            String[] strArrSplit = attributeValue2.split("-");
            j6 = Long.parseLong(strArrSplit[0]);
            if (strArrSplit.length == 2) {
                j7 = (Long.parseLong(strArrSplit[1]) - j6) + 1;
            }
        } else {
            j6 = 0;
        }
        return new j(j6, j7, attributeValue);
    }

    public static int n(String str) {
        if (str != null) {
            switch (str) {
                case "subtitle":
                case "forced_subtitle":
                case "forced-subtitle":
                    return 128;
                case "description":
                    return 512;
                case "enhanced-audio-intelligibility":
                    return 2048;
                case "alternate":
                    return 2;
                case "dub":
                    return 16;
                case "main":
                    return 1;
                case "sign":
                    return 256;
                case "caption":
                    return 64;
                case "commentary":
                    return 8;
                case "emergency":
                    return 32;
                case "supplementary":
                    return 4;
            }
        }
        return 0;
    }

    public static int o(ArrayList arrayList) {
        int i6 = 0;
        for (int i7 = 0; i7 < arrayList.size(); i7++) {
            if (p000a.a.o("http://dashif.org/guidelines/trickmode", ((f) arrayList.get(i7)).f224a)) {
                i6 = 16384;
            }
        }
        return i6;
    }

    public static r p(XmlPullParser xmlPullParser, r rVar) throws XmlPullParserException, IOException {
        long j6 = rVar != null ? rVar.f265b : 1L;
        String attributeValue = xmlPullParser.getAttributeValue(null, "timescale");
        if (attributeValue != null) {
            j6 = Long.parseLong(attributeValue);
        }
        long j7 = j6;
        long j8 = rVar != null ? rVar.f266c : 0L;
        String attributeValue2 = xmlPullParser.getAttributeValue(null, "presentationTimeOffset");
        if (attributeValue2 != null) {
            j8 = Long.parseLong(attributeValue2);
        }
        long j9 = j8;
        long j10 = rVar != null ? rVar.f262d : 0L;
        long j11 = rVar != null ? rVar.f263e : 0L;
        String attributeValue3 = xmlPullParser.getAttributeValue(null, "indexRange");
        if (attributeValue3 != null) {
            String[] strArrSplit = attributeValue3.split("-");
            j10 = Long.parseLong(strArrSplit[0]);
            j11 = (Long.parseLong(strArrSplit[1]) - j10) + 1;
        }
        long j12 = j11;
        long j13 = j10;
        j jVarM = rVar != null ? rVar.f264a : null;
        while (true) {
            xmlPullParser.next();
            if (p117t0.a.r(xmlPullParser, "Initialization")) {
                jVarM = m(xmlPullParser, "sourceURL", "range");
            } else {
                b(xmlPullParser);
            }
            j jVar = jVarM;
            if (p117t0.a.q(xmlPullParser, "SegmentBase")) {
                return new r(jVar, j7, j9, j13, j12);
            }
            jVarM = jVar;
        }
    }

    public static o q(XmlPullParser xmlPullParser, o oVar, long j6, long j7, long j8, long j9, long j10) throws XmlPullParserException, IOException {
        long j11 = oVar != null ? oVar.f265b : 1L;
        List arrayList = null;
        String attributeValue = xmlPullParser.getAttributeValue(null, "timescale");
        if (attributeValue != null) {
            j11 = Long.parseLong(attributeValue);
        }
        long j12 = j11;
        long j13 = oVar != null ? oVar.f266c : 0L;
        String attributeValue2 = xmlPullParser.getAttributeValue(null, "presentationTimeOffset");
        if (attributeValue2 != null) {
            j13 = Long.parseLong(attributeValue2);
        }
        long j14 = j13;
        long j15 = oVar != null ? oVar.f251e : -9223372036854775807L;
        String attributeValue3 = xmlPullParser.getAttributeValue(null, "duration");
        if (attributeValue3 != null) {
            j15 = Long.parseLong(attributeValue3);
        }
        long j16 = j15;
        long j17 = oVar != null ? oVar.f250d : 1L;
        String attributeValue4 = xmlPullParser.getAttributeValue(null, "startNumber");
        if (attributeValue4 != null) {
            j17 = Long.parseLong(attributeValue4);
        }
        long j18 = j17;
        long j19 = j9 == -9223372036854775807L ? j8 : j9;
        long j20 = j19 == Long.MAX_VALUE ? -9223372036854775807L : j19;
        j jVarM = null;
        List listS = null;
        do {
            xmlPullParser.next();
            if (p117t0.a.r(xmlPullParser, "Initialization")) {
                jVarM = m(xmlPullParser, "sourceURL", "range");
            } else if (p117t0.a.r(xmlPullParser, "SegmentTimeline")) {
                listS = s(xmlPullParser, j12, j7);
            } else if (p117t0.a.r(xmlPullParser, "SegmentURL")) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add(m(xmlPullParser, "media", "mediaRange"));
            } else {
                b(xmlPullParser);
            }
        } while (!p117t0.a.q(xmlPullParser, "SegmentList"));
        if (oVar != null) {
            if (jVarM == null) {
                jVarM = oVar.f264a;
            }
            if (listS == null) {
                listS = oVar.f252f;
            }
            if (arrayList == null) {
                arrayList = oVar.f256j;
            }
        }
        return new o(jVarM, j12, j14, j18, j16, listS, j20, arrayList, p117t0.s.H(j10), p117t0.s.H(j6));
    }

    public static p r(XmlPullParser xmlPullParser, p pVar, List list, long j6, long j7, long j8, long j9, long j10) throws XmlPullParserException, IOException {
        long j11;
        long j12 = pVar != null ? pVar.f265b : 1L;
        j jVarM = null;
        String attributeValue = xmlPullParser.getAttributeValue(null, "timescale");
        if (attributeValue != null) {
            j12 = Long.parseLong(attributeValue);
        }
        long j13 = j12;
        long j14 = pVar != null ? pVar.f266c : 0L;
        String attributeValue2 = xmlPullParser.getAttributeValue(null, "presentationTimeOffset");
        if (attributeValue2 != null) {
            j14 = Long.parseLong(attributeValue2);
        }
        long j15 = j14;
        long j16 = pVar != null ? pVar.f251e : -9223372036854775807L;
        String attributeValue3 = xmlPullParser.getAttributeValue(null, "duration");
        if (attributeValue3 != null) {
            j16 = Long.parseLong(attributeValue3);
        }
        long j17 = j16;
        long j18 = pVar != null ? pVar.f250d : 1L;
        String attributeValue4 = xmlPullParser.getAttributeValue(null, "startNumber");
        if (attributeValue4 != null) {
            j18 = Long.parseLong(attributeValue4);
        }
        long j19 = j18;
        int i6 = 0;
        while (true) {
            if (i6 >= list.size()) {
                j11 = -1;
                break;
            }
            f fVar = (f) list.get(i6);
            if (p000a.a.o("http://dashif.org/guidelines/last-segment-number", fVar.f224a)) {
                j11 = Long.parseLong(fVar.f225b);
                break;
            }
            i6++;
        }
        long j20 = j11;
        long j21 = j9 == -9223372036854775807L ? j8 : j9;
        long j22 = j21 == Long.MAX_VALUE ? -9223372036854775807L : j21;
        A4.d dVarT = t(xmlPullParser, "media", pVar != null ? pVar.f258k : null);
        A4.d dVarT2 = t(xmlPullParser, "initialization", pVar != null ? pVar.f257j : null);
        List listS = null;
        do {
            xmlPullParser.next();
            if (p117t0.a.r(xmlPullParser, "Initialization")) {
                jVarM = m(xmlPullParser, "sourceURL", "range");
            } else if (p117t0.a.r(xmlPullParser, "SegmentTimeline")) {
                listS = s(xmlPullParser, j13, j7);
            } else {
                b(xmlPullParser);
            }
        } while (!p117t0.a.q(xmlPullParser, "SegmentTemplate"));
        if (pVar != null) {
            if (jVarM == null) {
                jVarM = pVar.f264a;
            }
            if (listS == null) {
                listS = pVar.f252f;
            }
        }
        return new p(jVarM, j13, j15, j19, j20, j17, listS, j22, dVarT2, dVarT, p117t0.s.H(j10), p117t0.s.H(j6));
    }

    public static ArrayList s(XmlPullParser xmlPullParser, long j6, long j7) throws XmlPullParserException, IOException {
        long j8;
        ArrayList arrayList = new ArrayList();
        long jA = 0;
        long j9 = -9223372036854775807L;
        boolean z6 = false;
        int i6 = 0;
        do {
            xmlPullParser.next();
            if (p117t0.a.r(xmlPullParser, "S")) {
                String attributeValue = xmlPullParser.getAttributeValue(null, "t");
                long j10 = attributeValue == null ? -9223372036854775807L : Long.parseLong(attributeValue);
                if (z6) {
                    int i7 = i6;
                    j8 = j10;
                    jA = a(arrayList, jA, j9, i7, j8);
                } else {
                    j8 = j10;
                }
                if (j8 != -9223372036854775807L) {
                    jA = j8;
                }
                String attributeValue2 = xmlPullParser.getAttributeValue(null, "d");
                j9 = attributeValue2 == null ? -9223372036854775807L : Long.parseLong(attributeValue2);
                String attributeValue3 = xmlPullParser.getAttributeValue(null, "r");
                i6 = attributeValue3 == null ? 0 : Integer.parseInt(attributeValue3);
                z6 = true;
            } else {
                b(xmlPullParser);
            }
        } while (!p117t0.a.q(xmlPullParser, "SegmentTimeline"));
        if (z6) {
            int i8 = p117t0.s.f9002a;
            a(arrayList, jA, j9, i6, p117t0.s.P(j7, j6, 1000L, RoundingMode.FLOOR));
        }
        return arrayList;
    }

    /* JADX WARN: Failed to find 'out' block for switch in B:30:0x00ff. Please report as an issue. */
    public static A4.d t(XmlPullParser xmlPullParser, String str, A4.d dVar) {
        String strSubstring;
        String attributeValue = xmlPullParser.getAttributeValue(null, str);
        if (attributeValue == null) {
            return dVar;
        }
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList();
        arrayList.add(StringUtils.EMPTY);
        int length = 0;
        while (length < attributeValue.length()) {
            int iIndexOf = attributeValue.indexOf("$", length);
            if (iIndexOf == -1) {
                arrayList.set(arrayList2.size(), ((String) arrayList.get(arrayList2.size())) + attributeValue.substring(length));
                length = attributeValue.length();
            } else if (iIndexOf != length) {
                arrayList.set(arrayList2.size(), ((String) arrayList.get(arrayList2.size())) + attributeValue.substring(length, iIndexOf));
                length = iIndexOf;
            } else if (attributeValue.startsWith("$$", length)) {
                arrayList.set(arrayList2.size(), ((String) arrayList.get(arrayList2.size())) + "$");
                length += 2;
            } else {
                arrayList3.add(StringUtils.EMPTY);
                int i6 = length + 1;
                int iIndexOf2 = attributeValue.indexOf("$", i6);
                String strSubstring2 = attributeValue.substring(i6, iIndexOf2);
                if (strSubstring2.equals("RepresentationID")) {
                    arrayList2.add(1);
                } else {
                    int iIndexOf3 = strSubstring2.indexOf("%0");
                    if (iIndexOf3 != -1) {
                        strSubstring = strSubstring2.substring(iIndexOf3);
                        if (!strSubstring.endsWith("d") && !strSubstring.endsWith("x") && !strSubstring.endsWith("X")) {
                            strSubstring = strSubstring.concat("d");
                        }
                        strSubstring2 = strSubstring2.substring(0, iIndexOf3);
                    } else {
                        strSubstring = "%01d";
                    }
                    strSubstring2.getClass();
                    switch (strSubstring2) {
                        case "Number":
                            arrayList2.add(2);
                            break;
                        case "Time":
                            arrayList2.add(4);
                            break;
                        case "Bandwidth":
                            arrayList2.add(3);
                            break;
                        default:
                            throw new IllegalArgumentException("Invalid template: ".concat(attributeValue));
                    }
                    arrayList3.set(arrayList2.size() - 1, strSubstring);
                }
                arrayList.add(StringUtils.EMPTY);
                length = iIndexOf2 + 1;
            }
        }
        return new A4.d(arrayList, arrayList2, arrayList3, 1);
    }

    @Override // N0.q
    public final Object g(Uri uri, p128v0.j jVar) throws D {
        try {
            XmlPullParser xmlPullParserNewPullParser = this.r.newPullParser();
            xmlPullParserNewPullParser.setInput(jVar, null);
            if (xmlPullParserNewPullParser.next() == 2 && "MPD".equals(xmlPullParserNewPullParser.getName())) {
                return l(xmlPullParserNewPullParser, uri);
            }
            throw D.b("inputStream does not contain a valid media presentation description", null);
        } catch (XmlPullParserException e6) {
            throw D.b(null, e6);
        }
    }
}
