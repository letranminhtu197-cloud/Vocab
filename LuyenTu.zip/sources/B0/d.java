package B0;

import java.util.ArrayList;
import p101q0.C0427o;
import p108r3.C;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0427o f215a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C f216b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final s f217c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f218d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final ArrayList f219e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final ArrayList f220f;

    public d(C0427o c0427o, ArrayList arrayList, s sVar, String str, ArrayList arrayList2, ArrayList arrayList3, ArrayList arrayList4, ArrayList arrayList5) {
        this.f215a = c0427o;
        this.f216b = C.n(arrayList);
        this.f217c = sVar;
        this.f218d = str;
        this.f219e = arrayList2;
        this.f220f = arrayList3;
    }
}
