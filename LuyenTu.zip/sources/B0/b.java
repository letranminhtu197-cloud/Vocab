package B0;

import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f198a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f199b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f200c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f201d;

    public b(int i6, int i7, String str, String str2) {
        this.f198a = str;
        this.f199b = str2;
        this.f200c = i6;
        this.f201d = i7;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return this.f200c == bVar.f200c && this.f201d == bVar.f201d && android.support.v4.media.session.b.B(this.f198a, bVar.f198a) && android.support.v4.media.session.b.B(this.f199b, bVar.f199b);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{this.f198a, this.f199b, Integer.valueOf(this.f200c), Integer.valueOf(this.f201d)});
    }
}
