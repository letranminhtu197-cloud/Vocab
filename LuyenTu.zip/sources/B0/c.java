package B0;

import android.net.Uri;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import p101q0.K;

/* JADX INFO: loaded from: classes.dex */
public final class c implements I0.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f202a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f203b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f204c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f205d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f206e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final long f207f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final long f208g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final long f209h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final u f210i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final t f211j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final Uri f212k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final i f213l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final List f214m;

    public c(long j6, long j7, long j8, boolean z6, long j9, long j10, long j11, long j12, i iVar, u uVar, t tVar, Uri uri, ArrayList arrayList) {
        this.f202a = j6;
        this.f203b = j7;
        this.f204c = j8;
        this.f205d = z6;
        this.f206e = j9;
        this.f207f = j10;
        this.f208g = j11;
        this.f209h = j12;
        this.f213l = iVar;
        this.f210i = uVar;
        this.f212k = uri;
        this.f211j = tVar;
        this.f214m = arrayList;
    }

    @Override // I0.a
    public final Object a(List list) {
        long j6;
        LinkedList linkedList = new LinkedList(list);
        Collections.sort(linkedList);
        linkedList.add(new K());
        ArrayList arrayList = new ArrayList();
        long j7 = 0;
        int i6 = 0;
        while (true) {
            if (i6 >= this.f214m.size()) {
                break;
            }
            if (((K) linkedList.peek()).r != i6) {
                long jC = c(i6);
                if (jC != -9223372036854775807L) {
                    j7 += jC;
                }
            } else {
                h hVarB = b(i6);
                List list2 = hVarB.f233c;
                K k3 = (K) linkedList.poll();
                int i7 = k3.r;
                ArrayList arrayList2 = new ArrayList();
                while (true) {
                    int i8 = k3.f8232s;
                    a aVar = (a) list2.get(i8);
                    List list3 = aVar.f194c;
                    ArrayList arrayList3 = new ArrayList();
                    do {
                        arrayList3.add((m) list3.get(k3.t));
                        k3 = (K) linkedList.poll();
                        if (k3.r != i7) {
                            break;
                        }
                    } while (k3.f8232s == i8);
                    j6 = j7;
                    arrayList2.add(new a(aVar.f192a, aVar.f193b, arrayList3, aVar.f195d, aVar.f196e, aVar.f197f));
                    if (k3.r != i7) {
                        break;
                    }
                    j7 = j6;
                }
                linkedList.addFirst(k3);
                arrayList.add(new h(hVarB.f231a, hVarB.f232b - j6, arrayList2, hVarB.f234d));
                j7 = j6;
            }
            i6++;
        }
        long j8 = j7;
        long j9 = this.f203b;
        return new c(this.f202a, j9 != -9223372036854775807L ? j9 - j8 : -9223372036854775807L, this.f204c, this.f205d, this.f206e, this.f207f, this.f208g, this.f209h, this.f213l, this.f210i, this.f211j, this.f212k, arrayList);
    }

    public final h b(int i6) {
        return (h) this.f214m.get(i6);
    }

    public final long c(int i6) {
        long j6;
        long j7;
        List list = this.f214m;
        if (i6 == list.size() - 1) {
            j6 = this.f203b;
            if (j6 == -9223372036854775807L) {
                return -9223372036854775807L;
            }
            j7 = ((h) list.get(i6)).f232b;
        } else {
            j6 = ((h) list.get(i6 + 1)).f232b;
            j7 = ((h) list.get(i6)).f232b;
        }
        return j6 - j7;
    }

    public final long d(int i6) {
        return p117t0.s.H(c(i6));
    }
}
