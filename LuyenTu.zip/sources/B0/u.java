package B0;

/* JADX INFO: loaded from: classes.dex */
public final class u {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f272a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f273b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public String f274c;

    public String toString() {
        switch (this.f272a) {
            case 0:
                return this.f273b + ", " + this.f274c;
            default:
                return super.toString();
        }
    }

    public /* synthetic */ u(String str, int i6, String str2) {
        this.f272a = i6;
        this.f273b = str;
        this.f274c = str2;
    }
}
