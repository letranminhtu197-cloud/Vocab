package B0;

/* JADX INFO: loaded from: classes.dex */
public abstract class s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final j f264a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f265b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f266c;

    public s(j jVar, long j6, long j7) {
        this.f264a = jVar;
        this.f265b = j6;
        this.f266c = j7;
    }

    public j a(m mVar) {
        return this.f264a;
    }
}
