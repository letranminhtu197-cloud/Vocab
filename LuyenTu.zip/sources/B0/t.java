package B0;

import p101q0.C0430s;

/* JADX INFO: loaded from: classes.dex */
public final class t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f267a = -9223372036854775807L;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f268b = -9223372036854775807L;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public long f269c = -9223372036854775807L;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f270d = -3.4028235E38f;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public float f271e = -3.4028235E38f;

    public C0430s a() {
        return new C0430s(this);
    }
}
