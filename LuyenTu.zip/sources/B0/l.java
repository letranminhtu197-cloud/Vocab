package B0;

import android.net.Uri;
import java.util.ArrayList;
import p101q0.C0427o;
import p108r3.C;

/* JADX INFO: loaded from: classes.dex */
public final class l extends m {

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final j f245w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final A0.i f246x;

    public l(C0427o c0427o, C c2, r rVar, ArrayList arrayList) {
        super(c0427o, c2, rVar, arrayList);
        Uri.parse(((b) c2.get(0)).f198a);
        long j6 = rVar.f263e;
        j jVar = j6 <= 0 ? null : new j(rVar.f262d, j6, null);
        this.f245w = jVar;
        this.f246x = jVar == null ? new A0.i(new j(0L, -1L, null), 1) : null;
    }

    @Override // B0.m
    public final String a() {
        return null;
    }

    @Override // B0.m
    public final A0.l b() {
        return this.f246x;
    }

    @Override // B0.m
    public final j e() {
        return this.f245w;
    }
}
