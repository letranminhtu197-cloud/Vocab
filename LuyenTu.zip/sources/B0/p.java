package B0;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.List;
import p101q0.C0427o;

/* JADX INFO: loaded from: classes.dex */
public final class p extends n {

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final A4.d f257j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final A4.d f258k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final long f259l;

    public p(j jVar, long j6, long j7, long j8, long j9, long j10, List list, long j11, A4.d dVar, A4.d dVar2, long j12, long j13) {
        super(jVar, j6, j7, j8, j10, list, j11, j12, j13);
        this.f257j = dVar;
        this.f258k = dVar2;
        this.f259l = j9;
    }

    @Override // B0.s
    public final j a(m mVar) {
        A4.d dVar = this.f257j;
        if (dVar == null) {
            return this.f264a;
        }
        C0427o c0427o = mVar.r;
        return new j(0L, -1L, dVar.w(c0427o.f8384a, 0L, c0427o.f8392i, 0L));
    }

    @Override // B0.n
    public final long d(long j6) {
        List list = this.f252f;
        if (list != null) {
            return list.size();
        }
        long j7 = this.f259l;
        if (j7 != -1) {
            return (j7 - this.f250d) + 1;
        }
        if (j6 == -9223372036854775807L) {
            return -1L;
        }
        BigInteger bigIntegerMultiply = BigInteger.valueOf(j6).multiply(BigInteger.valueOf(this.f265b));
        BigInteger bigIntegerMultiply2 = BigInteger.valueOf(this.f251e).multiply(BigInteger.valueOf(1000000L));
        RoundingMode roundingMode = RoundingMode.CEILING;
        int i6 = t3.a.f9026a;
        return new BigDecimal(bigIntegerMultiply).divide(new BigDecimal(bigIntegerMultiply2), 0, roundingMode).toBigIntegerExact().longValue();
    }

    @Override // B0.n
    public final j h(k kVar, long j6) {
        long j7 = this.f250d;
        List list = this.f252f;
        long j8 = list != null ? ((q) list.get((int) (j6 - j7))).f260a : (j6 - j7) * this.f251e;
        C0427o c0427o = kVar.r;
        return new j(0L, -1L, this.f258k.w(c0427o.f8384a, j6, c0427o.f8392i, j8));
    }
}
