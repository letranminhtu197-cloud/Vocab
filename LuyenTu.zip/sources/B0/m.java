package B0;

import java.math.RoundingMode;
import java.util.Collections;
import java.util.List;
import p101q0.C0427o;
import p108r3.C;

/* JADX INFO: loaded from: classes.dex */
public abstract class m {
    public final C0427o r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final C f247s;
    public final long t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final List f248u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final j f249v;

    public m(C0427o c0427o, List list, s sVar, List list2) {
        p117t0.a.d(!list.isEmpty());
        this.r = c0427o;
        this.f247s = C.n(list);
        this.f248u = list2 == null ? Collections.EMPTY_LIST : Collections.unmodifiableList(list2);
        this.f249v = sVar.a(this);
        long j6 = sVar.f266c;
        long j7 = sVar.f265b;
        int i6 = p117t0.s.f9002a;
        this.t = p117t0.s.P(j6, 1000000L, j7, RoundingMode.FLOOR);
    }

    public abstract String a();

    public abstract A0.l b();

    public abstract j e();
}
