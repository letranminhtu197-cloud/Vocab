package B0;

/* JADX INFO: loaded from: classes.dex */
public final class r extends s {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f262d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f263e;

    public r(j jVar, long j6, long j7, long j8, long j9) {
        super(jVar, j6, j7);
        this.f262d = j8;
        this.f263e = j9;
    }
}
