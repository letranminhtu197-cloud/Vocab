package B0;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f231a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f232b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final List f233c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final List f234d;

    public h(String str, long j6, ArrayList arrayList, List list) {
        this.f231a = str;
        this.f232b = j6;
        this.f233c = Collections.unmodifiableList(arrayList);
        this.f234d = Collections.unmodifiableList(list);
    }
}
