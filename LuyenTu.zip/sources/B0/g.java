package B0;

/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p012c1.a[] f227a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long[] f228b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f229c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f230d;

    public g(String str, String str2, long[] jArr, p012c1.a[] aVarArr) {
        this.f229c = str;
        this.f230d = str2;
        this.f228b = jArr;
        this.f227a = aVarArr;
    }

    public final String a() {
        return this.f229c + "/" + this.f230d;
    }
}
