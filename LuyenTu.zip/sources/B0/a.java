package B0;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f192a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f193b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final List f194c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final List f195d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final List f196e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final List f197f;

    public a(long j6, int i6, ArrayList arrayList, List list, List list2, List list3) {
        this.f192a = j6;
        this.f193b = i6;
        this.f194c = Collections.unmodifiableList(arrayList);
        this.f195d = Collections.unmodifiableList(list);
        this.f196e = Collections.unmodifiableList(list2);
        this.f197f = Collections.unmodifiableList(list3);
    }
}
