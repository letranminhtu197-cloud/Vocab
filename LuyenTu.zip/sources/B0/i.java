package B0;

/* JADX INFO: loaded from: classes.dex */
public final class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f235a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f236b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f237c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f238d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f239e;

    public i(String str, String str2, String str3, String str4, String str5) {
        this.f235a = str;
        this.f236b = str2;
        this.f237c = str3;
        this.f238d = str4;
        this.f239e = str5;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof i)) {
            return false;
        }
        i iVar = (i) obj;
        return p117t0.s.a(this.f235a, iVar.f235a) && p117t0.s.a(this.f236b, iVar.f236b) && p117t0.s.a(this.f237c, iVar.f237c) && p117t0.s.a(this.f238d, iVar.f238d) && p117t0.s.a(this.f239e, iVar.f239e);
    }

    public final int hashCode() {
        String str = this.f235a;
        int iHashCode = (527 + (str != null ? str.hashCode() : 0)) * 31;
        String str2 = this.f236b;
        int iHashCode2 = (iHashCode + (str2 != null ? str2.hashCode() : 0)) * 31;
        String str3 = this.f237c;
        int iHashCode3 = (iHashCode2 + (str3 != null ? str3.hashCode() : 0)) * 31;
        String str4 = this.f238d;
        int iHashCode4 = (iHashCode3 + (str4 != null ? str4.hashCode() : 0)) * 31;
        String str5 = this.f239e;
        return iHashCode4 + (str5 != null ? str5.hashCode() : 0);
    }
}
