package B0;

/* JADX INFO: loaded from: classes.dex */
public final class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f260a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f261b;

    public q(long j6, long j7) {
        this.f260a = j6;
        this.f261b = j7;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && q.class == obj.getClass()) {
            q qVar = (q) obj;
            if (this.f260a == qVar.f260a && this.f261b == qVar.f261b) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return (((int) this.f260a) * 31) + ((int) this.f261b);
    }
}
