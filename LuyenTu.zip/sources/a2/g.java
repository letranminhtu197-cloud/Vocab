package a2;

import android.graphics.Rect;
import androidx.window.sidecar.SidecarDeviceState;
import androidx.window.sidecar.SidecarDisplayFeature;
import androidx.window.sidecar.SidecarWindowLayoutInfo;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final /* synthetic */ int f4007b = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f4008a;

    public g() {
        A3.a.p("verificationMode", 3);
        this.f4008a = 3;
    }

    public static boolean a(SidecarDisplayFeature sidecarDisplayFeature, SidecarDisplayFeature sidecarDisplayFeature2) {
        if (A5.h.a(sidecarDisplayFeature, sidecarDisplayFeature2)) {
            return true;
        }
        if (sidecarDisplayFeature == null || sidecarDisplayFeature2 == null || sidecarDisplayFeature.getType() != sidecarDisplayFeature2.getType()) {
            return false;
        }
        return A5.h.a(sidecarDisplayFeature.getRect(), sidecarDisplayFeature2.getRect());
    }

    public static boolean b(List list, List list2) {
        if (list == list2) {
            return true;
        }
        if (list.size() == list2.size()) {
            int size = list.size();
            for (int i6 = 0; i6 < size; i6++) {
                if (a((SidecarDisplayFeature) list.get(i6), (SidecarDisplayFeature) list2.get(i6))) {
                }
            }
            return true;
        }
        return false;
    }

    public final X1.k c(SidecarWindowLayoutInfo sidecarWindowLayoutInfo, SidecarDeviceState sidecarDeviceState) {
        if (sidecarWindowLayoutInfo == null) {
            return new X1.k(p081m5.m.r);
        }
        SidecarDeviceState sidecarDeviceState2 = new SidecarDeviceState();
        b.d(sidecarDeviceState2, b.b(sidecarDeviceState));
        return new X1.k(d(b.c(sidecarWindowLayoutInfo), sidecarDeviceState2));
    }

    public final ArrayList d(List list, SidecarDeviceState sidecarDeviceState) {
        ArrayList arrayList = new ArrayList();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            X1.c cVarE = e((SidecarDisplayFeature) it.next(), sidecarDeviceState);
            if (cVarE != null) {
                arrayList.add(cVarE);
            }
        }
        return arrayList;
    }

    public final X1.c e(SidecarDisplayFeature sidecarDisplayFeature, SidecarDeviceState sidecarDeviceState) {
        X1.b bVar;
        X1.b bVar2 = X1.b.f3781v;
        A5.h.e(sidecarDisplayFeature, "feature");
        int i6 = this.f4008a;
        A3.a.p("verificationMode", i6);
        SidecarDisplayFeature sidecarDisplayFeature2 = (SidecarDisplayFeature) new U1.g(sidecarDisplayFeature, i6, U1.a.f3571a).K("Type must be either TYPE_FOLD or TYPE_HINGE", c.f4003s).K("Feature bounds must not be 0", d.f4004s).K("TYPE_FOLD must have 0 area", e.f4005s).K("Feature be pinned to either left or top", f.f4006s).g();
        if (sidecarDisplayFeature2 == null) {
            return null;
        }
        int type = sidecarDisplayFeature2.getType();
        if (type == 1) {
            bVar = X1.b.f3783x;
        } else {
            if (type != 2) {
                return null;
            }
            bVar = X1.b.y;
        }
        int iB = b.b(sidecarDeviceState);
        if (iB == 0 || iB == 1) {
            return null;
        }
        if (iB == 2) {
            bVar2 = X1.b.f3782w;
        } else if (iB != 3 && iB == 4) {
            return null;
        }
        Rect rect = sidecarDisplayFeature.getRect();
        A5.h.d(rect, "feature.rect");
        return new X1.c(new U1.b(rect), bVar, bVar2);
    }
}
