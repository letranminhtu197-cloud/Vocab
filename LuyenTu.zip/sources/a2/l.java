package a2;

import android.app.Activity;

/* JADX INFO: loaded from: classes.dex */
public final class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Activity f4017a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final L4.l f4018b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public X1.k f4019c;

    public l(Activity activity, B1.d dVar, L4.l lVar) {
        this.f4017a = activity;
        this.f4018b = lVar;
    }
}
