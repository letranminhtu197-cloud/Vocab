package a2;

import androidx.window.sidecar.SidecarDisplayFeature;

/* JADX INFO: loaded from: classes.dex */
public final class e extends A5.i implements p154z5.c {

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final e f4005s = new e(1);

    @Override // p154z5.c
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public final Boolean a(SidecarDisplayFeature sidecarDisplayFeature) {
        A5.h.e(sidecarDisplayFeature, "$this$require");
        boolean z6 = true;
        if (sidecarDisplayFeature.getType() == 1 && sidecarDisplayFeature.getRect().width() != 0 && sidecarDisplayFeature.getRect().height() != 0) {
            z6 = false;
        }
        return Boolean.valueOf(z6);
    }
}
