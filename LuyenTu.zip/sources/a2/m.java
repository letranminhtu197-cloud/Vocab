package a2;

import android.app.Activity;
import android.content.Context;
import android.os.IBinder;
import android.view.Window;
import android.view.WindowManager;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.locks.ReentrantLock;

/* JADX INFO: loaded from: classes.dex */
public final class m implements Y1.a {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static volatile m f4020c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final ReentrantLock f4021d = new ReentrantLock();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a f4022a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final CopyOnWriteArrayList f4023b = new CopyOnWriteArrayList();

    public m(k kVar) {
        this.f4022a = kVar;
        if (kVar != null) {
            kVar.d(new A0.i(this, 21));
        }
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // Y1.a
    public final void a(Context context, B1.d dVar, L4.l lVar) {
        Object next;
        WindowManager.LayoutParams attributes;
        p074l5.l lVar2 = null;
        iBinder = null;
        IBinder iBinder = null;
        Activity activity = context instanceof Activity ? (Activity) context : null;
        p081m5.m mVar = p081m5.m.r;
        if (activity != null) {
            ReentrantLock reentrantLock = f4021d;
            reentrantLock.lock();
            try {
                a aVar = this.f4022a;
                if (aVar == null) {
                    lVar.accept(new X1.k(mVar));
                    reentrantLock.unlock();
                    return;
                }
                CopyOnWriteArrayList copyOnWriteArrayList = this.f4023b;
                boolean z6 = false;
                if (copyOnWriteArrayList == null || !copyOnWriteArrayList.isEmpty()) {
                    Iterator it = copyOnWriteArrayList.iterator();
                    while (it.hasNext()) {
                        if (((l) it.next()).f4017a.equals(activity)) {
                            z6 = true;
                            break;
                        }
                    }
                }
                l lVar3 = new l(activity, dVar, lVar);
                copyOnWriteArrayList.add(lVar3);
                if (z6) {
                    Iterator it2 = copyOnWriteArrayList.iterator();
                    do {
                        if (!it2.hasNext()) {
                            next = null;
                            break;
                        }
                        next = it2.next();
                    } while (!activity.equals(((l) next).f4017a));
                    l lVar4 = (l) next;
                    X1.k kVar = lVar4 != null ? lVar4.f4019c : null;
                    if (kVar != null) {
                        lVar3.f4019c = kVar;
                        lVar3.f4018b.accept(kVar);
                    }
                } else {
                    k kVar2 = (k) aVar;
                    Window window = activity.getWindow();
                    if (window != null && (attributes = window.getAttributes()) != null) {
                        iBinder = attributes.token;
                    }
                    if (iBinder != null) {
                        kVar2.c(iBinder, activity);
                    } else {
                        activity.getWindow().getDecorView().addOnAttachStateChangeListener(new j(kVar2, activity));
                    }
                }
                reentrantLock.unlock();
                lVar2 = p074l5.l.f7746a;
            } catch (Throwable th) {
                reentrantLock.unlock();
                throw th;
            }
        }
        if (lVar2 == null) {
            lVar.accept(new X1.k(mVar));
        }
    }

    @Override // Y1.a
    public final void b(L4.l lVar) {
        synchronized (f4021d) {
            try {
                if (this.f4022a == null) {
                    return;
                }
                ArrayList arrayList = new ArrayList();
                for (l lVar2 : this.f4023b) {
                    if (lVar2.f4018b == lVar) {
                        arrayList.add(lVar2);
                    }
                }
                this.f4023b.removeAll(arrayList);
                int size = arrayList.size();
                int i6 = 0;
                while (i6 < size) {
                    Object obj = arrayList.get(i6);
                    i6++;
                    Activity activity = ((l) obj).f4017a;
                    CopyOnWriteArrayList copyOnWriteArrayList = this.f4023b;
                    if (copyOnWriteArrayList == null || !copyOnWriteArrayList.isEmpty()) {
                        Iterator it = copyOnWriteArrayList.iterator();
                        while (true) {
                            if (it.hasNext()) {
                                if (((l) it.next()).f4017a.equals(activity)) {
                                }
                            }
                        }
                    }
                    a aVar = this.f4022a;
                    if (aVar != null) {
                        ((k) aVar).b(activity);
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
