package C2;

import p101q0.I;
import p101q0.J;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class g implements E2.b, p117t0.f {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ Object f561s;
    public final /* synthetic */ Object t;

    public /* synthetic */ g(int i6, J j6, J j7) {
        this.r = i6;
        this.f561s = j6;
        this.t = j7;
    }

    @Override // p117t0.f
    public void a(Object obj) {
        J j6 = (J) this.f561s;
        J j7 = (J) this.t;
        I i6 = (I) obj;
        i6.getClass();
        i6.k(this.r, j6, j7);
    }

    @Override // E2.b
    public Object d() {
        l lVar = (l) this.f561s;
        lVar.f571d.a((p135w2.i) this.t, this.r + 1, false);
        return null;
    }

    public /* synthetic */ g(l lVar, p135w2.i iVar, int i6) {
        this.f561s = lVar;
        this.t = iVar;
        this.r = i6;
    }
}
