package C2;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.database.Cursor;
import android.os.PersistableBundle;
import android.util.Base64;
import android.util.Log;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.JobInfoSchedulerService;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.Set;
import java.util.zip.Adler32;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import p025e2.v;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f554a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final D2.d f555b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final b f556c;

    public d(Context context, D2.d dVar, b bVar) {
        this.f554a = context;
        this.f555b = dVar;
        this.f556c = bVar;
    }

    public final void a(p135w2.i iVar, int i6, boolean z6) {
        Context context = this.f554a;
        ComponentName componentName = new ComponentName(context, (Class<?>) JobInfoSchedulerService.class);
        JobScheduler jobScheduler = (JobScheduler) context.getSystemService("jobscheduler");
        Adler32 adler32 = new Adler32();
        adler32.update(context.getPackageName().getBytes(Charset.forName("UTF-8")));
        String str = iVar.f9648a;
        String str2 = iVar.f9648a;
        adler32.update(str.getBytes(Charset.forName("UTF-8")));
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(4);
        t2.d dVar = iVar.f9650c;
        adler32.update(byteBufferAllocate.putInt(G2.a.a(dVar)).array());
        byte[] bArr = iVar.f9649b;
        if (bArr != null) {
            adler32.update(bArr);
        }
        int value = (int) adler32.getValue();
        if (!z6) {
            for (JobInfo jobInfo : jobScheduler.getAllPendingJobs()) {
                int i7 = jobInfo.getExtras().getInt("attemptNumber");
                if (jobInfo.getId() == value) {
                    if (i7 < i6) {
                        break;
                    }
                    v.i("JobInfoScheduler", "Upload for context %s is already scheduled. Returning...", iVar);
                    return;
                }
            }
        }
        Cursor cursorRawQuery = ((D2.h) this.f555b).a().rawQuery("SELECT next_request_ms FROM transport_contexts WHERE backend_name = ? and priority = ?", new String[]{str2, String.valueOf(G2.a.a(dVar))});
        try {
            Long lValueOf = cursorRawQuery.moveToNext() ? Long.valueOf(cursorRawQuery.getLong(0)) : 0L;
            cursorRawQuery.close();
            long jLongValue = lValueOf.longValue();
            JobInfo.Builder builder = new JobInfo.Builder(value, componentName);
            b bVar = this.f556c;
            builder.setMinimumLatency(bVar.a(dVar, jLongValue, i6));
            Set set = ((c) bVar.f550b.get(dVar)).f553c;
            if (set.contains(e.r)) {
                builder.setRequiredNetworkType(2);
            } else {
                builder.setRequiredNetworkType(1);
            }
            if (set.contains(e.t)) {
                builder.setRequiresCharging(true);
            }
            if (set.contains(e.f557s)) {
                builder.setRequiresDeviceIdle(true);
            }
            PersistableBundle persistableBundle = new PersistableBundle();
            persistableBundle.putInt("attemptNumber", i6);
            persistableBundle.putString("backendName", str2);
            persistableBundle.putInt(MimeTypesReaderMetKeys.MAGIC_PRIORITY_ATTR, G2.a.a(dVar));
            if (bArr != null) {
                persistableBundle.putString("extras", Base64.encodeToString(bArr, 0));
            }
            builder.setExtras(persistableBundle);
            Object[] objArr = {iVar, Integer.valueOf(value), Long.valueOf(bVar.a(dVar, jLongValue, i6)), lValueOf, Integer.valueOf(i6)};
            String strX = v.x("JobInfoScheduler");
            if (Log.isLoggable(strX, 3)) {
                Log.d(strX, String.format("Scheduling upload for context %s with jobId=%d in %dms(Backend next call timestamp %d). Attempt %d", objArr));
            }
            jobScheduler.schedule(builder.build());
        } catch (Throwable th) {
            cursorRawQuery.close();
            throw th;
        }
    }
}
