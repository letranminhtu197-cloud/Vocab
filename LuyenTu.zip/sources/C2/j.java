package C2;

import D3.p;
import H.C0031j;
import J0.B;
import J0.E;
import M0.n;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Point;
import android.media.DeniedByServerException;
import android.media.MediaCodec;
import android.media.MediaDrm;
import android.media.MediaDrmResetException;
import android.media.NotProvisionedException;
import android.media.metrics.PlaybackMetrics;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.SystemClock;
import android.os.Trace;
import android.system.ErrnoException;
import android.system.OsConstants;
import android.util.Log;
import android.util.SparseArray;
import androidx.credentials.playservices.CredentialProviderPlayServicesImpl;
import com.google.firebase.FirebaseCommonRegistrar;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;
import org.apache.tika.utils.XMLReaderUtils;
import p018d2.q;
import p018d2.r;
import p045h3.C0331c;
import p047h5.C0362i;
import p047h5.H;
import p047h5.J;
import p047h5.K;
import p047h5.N;
import p047h5.x;
import p047h5.y;
import p047h5.z;
import p053i4.AbstractServiceC0374g;
import p053i4.C0375h;
import p101q0.AbstractC0419g;
import p101q0.C0424l;
import p101q0.C0425m;
import p101q0.C0427o;
import p101q0.D;
import p101q0.G;
import p101q0.O;
import p101q0.P;
import p101q0.U;
import p101q0.V;
import p103q2.C0442f;
import p108r3.A;
import p108r3.C;
import p108r3.C0468z;
import p108r3.T;
import p117t0.s;
import p128v0.t;
import p128v0.u;
import p128v0.v;
import p140x0.C0490l;
import p140x0.C0503z;
import p150z0.o;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class j implements E2.b, D2.f, n, p091o3.e, p091o3.d, p121u.i, p091o3.a, Q3.e, p091o3.h, p117t0.g, p117t0.f {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ Object f566s;
    public final /* synthetic */ Object t;

    public /* synthetic */ j(Object obj, Object obj2, int i6) {
        this.r = i6;
        this.f566s = obj;
        this.t = obj2;
    }

    private final Object k(p091o3.i iVar) {
        p080m4.h hVar = (p080m4.h) this.f566s;
        Date date = (Date) this.t;
        hVar.getClass();
        if (iVar.h()) {
            p080m4.n nVar = hVar.f7871g;
            synchronized (nVar.f7903b) {
                nVar.f7902a.edit().putInt("last_fetch_status", -1).putLong("last_fetch_time_in_millis", date.getTime()).apply();
            }
            return iVar;
        }
        Exception excE = iVar.e();
        if (excE == null) {
            return iVar;
        }
        if (excE instanceof p073l4.h) {
            p080m4.n nVar2 = hVar.f7871g;
            synchronized (nVar2.f7903b) {
                nVar2.f7902a.edit().putInt("last_fetch_status", 2).apply();
            }
            return iVar;
        }
        p080m4.n nVar3 = hVar.f7871g;
        synchronized (nVar3.f7903b) {
            nVar3.f7902a.edit().putInt("last_fetch_status", 1).apply();
        }
        return iVar;
    }

    @Override // p117t0.f
    public void a(Object obj) {
        y0.a aVar = (y0.a) this.f566s;
        B b6 = (B) this.t;
        y0.i iVar = (y0.i) obj;
        iVar.getClass();
        E e6 = aVar.f10440d;
        if (e6 == null) {
            return;
        }
        C0427o c0427o = b6.f1661c;
        c0427o.getClass();
        int i6 = b6.f1662d;
        y0.f fVar = iVar.f10471b;
        O o = aVar.f10438b;
        e6.getClass();
        A0.n nVar = new A0.n(c0427o, i6, fVar.c(o, e6));
        int i7 = b6.f1660b;
        if (i7 != 0) {
            if (i7 == 1) {
                iVar.f10484p = nVar;
                return;
            } else if (i7 != 2) {
                if (i7 != 3) {
                    return;
                }
                iVar.f10485q = nVar;
                return;
            }
        }
        iVar.o = nVar;
    }

    @Override // D2.f
    public Object apply(Object obj) {
        D2.h hVar = (D2.h) this.f566s;
        p135w2.i iVar = (p135w2.i) this.t;
        SQLiteDatabase sQLiteDatabase = (SQLiteDatabase) obj;
        D2.a aVar = hVar.f803u;
        ArrayList arrayListF = hVar.f(sQLiteDatabase, iVar, aVar.f791b);
        for (t2.d dVar : t2.d.values()) {
            if (dVar != iVar.f9650c) {
                int size = aVar.f791b - arrayListF.size();
                if (size <= 0) {
                    break;
                }
                C0331c c0331cA = p135w2.i.a();
                c0331cA.A(iVar.f9648a);
                if (dVar == null) {
                    throw new NullPointerException("Null priority");
                }
                c0331cA.t = dVar;
                c0331cA.f6060u = iVar.f9649b;
                arrayListF.addAll(hVar.f(sQLiteDatabase, c0331cA.h(), size));
            }
        }
        HashMap map = new HashMap();
        StringBuilder sb = new StringBuilder("event_id IN (");
        for (int i6 = 0; i6 < arrayListF.size(); i6++) {
            sb.append(((D2.b) arrayListF.get(i6)).f795a);
            if (i6 < arrayListF.size() - 1) {
                sb.append(',');
            }
        }
        sb.append(')');
        Cursor cursorQuery = sQLiteDatabase.query("event_metadata", new String[]{"event_id", "name", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR}, sb.toString(), null, null, null, null);
        while (cursorQuery.moveToNext()) {
            try {
                long j6 = cursorQuery.getLong(0);
                Set hashSet = (Set) map.get(Long.valueOf(j6));
                if (hashSet == null) {
                    hashSet = new HashSet();
                    map.put(Long.valueOf(j6), hashSet);
                }
                hashSet.add(new D2.g(cursorQuery.getString(1), cursorQuery.getString(2)));
            } catch (Throwable th) {
                cursorQuery.close();
                throw th;
            }
        }
        cursorQuery.close();
        ListIterator listIterator = arrayListF.listIterator();
        while (listIterator.hasNext()) {
            D2.b bVar = (D2.b) listIterator.next();
            long j7 = bVar.f795a;
            if (map.containsKey(Long.valueOf(j7))) {
                p pVarC = bVar.f797c.c();
                for (D2.g gVar : (Set) map.get(Long.valueOf(j7))) {
                    pVarC.g(gVar.f799a, gVar.f800b);
                }
                listIterator.set(new D2.b(j7, bVar.f796b, pVarC.j()));
            }
        }
        return arrayListF;
    }

    @Override // p121u.i
    public Object b(p121u.h hVar) {
        Executor executor = (Executor) this.f566s;
        p154z5.a aVar = (p154z5.a) this.t;
        AtomicBoolean atomicBoolean = new AtomicBoolean(false);
        q qVar = new q(atomicBoolean, 1);
        p121u.m mVar = hVar.f9089c;
        if (mVar != null) {
            mVar.a(qVar, p018d2.m.r);
        }
        executor.execute(new r(atomicBoolean, hVar, aVar, 1));
        return p074l5.l.f7746a;
    }

    /* JADX WARN: Code duplicated, block: B:397:0x068c  */
    /* JADX WARN: Code duplicated, block: B:400:0x06b4  */
    /* JADX WARN: Code duplicated, block: B:404:0x06c4 A[Catch: all -> 0x06d3, TryCatch #0 {all -> 0x06d3, blocks: (B:402:0x06c0, B:404:0x06c4, B:407:0x06d5, B:408:0x06df, B:410:0x06e5, B:412:0x06f2, B:414:0x06f6), top: B:421:0x06c0 }] */
    /* JADX WARN: Code duplicated, block: B:410:0x06e5 A[Catch: all -> 0x06d3, TryCatch #0 {all -> 0x06d3, blocks: (B:402:0x06c0, B:404:0x06c4, B:407:0x06d5, B:408:0x06df, B:410:0x06e5, B:412:0x06f2, B:414:0x06f6), top: B:421:0x06c0 }] */
    /* JADX WARN: Code duplicated, block: B:420:0x0700 A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Code duplicated, block: B:421:0x06c0 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Multi-variable type inference failed */
    @Override // p117t0.g
    public void c(Object obj, C0425m c0425m) {
        int i6;
        boolean z6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        C0031j c0031j;
        C0031j c0031j2;
        C0031j c0031j3;
        int i14;
        int i15;
        A0.n nVar;
        int i16;
        int i17;
        boolean z7;
        int i18;
        boolean z8;
        y0.f fVar;
        String str;
        Iterator it;
        y0.e eVar;
        y0.i iVar;
        C0427o c0427o;
        C0424l c0424l;
        int i19;
        y0.d dVar = (y0.d) this.f566s;
        D3.e eVar2 = (D3.e) this.t;
        y0.i iVar2 = (y0.i) obj;
        SparseArray sparseArray = dVar.f10449v;
        SparseArray sparseArray2 = new SparseArray(c0425m.f8343a.size());
        for (int i20 = 0; i20 < c0425m.f8343a.size(); i20++) {
            int iA = c0425m.a(i20);
            y0.a aVar = (y0.a) sparseArray.get(iA);
            aVar.getClass();
            sparseArray2.append(iA, aVar);
        }
        iVar2.getClass();
        if (c0425m.f8343a.size() == 0) {
            return;
        }
        int i21 = 0;
        while (true) {
            boolean z9 = true;
            if (i21 >= c0425m.f8343a.size()) {
                break;
            }
            int iA2 = c0425m.a(i21);
            y0.a aVar2 = (y0.a) sparseArray2.get(iA2);
            aVar2.getClass();
            if (iA2 == 0) {
                y0.f fVar2 = iVar2.f10471b;
                synchronized (fVar2) {
                    try {
                        fVar2.f10465d.getClass();
                        O o = fVar2.f10466e;
                        fVar2.f10466e = aVar2.f10438b;
                        Iterator it2 = fVar2.f10464c.values().iterator();
                        while (it2.hasNext()) {
                            y0.e eVar3 = (y0.e) it2.next();
                            if (!eVar3.b(o, fVar2.f10466e) || eVar3.a(aVar2)) {
                                it2.remove();
                                if (eVar3.f10457e) {
                                    if (eVar3.f10453a.equals(fVar2.f10467f)) {
                                        fVar2.a(eVar3);
                                    }
                                    fVar2.f10465d.d(aVar2, eVar3.f10453a);
                                }
                            }
                        }
                        fVar2.d(aVar2);
                    } catch (Throwable th) {
                        throw th;
                    }
                }
            } else if (iA2 == 11) {
                y0.f fVar3 = iVar2.f10471b;
                int i22 = iVar2.f10480k;
                synchronized (fVar3) {
                    try {
                        fVar3.f10465d.getClass();
                        if (i22 != 0) {
                            z9 = false;
                        }
                        Iterator it3 = fVar3.f10464c.values().iterator();
                        while (it3.hasNext()) {
                            y0.e eVar4 = (y0.e) it3.next();
                            if (eVar4.a(aVar2)) {
                                it3.remove();
                                if (eVar4.f10457e) {
                                    boolean zEquals = eVar4.f10453a.equals(fVar3.f10467f);
                                    if (z9 && zEquals) {
                                        boolean z10 = eVar4.f10458f;
                                    }
                                    if (zEquals) {
                                        fVar3.a(eVar4);
                                    }
                                    fVar3.f10465d.d(aVar2, eVar4.f10453a);
                                }
                            }
                        }
                        fVar3.d(aVar2);
                    } catch (Throwable th2) {
                        throw th2;
                    }
                }
            } else {
                iVar2.f10471b.e(aVar2);
            }
            i21++;
        }
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        if (c0425m.f8343a.get(0)) {
            y0.a aVar3 = (y0.a) sparseArray2.get(0);
            aVar3.getClass();
            if (iVar2.f10479j != null) {
                iVar2.c(aVar3.f10438b, aVar3.f10440d);
            }
        }
        if (c0425m.f8343a.get(2) && iVar2.f10479j != null) {
            C0503z c0503z = (C0503z) eVar2;
            c0503z.I();
            A aListIterator = c0503z.f10006Z.f9843i.f2417d.f8304a.listIterator(0);
            loop4: while (true) {
                if (!aListIterator.hasNext()) {
                    c0424l = null;
                    break;
                }
                U u6 = (U) aListIterator.next();
                for (int i23 = 0; i23 < u6.f8298a; i23++) {
                    if (u6.f8302e[i23] && (c0424l = u6.f8299b.f8260d[i23].f8399q) != null) {
                        break loop4;
                    }
                }
            }
            if (c0424l != null) {
                PlaybackMetrics.Builder builderH = p078m2.e.h(iVar2.f10479j);
                int i24 = 0;
                while (true) {
                    if (i24 >= c0424l.f8342u) {
                        i19 = 1;
                        break;
                    }
                    UUID uuid = c0424l.r[i24].f8338s;
                    if (uuid.equals(AbstractC0419g.f8328d)) {
                        i19 = 3;
                        break;
                    } else if (uuid.equals(AbstractC0419g.f8329e)) {
                        i19 = 2;
                        break;
                    } else {
                        if (uuid.equals(AbstractC0419g.f8327c)) {
                            i19 = 6;
                            break;
                        }
                        i24++;
                    }
                }
                builderH.setDrmType(i19);
            }
        }
        if (c0425m.f8343a.get(1011)) {
            iVar2.f10491z++;
        }
        p101q0.E e6 = iVar2.f10483n;
        if (e6 == null) {
            i11 = 4;
            i7 = 5;
            i13 = 13;
            i8 = 8;
            i9 = 7;
            i10 = 6;
            i12 = 9;
        } else {
            int i25 = e6.r;
            Context context = iVar2.f10470a;
            boolean z11 = iVar2.f10488v == 4;
            if (i25 == 1001) {
                c0031j = new C0031j(20, 0);
                i7 = 5;
            } else {
                if (e6 instanceof C0490l) {
                    C0490l c0490l = (C0490l) e6;
                    z6 = c0490l.t == 1;
                    i6 = c0490l.f9954x;
                } else {
                    i6 = 0;
                    z6 = false;
                }
                Throwable cause = e6.getCause();
                cause.getClass();
                if (!(cause instanceof IOException)) {
                    i7 = 5;
                    int i26 = 24;
                    i8 = 8;
                    i9 = 7;
                    i10 = 6;
                    i11 = 4;
                    i12 = 9;
                    if (z6 && (i6 == 0 || i6 == 1)) {
                        c0031j3 = new C0031j(35, 0);
                    } else if (z6 && i6 == 3) {
                        c0031j3 = new C0031j(15, 0);
                    } else if (z6 && i6 == 2) {
                        c0031j3 = new C0031j(23, 0);
                    } else {
                        if (cause instanceof G0.r) {
                            i13 = 13;
                            c0031j2 = new C0031j(13, s.u(((G0.r) cause).f1343u));
                        } else {
                            i13 = 13;
                            if (cause instanceof G0.m) {
                                c0031j = new C0031j(14, ((G0.m) cause).r);
                            } else if (cause instanceof OutOfMemoryError) {
                                c0031j = new C0031j(14, 0);
                            } else if (cause instanceof p150z0.n) {
                                c0031j2 = new C0031j(17, ((p150z0.n) cause).r);
                            } else if (cause instanceof o) {
                                c0031j2 = new C0031j(18, ((o) cause).r);
                            } else if (cause instanceof MediaCodec.CryptoException) {
                                int errorCode = ((MediaCodec.CryptoException) cause).getErrorCode();
                                switch (s.t(errorCode)) {
                                    case 6002:
                                        break;
                                    case 6003:
                                        i26 = 28;
                                        break;
                                    case 6004:
                                        i26 = 25;
                                        break;
                                    case 6005:
                                        i26 = 26;
                                        break;
                                    default:
                                        i26 = 27;
                                        break;
                                }
                                c0031j2 = new C0031j(i26, errorCode);
                            } else {
                                c0031j = new C0031j(22, 0);
                            }
                        }
                        c0031j = c0031j2;
                    }
                    c0031j = c0031j3;
                    i13 = 13;
                } else if (cause instanceof v) {
                    i7 = 5;
                    c0031j = new C0031j(5, ((v) cause).f9346u);
                } else {
                    i7 = 5;
                    if ((cause instanceof u) || (cause instanceof D)) {
                        c0031j = new C0031j(z11 ? 10 : 11, 0);
                        i11 = 4;
                        i9 = 7;
                        i10 = 6;
                        i8 = 8;
                        i13 = 13;
                        i12 = 9;
                    } else {
                        boolean z12 = cause instanceof t;
                        if (z12 || (cause instanceof p128v0.B)) {
                            i14 = 9;
                            if (p117t0.k.b(context).c() == 1) {
                                c0031j = new C0031j(3, 0);
                            } else {
                                Throwable cause2 = cause.getCause();
                                if (cause2 instanceof UnknownHostException) {
                                    c0031j = new C0031j(6, 0);
                                    i12 = 9;
                                    i10 = 6;
                                    i13 = 13;
                                    i8 = 8;
                                    i9 = 7;
                                } else if (cause2 instanceof SocketTimeoutException) {
                                    c0031j = new C0031j(7, 0);
                                    i12 = 9;
                                    i9 = 7;
                                    i10 = 6;
                                    i13 = 13;
                                    i8 = 8;
                                } else if (z12 && ((t) cause).t == 1) {
                                    c0031j = new C0031j(4, 0);
                                    i12 = 9;
                                    i11 = 4;
                                    i9 = 7;
                                    i10 = 6;
                                    i13 = 13;
                                    i8 = 8;
                                } else {
                                    c0031j = new C0031j(8, 0);
                                    i12 = 9;
                                    i11 = 4;
                                    i9 = 7;
                                    i10 = 6;
                                    i8 = 8;
                                    i13 = 13;
                                }
                                i11 = 4;
                            }
                        } else if (i25 == 1002) {
                            c0031j = new C0031j(21, 0);
                        } else if (cause instanceof C0.c) {
                            Throwable cause3 = cause.getCause();
                            cause3.getClass();
                            int i27 = s.f9002a;
                            if (i27 >= 21 && (cause3 instanceof MediaDrm.MediaDrmStateException)) {
                                int iU = s.u(((MediaDrm.MediaDrmStateException) cause3).getDiagnosticInfo());
                                switch (s.t(iU)) {
                                    case 6002:
                                        i15 = 24;
                                        break;
                                    case 6003:
                                        i15 = 28;
                                        break;
                                    case 6004:
                                        i15 = 25;
                                        break;
                                    case 6005:
                                        i15 = 26;
                                        break;
                                    default:
                                        i15 = 27;
                                        break;
                                }
                                c0031j = new C0031j(i15, iU);
                            } else if (i27 >= 23 && (cause3 instanceof MediaDrmResetException)) {
                                c0031j = new C0031j(27, 0);
                            } else if (cause3 instanceof NotProvisionedException) {
                                c0031j = new C0031j(24, 0);
                            } else if (cause3 instanceof DeniedByServerException) {
                                c0031j = new C0031j(29, 0);
                            } else if (cause3 instanceof C0.k) {
                                c0031j = new C0031j(23, 0);
                            } else {
                                c0031j = cause3 instanceof C0.a ? new C0031j(28, 0) : new C0031j(30, 0);
                            }
                        } else if ((cause instanceof p128v0.q) && (cause.getCause() instanceof FileNotFoundException)) {
                            Throwable cause4 = cause.getCause();
                            cause4.getClass();
                            Throwable cause5 = cause4.getCause();
                            c0031j = (s.f9002a >= 21 && (cause5 instanceof ErrnoException) && ((ErrnoException) cause5).errno == OsConstants.EACCES) ? new C0031j(32, 0) : new C0031j(31, 0);
                        } else {
                            i14 = 9;
                            c0031j = new C0031j(9, 0);
                        }
                        i12 = i14;
                        i13 = 13;
                        i8 = 8;
                        i9 = 7;
                        i10 = 6;
                        i11 = 4;
                    }
                }
                iVar2.f10472c.reportPlaybackErrorEvent(y0.g.c().setTimeSinceCreatedMillis(jElapsedRealtime - iVar2.f10473d).setErrorCode(c0031j.f1491a).setSubErrorCode(c0031j.f1492b).setException(e6).build());
                iVar2.f10469A = true;
                iVar2.f10483n = null;
            }
            i13 = 13;
            i8 = 8;
            i9 = 7;
            i10 = 6;
            i11 = 4;
            i12 = 9;
            iVar2.f10472c.reportPlaybackErrorEvent(y0.g.c().setTimeSinceCreatedMillis(jElapsedRealtime - iVar2.f10473d).setErrorCode(c0031j.f1491a).setSubErrorCode(c0031j.f1492b).setException(e6).build());
            iVar2.f10469A = true;
            iVar2.f10483n = null;
        }
        if (c0425m.f8343a.get(2)) {
            C0503z c0503z2 = (C0503z) eVar2;
            c0503z2.I();
            V v6 = c0503z2.f10006Z.f9843i.f2417d;
            boolean zA = v6.a(2);
            boolean zA2 = v6.a(1);
            i16 = 3;
            boolean zA3 = v6.a(3);
            if (zA || zA2 || zA3) {
                if (zA) {
                    c0427o = null;
                } else {
                    c0427o = null;
                    if (!s.a(iVar2.r, null)) {
                        int i28 = iVar2.r == null ? 1 : 0;
                        iVar2.r = null;
                        iVar2.e(1, jElapsedRealtime, null, i28);
                    }
                }
                if (!zA2 && !s.a(iVar2.f10486s, c0427o)) {
                    int i29 = iVar2.f10486s == null ? 1 : 0;
                    iVar2.f10486s = c0427o;
                    iVar2.e(0, jElapsedRealtime, c0427o, i29);
                }
                if (!zA3 && !s.a(iVar2.t, c0427o)) {
                    int i30 = iVar2.t == null ? 1 : 0;
                    iVar2.t = c0427o;
                    iVar2.e(2, jElapsedRealtime, c0427o, i30);
                }
                nVar = c0427o;
            } else {
                i16 = 3;
                i11 = i11;
                nVar = 0;
            }
        } else {
            i11 = i11;
            nVar = 0;
            i16 = 3;
        }
        if (iVar2.a(iVar2.o)) {
            A0.n nVar2 = iVar2.o;
            C0427o c0427o2 = (C0427o) nVar2.f96s;
            if (c0427o2.t != -1) {
                int i31 = nVar2.r;
                if (!s.a(iVar2.r, c0427o2)) {
                    int i32 = (iVar2.r == null && i31 == 0) ? 1 : i31;
                    iVar2.r = c0427o2;
                    iVar2.e(1, jElapsedRealtime, c0427o2, i32);
                }
                iVar2.o = nVar;
            }
        }
        if (iVar2.a(iVar2.f10484p)) {
            A0.n nVar3 = iVar2.f10484p;
            C0427o c0427o3 = (C0427o) nVar3.f96s;
            int i33 = nVar3.r;
            if (!s.a(iVar2.f10486s, c0427o3)) {
                int i34 = (iVar2.f10486s == null && i33 == 0) ? 1 : i33;
                iVar2.f10486s = c0427o3;
                iVar2.e(0, jElapsedRealtime, c0427o3, i34);
            }
            iVar2.f10484p = nVar;
        }
        if (iVar2.a(iVar2.f10485q)) {
            A0.n nVar4 = iVar2.f10485q;
            C0427o c0427o4 = (C0427o) nVar4.f96s;
            int i35 = nVar4.r;
            if (!s.a(iVar2.t, c0427o4)) {
                int i36 = (iVar2.t == null && i35 == 0) ? 1 : i35;
                iVar2.t = c0427o4;
                iVar2.e(2, jElapsedRealtime, c0427o4, i36);
            }
            iVar2.f10485q = nVar;
        }
        switch (p117t0.k.b(iVar2.f10470a).c()) {
            case 0:
                i17 = 0;
                break;
            case 1:
                i17 = i12;
                break;
            case 2:
                i17 = 2;
                break;
            case 3:
                i17 = i11;
                break;
            case 4:
                i17 = i7;
                break;
            case 5:
                i17 = i10;
                break;
            case 6:
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
            default:
                i17 = 1;
                break;
            case 7:
                i17 = i16;
                break;
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                i17 = i8;
                break;
            case 10:
                i17 = i9;
                break;
        }
        if (i17 != iVar2.f10482m) {
            iVar2.f10482m = i17;
            iVar2.f10472c.reportNetworkEvent(y0.g.b().setNetworkType(i17).setTimeSinceCreatedMillis(jElapsedRealtime - iVar2.f10473d).build());
        }
        C0503z c0503z3 = (C0503z) eVar2;
        if (c0503z3.s() != 2) {
            z7 = false;
            iVar2.f10487u = false;
        } else {
            z7 = false;
        }
        c0503z3.I();
        if (c0503z3.f10006Z.f9840f == null) {
            iVar2.f10489w = z7;
            i18 = 10;
        } else {
            i18 = 10;
            if (c0425m.f8343a.get(10)) {
                iVar2.f10489w = true;
            }
        }
        int iS = c0503z3.s();
        if (!iVar2.f10487u) {
            if (!iVar2.f10489w) {
                if (iS == i11) {
                    i13 = 11;
                } else {
                    i13 = 12;
                    if (iS == 2) {
                        int i37 = iVar2.f10481l;
                        if (i37 == 0 || i37 == 2 || i37 == 12) {
                            i13 = 2;
                        } else if (c0503z3.r()) {
                            c0503z3.I();
                            i13 = c0503z3.f10006Z.f9848n != 0 ? i18 : i10;
                        } else {
                            i13 = i9;
                        }
                    } else if (iS != i16) {
                        z8 = true;
                        if (iS != 1 || iVar2.f10481l == 0) {
                            i13 = iVar2.f10481l;
                        }
                    } else if (c0503z3.r()) {
                        c0503z3.I();
                        i13 = c0503z3.f10006Z.f9848n != 0 ? i12 : i16;
                    } else {
                        i13 = i11;
                    }
                }
            }
            if (iVar2.f10481l != i13) {
                iVar2.f10481l = i13;
                iVar2.f10469A = z8;
                iVar2.f10472c.reportPlaybackStateEvent(y0.g.k().setState(iVar2.f10481l).setTimeSinceCreatedMillis(jElapsedRealtime - iVar2.f10473d).build());
            }
            if (c0425m.f8343a.get(1028)) {
                fVar = iVar2.f10471b;
                y0.a aVar4 = (y0.a) sparseArray2.get(1028);
                aVar4.getClass();
                synchronized (fVar) {
                    try {
                        str = fVar.f10467f;
                        if (str != null) {
                            y0.e eVar5 = (y0.e) fVar.f10464c.get(str);
                            eVar5.getClass();
                            fVar.a(eVar5);
                        }
                        it = fVar.f10464c.values().iterator();
                        while (it.hasNext()) {
                            eVar = (y0.e) it.next();
                            it.remove();
                            if (!eVar.f10457e && (iVar = fVar.f10465d) != null) {
                                iVar.d(aVar4, eVar.f10453a);
                            }
                        }
                    } catch (Throwable th3) {
                        throw th3;
                    }
                }
            }
        }
        i13 = i7;
        z8 = true;
        if (iVar2.f10481l != i13) {
            iVar2.f10481l = i13;
            iVar2.f10469A = z8;
            iVar2.f10472c.reportPlaybackStateEvent(y0.g.k().setState(iVar2.f10481l).setTimeSinceCreatedMillis(jElapsedRealtime - iVar2.f10473d).build());
        }
        if (c0425m.f8343a.get(1028)) {
            fVar = iVar2.f10471b;
            y0.a aVar5 = (y0.a) sparseArray2.get(1028);
            aVar5.getClass();
            synchronized (fVar) {
                str = fVar.f10467f;
                if (str != null) {
                    y0.e eVar6 = (y0.e) fVar.f10464c.get(str);
                    eVar6.getClass();
                    fVar.a(eVar6);
                }
                it = fVar.f10464c.values().iterator();
                while (it.hasNext()) {
                    eVar = (y0.e) it.next();
                    it.remove();
                    if (!eVar.f10457e) {
                    }
                }
            }
        }
    }

    @Override // E2.b
    public Object d() {
        switch (this.r) {
            case 0:
                l lVar = (l) this.f566s;
                Iterable iterable = (Iterable) this.t;
                D2.h hVar = (D2.h) lVar.f570c;
                hVar.getClass();
                if (iterable.iterator().hasNext()) {
                    hVar.a().compileStatement("DELETE FROM events WHERE _id in " + D2.h.q(iterable)).execute();
                    break;
                }
                break;
            default:
                l lVar2 = (l) this.f566s;
                for (Map.Entry entry : ((HashMap) this.t).entrySet()) {
                    ((D2.h) lVar2.f576i).j(((Integer) entry.getValue()).intValue(), p151z2.c.f10778x, (String) entry.getKey());
                }
                break;
        }
        return null;
    }

    /* JADX WARN: Code duplicated, block: B:29:0x006e  */
    @Override // M0.n
    public T e(int i6, P p6, int[] iArr) {
        int i7;
        int i8;
        int i9;
        int i10;
        P p7 = p6;
        switch (this.r) {
            case 3:
                M0.k kVar = (M0.k) this.f566s;
                int i11 = ((int[]) this.t)[i6];
                int i12 = kVar.f8286e;
                int i13 = kVar.f8287f;
                boolean z6 = kVar.f8288g;
                if (i12 == Integer.MAX_VALUE || i13 == Integer.MAX_VALUE) {
                    i7 = Integer.MAX_VALUE;
                } else {
                    int i14 = Integer.MAX_VALUE;
                    for (int i15 = 0; i15 < p7.f8257a; i15++) {
                        C0427o c0427o = p7.f8260d[i15];
                        int i16 = c0427o.f8400s;
                        int i17 = c0427o.t;
                        if (i16 > 0 && i17 > 0) {
                            if (!z6) {
                                i9 = i12;
                                i10 = i13;
                            } else if ((i16 > i17) != (i12 > i13)) {
                                i10 = i12;
                                i9 = i13;
                            } else {
                                i9 = i12;
                                i10 = i13;
                            }
                            int i18 = i16 * i10;
                            int i19 = i17 * i9;
                            Point point = i18 >= i19 ? new Point(i9, s.g(i19, i16)) : new Point(s.g(i18, i17), i10);
                            int i20 = c0427o.f8400s;
                            int i21 = i20 * i17;
                            if (i20 >= ((int) (point.x * 0.98f)) && i17 >= ((int) (point.y * 0.98f)) && i21 < i14) {
                                i14 = i21;
                            }
                        }
                    }
                    i7 = i14;
                }
                C0468z c0468zM = C.m();
                int i22 = 0;
                while (i22 < p7.f8257a) {
                    C0427o c0427o2 = p7.f8260d[i22];
                    int i23 = c0427o2.f8400s;
                    int i24 = (i23 == -1 || (i8 = c0427o2.t) == -1) ? -1 : i23 * i8;
                    c0468zM.a(new M0.p(i6, p7, i22, kVar, iArr[i22], i11, i7 == Integer.MAX_VALUE || (i24 != -1 && i24 <= i7)));
                    i22++;
                    p7 = p6;
                }
                return c0468zM.f();
            default:
                M0.k kVar2 = (M0.k) this.f566s;
                String str = (String) this.t;
                C0468z c0468zM2 = C.m();
                for (int i25 = 0; i25 < p7.f8257a; i25++) {
                    c0468zM2.a(new M0.m(i6, p7, i25, kVar2, iArr[i25], str));
                }
                return c0468zM2.f();
        }
    }

    /* JADX WARN: Code duplicated, block: B:108:0x015d  */
    /* JADX WARN: Code duplicated, block: B:110:0x0160  */
    /* JADX WARN: Code duplicated, block: B:118:0x019c  */
    /* JADX WARN: Code duplicated, block: B:135:0x0149 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:138:0x00e7 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:145:0x00d5 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:43:0x00a7  */
    /* JADX WARN: Code duplicated, block: B:64:0x00d4 A[Catch: all -> 0x0056, TRY_LEAVE, TryCatch #9 {all -> 0x0056, blocks: (B:11:0x003f, B:13:0x0042, B:14:0x0043, B:22:0x005f, B:62:0x00d0, B:64:0x00d4, B:66:0x00d7, B:70:0x00db, B:71:0x00dc, B:65:0x00d5), top: B:144:0x001b, inners: #10 }] */
    /* JADX WARN: Code duplicated, block: B:71:0x00dc A[Catch: all -> 0x0056, TRY_LEAVE, TryCatch #9 {all -> 0x0056, blocks: (B:11:0x003f, B:13:0x0042, B:14:0x0043, B:22:0x005f, B:62:0x00d0, B:64:0x00d4, B:66:0x00d7, B:70:0x00db, B:71:0x00dc, B:65:0x00d5), top: B:144:0x001b, inners: #10 }] */
    /* JADX WARN: Code duplicated, block: B:82:0x00fb  */
    /* JADX WARN: Code duplicated, block: B:84:0x00fe  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v6, types: [m4.l] */
    /* JADX WARN: Type inference failed for: r11v0 */
    /* JADX WARN: Type inference failed for: r11v10 */
    /* JADX WARN: Type inference failed for: r11v2 */
    /* JADX WARN: Type inference failed for: r11v3, types: [java.lang.Integer, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r11v4 */
    /* JADX WARN: Type inference failed for: r11v5, types: [java.lang.Integer, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r11v6 */
    /* JADX WARN: Type inference failed for: r11v7 */
    /* JADX WARN: Type inference failed for: r11v8 */
    /* JADX WARN: Type inference failed for: r11v9, types: [java.lang.Integer, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r15v21 */
    /* JADX WARN: Type inference failed for: r15v22, types: [java.io.InputStream] */
    /* JADX WARN: Type inference failed for: r15v39, types: [java.io.InputStream] */
    /* JADX WARN: Type inference failed for: r15v5, types: [o3.q] */
    /* JADX WARN: Type inference failed for: r15v50 */
    /* JADX WARN: Type inference failed for: r15v6 */
    /* JADX WARN: Type inference failed for: r15v7 */
    /* JADX WARN: Type inference failed for: r15v8 */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Type inference failed for: r8v1, types: [java.io.InputStream] */
    /* JADX WARN: Type inference failed for: r8v3 */
    @Override // p091o3.a
    public Object f(p091o3.i iVar) throws Throwable {
        InputStream errorStream;
        ?? r11;
        ?? ValueOf;
        p073l4.i iVar2;
        switch (this.r) {
            case 18:
                C0375h c0375h = (C0375h) this.f566s;
                String str = (String) this.t;
                synchronized (c0375h) {
                    ((p093p.e) c0375h.f6335b).remove(str);
                    break;
                }
                return iVar;
            case 19:
            case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
            default:
                ?? r6 = (p080m4.l) this.f566s;
                ?? inputStream = (p091o3.q) this.t;
                V2.a aVar = r6.f7896p;
                boolean z6 = true;
                ?? r8 = 0;
                try {
                    try {
                        if (!inputStream.h()) {
                            throw new IOException(inputStream.e());
                        }
                        HttpURLConnection httpURLConnection = (HttpURLConnection) inputStream.f();
                        r6.f7887f = httpURLConnection;
                        inputStream = httpURLConnection.getInputStream();
                        try {
                            errorStream = r6.f7887f.getErrorStream();
                            try {
                                int responseCode = r6.f7887f.getResponseCode();
                                ValueOf = Integer.valueOf(responseCode);
                                if (responseCode == 200) {
                                    try {
                                        synchronized (r6) {
                                            r6.f7884c = 8;
                                        }
                                        r6.f7897q.e(0, p080m4.n.f7901g);
                                        B1.b bVarJ = r6.j(r6.f7887f);
                                        r6.f7888g = bVarJ;
                                        bVarJ.i();
                                    } catch (IOException e6) {
                                        e = e6;
                                        if (r6.f7886e) {
                                            synchronized (r6) {
                                                r6.f7884c = 8;
                                            }
                                        } else {
                                            Log.d("FirebaseRemoteConfig", "Exception connecting to real-time RC backend. Retrying the connection...", e);
                                        }
                                        r6.b(inputStream, errorStream);
                                        synchronized (r6) {
                                            r6.f7883b = false;
                                        }
                                        if (r6.f7886e || (ValueOf != 0 && !p080m4.l.d(ValueOf.intValue()))) {
                                            z6 = false;
                                        }
                                        if (z6) {
                                            aVar.getClass();
                                            r6.k(new Date(System.currentTimeMillis()));
                                        }
                                        if (!z6 || ValueOf.intValue() == 200) {
                                            r6.h();
                                        } else {
                                            String strF = String.format("Unable to connect to the server. Try again in a few minutes. HTTP status code: %d", ValueOf);
                                            if (ValueOf.intValue() == 403) {
                                                strF = p080m4.l.f(r6.f7887f.getErrorStream());
                                            }
                                            iVar2 = new p073l4.i(ValueOf.intValue(), 0, strF);
                                        }
                                        r6.f7887f = null;
                                        r6.f7888g = null;
                                        return android.support.v4.media.session.b.D(null);
                                    }
                                }
                                r6.b(inputStream, errorStream);
                                synchronized (r6) {
                                    r6.f7883b = false;
                                }
                                z6 = !r6.f7886e && p080m4.l.d(responseCode);
                                if (z6) {
                                    aVar.getClass();
                                    r6.k(new Date(System.currentTimeMillis()));
                                }
                                if (z6 || responseCode == 200) {
                                    r6.h();
                                } else {
                                    String strF2 = String.format("Unable to connect to the server. Try again in a few minutes. HTTP status code: %d", ValueOf);
                                    if (responseCode == 403) {
                                        strF2 = p080m4.l.f(r6.f7887f.getErrorStream());
                                    }
                                    iVar2 = new p073l4.i(responseCode, 0, strF2);
                                    r6.g(iVar2);
                                }
                            } catch (IOException e7) {
                                e = e7;
                                ValueOf = 0;
                            } catch (Throwable th) {
                                th = th;
                                ValueOf = 0;
                                r8 = inputStream;
                                r11 = ValueOf;
                                r6.b(r8, errorStream);
                                synchronized (r6) {
                                    r6.f7883b = false;
                                    if (r6.f7886e || (r11 != 0 && !p080m4.l.d(r11.intValue()))) {
                                        z6 = false;
                                    }
                                    if (z6) {
                                        aVar.getClass();
                                        r6.k(new Date(System.currentTimeMillis()));
                                    }
                                    if (!z6 || r11.intValue() == 200) {
                                        r6.h();
                                    } else {
                                        String strF3 = String.format("Unable to connect to the server. Try again in a few minutes. HTTP status code: %d", r11);
                                        if (r11.intValue() == 403) {
                                            strF3 = p080m4.l.f(r6.f7887f.getErrorStream());
                                        }
                                        r6.g(new p073l4.i(r11.intValue(), 0, strF3));
                                    }
                                    throw th;
                                }
                            }
                        } catch (IOException e8) {
                            e = e8;
                            errorStream = null;
                            inputStream = inputStream;
                            ValueOf = errorStream;
                            if (r6.f7886e) {
                                synchronized (r6) {
                                    r6.f7884c = 8;
                                }
                            } else {
                                Log.d("FirebaseRemoteConfig", "Exception connecting to real-time RC backend. Retrying the connection...", e);
                            }
                            r6.b(inputStream, errorStream);
                            synchronized (r6) {
                                r6.f7883b = false;
                                if (r6.f7886e) {
                                    z6 = false;
                                } else {
                                    z6 = false;
                                }
                                if (z6) {
                                    aVar.getClass();
                                    r6.k(new Date(System.currentTimeMillis()));
                                }
                                if (z6) {
                                }
                                r6.h();
                                r6.f7887f = null;
                                r6.f7888g = null;
                                return android.support.v4.media.session.b.D(null);
                            }
                        } catch (Throwable th2) {
                            th = th2;
                            errorStream = null;
                            ValueOf = 0;
                        }
                        r6.f7887f = null;
                        r6.f7888g = null;
                        return android.support.v4.media.session.b.D(null);
                    } catch (IOException e9) {
                        e = e9;
                        inputStream = 0;
                        errorStream = null;
                    } catch (Throwable th3) {
                        th = th3;
                        errorStream = null;
                        r11 = 0;
                        r6.b(r8, errorStream);
                        synchronized (r6) {
                            r6.f7883b = false;
                            if (r6.f7886e) {
                                z6 = false;
                            } else {
                                z6 = false;
                            }
                            if (z6) {
                                aVar.getClass();
                                r6.k(new Date(System.currentTimeMillis()));
                            }
                            if (z6) {
                                r6.h();
                            } else {
                                r6.h();
                            }
                            throw th;
                        }
                    }
                } catch (Throwable th4) {
                    th = th4;
                }
                break;
            case 21:
                return ((p080m4.h) this.f566s).b(iVar, 0L, (HashMap) this.t);
            case 22:
                k(iVar);
                return iVar;
        }
    }

    /* JADX WARN: Code duplicated, block: B:16:0x0047  */
    @Override // Q3.e
    public Object g(p pVar) {
        String strValueOf;
        switch (this.r) {
            case 19:
                String str = (String) this.f566s;
                A0.c cVar = (A0.c) this.t;
                Context context = (Context) pVar.a(Context.class);
                switch (cVar.r) {
                    case 21:
                        ApplicationInfo applicationInfo = context.getApplicationInfo();
                        if (applicationInfo == null) {
                            strValueOf = StringUtils.EMPTY;
                        } else {
                            strValueOf = String.valueOf(applicationInfo.targetSdkVersion);
                        }
                        break;
                    case 22:
                        ApplicationInfo applicationInfo2 = context.getApplicationInfo();
                        if (applicationInfo2 == null) {
                            strValueOf = StringUtils.EMPTY;
                        } else {
                            strValueOf = String.valueOf(applicationInfo2.minSdkVersion);
                        }
                        break;
                    case 23:
                        int i6 = Build.VERSION.SDK_INT;
                        if (context.getPackageManager().hasSystemFeature("android.hardware.type.television")) {
                            strValueOf = "tv";
                        } else if (context.getPackageManager().hasSystemFeature("android.hardware.type.watch")) {
                            strValueOf = "watch";
                        } else if (context.getPackageManager().hasSystemFeature("android.hardware.type.automotive")) {
                            strValueOf = "auto";
                        } else if (i6 >= 26 && context.getPackageManager().hasSystemFeature("android.hardware.type.embedded")) {
                            strValueOf = "embedded";
                        } else {
                            strValueOf = StringUtils.EMPTY;
                        }
                        break;
                    default:
                        String installerPackageName = context.getPackageManager().getInstallerPackageName(context.getPackageName());
                        if (installerPackageName == null) {
                            strValueOf = StringUtils.EMPTY;
                        } else {
                            strValueOf = FirebaseCommonRegistrar.a(installerPackageName);
                        }
                        break;
                }
                return new p066k4.a(str, strValueOf);
            default:
                String str2 = (String) this.f566s;
                Q3.b bVar = (Q3.b) this.t;
                try {
                    Trace.beginSection(str2);
                    return bVar.f3204f.g(pVar);
                } finally {
                    Trace.endSection();
                }
        }
    }

    @Override // p091o3.h
    public p091o3.q h(Object obj) {
        p080m4.d dVar = (p080m4.d) this.f566s;
        p080m4.f fVar = (p080m4.f) this.t;
        synchronized (dVar) {
            dVar.f7845c = android.support.v4.media.session.b.D(fVar);
        }
        return android.support.v4.media.session.b.D(fVar);
    }

    /* JADX WARN: Code duplicated, block: B:28:0x0079  */
    /* JADX WARN: Code duplicated, block: B:58:0x010c  */
    @Override // p091o3.e
    public void i(Exception exc) {
        M.e cVar;
        M.e cVar2;
        switch (this.r) {
            case 5:
                S.c cVar3 = (S.c) this.f566s;
                CancellationSignal cancellationSignal = (CancellationSignal) this.t;
                String str = ((exc instanceof O2.e) && R.a.f3255a.contains(Integer.valueOf(((O2.e) exc).r.r))) ? "GET_INTERRUPTED" : "GET_NO_CREDENTIALS";
                String str2 = "During begin sign in, failure response from one tap: " + exc.getMessage();
                int iHashCode = str.hashCode();
                if (iHashCode != -1567968963) {
                    if (iHashCode != -154594663) {
                        if (iHashCode == 1996705159 && str.equals("GET_NO_CREDENTIALS")) {
                            cVar = new M.i(str2);
                        } else {
                            cVar = new M.d(str2);
                        }
                    } else if (str.equals("GET_INTERRUPTED")) {
                        cVar = new M.f(str2);
                    } else {
                        cVar = new M.d(str2);
                    }
                } else if (str.equals("GET_CANCELED_TAG")) {
                    cVar = new M.c(str2);
                } else {
                    cVar = new M.d(str2);
                }
                CredentialProviderPlayServicesImpl.Companion.getClass();
                if (!Q.g.a(cancellationSignal)) {
                    cVar3.d().execute(new S.a(cVar3, cVar, 0));
                    break;
                }
                break;
            default:
                U.b bVar = (U.b) this.f566s;
                CancellationSignal cancellationSignal2 = (CancellationSignal) this.t;
                String str3 = ((exc instanceof O2.e) && R.a.f3255a.contains(Integer.valueOf(((O2.e) exc).r.r))) ? "GET_INTERRUPTED" : "GET_NO_CREDENTIALS";
                String str4 = "During get sign-in intent, failure response from one tap: " + exc.getMessage();
                int iHashCode2 = str3.hashCode();
                if (iHashCode2 != -1567968963) {
                    if (iHashCode2 != -154594663) {
                        if (iHashCode2 == 1996705159 && str3.equals("GET_NO_CREDENTIALS")) {
                            cVar2 = new M.i(str4);
                        } else {
                            cVar2 = new M.d(str4);
                        }
                    } else if (str3.equals("GET_INTERRUPTED")) {
                        cVar2 = new M.f(str4);
                    } else {
                        cVar2 = new M.d(str4);
                    }
                } else if (str3.equals("GET_CANCELED_TAG")) {
                    cVar2 = new M.c(str4);
                } else {
                    cVar2 = new M.d(str4);
                }
                CredentialProviderPlayServicesImpl.Companion.getClass();
                if (!Q.g.a(cancellationSignal2)) {
                    bVar.e().execute(new U.a(bVar, cVar2, 1));
                    break;
                }
                break;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v2, types: [java.util.List] */
    /* JADX WARN: Type inference failed for: r6v3, types: [java.util.ArrayList] */
    public void j(C0442f c0442f, p086n4.a aVar) {
        p081m5.m mVar;
        List list;
        ?? arrayList;
        p047h5.u uVar;
        ArrayList arrayList2;
        ArrayList arrayList3;
        ArrayList arrayList4;
        p047h5.u uVar2;
        C0362i c0362i = (C0362i) this.f566s;
        c5.b bVar = (c5.b) this.t;
        c0362i.getClass();
        List<p103q2.k> list2 = (List) aVar.f7949s;
        if (list2 != null) {
            for (p103q2.k kVar : list2) {
                c0362i.f6161w.put(kVar.f8620c, kVar);
            }
        }
        p047h5.q qVarV = X2.a.v(c0442f);
        p081m5.m mVar2 = p081m5.m.r;
        if (list2 != null) {
            ArrayList arrayList5 = new ArrayList(p081m5.g.x0(list2));
            Iterator it = list2.iterator();
            while (it.hasNext()) {
                p103q2.k kVar2 = (p103q2.k) it.next();
                A5.h.e(kVar2, "detail");
                String str = kVar2.f8624g;
                A5.h.d(str, "getDescription(...)");
                String str2 = kVar2.f8623f;
                A5.h.d(str2, "getName(...)");
                String str3 = kVar2.f8620c;
                A5.h.d(str3, "getProductId(...)");
                String str4 = kVar2.f8621d;
                A5.h.d(str4, "getProductType(...)");
                boolean zEquals = str4.equals("inapp");
                p047h5.A a5 = p047h5.A.t;
                if (!zEquals && str4.equals("subs")) {
                    a5 = p047h5.A.f6090u;
                }
                p047h5.A a7 = a5;
                String str5 = kVar2.f8622e;
                A5.h.d(str5, "getTitle(...)");
                p103q2.h hVarA = kVar2.a();
                Iterator it2 = it;
                p081m5.m mVar3 = mVar2;
                if (hVarA == null) {
                    uVar = null;
                } else {
                    long j6 = hVarA.f8600b;
                    String str6 = hVarA.f8599a;
                    A5.h.d(str6, "getFormattedPrice(...)");
                    String str7 = hVarA.f8601c;
                    A5.h.d(str7, "getPriceCurrencyCode(...)");
                    uVar = new p047h5.u(j6, str6, str7);
                }
                ArrayList arrayList6 = kVar2.f8628k;
                if (arrayList6 != null) {
                    arrayList2 = new ArrayList();
                    int size = arrayList6.size();
                    int i6 = 0;
                    while (i6 < size) {
                        Object obj = arrayList6.get(i6);
                        int i7 = i6 + 1;
                        ArrayList arrayList7 = arrayList6;
                        p103q2.h hVar = (p103q2.h) obj;
                        if (hVar == null) {
                            uVar2 = null;
                        } else {
                            long j7 = hVar.f8600b;
                            String str8 = hVar.f8599a;
                            A5.h.d(str8, "getFormattedPrice(...)");
                            String str9 = hVar.f8601c;
                            A5.h.d(str9, "getPriceCurrencyCode(...)");
                            uVar2 = new p047h5.u(j7, str8, str9);
                        }
                        if (uVar2 != null) {
                            arrayList2.add(uVar2);
                        }
                        uVar = uVar;
                        arrayList6 = arrayList7;
                        str3 = str3;
                        size = size;
                        i6 = i7;
                    }
                } else {
                    arrayList2 = null;
                }
                p047h5.u uVar3 = uVar;
                String str10 = str3;
                ArrayList arrayList8 = kVar2.f8627j;
                if (arrayList8 != null) {
                    ArrayList arrayList9 = new ArrayList(p081m5.g.x0(arrayList8));
                    int size2 = arrayList8.size();
                    int i8 = 0;
                    while (i8 < size2) {
                        Object obj2 = arrayList8.get(i8);
                        int i9 = i8 + 1;
                        p103q2.j jVar = (p103q2.j) obj2;
                        A5.h.e(jVar, "subscriptionOfferDetails");
                        String str11 = jVar.f8612a;
                        ArrayList arrayList10 = arrayList8;
                        A5.h.d(str11, "getBasePlanId(...)");
                        String str12 = jVar.f8613b;
                        String str13 = jVar.f8614c;
                        int i10 = size2;
                        A5.h.d(str13, "getOfferToken(...)");
                        ArrayList arrayList11 = jVar.f8616e;
                        A5.h.d(arrayList11, "getOfferTags(...)");
                        G g7 = jVar.f8615d;
                        A5.h.d(g7, "getPricingPhases(...)");
                        ArrayList arrayList12 = (ArrayList) g7.r;
                        A5.h.d(arrayList12, "getPricingPhaseList(...)");
                        ArrayList arrayList13 = new ArrayList(p081m5.g.x0(arrayList12));
                        int size3 = arrayList12.size();
                        ArrayList arrayList14 = arrayList2;
                        int i11 = 0;
                        while (i11 < size3) {
                            Object obj3 = arrayList12.get(i11);
                            int i12 = i11 + 1;
                            ArrayList arrayList15 = arrayList12;
                            p103q2.i iVar = (p103q2.i) obj3;
                            A5.h.b(iVar);
                            int i13 = size3;
                            long j8 = iVar.f8610e;
                            int i14 = iVar.f8611f;
                            H h7 = i14 != 1 ? i14 != 2 ? H.f6125v : H.t : H.f6124u;
                            long j9 = iVar.f8607b;
                            String str14 = iVar.f8609d;
                            A5.h.d(str14, "getBillingPeriod(...)");
                            String str15 = iVar.f8606a;
                            A5.h.d(str15, "getFormattedPrice(...)");
                            String str16 = iVar.f8608c;
                            A5.h.d(str16, "getPriceCurrencyCode(...)");
                            arrayList13.add(new x(j8, h7, j9, str14, str15, str16));
                            size3 = i13;
                            arrayList12 = arrayList15;
                            i11 = i12;
                        }
                        C0031j c0031j = jVar.f8617f;
                        arrayList9.add(new J(str11, str12, str13, arrayList11, arrayList13, c0031j == null ? null : new p047h5.t(c0031j.f1491a, c0031j.f1492b)));
                        arrayList8 = arrayList10;
                        size2 = i10;
                        i8 = i9;
                        arrayList2 = arrayList14;
                        a7 = a7;
                    }
                    arrayList3 = arrayList2;
                    arrayList4 = arrayList9;
                } else {
                    arrayList3 = arrayList2;
                    arrayList4 = null;
                }
                arrayList5.add(new y(str, str2, str10, a7, str5, uVar3, arrayList3, arrayList4));
                it = it2;
                mVar2 = mVar3;
            }
            mVar = mVar2;
            list = arrayList5;
        } else {
            mVar = mVar2;
            list = mVar;
        }
        List<p103q2.n> list3 = (List) aVar.t;
        if (list3 != null) {
            arrayList = new ArrayList(p081m5.g.x0(list3));
            for (p103q2.n nVar : list3) {
                A5.h.e(nVar, "unfetchedProduct");
                String str17 = nVar.f8632b;
                A5.h.d(str17, "getProductId(...)");
                arrayList.add(new K(str17));
            }
        } else {
            arrayList = mVar;
        }
        N.a(new z(qVarV, list, arrayList), bVar);
    }

    @Override // p091o3.d
    public void p(p091o3.i iVar) {
        switch (this.r) {
            case 7:
                c5.b bVar = (c5.b) this.f566s;
                c5.f fVar = (c5.f) this.t;
                A5.h.e(iVar, "task");
                if (!iVar.h()) {
                    Exception excE = iVar.e();
                    fVar.getClass();
                    c5.f.c(bVar, excE);
                } else {
                    bVar.a(new p074l5.i(p074l5.l.f7746a));
                }
                break;
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                c5.b bVar2 = (c5.b) this.f566s;
                c5.f fVar2 = (c5.f) this.t;
                A5.h.e(iVar, "task");
                if (!iVar.h()) {
                    Exception excE2 = iVar.e();
                    fVar2.getClass();
                    c5.f.c(bVar2, excE2);
                } else {
                    bVar2.a(new p074l5.i(p074l5.l.f7746a));
                }
                break;
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                c5.b bVar3 = (c5.b) this.f566s;
                c5.f fVar3 = (c5.f) this.t;
                A5.h.e(iVar, "task");
                if (!iVar.h()) {
                    Exception excE3 = iVar.e();
                    fVar3.getClass();
                    c5.f.c(bVar3, excE3);
                } else {
                    bVar3.a(new p074l5.i(p074l5.l.f7746a));
                }
                break;
            case 10:
                c5.b bVar4 = (c5.b) this.f566s;
                c5.f fVar4 = (c5.f) this.t;
                A5.h.e(iVar, "task");
                if (!iVar.h()) {
                    Exception excE4 = iVar.e();
                    fVar4.getClass();
                    c5.f.c(bVar4, excE4);
                } else {
                    bVar4.a(new p074l5.i(iVar.f()));
                }
                break;
            case 11:
                c5.b bVar5 = (c5.b) this.f566s;
                c5.f fVar5 = (c5.f) this.t;
                A5.h.e(iVar, "task");
                if (!iVar.h()) {
                    Exception excE5 = iVar.e();
                    fVar5.getClass();
                    c5.f.c(bVar5, excE5);
                } else {
                    bVar5.a(new p074l5.i(p074l5.l.f7746a));
                }
                break;
            case 12:
                c5.b bVar6 = (c5.b) this.f566s;
                c5.f fVar6 = (c5.f) this.t;
                A5.h.e(iVar, "task");
                if (!iVar.h()) {
                    Exception excE6 = iVar.e();
                    fVar6.getClass();
                    c5.f.c(bVar6, excE6);
                } else {
                    bVar6.a(new p074l5.i(p074l5.l.f7746a));
                }
                break;
            case 13:
                c5.b bVar7 = (c5.b) this.f566s;
                c5.f fVar7 = (c5.f) this.t;
                A5.h.e(iVar, "task");
                if (!iVar.h()) {
                    Exception excE7 = iVar.e();
                    fVar7.getClass();
                    c5.f.c(bVar7, excE7);
                } else {
                    bVar7.a(new p074l5.i(iVar.f()));
                }
                break;
            default:
                ((AbstractServiceC0374g) this.f566s).a((Intent) this.t);
                break;
        }
    }
}
