package C2;

import D3.p;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import com.google.crypto.tink.shaded.protobuf.T;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Executor;
import org.apache.tika.utils.StringUtils;
import p025e2.v;
import p045h3.C0331c;
import p053i4.E;
import p068l.v0;
import p130v2.t;
import p130v2.u;
import p130v2.w;
import p135w2.n;

/* JADX INFO: loaded from: classes.dex */
public final class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f568a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final p142x2.f f569b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final D2.d f570c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final d f571d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Executor f572e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final E2.c f573f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Z3.e f574g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final Z3.e f575h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final D2.c f576i;

    public l(Context context, p142x2.f fVar, D2.d dVar, d dVar2, Executor executor, E2.c cVar, Z3.e eVar, Z3.e eVar2, D2.c cVar2) {
        this.f568a = context;
        this.f569b = fVar;
        this.f570c = dVar;
        this.f571d = dVar2;
        this.f572e = executor;
        this.f573f = cVar;
        this.f574g = eVar;
        this.f575h = eVar2;
        this.f576i = cVar2;
    }

    public final void a(p135w2.i iVar, int i6) {
        byte[] bArr;
        long j6;
        p142x2.a aVar;
        String str;
        int i7;
        F0.g gVarB;
        String str2;
        Integer numValueOf;
        v0 v0Var;
        final l lVar = this;
        final p135w2.i iVar2 = iVar;
        byte[] bArr2 = iVar2.f9649b;
        p142x2.g gVarA = lVar.f569b.a(iVar2.f9648a);
        long jMax = 0;
        while (true) {
            final int i8 = 0;
            E2.b bVar = new E2.b(lVar) { // from class: C2.h

                /* JADX INFO: renamed from: s, reason: collision with root package name */
                public final /* synthetic */ l f562s;

                {
                    this.f562s = lVar;
                }

                @Override // E2.b
                public final Object d() {
                    Boolean bool;
                    switch (i8) {
                        case 0:
                            p135w2.i iVar3 = iVar2;
                            D2.h hVar = (D2.h) this.f562s.f570c;
                            SQLiteDatabase sQLiteDatabaseA = hVar.a();
                            sQLiteDatabaseA.beginTransaction();
                            try {
                                Long lD = D2.h.d(sQLiteDatabaseA, iVar3);
                                if (lD == null) {
                                    bool = Boolean.FALSE;
                                } else {
                                    Cursor cursorRawQuery = hVar.a().rawQuery("SELECT 1 FROM events WHERE context_id = ? LIMIT 1", new String[]{lD.toString()});
                                    try {
                                        Boolean boolValueOf = Boolean.valueOf(cursorRawQuery.moveToNext());
                                        cursorRawQuery.close();
                                        bool = boolValueOf;
                                    } catch (Throwable th) {
                                        cursorRawQuery.close();
                                        throw th;
                                    }
                                }
                                sQLiteDatabaseA.setTransactionSuccessful();
                                sQLiteDatabaseA.endTransaction();
                                return bool;
                            } catch (Throwable th2) {
                                sQLiteDatabaseA.endTransaction();
                                throw th2;
                            }
                        default:
                            D2.h hVar2 = (D2.h) this.f562s.f570c;
                            hVar2.getClass();
                            return (Iterable) hVar2.e(new j(hVar2, iVar2, 2));
                    }
                }
            };
            D2.h hVar = (D2.h) lVar.f573f;
            if (!((Boolean) hVar.o(bVar)).booleanValue()) {
                hVar.o(new k(jMax, lVar, iVar2));
                return;
            }
            final int i9 = 1;
            Iterable iterable = (Iterable) hVar.o(new E2.b(lVar) { // from class: C2.h

                /* JADX INFO: renamed from: s, reason: collision with root package name */
                public final /* synthetic */ l f562s;

                {
                    this.f562s = lVar;
                }

                @Override // E2.b
                public final Object d() {
                    Boolean bool;
                    switch (i9) {
                        case 0:
                            p135w2.i iVar3 = iVar2;
                            D2.h hVar2 = (D2.h) this.f562s.f570c;
                            SQLiteDatabase sQLiteDatabaseA = hVar2.a();
                            sQLiteDatabaseA.beginTransaction();
                            try {
                                Long lD = D2.h.d(sQLiteDatabaseA, iVar3);
                                if (lD == null) {
                                    bool = Boolean.FALSE;
                                } else {
                                    Cursor cursorRawQuery = hVar2.a().rawQuery("SELECT 1 FROM events WHERE context_id = ? LIMIT 1", new String[]{lD.toString()});
                                    try {
                                        Boolean boolValueOf = Boolean.valueOf(cursorRawQuery.moveToNext());
                                        cursorRawQuery.close();
                                        bool = boolValueOf;
                                    } catch (Throwable th) {
                                        cursorRawQuery.close();
                                        throw th;
                                    }
                                }
                                sQLiteDatabaseA.setTransactionSuccessful();
                                sQLiteDatabaseA.endTransaction();
                                return bool;
                            } catch (Throwable th2) {
                                sQLiteDatabaseA.endTransaction();
                                throw th2;
                            }
                        default:
                            D2.h hVar3 = (D2.h) this.f562s.f570c;
                            hVar3.getClass();
                            return (Iterable) hVar3.e(new j(hVar3, iVar2, 2));
                    }
                }
            });
            if (!iterable.iterator().hasNext()) {
                return;
            }
            if (gVarA == null) {
                v.i("Uploader", "Unknown backend for %s, deleting event batch for it...", iVar2);
                aVar = new p142x2.a(-1L, 3);
                bArr = bArr2;
                j6 = jMax;
            } else {
                ArrayList arrayList = new ArrayList();
                Iterator it = iterable.iterator();
                while (it.hasNext()) {
                    arrayList.add(((D2.b) it.next()).f797c);
                }
                if (bArr2 != null) {
                    D2.c cVar = lVar.f576i;
                    Objects.requireNonNull(cVar);
                    p151z2.a aVar2 = (p151z2.a) hVar.o(new B4.b(cVar, i9));
                    p pVar = new p();
                    pVar.f838f = new HashMap();
                    pVar.f836d = Long.valueOf(lVar.f574g.n());
                    pVar.f837e = Long.valueOf(lVar.f575h.n());
                    pVar.f833a = "GDT_CLIENT_METRICS";
                    t2.c cVar2 = new t2.c("proto");
                    aVar2.getClass();
                    A4.d dVar = n.f9658a;
                    dVar.getClass();
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    try {
                        dVar.A(aVar2, byteArrayOutputStream);
                    } catch (IOException unused) {
                    }
                    pVar.f835c = new p135w2.l(cVar2, byteArrayOutputStream.toByteArray());
                    arrayList.add(((p124u2.b) gVarA).a(pVar.j()));
                }
                p124u2.b bVar2 = (p124u2.b) gVarA;
                HashMap map = new HashMap();
                int size = arrayList.size();
                int i10 = 0;
                while (i10 < size) {
                    Object obj = arrayList.get(i10);
                    i10++;
                    p135w2.h hVar2 = (p135w2.h) obj;
                    String str3 = hVar2.f9642a;
                    if (map.containsKey(str3)) {
                        ((List) map.get(str3)).add(hVar2);
                    } else {
                        ArrayList arrayList2 = new ArrayList();
                        arrayList2.add(hVar2);
                        map.put(str3, arrayList2);
                    }
                    arrayList = arrayList;
                }
                ArrayList arrayList3 = new ArrayList();
                for (Map.Entry entry : map.entrySet()) {
                    p135w2.h hVar3 = (p135w2.h) ((List) entry.getValue()).get(0);
                    w wVar = w.r;
                    long jN = bVar2.f9202f.n();
                    long jN2 = bVar2.f9201e.n();
                    p130v2.j jVar = new p130v2.j(new p130v2.h(Integer.valueOf(hVar3.b("sdk-version")), hVar3.a("model"), hVar3.a("hardware"), hVar3.a("device"), hVar3.a("product"), hVar3.a("os-uild"), hVar3.a("manufacturer"), hVar3.a("fingerprint"), hVar3.a("locale"), hVar3.a("country"), hVar3.a("mcc_mnc"), hVar3.a("application_build")));
                    try {
                        numValueOf = Integer.valueOf(Integer.parseInt((String) entry.getKey()));
                        str2 = null;
                    } catch (NumberFormatException unused2) {
                        str2 = (String) entry.getKey();
                        numValueOf = null;
                    }
                    ArrayList arrayList4 = new ArrayList();
                    for (p135w2.h hVar4 : (List) entry.getValue()) {
                        byte[] bArr3 = bArr2;
                        p135w2.l lVar2 = hVar4.f9644c;
                        t2.c cVar3 = lVar2.f9655a;
                        byte[] bArr4 = lVar2.f9656b;
                        long j7 = jMax;
                        if (cVar3.equals(new t2.c("proto"))) {
                            v0Var = new v0();
                            v0Var.f7491u = bArr4;
                        } else {
                            if (cVar3.equals(new t2.c("json"))) {
                                String str4 = new String(bArr4, Charset.forName("UTF-8"));
                                v0 v0Var2 = new v0();
                                v0Var2.f7492v = str4;
                                v0Var = v0Var2;
                            } else {
                                String strX = v.x("CctTransportBackend");
                                if (Log.isLoggable(strX, 5)) {
                                    Log.w(strX, "Received event of unsupported encoding " + cVar3 + ". Skipping...");
                                }
                            }
                            bArr2 = bArr3;
                            jMax = j7;
                        }
                        v0Var.r = Long.valueOf(hVar4.f9645d);
                        v0Var.t = Long.valueOf(hVar4.f9646e);
                        String str5 = (String) hVar4.f9647f.get("tz-offset");
                        v0Var.f7493w = Long.valueOf(str5 == null ? 0L : Long.valueOf(str5).longValue());
                        v0Var.f7494x = new p130v2.n((u) u.r.get(hVar4.b("net-type")), (t) t.r.get(hVar4.b("mobile-subtype")));
                        Integer num = hVar4.f9643b;
                        if (num != null) {
                            v0Var.f7490s = num;
                        }
                        String strI = ((Long) v0Var.r) == null ? " eventTimeMs" : StringUtils.EMPTY;
                        if (((Long) v0Var.t) == null) {
                            strI = strI.concat(" eventUptimeMs");
                        }
                        if (((Long) v0Var.f7493w) == null) {
                            strI = T.i(strI, " timezoneOffsetSeconds");
                        }
                        if (!strI.isEmpty()) {
                            throw new IllegalStateException("Missing required properties:".concat(strI));
                        }
                        arrayList4.add(new p130v2.k(((Long) v0Var.r).longValue(), (Integer) v0Var.f7490s, ((Long) v0Var.t).longValue(), (byte[]) v0Var.f7491u, (String) v0Var.f7492v, ((Long) v0Var.f7493w).longValue(), (p130v2.n) v0Var.f7494x));
                        bArr2 = bArr3;
                        jMax = j7;
                    }
                    arrayList3.add(new p130v2.l(jN, jN2, jVar, numValueOf, str2, arrayList4));
                }
                bArr = bArr2;
                j6 = jMax;
                p130v2.i iVar3 = new p130v2.i(arrayList3);
                URL urlB = bVar2.f9200d;
                if (bArr != null) {
                    try {
                        p124u2.a aVarA = p124u2.a.a(bArr);
                        str = aVarA.f9196b;
                        if (str == null) {
                            str = null;
                        }
                        String str6 = aVarA.f9195a;
                        if (str6 != null) {
                            urlB = p124u2.b.b(str6);
                        }
                    } catch (IllegalArgumentException unused3) {
                        aVar = new p142x2.a(-1L, 3);
                    }
                } else {
                    str = null;
                }
                try {
                    int i11 = 8;
                    C0331c c0331c = new C0331c(urlB, iVar3, str, i11);
                    E e6 = new E(bVar2, 9);
                    int i12 = 5;
                    do {
                        gVarB = e6.b(c0331c);
                        URL url = (URL) gVarB.f1205c;
                        if (url != null) {
                            v.i("CctTransportBackend", "Following redirect to: %s", url);
                            c0331c = new C0331c(url, (p130v2.i) c0331c.t, (String) c0331c.f6059s, i11);
                        } else {
                            c0331c = null;
                        }
                        if (c0331c == null) {
                            break;
                        } else {
                            i12--;
                        }
                    } while (i12 >= 1);
                    int i13 = gVarB.f1203a;
                    if (i13 == 200) {
                        aVar = new p142x2.a(gVarB.f1204b, 1);
                    } else if (i13 >= 500 || i13 == 404) {
                        aVar = new p142x2.a(-1L, 2);
                    } else if (i13 == 400) {
                        try {
                            aVar = new p142x2.a(-1L, 4);
                        } catch (IOException e7) {
                            e = e7;
                            v.q("CctTransportBackend", "Could not make request to the backend", e);
                            i7 = 2;
                            aVar = new p142x2.a(-1L, 2);
                        }
                    } else {
                        aVar = new p142x2.a(-1L, 3);
                    }
                } catch (IOException e8) {
                    e = e8;
                }
            }
            i7 = 2;
            int i14 = aVar.f10348a;
            if (i14 == i7) {
                hVar.o(new i(this, iterable, iVar, j6));
                this.f571d.a(iVar, i6 + 1, true);
                return;
            }
            lVar = this;
            iVar2 = iVar;
            long j8 = j6;
            hVar.o(new j(lVar, iterable, 0));
            if (i14 == 1) {
                jMax = Math.max(j8, aVar.f10349b);
                if (bArr != null) {
                    hVar.o(new B4.b(lVar, 3));
                }
            } else {
                if (i14 == 4) {
                    HashMap map2 = new HashMap();
                    Iterator it2 = iterable.iterator();
                    while (it2.hasNext()) {
                        String str7 = ((D2.b) it2.next()).f797c.f9642a;
                        if (map2.containsKey(str7)) {
                            map2.put(str7, Integer.valueOf(((Integer) map2.get(str7)).intValue() + 1));
                        } else {
                            map2.put(str7, 1);
                        }
                    }
                    hVar.o(new j(lVar, map2, 1));
                }
                jMax = j8;
            }
            bArr2 = bArr;
        }
    }
}
