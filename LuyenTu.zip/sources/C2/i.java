package C2;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.concurrent.Callable;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class i implements E2.b, R3.g {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ long f563s;
    public final /* synthetic */ Object t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ Object f564u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ Object f565v;

    public /* synthetic */ i(l lVar, Iterable iterable, p135w2.i iVar, long j6) {
        this.r = 0;
        this.t = lVar;
        this.f564u = iterable;
        this.f565v = iVar;
        this.f563s = j6;
    }

    @Override // R3.g
    public ScheduledFuture a(A0.i iVar) {
        switch (this.r) {
            case 1:
                R3.f fVar = (R3.f) this.t;
                Runnable runnable = (Runnable) this.f564u;
                return fVar.f3418s.schedule(new R3.d(fVar, runnable, iVar, 1), this.f563s, (TimeUnit) this.f565v);
            default:
                R3.f fVar2 = (R3.f) this.t;
                Callable callable = (Callable) this.f564u;
                return fVar2.f3418s.schedule(new R3.e(fVar2, callable, iVar, 0), this.f563s, (TimeUnit) this.f565v);
        }
    }

    @Override // E2.b
    public Object d() {
        l lVar = (l) this.t;
        Iterable iterable = (Iterable) this.f564u;
        p135w2.i iVar = (p135w2.i) this.f565v;
        D2.h hVar = (D2.h) lVar.f570c;
        hVar.getClass();
        if (iterable.iterator().hasNext()) {
            String str = "UPDATE events SET num_attempts = num_attempts + 1 WHERE _id in " + D2.h.q(iterable);
            SQLiteDatabase sQLiteDatabaseA = hVar.a();
            sQLiteDatabaseA.beginTransaction();
            try {
                sQLiteDatabaseA.compileStatement(str).execute();
                Cursor cursorRawQuery = sQLiteDatabaseA.rawQuery("SELECT COUNT(*), transport_name FROM events WHERE num_attempts >= 16 GROUP BY transport_name", null);
                while (cursorRawQuery.moveToNext()) {
                    try {
                        hVar.j(cursorRawQuery.getInt(0), p151z2.c.f10777w, cursorRawQuery.getString(1));
                    } catch (Throwable th) {
                        cursorRawQuery.close();
                        throw th;
                    }
                }
                cursorRawQuery.close();
                sQLiteDatabaseA.compileStatement("DELETE FROM events WHERE num_attempts >= 16").execute();
                sQLiteDatabaseA.setTransactionSuccessful();
                sQLiteDatabaseA.endTransaction();
            } catch (Throwable th2) {
                sQLiteDatabaseA.endTransaction();
                throw th2;
            }
        }
        hVar.e(new D2.e(lVar.f574g.n() + this.f563s, iVar));
        return null;
    }

    public /* synthetic */ i(R3.f fVar, Object obj, long j6, TimeUnit timeUnit, int i6) {
        this.r = i6;
        this.t = fVar;
        this.f564u = obj;
        this.f563s = j6;
        this.f565v = timeUnit;
    }
}
