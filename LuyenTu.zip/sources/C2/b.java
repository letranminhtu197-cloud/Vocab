package C2;

import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Z3.e f549a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final HashMap f550b;

    public b(Z3.e eVar, HashMap map) {
        this.f549a = eVar;
        this.f550b = map;
    }

    public final long a(t2.d dVar, long j6, int i6) {
        long jN = j6 - this.f549a.n();
        c cVar = (c) this.f550b.get(dVar);
        long j7 = cVar.f551a;
        int i7 = i6 - 1;
        return Math.min(Math.max((long) (Math.pow(3.0d, i7) * j7 * Math.max(1.0d, Math.log(10000.0d) / Math.log((j7 > 1 ? j7 : 2L) * ((long) i7)))), jN), cVar.f552b);
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return this.f549a.equals(bVar.f549a) && this.f550b.equals(bVar.f550b);
    }

    public final int hashCode() {
        return ((this.f549a.hashCode() ^ 1000003) * 1000003) ^ this.f550b.hashCode();
    }

    public final String toString() {
        return "SchedulerConfig{clock=" + this.f549a + ", values=" + this.f550b + "}";
    }
}
