package C2;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class e {
    public static final e r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final e f557s;
    public static final e t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final /* synthetic */ e[] f558u;

    static {
        e eVar = new e("NETWORK_UNMETERED", 0);
        r = eVar;
        e eVar2 = new e("DEVICE_IDLE", 1);
        f557s = eVar2;
        e eVar3 = new e("DEVICE_CHARGING", 2);
        t = eVar3;
        f558u = new e[]{eVar, eVar2, eVar3};
    }

    public static e valueOf(String str) {
        return (e) Enum.valueOf(e.class, str);
    }

    public static e[] values() {
        return (e[]) f558u.clone();
    }
}
