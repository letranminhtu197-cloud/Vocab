package C2;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class f implements Runnable {
    public final /* synthetic */ l r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ p135w2.i f559s;
    public final /* synthetic */ int t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ Runnable f560u;

    public /* synthetic */ f(l lVar, p135w2.i iVar, int i6, Runnable runnable) {
        this.r = lVar;
        this.f559s = iVar;
        this.t = i6;
        this.f560u = runnable;
    }

    @Override // java.lang.Runnable
    public final void run() {
        p135w2.i iVar = this.f559s;
        int i6 = this.t;
        Runnable runnable = this.f560u;
        l lVar = this.r;
        E2.c cVar = lVar.f573f;
        try {
            D2.d dVar = lVar.f570c;
            Objects.requireNonNull(dVar);
            ((D2.h) cVar).o(new B4.b(dVar, 2));
            NetworkInfo activeNetworkInfo = ((ConnectivityManager) lVar.f568a.getSystemService("connectivity")).getActiveNetworkInfo();
            if (activeNetworkInfo == null || !activeNetworkInfo.isConnected()) {
                ((D2.h) cVar).o(new g(lVar, iVar, i6));
            } else {
                lVar.a(iVar, i6);
            }
        } catch (E2.a unused) {
            lVar.f571d.a(iVar, i6 + 1, false);
        } finally {
            runnable.run();
        }
    }
}
