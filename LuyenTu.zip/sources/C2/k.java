package C2;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class k implements E2.b, D2.f, p091o3.a {
    public final /* synthetic */ long r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ Object f567s;
    public final /* synthetic */ Object t;

    public /* synthetic */ k(long j6, Object obj, Object obj2) {
        this.f567s = obj;
        this.t = obj2;
        this.r = j6;
    }

    @Override // D2.f
    public Object apply(Object obj) {
        String str = (String) this.f567s;
        SQLiteDatabase sQLiteDatabase = (SQLiteDatabase) obj;
        int i6 = ((p151z2.c) this.t).r;
        Cursor cursorRawQuery = sQLiteDatabase.rawQuery("SELECT 1 FROM log_event_dropped WHERE log_source = ? AND reason = ?", new String[]{str, Integer.toString(i6)});
        try {
            boolean z6 = cursorRawQuery.getCount() > 0;
            cursorRawQuery.close();
            long j6 = this.r;
            if (z6) {
                sQLiteDatabase.execSQL("UPDATE log_event_dropped SET events_dropped_count = events_dropped_count + " + j6 + " WHERE log_source = ? AND reason = ?", new String[]{str, Integer.toString(i6)});
                return null;
            }
            ContentValues contentValues = new ContentValues();
            contentValues.put("log_source", str);
            contentValues.put("reason", Integer.valueOf(i6));
            contentValues.put("events_dropped_count", Long.valueOf(j6));
            sQLiteDatabase.insert("log_event_dropped", null, contentValues);
            return null;
        } catch (Throwable th) {
            cursorRawQuery.close();
            throw th;
        }
    }

    @Override // E2.b
    public Object d() {
        l lVar = (l) this.f567s;
        p135w2.i iVar = (p135w2.i) this.t;
        D2.d dVar = lVar.f570c;
        long jN = lVar.f574g.n() + this.r;
        D2.h hVar = (D2.h) dVar;
        hVar.getClass();
        hVar.e(new D2.e(jN, iVar));
        return null;
    }

    @Override // p091o3.a
    public Object f(p091o3.i iVar) {
        return ((p080m4.h) this.f567s).b(iVar, this.r, (HashMap) this.t);
    }

    public /* synthetic */ k(p080m4.h hVar, long j6, HashMap map) {
        this.f567s = hVar;
        this.r = j6;
        this.t = map;
    }
}
