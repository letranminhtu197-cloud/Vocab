package C2;

import com.google.android.datatransport.runtime.scheduling.jobscheduling.AlarmManagerSchedulerBroadcastReceiver;
import org.apache.tika.parser.AbstractExternalProcessParser;
import org.apache.tika.utils.ProcessUtils;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements Runnable {
    public final /* synthetic */ int r;

    public /* synthetic */ a(int i6) {
        this.r = i6;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.r) {
            case 0:
                int i6 = AlarmManagerSchedulerBroadcastReceiver.f4664a;
                return;
            case 1:
                throw null;
            case 2:
                AbstractExternalProcessParser.lambda$static$0();
                return;
            default:
                ProcessUtils.lambda$static$0();
                return;
        }
    }
}
