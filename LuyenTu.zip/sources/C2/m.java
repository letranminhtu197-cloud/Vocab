package C2;

import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
public final class m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Executor f577a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final D2.d f578b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final d f579c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final E2.c f580d;

    public m(Executor executor, D2.d dVar, d dVar2, E2.c cVar) {
        this.f577a = executor;
        this.f578b = dVar;
        this.f579c = dVar2;
        this.f580d = cVar;
    }
}
