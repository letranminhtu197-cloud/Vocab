package C2;

import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f551a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f552b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Set f553c;

    public c(long j6, long j7, Set set) {
        this.f551a = j6;
        this.f552b = j7;
        this.f553c = set;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof c) {
            c cVar = (c) obj;
            if (this.f551a == cVar.f551a && this.f552b == cVar.f552b && this.f553c.equals(cVar.f553c)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        long j6 = this.f551a;
        int i6 = (((int) (j6 ^ (j6 >>> 32))) ^ 1000003) * 1000003;
        long j7 = this.f552b;
        return ((i6 ^ ((int) ((j7 >>> 32) ^ j7))) * 1000003) ^ this.f553c.hashCode();
    }

    public final String toString() {
        return "ConfigValue{delta=" + this.f551a + ", maxAllowedDelay=" + this.f552b + ", flags=" + this.f553c + "}";
    }
}
