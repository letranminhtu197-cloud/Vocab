package C0;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final h f383a = new h();

    public final void a() {
    }
}
