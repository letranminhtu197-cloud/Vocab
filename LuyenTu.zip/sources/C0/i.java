package C0;

import android.os.Looper;
import p101q0.C0427o;

/* JADX INFO: loaded from: classes.dex */
public interface i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final g f384a = new g();

    void a(Looper looper, y0.k kVar);

    int c(C0427o c0427o);

    M4.i d(e eVar, C0427o c0427o);

    default void b() {
    }

    default void release() {
    }
}
