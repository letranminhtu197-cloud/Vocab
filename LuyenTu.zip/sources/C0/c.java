package C0;

import java.io.IOException;

/* JADX INFO: loaded from: classes.dex */
public final class c extends IOException {
    public final int r;

    public c(Throwable th, int i6) {
        super(th);
        this.r = i6;
    }
}
