package C0;

import p117t0.s;

/* JADX INFO: loaded from: classes.dex */
public abstract class j implements p134w0.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final boolean f385a;

    /* JADX WARN: Code duplicated, block: B:9:0x001e  */
    static {
        boolean z6;
        if ("Amazon".equals(s.f9004c)) {
            String str = s.f9005d;
            if ("AFTM".equals(str) || "AFTB".equals(str)) {
                z6 = true;
            } else {
                z6 = false;
            }
        } else {
            z6 = false;
        }
        f385a = z6;
    }
}
