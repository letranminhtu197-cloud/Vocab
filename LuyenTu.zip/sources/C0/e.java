package C0;

import J0.B;
import J0.C0093w;
import J0.E;
import J0.G;
import J0.H;
import J0.I;
import J0.J;
import java.io.IOException;
import java.util.concurrent.CopyOnWriteArrayList;
import p101q0.C0427o;
import p117t0.s;

/* JADX INFO: loaded from: classes.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f380a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final E f381b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final CopyOnWriteArrayList f382c;

    public /* synthetic */ e(CopyOnWriteArrayList copyOnWriteArrayList, int i6, E e6) {
        this.f382c = copyOnWriteArrayList;
        this.f380a = i6;
        this.f381b = e6;
    }

    public void a(int i6, C0427o c0427o, int i7, Object obj, long j6) {
        b(new B(1, i6, c0427o, i7, obj, s.S(j6), -9223372036854775807L));
    }

    public void b(B b6) {
        for (I i6 : this.f382c) {
            s.L(i6.f1679a, new B2.a(this, i6.f1680b, b6, 2));
        }
    }

    public void c(C0093w c0093w, int i6, int i7, C0427o c0427o, int i8, Object obj, long j6, long j7) {
        d(c0093w, new B(i6, i7, c0427o, i8, obj, s.S(j6), s.S(j7)));
    }

    /* JADX WARN: Type inference failed for: r4v0, types: [J0.J, java.lang.Object] */
    public void d(C0093w c0093w, B b6) {
        for (I i6 : this.f382c) {
            s.L(i6.f1679a, new G(this, i6.f1680b, c0093w, b6, 2));
        }
    }

    public void e(C0093w c0093w, int i6, int i7, C0427o c0427o, int i8, Object obj, long j6, long j7) {
        f(c0093w, new B(i6, i7, c0427o, i8, obj, s.S(j6), s.S(j7)));
    }

    /* JADX WARN: Type inference failed for: r4v0, types: [J0.J, java.lang.Object] */
    public void f(C0093w c0093w, B b6) {
        for (I i6 : this.f382c) {
            s.L(i6.f1679a, new G(this, i6.f1680b, c0093w, b6, 1));
        }
    }

    public void g(C0093w c0093w, int i6, int i7, C0427o c0427o, int i8, Object obj, long j6, long j7, IOException iOException, boolean z6) {
        i(c0093w, new B(i6, i7, c0427o, i8, obj, s.S(j6), s.S(j7)), iOException, z6);
    }

    public void h(C0093w c0093w, int i6, IOException iOException, boolean z6) {
        g(c0093w, i6, -1, null, 0, null, -9223372036854775807L, -9223372036854775807L, iOException, z6);
    }

    public void i(C0093w c0093w, B b6, IOException iOException, boolean z6) {
        for (I i6 : this.f382c) {
            s.L(i6.f1679a, new H(this, i6.f1680b, c0093w, b6, iOException, z6, 0));
        }
    }

    public void j(C0093w c0093w, int i6, int i7, C0427o c0427o, int i8, Object obj, long j6, long j7) {
        k(c0093w, new B(i6, i7, c0427o, i8, obj, s.S(j6), s.S(j7)));
    }

    /* JADX WARN: Type inference failed for: r4v0, types: [J0.J, java.lang.Object] */
    public void k(C0093w c0093w, B b6) {
        for (I i6 : this.f382c) {
            s.L(i6.f1679a, new G(this, i6.f1680b, c0093w, b6, 0));
        }
    }

    /* JADX WARN: Type inference failed for: r3v0, types: [J0.J, java.lang.Object] */
    public void l(B b6) {
        E e6 = this.f381b;
        e6.getClass();
        for (I i6 : this.f382c) {
            s.L(i6.f1679a, new C4.h(this, (J) i6.f1680b, e6, b6));
        }
    }
}
