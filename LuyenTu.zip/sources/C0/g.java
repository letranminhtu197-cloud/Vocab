package C0;

import android.os.Looper;
import p101q0.C0427o;

/* JADX INFO: loaded from: classes.dex */
public final class g implements i {
    @Override // C0.i
    public final int c(C0427o c0427o) {
        return c0427o.f8399q != null ? 1 : 0;
    }

    @Override // C0.i
    public final M4.i d(e eVar, C0427o c0427o) {
        if (c0427o.f8399q == null) {
            return null;
        }
        return new M4.i(new c(new k(), 6001), 1);
    }

    @Override // C0.i
    public final void a(Looper looper, y0.k kVar) {
    }
}
