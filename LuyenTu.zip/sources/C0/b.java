package C0;

/* JADX INFO: loaded from: classes.dex */
public abstract class b implements i {
}
