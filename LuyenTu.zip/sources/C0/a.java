package C0;

/* JADX INFO: loaded from: classes.dex */
public abstract class a extends Exception {
}
