package android.support.v4.media;

import android.os.Parcel;
import android.os.Parcelable;
import p002a3.l;

/* JADX INFO: loaded from: classes.dex */
public final class RatingCompat implements Parcelable {
    public static final Parcelable.Creator<RatingCompat> CREATOR = new l(13);
    public final int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final float f4060s;

    public RatingCompat(float f4, int i6) {
        this.r = i6;
        this.f4060s = f4;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return this.r;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Rating:style=");
        sb.append(this.r);
        sb.append(" rating=");
        float f4 = this.f4060s;
        sb.append(f4 < 0.0f ? "unrated" : String.valueOf(f4));
        return sb.toString();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i6) {
        parcel.writeInt(this.r);
        parcel.writeFloat(this.f4060s);
    }
}
