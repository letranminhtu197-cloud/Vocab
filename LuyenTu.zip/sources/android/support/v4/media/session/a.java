package android.support.v4.media.session;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.ResultReceiver;
import android.support.v4.media.MediaDescriptionCompat;

/* JADX INFO: loaded from: classes.dex */
public final class a implements Parcelable.Creator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f4076a;

    public /* synthetic */ a(int i6) {
        this.f4076a = i6;
    }

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(final Parcel parcel) {
        switch (this.f4076a) {
            case 0:
                MediaSessionCompat$ResultReceiverWrapper mediaSessionCompat$ResultReceiverWrapper = new MediaSessionCompat$ResultReceiverWrapper();
                mediaSessionCompat$ResultReceiverWrapper.r = (ResultReceiver) ResultReceiver.CREATOR.createFromParcel(parcel);
                return mediaSessionCompat$ResultReceiverWrapper;
            case 1:
                return new Parcelable(parcel) { // from class: android.support.v4.media.session.MediaSessionCompat$QueueItem
                    public static final Parcelable.Creator<MediaSessionCompat$QueueItem> CREATOR = new a(1);
                    public final MediaDescriptionCompat r;

                    /* JADX INFO: renamed from: s, reason: collision with root package name */
                    public final long f4061s;

                    {
                        this.r = MediaDescriptionCompat.CREATOR.createFromParcel(parcel);
                        this.f4061s = parcel.readLong();
                    }

                    @Override // android.os.Parcelable
                    public final int describeContents() {
                        return 0;
                    }

                    public final String toString() {
                        StringBuilder sb = new StringBuilder("MediaSession.QueueItem {Description=");
                        sb.append(this.r);
                        sb.append(", Id=");
                        return A3.a.n(sb, this.f4061s, " }");
                    }

                    @Override // android.os.Parcelable
                    public final void writeToParcel(Parcel parcel2, int i6) {
                        this.r.writeToParcel(parcel2, i6);
                        parcel2.writeLong(this.f4061s);
                    }
                };
            case 2:
                return new MediaSessionCompat$Token(parcel.readParcelable(null));
            case 3:
                ParcelableVolumeInfo parcelableVolumeInfo = new ParcelableVolumeInfo();
                parcelableVolumeInfo.r = parcel.readInt();
                parcelableVolumeInfo.t = parcel.readInt();
                parcelableVolumeInfo.f4064u = parcel.readInt();
                parcelableVolumeInfo.f4065v = parcel.readInt();
                parcelableVolumeInfo.f4063s = parcel.readInt();
                return parcelableVolumeInfo;
            default:
                return new PlaybackStateCompat(parcel);
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i6) {
        switch (this.f4076a) {
            case 0:
                return new MediaSessionCompat$ResultReceiverWrapper[i6];
            case 1:
                return new MediaSessionCompat$QueueItem[i6];
            case 2:
                return new MediaSessionCompat$Token[i6];
            case 3:
                return new ParcelableVolumeInfo[i6];
            default:
                return new PlaybackStateCompat[i6];
        }
    }
}
