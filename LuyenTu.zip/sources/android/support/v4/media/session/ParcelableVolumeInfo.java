package android.support.v4.media.session;

import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
public class ParcelableVolumeInfo implements Parcelable {
    public static final Parcelable.Creator<ParcelableVolumeInfo> CREATOR = new a(3);
    public int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f4063s;
    public int t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f4064u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f4065v;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i6) {
        parcel.writeInt(this.r);
        parcel.writeInt(this.t);
        parcel.writeInt(this.f4064u);
        parcel.writeInt(this.f4065v);
        parcel.writeInt(this.f4063s);
    }
}
