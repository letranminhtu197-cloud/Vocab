package android.support.v4.media.session;

import A0.i;
import A5.h;
import B0.m;
import B4.n;
import K5.AbstractC0120y;
import K5.C0112p;
import K5.p0;
import L3.g;
import R0.I;
import R0.l;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.icu.text.DecimalFormatSymbols;
import android.net.Uri;
import android.os.BadParcelableException;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.text.SpannableString;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.PasswordTransformationMethod;
import android.text.style.LeadingMarginSpan;
import android.text.style.StyleSpan;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.widget.RemoteViews;
import android.widget.TextView;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.play_billing.AbstractC0252u0;
import com.google.android.gms.internal.play_billing.O;
import com.google.crypto.tink.shaded.protobuf.A;
import com.google.crypto.tink.shaded.protobuf.AbstractC0270h;
import com.google.crypto.tink.shaded.protobuf.AbstractC0285x;
import com.google.crypto.tink.shaded.protobuf.C;
import com.google.crypto.tink.shaded.protobuf.InterfaceC0287z;
import com.google.crypto.tink.shaded.protobuf.T;
import com.google.crypto.tink.shaded.protobuf.d0;
import com.google.crypto.tink.shaded.protobuf.g0;
import com.google.crypto.tink.shaded.protobuf.s0;
import com.google.firebase.messaging.FirebaseMessaging;
import com.luyentu.mobile.R;
import com.luyentu.mobile.WordWidgetProvider;
import io.flutter.plugins.GeneratedPluginRegistrant;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import org.apache.tika.fork.ForkServer;
import org.apache.tika.metadata.TikaCoreProperties;
import org.apache.tika.utils.StringUtils;
import p018d2.G;
import p018d2.j;
import p018d2.k;
import p018d2.y;
import p025e2.p;
import p060j4.d;
import p060j4.e;
import p068l.C0407u;
import p081m5.r;
import p091o3.q;
import p108r3.Y;
import p135w2.o;
import t2.f;

/* JADX INFO: loaded from: classes.dex */
public abstract class b {
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0049, code lost:
    
        if (r8 > 0) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x004c, code lost:
    
        if (r8 < 0) goto L23;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static long A(long r8, long r10, java.math.RoundingMode r12) {
        /*
            r12.getClass()
            long r0 = r8 / r10
            long r2 = r10 * r0
            long r2 = r8 - r2
            r4 = 0
            int r6 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r6 != 0) goto L10
            goto L53
        L10:
            long r8 = r8 ^ r10
            r7 = 63
            long r8 = r8 >> r7
            int r8 = (int) r8
            r8 = r8 | 1
            int[] r9 = t3.e.f9030a
            int r7 = r12.ordinal()
            r9 = r9[r7]
            switch(r9) {
                case 1: goto L51;
                case 2: goto L53;
                case 3: goto L4c;
                case 4: goto L4e;
                case 5: goto L49;
                case 6: goto L28;
                case 7: goto L28;
                case 8: goto L28;
                default: goto L22;
            }
        L22:
            java.lang.AssertionError r8 = new java.lang.AssertionError
            r8.<init>()
            throw r8
        L28:
            long r2 = java.lang.Math.abs(r2)
            long r9 = java.lang.Math.abs(r10)
            long r9 = r9 - r2
            long r2 = r2 - r9
            int r9 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r9 != 0) goto L46
            java.math.RoundingMode r9 = java.math.RoundingMode.HALF_UP
            if (r12 == r9) goto L4e
            java.math.RoundingMode r9 = java.math.RoundingMode.HALF_EVEN
            if (r12 != r9) goto L53
            r9 = 1
            long r9 = r9 & r0
            int r9 = (r9 > r4 ? 1 : (r9 == r4 ? 0 : -1))
            if (r9 == 0) goto L53
            goto L4e
        L46:
            if (r9 <= 0) goto L53
            goto L4e
        L49:
            if (r8 <= 0) goto L53
            goto L4e
        L4c:
            if (r8 >= 0) goto L53
        L4e:
            long r8 = (long) r8
            long r0 = r0 + r8
            return r0
        L51:
            if (r6 != 0) goto L54
        L53:
            return r0
        L54:
            java.lang.ArithmeticException r8 = new java.lang.ArithmeticException
            java.lang.String r9 = "mode was UNNECESSARY, but rounding was necessary"
            r8.<init>(r9)
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v4.media.session.b.A(long, long, java.math.RoundingMode):long");
    }

    public static boolean B(Object obj, Object obj2) {
        if (obj != obj2) {
            return obj != null && obj.equals(obj2);
        }
        return true;
    }

    public static q C(Exception exc) {
        q qVar = new q();
        qVar.n(exc);
        return qVar;
    }

    public static q D(Object obj) {
        q qVar = new q();
        qVar.o(obj);
        return qVar;
    }

    public static int E(byte[] bArr) {
        boolean z6 = bArr.length >= 4;
        int length = bArr.length;
        if (!z6) {
            throw new IllegalArgumentException(G.F("array too small: %s < %s", Integer.valueOf(length), 4));
        }
        byte b6 = bArr[0];
        byte b7 = bArr[1];
        byte b8 = bArr[2];
        return (bArr[3] & ForkServer.ERROR) | (b6 << 24) | ((b7 & ForkServer.ERROR) << 16) | ((b8 & ForkServer.ERROR) << 8);
    }

    /* JADX WARN: Code duplicated, block: B:14:0x0034  */
    public static j F(byte[] bArr) {
        boolean z6;
        h.e(bArr, "bytes");
        if (bArr.length > 10240) {
            throw new IllegalStateException("Data cannot occupy more than 10240 bytes when serialized");
        }
        if (bArr.length == 0) {
            return j.f5273b;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        try {
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bArr);
            byte[] bArr2 = new byte[2];
            byteArrayInputStream.read(bArr2);
            byte b6 = (byte) (-21267);
            int i6 = 0;
            if (bArr2[0] == ((byte) 16777132)) {
                z6 = true;
                if (bArr2[1] != b6) {
                    z6 = false;
                }
            } else {
                z6 = false;
            }
            byteArrayInputStream.reset();
            if (z6) {
                ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);
                try {
                    int i7 = objectInputStream.readInt();
                    while (i6 < i7) {
                        linkedHashMap.put(objectInputStream.readUTF(), objectInputStream.readObject());
                        i6++;
                    }
                    objectInputStream.close();
                } catch (Throwable th) {
                    try {
                        throw th;
                    } catch (Throwable th2) {
                        p000a.a.e(objectInputStream, th);
                        throw th2;
                    }
                }
            } else {
                DataInputStream dataInputStream = new DataInputStream(byteArrayInputStream);
                try {
                    short s6 = dataInputStream.readShort();
                    if (s6 != -21521) {
                        throw new IllegalStateException(T.g("Magic number doesn't match: ", s6).toString());
                    }
                    short s7 = dataInputStream.readShort();
                    if (s7 != 1) {
                        throw new IllegalStateException(T.g("Unsupported version number: ", s7).toString());
                    }
                    int i8 = dataInputStream.readInt();
                    while (i6 < i8) {
                        linkedHashMap.put(dataInputStream.readUTF(), G(dataInputStream, dataInputStream.readByte()));
                        i6++;
                    }
                    dataInputStream.close();
                } catch (Throwable th3) {
                    try {
                        throw th3;
                    } catch (Throwable th4) {
                        p000a.a.e(dataInputStream, th3);
                        throw th4;
                    }
                }
            }
        } catch (IOException e6) {
            y.e().d(k.f5275a, "Error in Data#fromByteArray: ", e6);
        } catch (ClassNotFoundException e7) {
            y.e().d(k.f5275a, "Error in Data#fromByteArray: ", e7);
        }
        return new j(linkedHashMap);
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [java.io.Serializable, java.lang.Double[]] */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.io.Serializable, java.lang.Float[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.io.Serializable, java.lang.Long[]] */
    /* JADX WARN: Type inference failed for: r0v5, types: [java.io.Serializable, java.lang.Integer[]] */
    /* JADX WARN: Type inference failed for: r0v6, types: [java.io.Serializable, java.lang.Byte[]] */
    /* JADX WARN: Type inference failed for: r0v7, types: [java.io.Serializable, java.lang.Boolean[]] */
    /* JADX WARN: Type inference failed for: r1v14, types: [java.io.Serializable, java.lang.String[]] */
    public static final Serializable G(DataInputStream dataInputStream, byte b6) throws IOException {
        if (b6 == 0) {
            return null;
        }
        if (b6 == 1) {
            return Boolean.valueOf(dataInputStream.readBoolean());
        }
        if (b6 == 2) {
            return Byte.valueOf(dataInputStream.readByte());
        }
        if (b6 == 3) {
            return Integer.valueOf(dataInputStream.readInt());
        }
        if (b6 == 4) {
            return Long.valueOf(dataInputStream.readLong());
        }
        if (b6 == 5) {
            return Float.valueOf(dataInputStream.readFloat());
        }
        if (b6 == 6) {
            return Double.valueOf(dataInputStream.readDouble());
        }
        if (b6 == 7) {
            return dataInputStream.readUTF();
        }
        int i6 = 0;
        if (b6 == 8) {
            int i7 = dataInputStream.readInt();
            ?? r6 = new Boolean[i7];
            while (i6 < i7) {
                r6[i6] = Boolean.valueOf(dataInputStream.readBoolean());
                i6++;
            }
            return r6;
        }
        if (b6 == 9) {
            int i8 = dataInputStream.readInt();
            ?? r7 = new Byte[i8];
            while (i6 < i8) {
                r7[i6] = Byte.valueOf(dataInputStream.readByte());
                i6++;
            }
            return r7;
        }
        if (b6 == 10) {
            int i9 = dataInputStream.readInt();
            ?? r8 = new Integer[i9];
            while (i6 < i9) {
                r8[i6] = Integer.valueOf(dataInputStream.readInt());
                i6++;
            }
            return r8;
        }
        if (b6 == 11) {
            int i10 = dataInputStream.readInt();
            ?? r9 = new Long[i10];
            while (i6 < i10) {
                r9[i6] = Long.valueOf(dataInputStream.readLong());
                i6++;
            }
            return r9;
        }
        if (b6 == 12) {
            int i11 = dataInputStream.readInt();
            ?? r10 = new Float[i11];
            while (i6 < i11) {
                r10[i6] = Float.valueOf(dataInputStream.readFloat());
                i6++;
            }
            return r10;
        }
        if (b6 == 13) {
            int i12 = dataInputStream.readInt();
            ?? r11 = new Double[i12];
            while (i6 < i12) {
                r11[i6] = Double.valueOf(dataInputStream.readDouble());
                i6++;
            }
            return r11;
        }
        if (b6 != 14) {
            throw new IllegalStateException(T.g("Unsupported type ", b6));
        }
        int i13 = dataInputStream.readInt();
        ?? r12 = new String[i13];
        while (i6 < i13) {
            String utf = dataInputStream.readUTF();
            if (h.a(utf, "androidx.work.Data-95ed6082-b8e9-46e8-a73f-ff56f00f5d9d")) {
                utf = null;
            }
            r12[i6] = utf;
            i6++;
        }
        return r12;
    }

    public static long H(long j6, long j7) {
        AbstractC0252u0.g("a", j6);
        AbstractC0252u0.g("b", j7);
        if (j6 == 0) {
            return j7;
        }
        if (j7 == 0) {
            return j6;
        }
        int iNumberOfTrailingZeros = Long.numberOfTrailingZeros(j6);
        long jNumberOfTrailingZeros = j6 >> iNumberOfTrailingZeros;
        int iNumberOfTrailingZeros2 = Long.numberOfTrailingZeros(j7);
        long j8 = j7 >> iNumberOfTrailingZeros2;
        while (jNumberOfTrailingZeros != j8) {
            long j9 = jNumberOfTrailingZeros - j8;
            long j10 = (j9 >> 63) & j9;
            long j11 = (j9 - j10) - j10;
            j8 += j10;
            jNumberOfTrailingZeros = j11 >> Long.numberOfTrailingZeros(j11);
        }
        return jNumberOfTrailingZeros << Math.min(iNumberOfTrailingZeros, iNumberOfTrailingZeros2);
    }

    public static F.c J(C0407u c0407u) {
        int i6 = Build.VERSION.SDK_INT;
        if (i6 >= 28) {
            return new F.c(B.b.p(c0407u));
        }
        TextPaint textPaint = new TextPaint(c0407u.getPaint());
        TextDirectionHeuristic textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_LTR;
        int breakStrategy = c0407u.getBreakStrategy();
        int hyphenationFrequency = c0407u.getHyphenationFrequency();
        if (c0407u.getTransformationMethod() instanceof PasswordTransformationMethod) {
            textDirectionHeuristic = TextDirectionHeuristics.LTR;
        } else if (i6 < 28 || (c0407u.getInputType() & 15) != 3) {
            boolean z6 = c0407u.getLayoutDirection() == 1;
            switch (c0407u.getTextDirection()) {
                case 2:
                    textDirectionHeuristic = TextDirectionHeuristics.ANYRTL_LTR;
                    break;
                case 3:
                    textDirectionHeuristic = TextDirectionHeuristics.LTR;
                    break;
                case 4:
                    textDirectionHeuristic = TextDirectionHeuristics.RTL;
                    break;
                case 5:
                    textDirectionHeuristic = TextDirectionHeuristics.LOCALE;
                    break;
                case 6:
                    break;
                case 7:
                    textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_RTL;
                    break;
                default:
                    if (z6) {
                        textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_RTL;
                    }
                    break;
            }
        } else {
            byte directionality = Character.getDirectionality(B.b.e(DecimalFormatSymbols.getInstance(c0407u.getTextLocale()))[0].codePointAt(0));
            textDirectionHeuristic = (directionality == 1 || directionality == 2) ? TextDirectionHeuristics.RTL : TextDirectionHeuristics.LTR;
        }
        return new F.c(textPaint, textDirectionHeuristic, breakStrategy, hyphenationFrequency);
    }

    public static final int K(L1.a aVar) throws Exception {
        h.e(aVar, "connection");
        L1.c cVarI = aVar.I("SELECT changes()");
        try {
            cVarI.E();
            int i6 = (int) cVarI.getLong(0);
            G.h(cVarI, null);
            return i6;
        } catch (Throwable th) {
            try {
                throw th;
            } catch (Throwable th2) {
                G.h(cVarI, th);
                throw th2;
            }
        }
    }

    public static N1.b L(i iVar, SQLiteDatabase sQLiteDatabase) {
        h.e(iVar, "refHolder");
        N1.b bVar = (N1.b) iVar.f64s;
        if (bVar != null && bVar.r.equals(sQLiteDatabase)) {
            return bVar;
        }
        N1.b bVar2 = new N1.b(sQLiteDatabase);
        iVar.f64s = bVar2;
        return bVar2;
    }

    public static int M(int i6, int i7, int i8, int[] iArr) {
        while (i7 < i8) {
            if (iArr[i7] == i6) {
                return i7;
            }
            i7++;
        }
        return -1;
    }

    /* JADX WARN: Code duplicated, block: B:102:0x017c  */
    /* JADX WARN: Code duplicated, block: B:108:0x0195  */
    /* JADX WARN: Code duplicated, block: B:110:0x019e  */
    /* JADX WARN: Code duplicated, block: B:111:0x01a1  */
    /* JADX WARN: Code duplicated, block: B:120:0x01b8  */
    /* JADX WARN: Code duplicated, block: B:121:0x01ba  */
    /* JADX WARN: Code duplicated, block: B:135:0x0171 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:141:0x0088 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:143:0x0155 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:145:0x01aa A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:147:0x018b A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:42:0x00b4  */
    /* JADX WARN: Code duplicated, block: B:44:0x00b8  */
    /* JADX WARN: Code duplicated, block: B:47:0x00c5  */
    /* JADX WARN: Code duplicated, block: B:49:0x00d3  */
    /* JADX WARN: Code duplicated, block: B:50:0x00d5  */
    /* JADX WARN: Code duplicated, block: B:51:0x00db A[PHI: r6
  0x00db: PHI (r6v22 java.lang.String) = (r6v21 java.lang.String), (r6v34 java.lang.String) binds: [B:46:0x00c3, B:50:0x00d5] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:53:0x00e3  */
    /* JADX WARN: Code duplicated, block: B:54:0x00e5  */
    /* JADX WARN: Code duplicated, block: B:57:0x00ee  */
    /* JADX WARN: Code duplicated, block: B:59:0x00f1  */
    /* JADX WARN: Code duplicated, block: B:61:0x00f4 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:62:0x00f6  */
    /* JADX WARN: Code duplicated, block: B:65:0x0101  */
    /* JADX WARN: Code duplicated, block: B:68:0x010b  */
    /* JADX WARN: Code duplicated, block: B:69:0x010d  */
    /* JADX WARN: Code duplicated, block: B:76:0x0121  */
    /* JADX WARN: Code duplicated, block: B:77:0x0124  */
    /* JADX WARN: Code duplicated, block: B:80:0x012e  */
    /* JADX WARN: Code duplicated, block: B:81:0x0130  */
    /* JADX WARN: Code duplicated, block: B:84:0x0139  */
    /* JADX WARN: Code duplicated, block: B:85:0x013c  */
    /* JADX WARN: Code duplicated, block: B:88:0x0146  */
    /* JADX WARN: Code duplicated, block: B:89:0x0149  */
    /* JADX WARN: Code duplicated, block: B:96:0x0164  */
    public static void N(Intent intent) {
        int iIntValue;
        int i6;
        String string;
        p060j4.b bVar;
        String string2;
        byte b6;
        String string3;
        String str;
        String string4;
        String str2;
        String string5;
        String str3;
        String string6;
        String str4;
        String string7;
        String str5;
        long j6;
        long j7;
        g gVarE;
        L3.i iVar;
        String str6;
        String str7;
        String[] strArrSplit;
        String str8;
        if (d0(intent)) {
            O("_nr", intent.getExtras());
        }
        int i7 = 0;
        if ((intent == null || "com.google.firebase.messaging.RECEIVE_DIRECT_BOOT".equals(intent.getAction())) ? false : z()) {
            f fVar = (f) FirebaseMessaging.f5063m.get();
            if (fVar == null) {
                Log.e("FirebaseMessaging", "TransportFactory is null. Skip exporting message delivery metrics to Big Query");
                return;
            }
            d dVar = null;
            str = null;
            String str9 = null;
            if (intent != null) {
                Bundle extras = intent.getExtras();
                if (extras == null) {
                    extras = Bundle.EMPTY;
                }
                Object obj = extras.get("google.ttl");
                if (obj instanceof Integer) {
                    iIntValue = ((Integer) obj).intValue();
                } else {
                    if (obj instanceof String) {
                        try {
                            iIntValue = Integer.parseInt((String) obj);
                        } catch (NumberFormatException unused) {
                            Log.w("FirebaseMessaging", "Invalid TTL: " + obj);
                            i6 = 0;
                        }
                    }
                    i6 = 0;
                    string = extras.getString("google.to");
                    if (TextUtils.isEmpty(string)) {
                        try {
                            g gVarE2 = g.e();
                            try {
                                Object obj2 = p014c4.c.f4616m;
                                string = (String) c(((p014c4.c) gVarE2.c(p014c4.d.class)).c());
                            } catch (InterruptedException e6) {
                                e = e6;
                                throw new RuntimeException(e);
                            }
                        } catch (InterruptedException | ExecutionException e7) {
                            e = e7;
                        }
                    }
                    String str10 = string;
                    g gVarE3 = g.e();
                    gVarE3.a();
                    String packageName = gVarE3.f2200a.getPackageName();
                    if (K2.i.E(extras)) {
                        bVar = p060j4.b.t;
                    } else {
                        bVar = p060j4.b.f7112s;
                    }
                    p060j4.b bVar2 = bVar;
                    string2 = extras.getString("google.delivered_priority");
                    if (string2 != null) {
                        if ("high".equals(string2)) {
                            b6 = 1;
                        } else if ("normal".equals(string2)) {
                            b6 = 2;
                        } else {
                            b6 = 0;
                        }
                    } else if ("1".equals(extras.getString("google.priority_reduced"))) {
                        b6 = 2;
                    } else {
                        string2 = extras.getString("google.priority");
                        if ("high".equals(string2)) {
                            b6 = 1;
                        } else if ("normal".equals(string2)) {
                            b6 = 2;
                        } else {
                            b6 = 0;
                        }
                    }
                    if (b6 == 2) {
                        i7 = 5;
                    } else if (b6 == 1) {
                        i7 = 10;
                    }
                    int i8 = i7;
                    string3 = extras.getString("google.message_id");
                    if (string3 == null) {
                        string3 = extras.getString("message_id");
                    }
                    if (string3 != null) {
                        str = string3;
                    } else {
                        str = StringUtils.EMPTY;
                    }
                    string4 = extras.getString("from");
                    if (string4 != null && string4.startsWith("/topics/")) {
                        str9 = string4;
                    }
                    if (str9 != null) {
                        str2 = str9;
                    } else {
                        str2 = StringUtils.EMPTY;
                    }
                    string5 = extras.getString("collapse_key");
                    if (string5 != null) {
                        str3 = string5;
                    } else {
                        str3 = StringUtils.EMPTY;
                    }
                    string6 = extras.getString("google.c.a.m_l");
                    if (string6 != null) {
                        str4 = string6;
                    } else {
                        str4 = StringUtils.EMPTY;
                    }
                    string7 = extras.getString("google.c.a.c_l");
                    if (string7 != null) {
                        str5 = string7;
                    } else {
                        str5 = StringUtils.EMPTY;
                    }
                    if (extras.containsKey("google.c.sender.id")) {
                        try {
                            j6 = Long.parseLong(extras.getString("google.c.sender.id"));
                        } catch (NumberFormatException e8) {
                            Log.w("FirebaseMessaging", "error parsing project number", e8);
                            gVarE = g.e();
                            iVar = gVarE.f2202c;
                            gVarE.a();
                            str6 = iVar.f2214e;
                            if (str6 != null) {
                                try {
                                    j6 = Long.parseLong(str6);
                                } catch (NumberFormatException e9) {
                                    Log.w("FirebaseMessaging", "error parsing sender ID", e9);
                                    gVarE.a();
                                    str7 = iVar.f2211b;
                                    if (str7.startsWith("1:")) {
                                        strArrSplit = str7.split(TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER);
                                        if (strArrSplit.length < 2) {
                                            j6 = 0;
                                        } else {
                                            str8 = strArrSplit[1];
                                            if (str8.isEmpty()) {
                                                j6 = 0;
                                            } else {
                                                try {
                                                    j6 = Long.parseLong(str8);
                                                } catch (NumberFormatException e10) {
                                                    Log.w("FirebaseMessaging", "error parsing app ID", e10);
                                                    j6 = 0;
                                                }
                                            }
                                        }
                                    } else {
                                        try {
                                            j6 = Long.parseLong(str7);
                                        } catch (NumberFormatException e11) {
                                            Log.w("FirebaseMessaging", "error parsing app ID", e11);
                                            j6 = 0;
                                        }
                                    }
                                }
                            } else {
                                gVarE.a();
                                str7 = iVar.f2211b;
                                if (str7.startsWith("1:")) {
                                    j6 = Long.parseLong(str7);
                                } else {
                                    strArrSplit = str7.split(TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER);
                                    if (strArrSplit.length < 2) {
                                        j6 = 0;
                                    } else {
                                        str8 = strArrSplit[1];
                                        if (str8.isEmpty()) {
                                            j6 = 0;
                                        } else {
                                            j6 = Long.parseLong(str8);
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        gVarE = g.e();
                        iVar = gVarE.f2202c;
                        gVarE.a();
                        str6 = iVar.f2214e;
                        if (str6 != null) {
                            j6 = Long.parseLong(str6);
                        } else {
                            gVarE.a();
                            str7 = iVar.f2211b;
                            if (str7.startsWith("1:")) {
                                j6 = Long.parseLong(str7);
                            } else {
                                strArrSplit = str7.split(TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER);
                                if (strArrSplit.length < 2) {
                                    j6 = 0;
                                } else {
                                    str8 = strArrSplit[1];
                                    if (str8.isEmpty()) {
                                        j6 = 0;
                                    } else {
                                        j6 = Long.parseLong(str8);
                                    }
                                }
                            }
                        }
                    }
                    if (j6 > 0) {
                        j7 = j6;
                    } else {
                        j7 = 0;
                    }
                    dVar = new d(j7, str, str10, bVar2, packageName, str3, i8, i6, str2, str4, str5);
                }
                i6 = iIntValue;
                string = extras.getString("google.to");
                if (TextUtils.isEmpty(string)) {
                    g gVarE4 = g.e();
                    Object obj3 = p014c4.c.f4616m;
                    string = (String) c(((p014c4.c) gVarE4.c(p014c4.d.class)).c());
                }
                String str11 = string;
                g gVarE5 = g.e();
                gVarE5.a();
                String packageName2 = gVarE5.f2200a.getPackageName();
                if (K2.i.E(extras)) {
                    bVar = p060j4.b.t;
                } else {
                    bVar = p060j4.b.f7112s;
                }
                p060j4.b bVar3 = bVar;
                string2 = extras.getString("google.delivered_priority");
                if (string2 != null) {
                    if ("high".equals(string2)) {
                        b6 = 1;
                    } else if ("normal".equals(string2)) {
                        b6 = 2;
                    } else {
                        b6 = 0;
                    }
                } else if ("1".equals(extras.getString("google.priority_reduced"))) {
                    b6 = 2;
                } else {
                    string2 = extras.getString("google.priority");
                    if ("high".equals(string2)) {
                        b6 = 1;
                    } else if ("normal".equals(string2)) {
                        b6 = 2;
                    } else {
                        b6 = 0;
                    }
                }
                if (b6 == 2) {
                    i7 = 5;
                } else if (b6 == 1) {
                    i7 = 10;
                }
                int i9 = i7;
                string3 = extras.getString("google.message_id");
                if (string3 == null) {
                    string3 = extras.getString("message_id");
                }
                if (string3 != null) {
                    str = string3;
                } else {
                    str = StringUtils.EMPTY;
                }
                string4 = extras.getString("from");
                if (string4 != null) {
                    str9 = string4;
                }
                if (str9 != null) {
                    str2 = str9;
                } else {
                    str2 = StringUtils.EMPTY;
                }
                string5 = extras.getString("collapse_key");
                if (string5 != null) {
                    str3 = string5;
                } else {
                    str3 = StringUtils.EMPTY;
                }
                string6 = extras.getString("google.c.a.m_l");
                if (string6 != null) {
                    str4 = string6;
                } else {
                    str4 = StringUtils.EMPTY;
                }
                string7 = extras.getString("google.c.a.c_l");
                if (string7 != null) {
                    str5 = string7;
                } else {
                    str5 = StringUtils.EMPTY;
                }
                if (extras.containsKey("google.c.sender.id")) {
                    j6 = Long.parseLong(extras.getString("google.c.sender.id"));
                } else {
                    gVarE = g.e();
                    iVar = gVarE.f2202c;
                    gVarE.a();
                    str6 = iVar.f2214e;
                    if (str6 != null) {
                        j6 = Long.parseLong(str6);
                    } else {
                        gVarE.a();
                        str7 = iVar.f2211b;
                        if (str7.startsWith("1:")) {
                            j6 = Long.parseLong(str7);
                        } else {
                            strArrSplit = str7.split(TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER);
                            if (strArrSplit.length < 2) {
                                j6 = 0;
                            } else {
                                str8 = strArrSplit[1];
                                if (str8.isEmpty()) {
                                    j6 = 0;
                                } else {
                                    j6 = Long.parseLong(str8);
                                }
                            }
                        }
                    }
                }
                if (j6 > 0) {
                    j7 = j6;
                } else {
                    j7 = 0;
                }
                dVar = new d(j7, str, str11, bVar3, packageName2, str3, i9, i6, str2, str4, str5);
            }
            if (dVar == null) {
                return;
            }
            try {
                ((o) fVar).a("FCM_CLIENT_EVENT_LOGGING", new t2.c("proto"), new l(22)).j(new t2.a(new e(dVar), new t2.b(Integer.valueOf(intent.getIntExtra("google.product_id", 111881503)))));
            } catch (RuntimeException e12) {
                Log.w("FirebaseMessaging", "Failed to send big query analytics payload.", e12);
            }
        }
    }

    public static void O(String str, Bundle bundle) {
        try {
            g.e();
            if (bundle == null) {
                bundle = new Bundle();
            }
            Bundle bundle2 = new Bundle();
            String string = bundle.getString("google.c.a.c_id");
            if (string != null) {
                bundle2.putString("_nmid", string);
            }
            String string2 = bundle.getString("google.c.a.c_l");
            if (string2 != null) {
                bundle2.putString("_nmn", string2);
            }
            String string3 = bundle.getString("google.c.a.m_l");
            if (!TextUtils.isEmpty(string3)) {
                bundle2.putString("label", string3);
            }
            String string4 = bundle.getString("google.c.a.m_c");
            if (!TextUtils.isEmpty(string4)) {
                bundle2.putString("message_channel", string4);
            }
            String string5 = bundle.getString("from");
            if (string5 == null || !string5.startsWith("/topics/")) {
                string5 = null;
            }
            if (string5 != null) {
                bundle2.putString("_nt", string5);
            }
            String string6 = bundle.getString("google.c.a.ts");
            if (string6 != null) {
                try {
                    bundle2.putInt("_nmt", Integer.parseInt(string6));
                } catch (NumberFormatException e6) {
                    Log.w("FirebaseMessaging", "Error while parsing timestamp in GCM event", e6);
                }
            }
            String string7 = bundle.containsKey("google.c.a.udt") ? bundle.getString("google.c.a.udt") : null;
            if (string7 != null) {
                try {
                    bundle2.putInt("_ndt", Integer.parseInt(string7));
                } catch (NumberFormatException e7) {
                    Log.w("FirebaseMessaging", "Error while parsing use_device_time in GCM event", e7);
                }
            }
            String str2 = K2.i.E(bundle) ? "display" : "data";
            if ("_nr".equals(str) || "_nf".equals(str)) {
                bundle2.putString("_nmc", str2);
            }
            if (Log.isLoggable("FirebaseMessaging", 3)) {
                Log.d("FirebaseMessaging", "Logging to scion event=" + str + " scionPayload=" + bundle2);
            }
            if (g.e().c(O3.a.class) != null) {
                throw new ClassCastException();
            }
            Log.w("FirebaseMessaging", "Unable to log event: analytics library is missing");
        } catch (IllegalStateException unused) {
            Log.e("FirebaseMessaging", "Default FirebaseApp has not been initialized. Skip logging event to GA.");
        }
    }

    public static int P(Object obj, d0 d0Var, byte[] bArr, int i6, int i7, F0.g gVar) throws C {
        int iU = i6 + 1;
        int i8 = bArr[i6];
        if (i8 < 0) {
            iU = u(i8, bArr, iU, gVar);
            i8 = gVar.f1203a;
        }
        int i9 = iU;
        if (i8 < 0 || i8 > i7 - i9) {
            throw C.g();
        }
        int i10 = i9 + i8;
        d0Var.e(obj, bArr, i9, i10, gVar);
        gVar.f1205c = obj;
        return i10;
    }

    public static final void Q(Context context) {
        Map mapZ;
        h.e(context, "context");
        File databasePath = context.getDatabasePath("androidx.work.workdb");
        h.d(databasePath, "getDatabasePath(...)");
        if (databasePath.exists()) {
            y.e().a(p.f5469a, "Migrating WorkDatabase to the no-backup directory");
            File databasePath2 = context.getDatabasePath("androidx.work.workdb");
            h.d(databasePath2, "getDatabasePath(...)");
            File noBackupFilesDir = context.getNoBackupFilesDir();
            h.d(noBackupFilesDir, "getNoBackupFilesDir(...)");
            String[] strArr = p.f5470b;
            int iY = r.Y(strArr.length);
            if (iY < 16) {
                iY = 16;
            }
            LinkedHashMap linkedHashMap = new LinkedHashMap(iY);
            for (String str : strArr) {
                linkedHashMap.put(new File(databasePath2.getPath() + str), new File(noBackupFilesDir.getPath() + str));
            }
            p074l5.g gVar = new p074l5.g(databasePath2, noBackupFilesDir);
            if (linkedHashMap.isEmpty()) {
                mapZ = r.Z(gVar);
            } else {
                LinkedHashMap linkedHashMap2 = new LinkedHashMap(linkedHashMap);
                linkedHashMap2.put(databasePath2, noBackupFilesDir);
                mapZ = linkedHashMap2;
            }
            for (Map.Entry entry : mapZ.entrySet()) {
                File file = (File) entry.getKey();
                File file2 = (File) entry.getValue();
                if (file.exists()) {
                    if (file2.exists()) {
                        y.e().h(p.f5469a, "Over-writing contents of " + file2);
                    }
                    y.e().a(p.f5469a, file.renameTo(file2) ? "Migrated " + file + "to " + file2 : "Renaming " + file + " to " + file2 + " failed");
                }
            }
        }
    }

    public static PendingIntent R(Context context) {
        Intent launchIntentForPackage = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        if (launchIntentForPackage == null) {
            launchIntentForPackage = new Intent();
        }
        PendingIntent activity = PendingIntent.getActivity(context, 1, launchIntentForPackage, 201326592);
        h.d(activity, "getActivity(...)");
        return activity;
    }

    public static int T(I i6, int i7, int i8, int i9) {
        p117t0.a.d(Math.max(Math.max(i7, i8), i9) <= 31);
        int i10 = (1 << i7) - 1;
        int i11 = (1 << i8) - 1;
        p000a.a.d(p000a.a.d(i10, i11), 1 << i9);
        if (i6.b() < i7) {
            return -1;
        }
        int i12 = i6.i(i7);
        if (i12 == i10) {
            if (i6.b() < i8) {
                return -1;
            }
            int i13 = i6.i(i8);
            i12 += i13;
            if (i13 == i11) {
                if (i6.b() < i9) {
                    return -1;
                }
                return i6.i(i9) + i12;
            }
        }
        return i12;
    }

    public static void U(Context context) {
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
        int[] appWidgetIds = appWidgetManager.getAppWidgetIds(new ComponentName(context, (Class<?>) WordWidgetProvider.class));
        h.b(appWidgetIds);
        if (appWidgetIds.length == 0) {
            return;
        }
        for (int i6 : appWidgetIds) {
            appWidgetManager.updateAppWidget(i6, W(context, appWidgetManager, i6));
        }
    }

    public static void V(M4.b bVar) {
        try {
            GeneratedPluginRegistrant.class.getDeclaredMethod("registerWith", M4.b.class).invoke(null, bVar);
        } catch (Exception e6) {
            Log.e("GeneratedPluginsRegister", "Tried to automatically register plugins with FlutterEngine (" + bVar + ") but could not find or invoke the GeneratedPluginRegistrant.");
            Log.e("GeneratedPluginsRegister", "Received exception while registering", e6);
        }
    }

    /* JADX WARN: Type inference failed for: r8v0, types: [java.lang.Iterable, java.lang.Object, java.util.Collection, java.util.List] */
    public static RemoteViews W(Context context, AppWidgetManager appWidgetManager, int i6) {
        String str;
        String str2;
        String str3;
        boolean z6;
        float f4;
        int i7;
        float f7;
        Drawable drawableMutate;
        Drawable drawableMutate2;
        Bundle appWidgetOptions = appWidgetManager.getAppWidgetOptions(i6);
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        int i8 = appWidgetOptions != null ? appWidgetOptions.getInt("appWidgetMinWidth") : 0;
        int i9 = (int) (((((i8 > 0 ? i8 : (displayMetrics.widthPixels / displayMetrics.density) - 32.0f) - 20.0f) - 60.0f) - 6.0f) * displayMetrics.density);
        RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.word_widget);
        B4.l lVarV = p000a.a.v(context);
        B4.k kVarW = p000a.a.w(context);
        boolean z7 = kVarW.f364e;
        boolean z8 = kVarW.f361b;
        ?? r8 = lVarV.f365a;
        if (r8.isEmpty()) {
            remoteViews.setViewVisibility(R.id.word_content, 8);
            remoteViews.setViewVisibility(R.id.word_empty, 0);
            remoteViews.setViewVisibility(R.id.word_done, 8);
            remoteViews.setOnClickPendingIntent(R.id.word_root, R(context));
            return remoteViews;
        }
        String strE = p000a.a.E(lVarV);
        h.e(strE, "payloadStamp");
        Set set = h.a(kVarW.f363d, strE) ? kVarW.f362c : p081m5.o.r;
        if (!r8.isEmpty()) {
            Iterator it = r8.iterator();
            while (it.hasNext()) {
                if (!set.contains(((n) it.next()).f369a)) {
                    remoteViews.setViewVisibility(R.id.word_content, 0);
                    remoteViews.setViewVisibility(R.id.word_empty, 8);
                    remoteViews.setViewVisibility(R.id.word_done, 8);
                    n nVar = (n) r8.get(AbstractC0252u0.j(kVarW.f360a, r8.size() - 1));
                    String str4 = nVar.f377i;
                    String str5 = nVar.f372d;
                    String str6 = nVar.f370b;
                    String str7 = nVar.f375g;
                    String str8 = nVar.f369a;
                    String str9 = nVar.f374f;
                    remoteViews.setTextViewText(R.id.level_badge, str4.length() == 0 ? "BỘ TỪ CỦA TÔI" : "LỘ TRÌNH");
                    remoteViews.setInt(R.id.level_badge, "setBackgroundResource", R.drawable.widget_chip_on_card);
                    remoteViews.setTextColor(R.id.level_badge, -1);
                    int i10 = lVarV.f366b;
                    if (i10 > 0) {
                        str = i10 + " từ chưa thuộc";
                    } else {
                        str = StringUtils.EMPTY;
                    }
                    remoteViews.setTextViewText(R.id.due_count, str);
                    Intent action = new Intent(context, (Class<?>) WordWidgetProvider.class).setAction("com.luyentu.mobile.widget.ANSWER");
                    h.d(action, "setAction(...)");
                    action.putExtra("wordId", str8);
                    action.putExtra("learned", false);
                    action.putExtra("path", str4);
                    PendingIntent broadcast = PendingIntent.getBroadcast(context, 100, action, 201326592);
                    String str10 = "getBroadcast(...)";
                    h.d(broadcast, "getBroadcast(...)");
                    remoteViews.setOnClickPendingIntent(R.id.answer_forgot, broadcast);
                    Intent action2 = new Intent(context, (Class<?>) WordWidgetProvider.class).setAction("com.luyentu.mobile.widget.ANSWER");
                    h.d(action2, "setAction(...)");
                    action2.putExtra("wordId", str8);
                    action2.putExtra("learned", true);
                    action2.putExtra("path", str4);
                    PendingIntent broadcast2 = PendingIntent.getBroadcast(context, 101, action2, 201326592);
                    h.d(broadcast2, "getBroadcast(...)");
                    remoteViews.setOnClickPendingIntent(R.id.answer_learned, broadcast2);
                    Intent action3 = new Intent(context, (Class<?>) WordWidgetProvider.class).setAction("com.luyentu.mobile.widget.MOVE");
                    h.d(action3, "setAction(...)");
                    action3.putExtra("delta", -1);
                    PendingIntent broadcast3 = PendingIntent.getBroadcast(context, 4, action3, 201326592);
                    h.d(broadcast3, "getBroadcast(...)");
                    remoteViews.setOnClickPendingIntent(R.id.step_back, broadcast3);
                    Intent action4 = new Intent(context, (Class<?>) WordWidgetProvider.class).setAction("com.luyentu.mobile.widget.MOVE");
                    h.d(action4, "setAction(...)");
                    action4.putExtra("delta", 1);
                    PendingIntent broadcast4 = PendingIntent.getBroadcast(context, 5, action4, 201326592);
                    h.d(broadcast4, "getBroadcast(...)");
                    remoteViews.setOnClickPendingIntent(R.id.step_forward, broadcast4);
                    remoteViews.setInt(R.id.word_root, "setBackgroundResource", z8 ? R.drawable.widget_back_gradient : R.drawable.widget_front_gradient);
                    if (z8) {
                        remoteViews.setViewVisibility(R.id.card_front, 8);
                        remoteViews.setViewVisibility(R.id.card_back, 0);
                        remoteViews.setTextViewText(R.id.meaning, nVar.f371c);
                        boolean z9 = str9.length() > 0;
                        remoteViews.setViewVisibility(R.id.example_row, z9 ? 0 : 8);
                        boolean z10 = str7.length() > 0;
                        if (z9) {
                            DisplayMetrics displayMetrics2 = context.getResources().getDisplayMetrics();
                            float f8 = displayMetrics2.density;
                            float fApplyDimension = TypedValue.applyDimension(2, 14.0f, displayMetrics2);
                            TextPaint textPaint = new TextPaint(1);
                            textPaint.setTextSize(fApplyDimension);
                            textPaint.setColor(-1);
                            textPaint.setTypeface(Typeface.DEFAULT);
                            SpannableString spannableString = new SpannableString("Ví dụ: ".concat(str9));
                            z6 = z10;
                            spannableString.setSpan(new StyleSpan(1), 0, 7, 33);
                            spannableString.setSpan(new LeadingMarginSpan.Standard(AbstractC0252u0.z(23.0f * f8), 0), 0, spannableString.length(), 33);
                            float f9 = 24.0f * f8;
                            float f10 = 4.0f * f8;
                            int iMax = Math.max(i9, AbstractC0252u0.z(120.0f * f8));
                            StaticLayout staticLayoutD = X2.a.d(spannableString, textPaint, iMax);
                            if (z6) {
                                f4 = f9;
                                float f11 = iMax;
                                if (staticLayoutD.getLineRight(staticLayoutD.getLineCount() - 1) + f10 + f4 > f11) {
                                    staticLayoutD = X2.a.d(spannableString, textPaint, AbstractC0252u0.z((f11 - f4) - f10));
                                }
                            } else {
                                f4 = f9;
                            }
                            float f12 = 3.0f * f8;
                            float f13 = 2;
                            int iZ = AbstractC0252u0.z((f12 * f13) + staticLayoutD.getHeight());
                            if (iZ < 1) {
                                iZ = 1;
                            }
                            Bitmap bitmapCreateBitmap = Bitmap.createBitmap(iMax, iZ, Bitmap.Config.ARGB_8888);
                            h.d(bitmapCreateBitmap, "createBitmap(...)");
                            bitmapCreateBitmap.setDensity(displayMetrics2.densityDpi);
                            Canvas canvas = new Canvas(bitmapCreateBitmap);
                            canvas.translate(0.0f, f12);
                            staticLayoutD.draw(canvas);
                            Drawable drawable = context.getDrawable(R.drawable.ic_widget_speaker);
                            if (drawable == null || (drawableMutate2 = drawable.mutate()) == null) {
                                i7 = -1;
                                f7 = 0.36f;
                            } else {
                                float f14 = 17.0f * f8;
                                f7 = 0.36f;
                                float lineBaseline = (staticLayoutD.getLineBaseline(0) - (fApplyDimension * 0.36f)) - (f14 / f13);
                                drawableMutate2.setBounds(0, AbstractC0252u0.z(lineBaseline), AbstractC0252u0.z(f14), AbstractC0252u0.z(lineBaseline + f14));
                                i7 = -1;
                                drawableMutate2.setTint(-1);
                                drawableMutate2.draw(canvas);
                            }
                            if (z6) {
                                int lineCount = staticLayoutD.getLineCount() - 1;
                                float lineRight = staticLayoutD.getLineRight(lineCount) + f10;
                                float lineBaseline2 = staticLayoutD.getLineBaseline(lineCount) - (fApplyDimension * f7);
                                Paint paint = new Paint(1);
                                paint.setColor(z7 ? i7 : 956301311);
                                float f15 = f4 / f13;
                                canvas.drawCircle(lineRight + f15, lineBaseline2, f15, paint);
                                Drawable drawable2 = context.getDrawable(R.drawable.ic_widget_translate);
                                if (drawable2 != null && (drawableMutate = drawable2.mutate()) != null) {
                                    float f16 = 14.0f * f8;
                                    float f17 = ((f4 - f16) / f13) + lineRight;
                                    float f18 = lineBaseline2 - (f16 / f13);
                                    drawableMutate.setBounds(AbstractC0252u0.z(f17), AbstractC0252u0.z(f18), AbstractC0252u0.z(f17 + f16), AbstractC0252u0.z(f18 + f16));
                                    drawableMutate.setTint(z7 ? -14933714 : -1);
                                    drawableMutate.draw(canvas);
                                }
                            }
                            remoteViews.setImageViewBitmap(R.id.example_image, bitmapCreateBitmap);
                            remoteViews.setContentDescription(R.id.example_image, "Ví dụ: ".concat(str9));
                        } else {
                            z6 = z10;
                            str10 = "getBroadcast(...)";
                        }
                        Intent action5 = new Intent(context, (Class<?>) WordWidgetProvider.class).setAction("com.luyentu.mobile.widget.SPEAK");
                        h.d(action5, "setAction(...)");
                        action5.putExtra("term", str9);
                        PendingIntent broadcast5 = PendingIntent.getBroadcast(context, 10, action5, 201326592);
                        str2 = str10;
                        h.d(broadcast5, str2);
                        remoteViews.setOnClickPendingIntent(R.id.example_speaker, broadcast5);
                        if (z6) {
                            broadcast5 = e(9, context, "com.luyentu.mobile.widget.TOGGLE_TRANSLATION");
                        }
                        remoteViews.setOnClickPendingIntent(R.id.example_image, broadcast5);
                        remoteViews.setViewVisibility(R.id.example_translation, (z6 && z7) ? 0 : 8);
                        remoteViews.setTextViewText(R.id.example_translation, str7);
                        str3 = str6;
                    } else {
                        str2 = "getBroadcast(...)";
                        remoteViews.setViewVisibility(R.id.card_front, 0);
                        remoteViews.setViewVisibility(R.id.card_back, 8);
                        remoteViews.setViewVisibility(R.id.example_row, 8);
                        remoteViews.setViewVisibility(R.id.example_translation, 8);
                        str3 = str6;
                        remoteViews.setTextViewText(R.id.term, str3);
                        remoteViews.setTextViewText(R.id.pronunciation, str5);
                        remoteViews.setViewVisibility(R.id.pronunciation, str5.length() == 0 ? 8 : 0);
                    }
                    TextToSpeech textToSpeech = B4.i.f356a;
                    Context applicationContext = context.getApplicationContext();
                    h.d(applicationContext, "getApplicationContext(...)");
                    new Handler(Looper.getMainLooper()).post(new B1.h(applicationContext, 3));
                    remoteViews.setOnClickPendingIntent(R.id.word_root, e(2, context, "com.luyentu.mobile.widget.FLIP"));
                    Intent action6 = new Intent(context, (Class<?>) WordWidgetProvider.class).setAction("com.luyentu.mobile.widget.SPEAK");
                    h.d(action6, "setAction(...)");
                    action6.putExtra("term", str3);
                    PendingIntent broadcast6 = PendingIntent.getBroadcast(context, 3, action6, 201326592);
                    h.d(broadcast6, str2);
                    remoteViews.setOnClickPendingIntent(R.id.speaker_button, broadcast6);
                    return remoteViews;
                }
            }
        }
        remoteViews.setViewVisibility(R.id.word_content, 8);
        remoteViews.setViewVisibility(R.id.word_empty, 8);
        remoteViews.setViewVisibility(R.id.word_done, 0);
        remoteViews.setTextViewText(R.id.done_title, "Đã ôn hết " + r8.size() + " từ!");
        remoteViews.setOnClickPendingIntent(R.id.done_open, R(context));
        remoteViews.setOnClickPendingIntent(R.id.done_reset, e(8, context, "com.luyentu.mobile.widget.RESET"));
        return remoteViews;
    }

    public static int X(long j6) {
        if (j6 > 2147483647L) {
            return Integer.MAX_VALUE;
        }
        if (j6 < -2147483648L) {
            return Integer.MIN_VALUE;
        }
        return (int) j6;
    }

    public static long Y(long j6, long j7) {
        int iNumberOfLeadingZeros = Long.numberOfLeadingZeros(~j7) + Long.numberOfLeadingZeros(j7) + Long.numberOfLeadingZeros(~j6) + Long.numberOfLeadingZeros(j6);
        if (iNumberOfLeadingZeros > 65) {
            return j6 * j7;
        }
        long j8 = ((j6 ^ j7) >>> 63) + Long.MAX_VALUE;
        if (!((iNumberOfLeadingZeros < 64) | ((j7 == Long.MIN_VALUE) & (j6 < 0)))) {
            long j9 = j6 * j7;
            if (j6 == 0 || j9 / j6 == j7) {
                return j9;
            }
        }
        return j8;
    }

    public static void Z(Window window, boolean z6) {
        int i6 = Build.VERSION.SDK_INT;
        if (i6 >= 35) {
            B.c.e(window, z6);
        } else {
            if (i6 >= 30) {
                B.c.d(window, z6);
                return;
            }
            View decorView = window.getDecorView();
            int systemUiVisibility = decorView.getSystemUiVisibility();
            decorView.setSystemUiVisibility(z6 ? systemUiVisibility & (-1793) : systemUiVisibility | 1792);
        }
    }

    public static void a(StringBuilder sb, Object obj, p154z5.c cVar) {
        if (cVar != null) {
            sb.append((CharSequence) cVar.a(obj));
            return;
        }
        if (obj == null ? true : obj instanceof CharSequence) {
            sb.append((CharSequence) obj);
        } else if (obj instanceof Character) {
            sb.append(((Character) obj).charValue());
        } else {
            sb.append((CharSequence) obj.toString());
        }
    }

    public static void a0(TextView textView, int i6) {
        if (i6 < 0) {
            throw new IllegalArgumentException();
        }
        if (Build.VERSION.SDK_INT >= 28) {
            B.b.s(textView, i6);
            return;
        }
        Paint.FontMetricsInt fontMetricsInt = textView.getPaint().getFontMetricsInt();
        int i7 = textView.getIncludeFontPadding() ? fontMetricsInt.top : fontMetricsInt.ascent;
        if (i6 > Math.abs(i7)) {
            textView.setPadding(textView.getPaddingLeft(), i6 + i7, textView.getPaddingRight(), textView.getPaddingBottom());
        }
    }

    public static List b(int... iArr) {
        return iArr.length == 0 ? Collections.EMPTY_LIST : new p125u3.b(0, iArr.length, iArr);
    }

    public static void b0(TextView textView, int i6) {
        if (i6 < 0) {
            throw new IllegalArgumentException();
        }
        Paint.FontMetricsInt fontMetricsInt = textView.getPaint().getFontMetricsInt();
        int i7 = textView.getIncludeFontPadding() ? fontMetricsInt.bottom : fontMetricsInt.descent;
        if (i6 > Math.abs(i7)) {
            textView.setPadding(textView.getPaddingLeft(), textView.getPaddingTop(), textView.getPaddingRight(), i6 - i7);
        }
    }

    public static Object c(p091o3.i iVar) throws InterruptedException {
        if (Looper.getMainLooper() == Looper.myLooper()) {
            throw new IllegalStateException("Must not be called on the main application thread");
        }
        Looper looperMyLooper = Looper.myLooper();
        if (looperMyLooper != null && Objects.equals(looperMyLooper.getThread().getName(), "GoogleApiHandler")) {
            throw new IllegalStateException("Must not be called on GoogleApiHandler thread.");
        }
        Q2.q.g(iVar, "Task must not be null");
        if (iVar.g()) {
            return m0(iVar);
        }
        p080m4.c cVar = new p080m4.c(1);
        Executor executor = p091o3.k.f8051b;
        iVar.c(executor, cVar);
        iVar.b(executor, cVar);
        iVar.a(executor, cVar);
        cVar.f7840s.await();
        return m0(iVar);
    }

    public static void c0(Status status, Object obj, p091o3.j jVar) {
        if (status.e()) {
            jVar.b(obj);
        } else {
            jVar.a(Q2.q.j(status));
        }
    }

    public static Object d(p091o3.i iVar, long j6) throws TimeoutException {
        TimeUnit timeUnit = TimeUnit.SECONDS;
        if (Looper.getMainLooper() == Looper.myLooper()) {
            throw new IllegalStateException("Must not be called on the main application thread");
        }
        Looper looperMyLooper = Looper.myLooper();
        if (looperMyLooper != null && Objects.equals(looperMyLooper.getThread().getName(), "GoogleApiHandler")) {
            throw new IllegalStateException("Must not be called on GoogleApiHandler thread.");
        }
        Q2.q.g(iVar, "Task must not be null");
        Q2.q.g(timeUnit, "TimeUnit must not be null");
        if (iVar.g()) {
            return m0(iVar);
        }
        p080m4.c cVar = new p080m4.c(1);
        Executor executor = p091o3.k.f8051b;
        iVar.c(executor, cVar);
        iVar.b(executor, cVar);
        iVar.a(executor, cVar);
        if (cVar.f7840s.await(j6, timeUnit)) {
            return m0(iVar);
        }
        throw new TimeoutException("Timed out waiting for Task");
    }

    public static boolean d0(Intent intent) {
        Bundle extras;
        if (intent == null || "com.google.firebase.messaging.RECEIVE_DIRECT_BOOT".equals(intent.getAction()) || (extras = intent.getExtras()) == null) {
            return false;
        }
        return "1".equals(extras.getString("google.c.a.e"));
    }

    public static PendingIntent e(int i6, Context context, String str) {
        Intent action = new Intent(context, (Class<?>) WordWidgetProvider.class).setAction(str);
        h.d(action, "setAction(...)");
        PendingIntent broadcast = PendingIntent.getBroadcast(context, i6, action, 201326592);
        h.d(broadcast, "getBroadcast(...)");
        return broadcast;
    }

    public static void e0(I i6) {
        i6.t(3);
        i6.t(8);
        boolean zH = i6.h();
        boolean zH2 = i6.h();
        if (zH) {
            i6.t(5);
        }
        if (zH2) {
            i6.t(6);
        }
    }

    public static p128v0.k f(m mVar, String str, B0.j jVar, int i6) {
        Map map = Collections.EMPTY_MAP;
        Uri uriV = p117t0.a.v(str, jVar.f242c);
        long j6 = jVar.f240a;
        long j7 = jVar.f241b;
        String strA = mVar.a();
        if (strA == null) {
            strA = p117t0.a.v(((B0.b) mVar.f247s.get(0)).f198a, jVar.f242c).toString();
        }
        String str2 = strA;
        p117t0.a.j(uriV, "The uri must be set.");
        return new p128v0.k(uriV, 1, null, Y.f8791x, j6, j7, str2, i6);
    }

    public static void f0(I i6) {
        int i7;
        int i8 = i6.i(2);
        if (i8 == 0) {
            i6.t(6);
            return;
        }
        int iT = T(i6, 5, 8, 16) + 1;
        if (i8 == 1) {
            i6.t(iT * 7);
            return;
        }
        if (i8 == 2) {
            boolean zH = i6.h();
            int i9 = zH ? 1 : 5;
            int i10 = zH ? 7 : 5;
            int i11 = zH ? 8 : 6;
            int i12 = 0;
            while (i12 < iT) {
                if (i6.h()) {
                    i6.t(7);
                    i7 = 0;
                } else {
                    if (i6.i(2) == 3 && i6.i(i10) * i9 != 0) {
                        i6.s();
                    }
                    i7 = i6.i(i11) * i9;
                    if (i7 != 0 && i7 != 180) {
                        i6.s();
                    }
                    i6.s();
                }
                if (i7 != 0 && i7 != 180 && i6.h()) {
                    i12++;
                }
                i12++;
            }
        }
    }

    public static q g(Executor executor, Callable callable) {
        Q2.q.g(executor, "Executor must not be null");
        q qVar = new q();
        executor.execute(new E.a(qVar, callable, 20));
        return qVar;
    }

    public static final Object g0(P5.r rVar, boolean z6, P5.r rVar2, p154z5.e eVar) throws Throwable {
        Object c0112p;
        Object objO;
        try {
            if (eVar instanceof p116s5.a) {
                A5.q.a(2, eVar);
                c0112p = eVar.g(rVar2, rVar);
            } else {
                c0112p = h6.h.a0(eVar, rVar2, rVar);
            }
        } catch (K5.C e6) {
            Throwable th = e6.r;
            rVar.N(new C0112p(th, false));
            throw th;
        } catch (Throwable th2) {
            c0112p = new C0112p(th2, false);
        }
        p109r5.a aVar = p109r5.a.r;
        if (c0112p == aVar || (objO = rVar.O(c0112p)) == AbstractC0120y.f2146e) {
            return aVar;
        }
        rVar.d0();
        if (!(objO instanceof C0112p)) {
            return AbstractC0120y.v(objO);
        }
        if (!z6) {
            Throwable th3 = ((C0112p) objO).f2131a;
            if ((th3 instanceof p0) && ((p0) th3).r == rVar) {
                if (c0112p instanceof C0112p) {
                    throw ((C0112p) c0112p).f2131a;
                }
                return c0112p;
            }
        }
        throw ((C0112p) objO).f2131a;
    }

    public static void h(int i6, int i7, int i8) {
        if (i6 >= 0 && i7 <= i8) {
            if (i6 > i7) {
                throw new IllegalArgumentException(A3.a.k(i6, i7, "fromIndex: ", " > toIndex: "));
            }
            return;
        }
        throw new IndexOutOfBoundsException("fromIndex: " + i6 + ", toIndex: " + i7 + ", size: " + i8);
    }

    public static int[] h0(Collection collection) {
        if (collection instanceof p125u3.b) {
            p125u3.b bVar = (p125u3.b) collection;
            return Arrays.copyOfRange(bVar.r, bVar.f9205s, bVar.t);
        }
        Object[] array = collection.toArray();
        int length = array.length;
        int[] iArr = new int[length];
        for (int i6 = 0; i6 < length; i6++) {
            Object obj = array[i6];
            obj.getClass();
            iArr[i6] = ((Number) obj).intValue();
        }
        return iArr;
    }

    public static long i(long j6, long j7) {
        long j8 = j6 + j7;
        if (((j6 ^ j7) < 0) || ((j6 ^ j8) >= 0)) {
            return j8;
        }
        StringBuilder sb = new StringBuilder("overflow: checkedAdd(");
        sb.append(j6);
        sb.append(", ");
        throw new ArithmeticException(A3.a.n(sb, j7, ")"));
    }

    public static byte[] i0(j jVar) {
        h.e(jVar, "data");
        HashMap map = jVar.f5274a;
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);
            try {
                dataOutputStream.writeShort(-21521);
                dataOutputStream.writeShort(1);
                dataOutputStream.writeInt(map.size());
                for (Map.Entry entry : map.entrySet()) {
                    j0(dataOutputStream, (String) entry.getKey(), entry.getValue());
                }
                dataOutputStream.flush();
                if (dataOutputStream.size() > 10240) {
                    throw new IllegalStateException("Data cannot occupy more than 10240 bytes when serialized");
                }
                byte[] byteArray = byteArrayOutputStream.toByteArray();
                dataOutputStream.close();
                h.b(byteArray);
                return byteArray;
            } catch (Throwable th) {
                try {
                    throw th;
                } catch (Throwable th2) {
                    p000a.a.e(dataOutputStream, th);
                    throw th2;
                }
            }
        } catch (IOException e6) {
            y.e().d(k.f5275a, "Error in Data#toByteArray: ", e6);
            return new byte[0];
        }
    }

    public static int j(long j6) {
        int i6 = (int) j6;
        AbstractC0252u0.e(((long) i6) == j6, "Out of range: %s", j6);
        return i6;
    }

    public static final void j0(DataOutputStream dataOutputStream, String str, Object obj) throws IOException {
        int i6;
        if (obj == null) {
            dataOutputStream.writeByte(0);
        } else if (obj instanceof Boolean) {
            dataOutputStream.writeByte(1);
            dataOutputStream.writeBoolean(((Boolean) obj).booleanValue());
        } else if (obj instanceof Byte) {
            dataOutputStream.writeByte(2);
            dataOutputStream.writeByte(((Number) obj).byteValue());
        } else if (obj instanceof Integer) {
            dataOutputStream.writeByte(3);
            dataOutputStream.writeInt(((Number) obj).intValue());
        } else if (obj instanceof Long) {
            dataOutputStream.writeByte(4);
            dataOutputStream.writeLong(((Number) obj).longValue());
        } else if (obj instanceof Float) {
            dataOutputStream.writeByte(5);
            dataOutputStream.writeFloat(((Number) obj).floatValue());
        } else if (obj instanceof Double) {
            dataOutputStream.writeByte(6);
            dataOutputStream.writeDouble(((Number) obj).doubleValue());
        } else if (obj instanceof String) {
            dataOutputStream.writeByte(7);
            dataOutputStream.writeUTF((String) obj);
        } else {
            if (!(obj instanceof Object[])) {
                throw new IllegalArgumentException("Unsupported value type " + A5.o.a(obj.getClass()).c());
            }
            Object[] objArr = (Object[]) obj;
            A5.e eVarA = A5.o.a(objArr.getClass());
            if (eVarA.equals(A5.o.a(Boolean[].class))) {
                i6 = 8;
            } else if (eVarA.equals(A5.o.a(Byte[].class))) {
                i6 = 9;
            } else if (eVarA.equals(A5.o.a(Integer[].class))) {
                i6 = 10;
            } else if (eVarA.equals(A5.o.a(Long[].class))) {
                i6 = 11;
            } else if (eVarA.equals(A5.o.a(Float[].class))) {
                i6 = 12;
            } else if (eVarA.equals(A5.o.a(Double[].class))) {
                i6 = 13;
            } else {
                if (!eVarA.equals(A5.o.a(String[].class))) {
                    throw new IllegalArgumentException("Unsupported value type " + A5.o.a(objArr.getClass()).b());
                }
                i6 = 14;
            }
            dataOutputStream.writeByte(i6);
            dataOutputStream.writeInt(objArr.length);
            for (Object obj2 : objArr) {
                if (i6 == 8) {
                    Boolean bool = obj2 instanceof Boolean ? (Boolean) obj2 : null;
                    dataOutputStream.writeBoolean(bool != null ? bool.booleanValue() : false);
                } else if (i6 == 9) {
                    Byte b6 = obj2 instanceof Byte ? (Byte) obj2 : null;
                    dataOutputStream.writeByte(b6 != null ? b6.byteValue() : (byte) 0);
                } else if (i6 == 10) {
                    Integer num = obj2 instanceof Integer ? (Integer) obj2 : null;
                    dataOutputStream.writeInt(num != null ? num.intValue() : 0);
                } else if (i6 == 11) {
                    Long l6 = obj2 instanceof Long ? (Long) obj2 : null;
                    dataOutputStream.writeLong(l6 != null ? l6.longValue() : 0L);
                } else if (i6 == 12) {
                    Float f4 = obj2 instanceof Float ? (Float) obj2 : null;
                    dataOutputStream.writeFloat(f4 != null ? f4.floatValue() : 0.0f);
                } else if (i6 == 13) {
                    Double d6 = obj2 instanceof Double ? (Double) obj2 : null;
                    dataOutputStream.writeDouble(d6 != null ? d6.doubleValue() : 0.0d);
                } else if (i6 == 14) {
                    String str2 = obj2 instanceof String ? (String) obj2 : null;
                    if (str2 == null) {
                        str2 = "androidx.work.Data-95ed6082-b8e9-46e8-a73f-ff56f00f5d9d";
                    }
                    dataOutputStream.writeUTF(str2);
                }
            }
        }
        dataOutputStream.writeUTF(str);
    }

    public static final void k(p154z5.c cVar, p040g5.d dVar) {
        cVar.a(new p074l5.i(X2.a.m(dVar)));
    }

    public static Bundle k0(Bundle bundle) {
        if (bundle == null) {
            return null;
        }
        bundle.setClassLoader(b.class.getClassLoader());
        try {
            bundle.isEmpty();
            return bundle;
        } catch (BadParcelableException unused) {
            Log.e("MediaSessionCompat", "Could not unparcel the data.");
            return null;
        }
    }

    public static q l0(p091o3.i... iVarArr) {
        q qVar;
        if (iVarArr.length == 0) {
            return D(Collections.EMPTY_LIST);
        }
        List<p091o3.i> listAsList = Arrays.asList(iVarArr);
        p084n2.a aVar = p091o3.k.f8050a;
        if (listAsList == null || listAsList.isEmpty()) {
            return D(Collections.EMPTY_LIST);
        }
        if (listAsList.isEmpty()) {
            qVar = D(null);
        } else {
            Iterator it = listAsList.iterator();
            while (it.hasNext()) {
                if (((p091o3.i) it.next()) == null) {
                    throw new NullPointerException("null tasks are not accepted");
                }
            }
            qVar = new q();
            p091o3.l lVar = new p091o3.l(listAsList.size(), qVar);
            for (p091o3.i iVar : listAsList) {
                p091o3.p pVar = p091o3.k.f8051b;
                iVar.c(pVar, lVar);
                iVar.b(pVar, lVar);
                iVar.a(pVar, lVar);
            }
        }
        return qVar.d(aVar, new i(listAsList, 28));
    }

    public static byte[] m(byte[] bArr) {
        if (bArr.length != 16) {
            throw new IllegalArgumentException("value must be a block.");
        }
        byte[] bArr2 = new byte[16];
        for (int i6 = 0; i6 < 16; i6++) {
            byte b6 = (byte) ((bArr[i6] << 1) & 254);
            bArr2[i6] = b6;
            if (i6 < 15) {
                bArr2[i6] = (byte) (((byte) ((bArr[i6 + 1] >> 7) & 1)) | b6);
            }
        }
        bArr2[15] = (byte) (((byte) ((bArr[0] >> 7) & 135)) ^ bArr2[15]);
        return bArr2;
    }

    public static Object m0(p091o3.i iVar) throws ExecutionException {
        if (iVar.h()) {
            return iVar.f();
        }
        if (((q) iVar).f8064d) {
            throw new CancellationException("Task is already canceled");
        }
        throw new ExecutionException(iVar.e());
    }

    public static int n(byte[] bArr, int i6, F0.g gVar) throws C {
        int iV = v(bArr, i6, gVar);
        int i7 = gVar.f1203a;
        if (i7 < 0) {
            throw C.e();
        }
        if (i7 > bArr.length - iV) {
            throw C.g();
        }
        if (i7 == 0) {
            gVar.f1205c = AbstractC0270h.f5009s;
            return iV;
        }
        gVar.f1205c = AbstractC0270h.g(bArr, iV, i7);
        return iV + i7;
    }

    public static /* synthetic */ boolean n0(AtomicReferenceFieldUpdater atomicReferenceFieldUpdater, O o, Object obj, Object obj2) {
        while (!atomicReferenceFieldUpdater.compareAndSet(o, obj, obj2)) {
            if (atomicReferenceFieldUpdater.get(o) != obj && atomicReferenceFieldUpdater.get(o) != obj) {
                return false;
            }
        }
        return true;
    }

    public static int o(byte[] bArr, int i6) {
        return ((bArr[i6 + 3] & ForkServer.ERROR) << 24) | (bArr[i6] & ForkServer.ERROR) | ((bArr[i6 + 1] & ForkServer.ERROR) << 8) | ((bArr[i6 + 2] & ForkServer.ERROR) << 16);
    }

    public static long p(byte[] bArr, int i6) {
        return ((((long) bArr[i6 + 7]) & 255) << 56) | (((long) bArr[i6]) & 255) | ((((long) bArr[i6 + 1]) & 255) << 8) | ((((long) bArr[i6 + 2]) & 255) << 16) | ((((long) bArr[i6 + 3]) & 255) << 24) | ((((long) bArr[i6 + 4]) & 255) << 32) | ((((long) bArr[i6 + 5]) & 255) << 40) | ((((long) bArr[i6 + 6]) & 255) << 48);
    }

    public static int q(d0 d0Var, int i6, byte[] bArr, int i7, int i8, InterfaceC0287z interfaceC0287z, F0.g gVar) throws C {
        Object objNewInstance = d0Var.newInstance();
        d0 d0Var2 = d0Var;
        byte[] bArr2 = bArr;
        int i9 = i8;
        F0.g gVar2 = gVar;
        int iP = P(objNewInstance, d0Var2, bArr2, i7, i9, gVar2);
        d0Var2.a(objNewInstance);
        gVar2.f1205c = objNewInstance;
        interfaceC0287z.add(objNewInstance);
        while (iP < i9) {
            F0.g gVar3 = gVar2;
            int i10 = i9;
            int iV = v(bArr2, iP, gVar3);
            if (i6 != gVar3.f1203a) {
                break;
            }
            byte[] bArr3 = bArr2;
            d0 d0Var3 = d0Var2;
            Object objNewInstance2 = d0Var3.newInstance();
            iP = P(objNewInstance2, d0Var3, bArr3, iV, i10, gVar3);
            d0Var2 = d0Var3;
            bArr2 = bArr3;
            i9 = i10;
            gVar2 = gVar3;
            d0Var2.a(objNewInstance2);
            gVar2.f1205c = objNewInstance2;
            interfaceC0287z.add(objNewInstance2);
        }
        return iP;
    }

    public static int r(byte[] bArr, int i6, F0.g gVar) throws C {
        int iV = v(bArr, i6, gVar);
        int i7 = gVar.f1203a;
        if (i7 < 0) {
            throw C.e();
        }
        if (i7 == 0) {
            gVar.f1205c = StringUtils.EMPTY;
            return iV;
        }
        gVar.f1205c = new String(bArr, iV, i7, A.f4943a);
        return iV + i7;
    }

    public static int s(byte[] bArr, int i6, F0.g gVar) throws C {
        int iV = v(bArr, i6, gVar);
        int i7 = gVar.f1203a;
        if (i7 < 0) {
            throw C.e();
        }
        if (i7 == 0) {
            gVar.f1205c = StringUtils.EMPTY;
            return iV;
        }
        gVar.f1205c = s0.f5051a.t(bArr, iV, i7);
        return iV + i7;
    }

    public static int t(int i6, byte[] bArr, int i7, int i8, g0 g0Var, F0.g gVar) throws C {
        if ((i6 >>> 3) == 0) {
            throw C.a();
        }
        int i9 = i6 & 7;
        if (i9 == 0) {
            int iX = x(bArr, i7, gVar);
            g0Var.d(i6, Long.valueOf(gVar.f1204b));
            return iX;
        }
        if (i9 == 1) {
            g0Var.d(i6, Long.valueOf(p(bArr, i7)));
            return i7 + 8;
        }
        if (i9 == 2) {
            int iV = v(bArr, i7, gVar);
            int i10 = gVar.f1203a;
            if (i10 < 0) {
                throw C.e();
            }
            if (i10 > bArr.length - iV) {
                throw C.g();
            }
            if (i10 == 0) {
                g0Var.d(i6, AbstractC0270h.f5009s);
            } else {
                g0Var.d(i6, AbstractC0270h.g(bArr, iV, i10));
            }
            return iV + i10;
        }
        if (i9 != 3) {
            if (i9 != 5) {
                throw C.a();
            }
            g0Var.d(i6, Integer.valueOf(o(bArr, i7)));
            return i7 + 4;
        }
        g0 g0VarC = g0.c();
        int i11 = (i6 & (-8)) | 4;
        int i12 = 0;
        while (i7 < i8) {
            int iV2 = v(bArr, i7, gVar);
            i12 = gVar.f1203a;
            if (i12 == i11) {
                i7 = iV2;
                break;
            }
            i7 = t(i12, bArr, iV2, i8, g0VarC, gVar);
        }
        if (i7 > i8 || i12 != i11) {
            throw C.f();
        }
        g0Var.d(i6, g0VarC);
        return i7;
    }

    public static int u(int i6, byte[] bArr, int i7, F0.g gVar) {
        int i8 = i6 & 127;
        int i9 = i7 + 1;
        byte b6 = bArr[i7];
        if (b6 >= 0) {
            gVar.f1203a = i8 | (b6 << 7);
            return i9;
        }
        int i10 = i8 | ((b6 & 127) << 7);
        int i11 = i7 + 2;
        byte b7 = bArr[i9];
        if (b7 >= 0) {
            gVar.f1203a = i10 | (b7 << 14);
            return i11;
        }
        int i12 = i10 | ((b7 & 127) << 14);
        int i13 = i7 + 3;
        byte b8 = bArr[i11];
        if (b8 >= 0) {
            gVar.f1203a = i12 | (b8 << 21);
            return i13;
        }
        int i14 = i12 | ((b8 & 127) << 21);
        int i15 = i7 + 4;
        byte b9 = bArr[i13];
        if (b9 >= 0) {
            gVar.f1203a = i14 | (b9 << 28);
            return i15;
        }
        int i16 = i14 | ((b9 & 127) << 28);
        while (true) {
            int i17 = i15 + 1;
            if (bArr[i15] >= 0) {
                gVar.f1203a = i16;
                return i17;
            }
            i15 = i17;
        }
    }

    public static int v(byte[] bArr, int i6, F0.g gVar) {
        int i7 = i6 + 1;
        byte b6 = bArr[i6];
        if (b6 < 0) {
            return u(b6, bArr, i7, gVar);
        }
        gVar.f1203a = b6;
        return i7;
    }

    public static int w(int i6, byte[] bArr, int i7, int i8, InterfaceC0287z interfaceC0287z, F0.g gVar) {
        AbstractC0285x abstractC0285x = (AbstractC0285x) interfaceC0287z;
        int iV = v(bArr, i7, gVar);
        abstractC0285x.c(gVar.f1203a);
        while (iV < i8) {
            int iV2 = v(bArr, iV, gVar);
            if (i6 != gVar.f1203a) {
                break;
            }
            iV = v(bArr, iV2, gVar);
            abstractC0285x.c(gVar.f1203a);
        }
        return iV;
    }

    public static int x(byte[] bArr, int i6, F0.g gVar) {
        int i7 = i6 + 1;
        long j6 = bArr[i6];
        if (j6 >= 0) {
            gVar.f1204b = j6;
            return i7;
        }
        int i8 = i6 + 2;
        byte b6 = bArr[i7];
        long j7 = (j6 & 127) | (((long) (b6 & 127)) << 7);
        int i9 = 7;
        while (b6 < 0) {
            int i10 = i8 + 1;
            byte b7 = bArr[i8];
            i9 += 7;
            j7 |= ((long) (b7 & 127)) << i9;
            b6 = b7;
            i8 = i10;
        }
        gVar.f1204b = j7;
        return i8;
    }

    public static boolean y(Object obj, Object obj2) {
        if ((obj instanceof byte[]) && (obj2 instanceof byte[])) {
            return Arrays.equals((byte[]) obj, (byte[]) obj2);
        }
        if ((obj instanceof int[]) && (obj2 instanceof int[])) {
            return Arrays.equals((int[]) obj, (int[]) obj2);
        }
        if ((obj instanceof long[]) && (obj2 instanceof long[])) {
            return Arrays.equals((long[]) obj, (long[]) obj2);
        }
        if ((obj instanceof double[]) && (obj2 instanceof double[])) {
            return Arrays.equals((double[]) obj, (double[]) obj2);
        }
        if ((obj instanceof Object[]) && (obj2 instanceof Object[])) {
            Object[] objArr = (Object[]) obj;
            Object[] objArr2 = (Object[]) obj2;
            if (objArr.length == objArr2.length) {
                Iterable cVar = new F5.c(0, objArr.length - 1, 1);
                if (!(cVar instanceof Collection) || !((Collection) cVar).isEmpty()) {
                    Iterator it = cVar.iterator();
                    while (((F5.b) it).t) {
                        int iNextInt = ((F5.b) it).nextInt();
                        if (!y(objArr[iNextInt], objArr2[iNextInt])) {
                        }
                    }
                }
                return true;
            }
            return false;
        }
        if ((obj instanceof List) && (obj2 instanceof List)) {
            List list = (List) obj;
            List list2 = (List) obj2;
            if (list.size() == list2.size()) {
                Iterable iterableW = G.w((Collection) obj);
                if (!(iterableW instanceof Collection) || !((Collection) iterableW).isEmpty()) {
                    Iterator it2 = iterableW.iterator();
                    while (((F5.b) it2).t) {
                        int iNextInt2 = ((F5.b) it2).nextInt();
                        if (!y(list.get(iNextInt2), list2.get(iNextInt2))) {
                        }
                    }
                }
                return true;
            }
            return false;
        }
        if (!(obj instanceof Map) || !(obj2 instanceof Map)) {
            return h.a(obj, obj2);
        }
        Map map = (Map) obj;
        Map map2 = (Map) obj2;
        if (map.size() == map2.size()) {
            if (!map.isEmpty()) {
                for (Map.Entry entry : map.entrySet()) {
                    if (!map2.containsKey(entry.getKey()) || !y(entry.getValue(), map2.get(entry.getKey()))) {
                    }
                }
            }
            return true;
        }
        return false;
    }

    public static boolean z() {
        ApplicationInfo applicationInfo;
        Bundle bundle;
        try {
            g.e();
            g gVarE = g.e();
            gVarE.a();
            Context context = gVarE.f2200a;
            SharedPreferences sharedPreferences = context.getSharedPreferences("com.google.firebase.messaging", 0);
            if (sharedPreferences.contains("export_to_big_query")) {
                return sharedPreferences.getBoolean("export_to_big_query", false);
            }
            try {
                PackageManager packageManager = context.getPackageManager();
                if (packageManager != null && (applicationInfo = packageManager.getApplicationInfo(context.getPackageName(), 128)) != null && (bundle = applicationInfo.metaData) != null && bundle.containsKey("delivery_metrics_exported_to_big_query_enabled")) {
                    return applicationInfo.metaData.getBoolean("delivery_metrics_exported_to_big_query_enabled", false);
                }
            } catch (PackageManager.NameNotFoundException unused) {
            }
            return false;
        } catch (IllegalStateException unused2) {
            Log.i("FirebaseMessaging", "FirebaseApp has not being initialized. Device might be in direct boot mode. Skip exporting delivery metrics to Big Query");
            return false;
        }
    }

    public p034g.a I(Context context, Object obj) {
        return null;
    }

    public abstract Object S(Intent intent, int i6);

    public abstract Intent l(Context context, Object obj);
}
