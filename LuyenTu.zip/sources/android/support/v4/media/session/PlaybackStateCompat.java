package android.support.v4.media.session;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class PlaybackStateCompat implements Parcelable {
    public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new a(4);

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final long f4066A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public final Bundle f4067B;
    public final int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final long f4068s;
    public final long t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final float f4069u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final long f4070v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f4071w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final CharSequence f4072x;
    public final long y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final ArrayList f4073z;

    public static final class CustomAction implements Parcelable {
        public static final Parcelable.Creator<CustomAction> CREATOR = new c();
        public final String r;

        /* JADX INFO: renamed from: s, reason: collision with root package name */
        public final CharSequence f4074s;
        public final int t;

        /* JADX INFO: renamed from: u, reason: collision with root package name */
        public final Bundle f4075u;

        public CustomAction(Parcel parcel) {
            this.r = parcel.readString();
            this.f4074s = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.t = parcel.readInt();
            this.f4075u = parcel.readBundle(b.class.getClassLoader());
        }

        @Override // android.os.Parcelable
        public final int describeContents() {
            return 0;
        }

        public final String toString() {
            return "Action:mName='" + ((Object) this.f4074s) + ", mIcon=" + this.t + ", mExtras=" + this.f4075u;
        }

        @Override // android.os.Parcelable
        public final void writeToParcel(Parcel parcel, int i6) {
            parcel.writeString(this.r);
            TextUtils.writeToParcel(this.f4074s, parcel, i6);
            parcel.writeInt(this.t);
            parcel.writeBundle(this.f4075u);
        }
    }

    public PlaybackStateCompat(Parcel parcel) {
        this.r = parcel.readInt();
        this.f4068s = parcel.readLong();
        this.f4069u = parcel.readFloat();
        this.y = parcel.readLong();
        this.t = parcel.readLong();
        this.f4070v = parcel.readLong();
        this.f4072x = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f4073z = parcel.createTypedArrayList(CustomAction.CREATOR);
        this.f4066A = parcel.readLong();
        this.f4067B = parcel.readBundle(b.class.getClassLoader());
        this.f4071w = parcel.readInt();
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("PlaybackState {state=");
        sb.append(this.r);
        sb.append(", position=");
        sb.append(this.f4068s);
        sb.append(", buffered position=");
        sb.append(this.t);
        sb.append(", speed=");
        sb.append(this.f4069u);
        sb.append(", updated=");
        sb.append(this.y);
        sb.append(", actions=");
        sb.append(this.f4070v);
        sb.append(", error code=");
        sb.append(this.f4071w);
        sb.append(", error message=");
        sb.append(this.f4072x);
        sb.append(", custom actions=");
        sb.append(this.f4073z);
        sb.append(", active item id=");
        return A3.a.n(sb, this.f4066A, "}");
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i6) {
        parcel.writeInt(this.r);
        parcel.writeLong(this.f4068s);
        parcel.writeFloat(this.f4069u);
        parcel.writeLong(this.y);
        parcel.writeLong(this.t);
        parcel.writeLong(this.f4070v);
        TextUtils.writeToParcel(this.f4072x, parcel, i6);
        parcel.writeTypedList(this.f4073z);
        parcel.writeLong(this.f4066A);
        parcel.writeBundle(this.f4067B);
        parcel.writeInt(this.f4071w);
    }
}
