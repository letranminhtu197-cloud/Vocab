package android.support.v4.media;

import android.os.Bundle;
import c.d;

/* JADX INFO: loaded from: classes.dex */
class MediaBrowserCompat$CustomActionResultReceiver extends d {
    @Override // c.d
    public final void b(int i6, Bundle bundle) {
    }
}
