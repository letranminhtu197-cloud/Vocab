package android.support.v4.media;

import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import p002a3.l;

/* JADX INFO: loaded from: classes.dex */
public final class MediaDescriptionCompat implements Parcelable {
    public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new l(11);
    public final String r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final CharSequence f4054s;
    public final CharSequence t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final CharSequence f4055u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final Bitmap f4056v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final Uri f4057w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final Bundle f4058x;
    public final Uri y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public MediaDescription f4059z;

    public MediaDescriptionCompat(String str, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, Bitmap bitmap, Uri uri, Bundle bundle, Uri uri2) {
        this.r = str;
        this.f4054s = charSequence;
        this.t = charSequence2;
        this.f4055u = charSequence3;
        this.f4056v = bitmap;
        this.f4057w = uri;
        this.f4058x = bundle;
        this.y = uri2;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        return ((Object) this.f4054s) + ", " + ((Object) this.t) + ", " + ((Object) this.f4055u);
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i6) {
        MediaDescription mediaDescriptionA = this.f4059z;
        if (mediaDescriptionA == null) {
            MediaDescription.Builder builderB = a.b();
            a.n(builderB, this.r);
            a.p(builderB, this.f4054s);
            a.o(builderB, this.t);
            a.j(builderB, this.f4055u);
            a.l(builderB, this.f4056v);
            a.m(builderB, this.f4057w);
            a.k(builderB, this.f4058x);
            b.b(builderB, this.y);
            mediaDescriptionA = a.a(builderB);
            this.f4059z = mediaDescriptionA;
        }
        mediaDescriptionA.writeToParcel(parcel, i6);
    }
}
