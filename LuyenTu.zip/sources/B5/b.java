package B5;

/* JADX INFO: loaded from: classes.dex */
public interface b extends a {
}
