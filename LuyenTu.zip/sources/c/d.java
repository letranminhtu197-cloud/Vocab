package c;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import p008b3.p;

/* JADX INFO: loaded from: classes.dex */
public class d implements Parcelable {
    public static final Parcelable.Creator<d> CREATOR = new p(3);
    public b r;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i6) {
        synchronized (this) {
            try {
                if (this.r == null) {
                    this.r = new c(this);
                }
                parcel.writeStrongBinder(this.r.asBinder());
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public void b(int i6, Bundle bundle) {
    }
}
