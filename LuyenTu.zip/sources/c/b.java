package c;

import android.os.IInterface;

/* JADX INFO: loaded from: classes.dex */
public interface b extends IInterface {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final String f4589d = "android$support$v4$os$IResultReceiver".replace('$', '.');
}
