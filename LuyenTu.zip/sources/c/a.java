package c;

import android.os.IBinder;

/* JADX INFO: loaded from: classes.dex */
public final class a implements b {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public IBinder f4588e;

    @Override // android.os.IInterface
    public final IBinder asBinder() {
        return this.f4588e;
    }
}
