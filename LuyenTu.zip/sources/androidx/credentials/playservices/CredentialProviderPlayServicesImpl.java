package androidx.credentials.playservices;

import A5.h;
import A5.n;
import C1.B;
import K2.i;
import L.e;
import L.m;
import L.o;
import M.a;
import N2.d;
import Q.b;
import Q.f;
import Q.g;
import android.content.Context;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ResultReceiver;
import android.util.Log;
import androidx.credentials.playservices.CredentialProviderPlayServicesImpl;
import com.google.android.gms.identitycredentials.GetCredentialRequest;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;
import org.apache.tika.utils.StringUtils;
import p008b3.c;
import p074l5.l;
import p091o3.k;
import p091o3.q;

/* JADX INFO: loaded from: classes.dex */
public final class CredentialProviderPlayServicesImpl implements e {
    public static final g Companion = new g();
    public static final int MIN_GMS_APK_VERSION = 230815045;
    public static final int MIN_GMS_APK_VERSION_DIGITAL_CRED = 243100000;
    public static final int MIN_GMS_APK_VERSION_RESTORE_CRED = 242200000;
    public static final int MIN_GMS_APK_VERSION_SIGNAL_API = 254625000;
    public static final int PRE_U_MIN_GMS_APK_VERSION = 252400000;
    private static final String TAG = "PlayServicesImpl";
    private final Context context;
    private d googleApiAvailability;

    public CredentialProviderPlayServicesImpl(Context context) {
        h.e(context, "context");
        this.context = context;
        this.googleApiAvailability = d.f2653c;
    }

    public static /* synthetic */ void getGoogleApiAvailability$annotations() {
    }

    private final int isGooglePlayServicesAvailable(Context context, int i6) {
        return this.googleApiAvailability.b(context, i6);
    }

    private static final l onClearCredential$lambda$0(Executor executor, L.d dVar) {
        executor.execute(new b(dVar, 0));
        return l.f7746a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onClearCredential$lambda$0$0(L.d dVar) {
        dVar.i(new a());
    }

    private static final l onClearCredential$lambda$1(CancellationSignal cancellationSignal, Executor executor, L.d dVar, Boolean bool) {
        Companion.getClass();
        if (!g.a(cancellationSignal)) {
            onClearCredential$lambda$1$0(executor, dVar);
        }
        return l.f7746a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final l onClearCredential$lambda$1$0(Executor executor, L.d dVar) {
        Log.i(TAG, "Cleared restore credential successfully!");
        executor.execute(new b(dVar, 3));
        return l.f7746a;
    }

    private static final void onClearCredential$lambda$3(CancellationSignal cancellationSignal, Executor executor, L.d dVar, Exception exc) {
        h.e(exc, "e");
        Log.w(TAG, "Clearing restore credential failed", exc);
        n nVar = new n();
        nVar.r = new a("Clear restore credential failed for unknown reason.");
        if ((exc instanceof O2.e) && ((O2.e) exc).r.r == 40201) {
            nVar.r = new a("The restore credential internal service had a failure.");
        }
        Companion.getClass();
        if (g.a(cancellationSignal)) {
            return;
        }
        onClearCredential$lambda$3$0(executor, dVar, nVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final l onClearCredential$lambda$3$0(Executor executor, L.d dVar, n nVar) {
        executor.execute(new B(dVar, nVar, 12));
        return l.f7746a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onClearCredential$lambda$3$0$0(L.d dVar, n nVar) {
        dVar.i(nVar.r);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final l onClearCredential$lambda$4(CancellationSignal cancellationSignal, Executor executor, L.d dVar, c cVar) {
        Companion.getClass();
        if (!g.a(cancellationSignal)) {
            onClearCredential$lambda$4$0(executor, dVar);
        }
        return l.f7746a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final l onClearCredential$lambda$4$0(Executor executor, L.d dVar) {
        Log.i(TAG, "During clear credential, signed out successfully!");
        executor.execute(new b(dVar, 1));
        return l.f7746a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onClearCredential$lambda$6(CredentialProviderPlayServicesImpl credentialProviderPlayServicesImpl, L.a aVar, CancellationSignal cancellationSignal, Executor executor, L.d dVar, Exception exc) {
        h.e(exc, "it");
        Log.e(TAG, "GMS Clear credential flow failed, calling fallback");
        credentialProviderPlayServicesImpl.runFallbackClearCredFlow(aVar, cancellationSignal, executor, dVar);
    }

    private static final l onCreateCredential$lambda$0(Executor executor, L.d dVar) {
        executor.execute(new b(dVar, 2));
        return l.f7746a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreateCredential$lambda$0$0(L.d dVar) {
        dVar.i(new M.b("createCredentialAsync no provider dependencies found - please ensure the desired provider dependencies are added", "androidx.credentials.TYPE_CREATE_CREDENTIAL_PROVIDER_CONFIGURATION_EXCEPTION"));
    }

    private static final l onGetCredential$lambda$0(Executor executor, L.d dVar) {
        executor.execute(new b(dVar, 6));
        return l.f7746a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onGetCredential$lambda$0$0(L.d dVar) {
        dVar.i(new M.g("this device requires a Google Play Services update for the given feature to be supported"));
    }

    private static final l onGetCredential$lambda$1(Executor executor, L.d dVar) {
        executor.execute(new b(dVar, 5));
        return l.f7746a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onGetCredential$lambda$1$0(L.d dVar) {
        dVar.i(new M.g("getCredentialAsync no provider dependencies found - please ensure the desired provider dependencies are added"));
    }

    private final void runFallbackClearCredFlow(L.a aVar, final CancellationSignal cancellationSignal, final Executor executor, final L.d dVar) {
        p019d3.a aVarG = X2.a.G(this.context);
        aVarG.f2790a.getSharedPreferences("com.google.android.gms.signin", 0).edit().clear().apply();
        Set set = O2.l.f2800a;
        synchronized (set) {
        }
        Iterator it = set.iterator();
        if (it.hasNext()) {
            ((O2.l) it.next()).getClass();
            throw new UnsupportedOperationException();
        }
        P2.e.a();
        K.h hVarB = K.h.b();
        hVarB.f1971d = new N2.c[]{p019d3.e.f5316a};
        hVarB.f1970c = new p066k4.c(aVarG, 21);
        hVarB.f1969b = false;
        hVarB.f1968a = 1554;
        q qVarB = aVarG.b(1, hVarB.a());
        B4.b bVar = new B4.b(new p154z5.c() { // from class: Q.c
            @Override // p154z5.c
            public final Object a(Object obj) {
                return CredentialProviderPlayServicesImpl.runFallbackClearCredFlow$lambda$0(cancellationSignal, executor, dVar, (Void) obj);
            }
        }, 8);
        qVarB.getClass();
        qVarB.c(k.f8050a, bVar);
        qVarB.k(new p091o3.e() { // from class: Q.d
            @Override // p091o3.e
            public final void i(Exception exc) {
                CredentialProviderPlayServicesImpl.runFallbackClearCredFlow$lambda$2(this.r, cancellationSignal, executor, dVar, exc);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final l runFallbackClearCredFlow$lambda$0(CancellationSignal cancellationSignal, Executor executor, L.d dVar, Void r6) {
        Companion.getClass();
        if (!g.a(cancellationSignal)) {
            runFallbackClearCredFlow$lambda$0$0(executor, dVar);
        }
        return l.f7746a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final l runFallbackClearCredFlow$lambda$0$0(Executor executor, L.d dVar) {
        Log.i(TAG, "During clear credential, signed out successfully!");
        executor.execute(new b(dVar, 4));
        return l.f7746a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void runFallbackClearCredFlow$lambda$2(CredentialProviderPlayServicesImpl credentialProviderPlayServicesImpl, CancellationSignal cancellationSignal, Executor executor, L.d dVar, Exception exc) {
        h.e(exc, "e");
        Companion.getClass();
        if (g.a(cancellationSignal)) {
            return;
        }
        runFallbackClearCredFlow$lambda$2$0$0(exc, executor, dVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final l runFallbackClearCredFlow$lambda$2$0$0(Exception exc, Executor executor, L.d dVar) {
        Log.w(TAG, "During clear credential sign out failed with " + exc);
        executor.execute(new B(dVar, exc, 11));
        return l.f7746a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void runFallbackClearCredFlow$lambda$2$0$0$0(L.d dVar, Exception exc) {
        dVar.i(new a(exc.getMessage()));
    }

    public final d getGoogleApiAvailability() {
        return this.googleApiAvailability;
    }

    @Override // L.e
    public boolean isAvailableOnDevice() {
        return isAvailableOnDevice(MIN_GMS_APK_VERSION);
    }

    @Override // L.e
    public void onClearCredential(L.a aVar, final CancellationSignal cancellationSignal, final Executor executor, final L.d dVar) {
        h.e(aVar, "request");
        h.e(executor, "executor");
        h.e(dVar, "callback");
        Companion.getClass();
        if (g.a(cancellationSignal)) {
            return;
        }
        if (!isAvailableOnDevice(PRE_U_MIN_GMS_APK_VERSION)) {
            runFallbackClearCredFlow(aVar, cancellationSignal, executor, dVar);
            return;
        }
        Context context = this.context;
        h.e(context, "context");
        p013c3.g gVar = new p013c3.g(context, p013c3.g.f4611k, O2.b.f2782f, O2.h.f2787c);
        p008b3.b bVar = new p008b3.b();
        K.h hVarB = K.h.b();
        hVarB.f1971d = new N2.c[]{p052i3.b.f6275b};
        hVarB.f1970c = new i(bVar, 23);
        hVarB.f1968a = 32708;
        q qVarB = gVar.b(1, hVarB.a());
        h.d(qVarB, "doWrite(...)");
        B4.b bVar2 = new B4.b(new p154z5.c() { // from class: Q.e
            @Override // p154z5.c
            public final Object a(Object obj) {
                return CredentialProviderPlayServicesImpl.onClearCredential$lambda$4(cancellationSignal, executor, dVar, (p008b3.c) obj);
            }
        }, 9);
        p084n2.a aVar2 = k.f8050a;
        qVarB.c(aVar2, bVar2);
        qVarB.b(aVar2, new f(this, aVar, cancellationSignal, executor, dVar, 0));
    }

    public void onCreateCredential(Context context, L.b bVar, CancellationSignal cancellationSignal, Executor executor, L.d dVar) {
        h.e(context, "context");
        h.e(bVar, "request");
        throw null;
    }

    public void onGetCredential(Context context, L.n nVar, CancellationSignal cancellationSignal, Executor executor, L.d dVar) {
        h.e(context, "context");
        h.e(nVar, "pendingGetCredentialHandle");
        h.e(executor, "executor");
        h.e(dVar, "callback");
    }

    public void onPrepareCredential(L.k kVar, CancellationSignal cancellationSignal, Executor executor, L.d dVar) {
        h.e(kVar, "request");
        h.e(executor, "executor");
        h.e(dVar, "callback");
    }

    public void onSignalCredentialState(o oVar, Executor executor, L.d dVar) {
        h.e(oVar, "request");
        throw null;
    }

    public final void setGoogleApiAvailability(d dVar) {
        h.e(dVar, "<set-?>");
        this.googleApiAvailability = dVar;
    }

    public final boolean isAvailableOnDevice(int i6) {
        int iIsGooglePlayServicesAvailable = isGooglePlayServicesAvailable(this.context, i6);
        boolean z6 = iIsGooglePlayServicesAvailable == 0;
        if (!z6) {
            Log.w(TAG, "Connection with Google Play Services was not successful. Connection result is: " + new N2.a(iIsGooglePlayServicesAvailable, null, null));
        }
        return z6;
    }

    @Override // L.e
    public void onGetCredential(Context context, L.k kVar, CancellationSignal cancellationSignal, Executor executor, L.d dVar) {
        h.e(context, "context");
        h.e(kVar, "request");
        List<m> list = kVar.f2160a;
        h.e(executor, "executor");
        h.e(dVar, "callback");
        Companion.getClass();
        if (g.a(cancellationSignal)) {
            return;
        }
        for (m mVar : list) {
        }
        Companion.getClass();
        for (m mVar2 : list) {
        }
        if (!isAvailableOnDevice(PRE_U_MIN_GMS_APK_VERSION)) {
            Companion.getClass();
            if (g.b(kVar)) {
                new U.b(context).f(kVar, cancellationSignal, executor, dVar);
                return;
            } else {
                new S.c(context).e(kVar, cancellationSignal, executor, dVar);
                return;
            }
        }
        V.b bVar = new V.b(context);
        bVar.f3605g = cancellationSignal;
        bVar.f3603e = dVar;
        bVar.f3604f = executor;
        Companion.getClass();
        if (g.a(cancellationSignal)) {
            return;
        }
        Bundle bundle = new Bundle();
        bundle.putBoolean("androidx.credentials.BUNDLE_KEY_PREFER_IDENTITY_DOC_UI", false);
        bundle.putBoolean("androidx.credentials.BUNDLE_KEY_PREFER_IMMEDIATELY_AVAILABLE_CREDENTIALS", false);
        bundle.putParcelable("androidx.credentials.BUNDLE_KEY_PREFER_UI_BRANDING_COMPONENT_NAME", null);
        ArrayList arrayList = new ArrayList(p081m5.g.x0(list));
        for (m mVar3 : list) {
            mVar3.getClass();
            arrayList.add(new p008b3.h("com.google.android.libraries.identity.googleid.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL", mVar3.f2162a, mVar3.f2163b, StringUtils.EMPTY, StringUtils.EMPTY, StringUtils.EMPTY));
        }
        GetCredentialRequest getCredentialRequest = new GetCredentialRequest(arrayList, bundle, null, new ResultReceiver(null));
        Context context2 = bVar.f3602d;
        h.e(context2, "context");
        p013c3.g gVar = new p013c3.g(context2, p013c3.g.f4611k, O2.b.f2782f, O2.h.f2787c);
        K.h hVarB = K.h.b();
        hVarB.f1971d = new N2.c[]{p052i3.b.f6274a};
        hVarB.f1970c = new M4.i(getCredentialRequest, 22);
        hVarB.f1968a = 32701;
        q qVarB = gVar.b(0, hVarB.a());
        h.d(qVarB, "doRead(...)");
        qVarB.c(k.f8050a, new B4.b(new V.a(cancellationSignal, bVar, executor, dVar), 13));
        qVarB.k(new f(kVar, bVar, dVar, executor, cancellationSignal));
    }
}
