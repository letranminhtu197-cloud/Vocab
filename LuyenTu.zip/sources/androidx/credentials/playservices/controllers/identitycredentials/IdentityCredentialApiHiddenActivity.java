package androidx.credentials.playservices.controllers.identitycredentials;

import A5.h;
import M4.m;
import R.a;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.os.ResultReceiver;

/* JADX INFO: loaded from: classes.dex */
public class IdentityCredentialApiHiddenActivity extends Activity {
    public ResultReceiver r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f4271s;

    @Override // android.app.Activity
    public final void onActivityResult(int i6, int i7, Intent intent) {
        super.onActivityResult(i6, i7, intent);
        ResultReceiver resultReceiver = this.r;
        if (resultReceiver != null) {
            int i8 = a.f3257c;
            m.q(resultReceiver, i6, i7, intent);
        }
        this.f4271s = false;
        finish();
    }

    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) throws IntentSender.SendIntentException {
        super.onCreate(bundle);
        overridePendingTransition(0, 0);
        ResultReceiver resultReceiver = (ResultReceiver) getIntent().getParcelableExtra("RESULT_RECEIVER");
        this.r = resultReceiver;
        if (resultReceiver == null) {
            finish();
        }
        String stringExtra = getIntent().getStringExtra("EXTRA_ERROR_NAME");
        if (stringExtra == null) {
            finish();
            return;
        }
        if (bundle != null) {
            this.f4271s = bundle.getBoolean("androidx.credentials.playservices.AWAITING_RESULT", false);
        }
        if (this.f4271s) {
            return;
        }
        PendingIntent pendingIntent = (PendingIntent) getIntent().getParcelableExtra("EXTRA_FLOW_PENDING_INTENT");
        if (pendingIntent != null) {
            this.f4271s = true;
            startIntentSenderForResult(pendingIntent.getIntentSender(), a.f3256b, null, 0, 0, 0, null);
            return;
        }
        ResultReceiver resultReceiver2 = this.r;
        if (resultReceiver2 != null) {
            int i6 = a.f3257c;
            m.p(resultReceiver2, stringExtra, "Internal error");
        }
        finish();
    }

    @Override // android.app.Activity
    public final void onSaveInstanceState(Bundle bundle) {
        h.e(bundle, "outState");
        bundle.putBoolean("androidx.credentials.playservices.AWAITING_RESULT", this.f4271s);
        super.onSaveInstanceState(bundle);
    }
}
