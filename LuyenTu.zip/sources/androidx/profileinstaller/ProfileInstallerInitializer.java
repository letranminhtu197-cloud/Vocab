package androidx.profileinstaller;

import P1.b;
import Z3.e;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Choreographer;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import org.apache.tika.pipes.pipesiterator.PipesIterator;

/* JADX INFO: loaded from: classes.dex */
public class ProfileInstallerInitializer implements b {
    @Override // P1.b
    public final List a() {
        return Collections.EMPTY_LIST;
    }

    @Override // P1.b
    public final Object b(Context context) {
        final Context applicationContext = context.getApplicationContext();
        Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback(this) { // from class: B1.g
            @Override // android.view.Choreographer.FrameCallback
            public final void doFrame(long j6) {
                (Build.VERSION.SDK_INT >= 28 ? Handler.createAsync(Looper.getMainLooper()) : new Handler(Looper.getMainLooper())).postDelayed(new h(applicationContext, 0), new Random().nextInt(Math.max(PipesIterator.DEFAULT_QUEUE_SIZE, 1)) + 5000);
            }
        });
        return new e(4);
    }
}
