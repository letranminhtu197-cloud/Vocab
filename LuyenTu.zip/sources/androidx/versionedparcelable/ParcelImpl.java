package androidx.versionedparcelable;

import D0.t;
import S1.b;
import S1.c;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
public class ParcelImpl implements Parcelable {
    public static final Parcelable.Creator<ParcelImpl> CREATOR = new t(28);
    public final c r;

    public ParcelImpl(Parcel parcel) {
        this.r = new b(parcel).h();
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i6) {
        new b(parcel).l(this.r);
    }
}
