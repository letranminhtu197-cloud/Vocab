package androidx.core.app;

import S1.c;
import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

/* JADX INFO: loaded from: classes.dex */
public final class RemoteActionCompat implements c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public IconCompat f4226a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public CharSequence f4227b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public CharSequence f4228c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public PendingIntent f4229d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f4230e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f4231f;
}
