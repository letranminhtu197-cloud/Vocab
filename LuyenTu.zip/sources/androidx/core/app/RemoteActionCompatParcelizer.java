package androidx.core.app;

import S1.a;
import S1.b;
import S1.c;
import android.app.PendingIntent;
import android.os.Parcel;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;

/* JADX INFO: loaded from: classes.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(a aVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        c cVarH = remoteActionCompat.f4226a;
        boolean z6 = true;
        if (aVar.e(1)) {
            cVarH = aVar.h();
        }
        remoteActionCompat.f4226a = (IconCompat) cVarH;
        CharSequence charSequence = remoteActionCompat.f4227b;
        if (aVar.e(2)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((b) aVar).f3487e);
        }
        remoteActionCompat.f4227b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.f4228c;
        if (aVar.e(3)) {
            charSequence2 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((b) aVar).f3487e);
        }
        remoteActionCompat.f4228c = charSequence2;
        remoteActionCompat.f4229d = (PendingIntent) aVar.g(remoteActionCompat.f4229d, 4);
        boolean z7 = remoteActionCompat.f4230e;
        if (aVar.e(5)) {
            z7 = ((b) aVar).f3487e.readInt() != 0;
        }
        remoteActionCompat.f4230e = z7;
        boolean z8 = remoteActionCompat.f4231f;
        if (!aVar.e(6)) {
            z6 = z8;
        } else if (((b) aVar).f3487e.readInt() == 0) {
            z6 = false;
        }
        remoteActionCompat.f4231f = z6;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, a aVar) {
        aVar.getClass();
        IconCompat iconCompat = remoteActionCompat.f4226a;
        aVar.i(1);
        aVar.l(iconCompat);
        CharSequence charSequence = remoteActionCompat.f4227b;
        aVar.i(2);
        Parcel parcel = ((b) aVar).f3487e;
        TextUtils.writeToParcel(charSequence, parcel, 0);
        CharSequence charSequence2 = remoteActionCompat.f4228c;
        aVar.i(3);
        TextUtils.writeToParcel(charSequence2, parcel, 0);
        aVar.k(remoteActionCompat.f4229d, 4);
        boolean z6 = remoteActionCompat.f4230e;
        aVar.i(5);
        parcel.writeInt(z6 ? 1 : 0);
        boolean z7 = remoteActionCompat.f4231f;
        aVar.i(6);
        parcel.writeInt(z7 ? 1 : 0);
    }
}
