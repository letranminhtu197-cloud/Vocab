package androidx.core.widget;

import H.A;
import H.AbstractC0037p;
import H.AbstractC0038q;
import H.AbstractC0043w;
import H.AbstractC0046z;
import H.C0022a;
import H.C0023b;
import H.C0024c;
import H.C0028g;
import H.C0031j;
import H.C0036o;
import H.InterfaceC0029h;
import H.InterfaceC0030i;
import H.r;
import J.b;
import K.e;
import K.f;
import K.g;
import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;
import org.apache.tika.pipes.pipesiterator.PipesIterator;
import p000a.a;
import p066k4.c;

/* JADX INFO: loaded from: classes.dex */
public class NestedScrollView extends FrameLayout implements InterfaceC0030i {

    /* JADX INFO: renamed from: T, reason: collision with root package name */
    public static final float f4243T = (float) (Math.log(0.78d) / Math.log(0.9d));

    /* JADX INFO: renamed from: U, reason: collision with root package name */
    public static final e f4244U = new e();

    /* JADX INFO: renamed from: V, reason: collision with root package name */
    public static final int[] f4245V = {R.attr.fillViewport};

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public boolean f4246A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public View f4247B;
    public boolean C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public VelocityTracker f4248D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public boolean f4249E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public boolean f4250F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public final int f4251G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public final int f4252H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public final int f4253I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public int f4254J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public final int[] f4255K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public final int[] f4256L;

    /* JADX INFO: renamed from: M, reason: collision with root package name */
    public int f4257M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public int f4258N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public g f4259O;

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public final C0031j f4260P;

    /* JADX INFO: renamed from: Q, reason: collision with root package name */
    public final C0028g f4261Q;

    /* JADX INFO: renamed from: R, reason: collision with root package name */
    public float f4262R;

    /* JADX INFO: renamed from: S, reason: collision with root package name */
    public final C0024c f4263S;
    public final float r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public long f4264s;
    public final Rect t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final OverScroller f4265u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final EdgeEffect f4266v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final EdgeEffect f4267w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public C0036o f4268x;
    public int y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f4269z;

    /* JADX WARN: Code duplicated, block: B:25:0x00f5 A[Catch: all -> 0x00f8, TRY_LEAVE, TryCatch #0 {all -> 0x00f8, blocks: (B:23:0x00eb, B:25:0x00f5), top: B:40:0x00eb }] */
    /* JADX WARN: Code duplicated, block: B:28:0x00fa  */
    public NestedScrollView(Context context, AttributeSet attributeSet) {
        View.AccessibilityDelegate accessibilityDelegateA;
        Object obj;
        super(context, attributeSet, com.luyentu.mobile.R.attr.nestedScrollViewStyle);
        this.t = new Rect();
        this.f4269z = true;
        this.f4246A = false;
        this.f4247B = null;
        this.C = false;
        this.f4250F = true;
        this.f4254J = -1;
        this.f4255K = new int[2];
        this.f4256L = new int[2];
        this.f4263S = new C0024c(getContext(), new c(this, 8));
        int i6 = Build.VERSION.SDK_INT;
        this.f4266v = i6 >= 31 ? K.c.a(context, attributeSet) : new EdgeEffect(context);
        this.f4267w = i6 >= 31 ? K.c.a(context, attributeSet) : new EdgeEffect(context);
        this.r = context.getResources().getDisplayMetrics().density * 160.0f * 386.0878f * 0.84f;
        this.f4265u = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.f4251G = viewConfiguration.getScaledTouchSlop();
        this.f4252H = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f4253I = viewConfiguration.getScaledMaximumFlingVelocity();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f4245V, com.luyentu.mobile.R.attr.nestedScrollViewStyle, 0);
        setFillViewport(typedArrayObtainStyledAttributes.getBoolean(0, false));
        typedArrayObtainStyledAttributes.recycle();
        this.f4260P = new C0031j();
        C0028g c0028g = new C0028g();
        c0028g.f1489d = this;
        this.f4261Q = c0028g;
        setNestedScrollingEnabled(true);
        C0023b c0023b = f4244U;
        if (c0023b == null) {
            if (i6 >= 29) {
                Field field = AbstractC0046z.f1508a;
                accessibilityDelegateA = AbstractC0043w.a(this);
            } else if (AbstractC0046z.f1509b) {
                accessibilityDelegateA = null;
            } else if (AbstractC0046z.f1508a == null) {
                try {
                    Field declaredField = View.class.getDeclaredField("mAccessibilityDelegate");
                    AbstractC0046z.f1508a = declaredField;
                    declaredField.setAccessible(true);
                    try {
                        obj = AbstractC0046z.f1508a.get(this);
                        if (obj instanceof View.AccessibilityDelegate) {
                            accessibilityDelegateA = (View.AccessibilityDelegate) obj;
                        } else {
                            accessibilityDelegateA = null;
                        }
                    } catch (Throwable unused) {
                        AbstractC0046z.f1509b = true;
                    }
                } catch (Throwable unused2) {
                    AbstractC0046z.f1509b = true;
                }
            } else {
                obj = AbstractC0046z.f1508a.get(this);
                if (obj instanceof View.AccessibilityDelegate) {
                    accessibilityDelegateA = (View.AccessibilityDelegate) obj;
                } else {
                    accessibilityDelegateA = null;
                }
            }
            if (accessibilityDelegateA instanceof C0022a) {
                c0023b = new C0023b();
            }
        }
        Field field2 = AbstractC0046z.f1508a;
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
        setAccessibilityDelegate(c0023b != null ? c0023b.f1470b : null);
    }

    private C0036o getScrollFeedbackProvider() {
        if (this.f4268x == null) {
            this.f4268x = new C0036o(this);
        }
        return this.f4268x;
    }

    public static boolean k(View view, NestedScrollView nestedScrollView) {
        if (view == nestedScrollView) {
            return true;
        }
        Object parent = view.getParent();
        return (parent instanceof ViewGroup) && k((View) parent, nestedScrollView);
    }

    @Override // H.InterfaceC0029h
    public final void a(View view, View view2, int i6, int i7) {
        C0031j c0031j = this.f4260P;
        if (i7 == 1) {
            c0031j.f1492b = i6;
        } else {
            c0031j.f1491a = i6;
        }
        u(2, i7);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view);
    }

    @Override // H.InterfaceC0029h
    public final void b(View view, int i6) {
        C0031j c0031j = this.f4260P;
        if (i6 == 1) {
            c0031j.f1492b = 0;
        } else {
            c0031j.f1491a = 0;
        }
        w(i6);
    }

    @Override // H.InterfaceC0030i
    public final void c(NestedScrollView nestedScrollView, int i6, int i7, int i8, int i9, int i10, int[] iArr) {
        m(i9, i10, iArr);
    }

    @Override // android.view.View
    public final int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    @Override // android.view.View
    public final int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    @Override // android.view.View
    public final int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    /* JADX WARN: Code duplicated, block: B:22:0x0087  */
    /* JADX WARN: Code duplicated, block: B:24:0x0096  */
    /* JADX WARN: Code duplicated, block: B:26:0x00bb  */
    /* JADX WARN: Code duplicated, block: B:30:0x00c5 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:31:0x00c7  */
    /* JADX WARN: Code duplicated, block: B:33:0x00cd  */
    /* JADX WARN: Code duplicated, block: B:34:0x00d8  */
    /* JADX WARN: Code duplicated, block: B:36:0x00de  */
    /* JADX WARN: Code duplicated, block: B:40:0x00f8  */
    /* JADX WARN: Code duplicated, block: B:42:0x00fc  */
    @Override // android.view.View
    public final void computeScroll() {
        int iRound;
        int[] iArr;
        int i6;
        int scrollRange;
        int overScrollMode;
        if (this.f4265u.isFinished()) {
            return;
        }
        this.f4265u.computeScrollOffset();
        int currY = this.f4265u.getCurrY();
        int i7 = currY - this.f4258N;
        int height = getHeight();
        EdgeEffect edgeEffect = this.f4266v;
        EdgeEffect edgeEffect2 = this.f4267w;
        if (i7 <= 0 || a.q(edgeEffect) == 0.0f) {
            if (i7 < 0 && a.q(edgeEffect2) != 0.0f) {
                float f4 = height;
                iRound = Math.round(a.z(edgeEffect2, (i7 * 4.0f) / f4, 0.5f) * (f4 / 4.0f));
                if (iRound != i7) {
                    edgeEffect2.finish();
                }
            }
            int i8 = i7;
            this.f4258N = currY;
            iArr = this.f4256L;
            iArr[1] = 0;
            this.f4261Q.a(0, i8, 1, iArr, null);
            i6 = i8 - iArr[1];
            scrollRange = getScrollRange();
            if (Build.VERSION.SDK_INT >= 35) {
                b.a(this, Math.abs(this.f4265u.getCurrVelocity()));
            }
            if (i6 != 0) {
                int scrollY = getScrollY();
                o(i6, getScrollX(), scrollY, scrollRange);
                int scrollY2 = getScrollY() - scrollY;
                int i9 = i6 - scrollY2;
                iArr[1] = 0;
                this.f4261Q.b(0, scrollY2, 0, i9, this.f4255K, 1, iArr);
                i6 = i9 - iArr[1];
            }
            if (i6 != 0) {
                overScrollMode = getOverScrollMode();
                if (overScrollMode != 0 || (overScrollMode == 1 && scrollRange > 0)) {
                    if (i6 < 0) {
                        if (edgeEffect.isFinished()) {
                            edgeEffect.onAbsorb((int) this.f4265u.getCurrVelocity());
                        }
                    } else if (edgeEffect2.isFinished()) {
                        edgeEffect2.onAbsorb((int) this.f4265u.getCurrVelocity());
                    }
                }
                this.f4265u.abortAnimation();
                w(1);
            }
            if (this.f4265u.isFinished()) {
                w(1);
            } else {
                postInvalidateOnAnimation();
            }
        }
        iRound = Math.round(a.z(edgeEffect, ((-i7) * 4.0f) / height, 0.5f) * ((-height) / 4.0f));
        if (iRound != i7) {
            edgeEffect.finish();
        }
        i7 -= iRound;
        int i10 = i7;
        this.f4258N = currY;
        iArr = this.f4256L;
        iArr[1] = 0;
        this.f4261Q.a(0, i10, 1, iArr, null);
        i6 = i10 - iArr[1];
        scrollRange = getScrollRange();
        if (Build.VERSION.SDK_INT >= 35) {
            b.a(this, Math.abs(this.f4265u.getCurrVelocity()));
        }
        if (i6 != 0) {
            int scrollY3 = getScrollY();
            o(i6, getScrollX(), scrollY3, scrollRange);
            int scrollY4 = getScrollY() - scrollY3;
            int i11 = i6 - scrollY4;
            iArr[1] = 0;
            this.f4261Q.b(0, scrollY4, 0, i11, this.f4255K, 1, iArr);
            i6 = i11 - iArr[1];
        }
        if (i6 != 0) {
            overScrollMode = getOverScrollMode();
            if (overScrollMode != 0) {
                if (i6 < 0) {
                    if (edgeEffect.isFinished()) {
                        edgeEffect.onAbsorb((int) this.f4265u.getCurrVelocity());
                    }
                } else if (edgeEffect2.isFinished()) {
                    edgeEffect2.onAbsorb((int) this.f4265u.getCurrVelocity());
                }
            } else if (i6 < 0) {
                if (edgeEffect.isFinished()) {
                    edgeEffect.onAbsorb((int) this.f4265u.getCurrVelocity());
                }
            } else if (edgeEffect2.isFinished()) {
                edgeEffect2.onAbsorb((int) this.f4265u.getCurrVelocity());
            }
            this.f4265u.abortAnimation();
            w(1);
        }
        if (this.f4265u.isFinished()) {
            postInvalidateOnAnimation();
        } else {
            w(1);
        }
    }

    @Override // android.view.View
    public final int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    @Override // android.view.View
    public final int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    @Override // android.view.View
    public final int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int iMax = Math.max(0, bottom - height);
        if (scrollY < 0) {
            return bottom - scrollY;
        }
        return scrollY > iMax ? (scrollY - iMax) + bottom : bottom;
    }

    @Override // H.InterfaceC0029h
    public final void d(NestedScrollView nestedScrollView, int i6, int i7, int i8, int i9, int i10) {
        m(i9, i10, null);
    }

    /* JADX WARN: Code duplicated, block: B:26:0x0065  */
    /* JADX WARN: Code duplicated, block: B:42:0x00a1  */
    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        boolean zJ;
        if (!super.dispatchKeyEvent(keyEvent)) {
            this.t.setEmpty();
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                if (childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin > (getHeight() - getPaddingTop()) - getPaddingBottom()) {
                    if (keyEvent.getAction() != 0) {
                        zJ = false;
                    } else {
                        int keyCode = keyEvent.getKeyCode();
                        if (keyCode == 19) {
                            zJ = keyEvent.isAltPressed() ? j(33) : g(33);
                        } else if (keyCode != 20) {
                            if (keyCode == 62) {
                                p(keyEvent.isShiftPressed() ? 33 : 130);
                            } else if (keyCode == 92) {
                                zJ = j(33);
                            } else if (keyCode == 93) {
                                zJ = j(130);
                            } else if (keyCode == 122) {
                                p(33);
                            } else if (keyCode == 123) {
                                p(130);
                            }
                            zJ = false;
                        } else {
                            zJ = keyEvent.isAltPressed() ? j(130) : g(130);
                        }
                    }
                } else if (isFocused() || keyEvent.getKeyCode() == 4) {
                    zJ = false;
                } else {
                    View viewFindFocus = findFocus();
                    if (viewFindFocus == this) {
                        viewFindFocus = null;
                    }
                    View viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, 130);
                    if (viewFindNextFocus == null || viewFindNextFocus == this || !viewFindNextFocus.requestFocus(130)) {
                        zJ = false;
                    } else {
                        zJ = true;
                    }
                }
            } else if (isFocused()) {
                zJ = false;
            } else {
                zJ = false;
            }
            if (!zJ) {
                return false;
            }
        }
        return true;
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f4, float f7, boolean z6) {
        ViewParent viewParentC;
        C0028g c0028g = this.f4261Q;
        if (c0028g.f1486a && (viewParentC = c0028g.c(0)) != null) {
            try {
                return viewParentC.onNestedFling((NestedScrollView) c0028g.f1489d, f4, f7, z6);
            } catch (AbstractMethodError e6) {
                Log.e("ViewParentCompat", "ViewParent " + viewParentC + " does not implement interface method onNestedFling", e6);
            }
        }
        return false;
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f4, float f7) {
        ViewParent viewParentC;
        C0028g c0028g = this.f4261Q;
        if (c0028g.f1486a && (viewParentC = c0028g.c(0)) != null) {
            try {
                return viewParentC.onNestedPreFling((NestedScrollView) c0028g.f1489d, f4, f7);
            } catch (AbstractMethodError e6) {
                Log.e("ViewParentCompat", "ViewParent " + viewParentC + " does not implement interface method onNestedPreFling", e6);
            }
        }
        return false;
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i6, int i7, int[] iArr, int[] iArr2) {
        return this.f4261Q.a(i6, i7, 0, iArr, iArr2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i6, int i7, int i8, int i9, int[] iArr) {
        return this.f4261Q.b(i6, i7, i8, i9, iArr, 0, null);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int paddingLeft;
        super.draw(canvas);
        int scrollY = getScrollY();
        EdgeEffect edgeEffect = this.f4266v;
        int paddingLeft2 = 0;
        if (!edgeEffect.isFinished()) {
            int iSave = canvas.save();
            int width = getWidth();
            int height = getHeight();
            int iMin = Math.min(0, scrollY);
            if (getClipToPadding()) {
                width -= getPaddingRight() + getPaddingLeft();
                paddingLeft = getPaddingLeft();
                height -= getPaddingBottom() + getPaddingTop();
                iMin += getPaddingTop();
            } else {
                paddingLeft = 0;
            }
            canvas.translate(paddingLeft, iMin);
            edgeEffect.setSize(width, height);
            if (edgeEffect.draw(canvas)) {
                postInvalidateOnAnimation();
            }
            canvas.restoreToCount(iSave);
        }
        EdgeEffect edgeEffect2 = this.f4267w;
        if (edgeEffect2.isFinished()) {
            return;
        }
        int iSave2 = canvas.save();
        int width2 = getWidth();
        int height2 = getHeight();
        int iMax = Math.max(getScrollRange(), scrollY) + height2;
        if (getClipToPadding()) {
            width2 -= getPaddingRight() + getPaddingLeft();
            paddingLeft2 = getPaddingLeft();
        }
        if (getClipToPadding()) {
            height2 -= getPaddingBottom() + getPaddingTop();
            iMax -= getPaddingBottom();
        }
        canvas.translate(paddingLeft2 - width2, iMax);
        canvas.rotate(180.0f, width2, 0.0f);
        edgeEffect2.setSize(width2, height2);
        if (edgeEffect2.draw(canvas)) {
            postInvalidateOnAnimation();
        }
        canvas.restoreToCount(iSave2);
    }

    @Override // H.InterfaceC0029h
    public final void e(int i6, int i7, int i8, int[] iArr) {
        this.f4261Q.a(i6, i7, i8, iArr, null);
    }

    @Override // H.InterfaceC0029h
    public final boolean f(View view, View view2, int i6, int i7) {
        return (i6 & 2) != 0;
    }

    public final boolean g(int i6) {
        View viewFindFocus = findFocus();
        if (viewFindFocus == this) {
            viewFindFocus = null;
        }
        View view = viewFindFocus;
        View viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, view, i6);
        int maxScrollAmount = getMaxScrollAmount();
        if (viewFindNextFocus == null || !l(viewFindNextFocus, maxScrollAmount, getHeight())) {
            if (i6 == 33 && getScrollY() < maxScrollAmount) {
                maxScrollAmount = getScrollY();
            } else if (i6 == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                maxScrollAmount = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getHeight() + getScrollY()) - getPaddingBottom()), maxScrollAmount);
            }
            if (maxScrollAmount == 0) {
                return false;
            }
            if (i6 != 130) {
                maxScrollAmount = -maxScrollAmount;
            }
            r(maxScrollAmount, -1, null, 0, 1, true);
        } else {
            Rect rect = this.t;
            viewFindNextFocus.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(viewFindNextFocus, rect);
            r(h(rect), -1, null, 0, 1, true);
            viewFindNextFocus.requestFocus(i6);
        }
        if (view != null && view.isFocused() && !l(view, 0, getHeight())) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    @Override // android.view.View
    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + layoutParams.bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return bottom / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (getHeight() * 0.5f);
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        C0031j c0031j = this.f4260P;
        return c0031j.f1492b | c0031j.f1491a;
    }

    public int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    @Override // android.view.View
    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return scrollY / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    public float getVerticalScrollFactorCompat() {
        if (this.f4262R == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (!context.getTheme().resolveAttribute(R.attr.listPreferredItemHeight, typedValue, true)) {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
            this.f4262R = typedValue.getDimension(context.getResources().getDisplayMetrics());
        }
        return this.f4262R;
    }

    public final int h(Rect rect) {
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i6 = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int i7 = rect.bottom < (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin ? i6 - verticalFadingEdgeLength : i6;
        int i8 = rect.bottom;
        if (i8 > i7 && rect.top > scrollY) {
            return Math.min(rect.height() > height ? rect.top - scrollY : rect.bottom - i7, (childAt.getBottom() + layoutParams.bottomMargin) - i6);
        }
        if (rect.top >= scrollY || i8 >= i7) {
            return 0;
        }
        return Math.max(rect.height() > height ? 0 - (i7 - rect.bottom) : 0 - (scrollY - rect.top), -getScrollY());
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        return this.f4261Q.c(0) != null;
    }

    public final void i(int i6) {
        if (getChildCount() > 0) {
            this.f4265u.fling(getScrollX(), getScrollY(), 0, i6, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
            u(2, 1);
            this.f4258N = getScrollY();
            postInvalidateOnAnimation();
            if (Build.VERSION.SDK_INT >= 35) {
                b.a(this, Math.abs(this.f4265u.getCurrVelocity()));
            }
        }
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return this.f4261Q.f1486a;
    }

    public final boolean j(int i6) {
        int childCount;
        boolean z6 = i6 == 130;
        int height = getHeight();
        Rect rect = this.t;
        rect.top = 0;
        rect.bottom = height;
        if (z6 && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            int paddingBottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
            rect.bottom = paddingBottom;
            rect.top = paddingBottom - height;
        }
        return q(i6, rect.top, rect.bottom);
    }

    public final boolean l(View view, int i6, int i7) {
        Rect rect = this.t;
        view.getDrawingRect(rect);
        offsetDescendantRectToMyCoords(view, rect);
        return rect.bottom + i6 >= getScrollY() && rect.top - i6 <= getScrollY() + i7;
    }

    public final void m(int i6, int i7, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i6);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.f4261Q.b(0, scrollY2, 0, i6 - scrollY2, null, i7, iArr);
    }

    @Override // android.view.ViewGroup
    public final void measureChild(View view, int i6, int i7) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i6, getPaddingRight() + getPaddingLeft(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    @Override // android.view.ViewGroup
    public final void measureChildWithMargins(View view, int i6, int i7, int i8, int i9) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i6, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i7, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    public final void n(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f4254J) {
            int i6 = actionIndex == 0 ? 1 : 0;
            this.y = (int) motionEvent.getY(i6);
            this.f4254J = motionEvent.getPointerId(i6);
            VelocityTracker velocityTracker = this.f4248D;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    public final boolean o(int i6, int i7, int i8, int i9) {
        int i10;
        boolean z6;
        int i11;
        boolean z7;
        getOverScrollMode();
        super.computeHorizontalScrollRange();
        super.computeHorizontalScrollExtent();
        computeVerticalScrollRange();
        super.computeVerticalScrollExtent();
        int i12 = i8 + i6;
        if (i7 <= 0 && i7 >= 0) {
            i10 = i7;
            z6 = false;
        } else {
            i10 = 0;
            z6 = true;
        }
        if (i12 <= i9) {
            if (i12 < 0) {
                i11 = 0;
            } else {
                i11 = i12;
                z7 = false;
            }
            if (z7 && this.f4261Q.c(1) == null) {
                this.f4265u.springBack(i10, i11, 0, 0, 0, getScrollRange());
            }
            super.scrollTo(i10, i11);
            return !z6 || z7;
        }
        i11 = i9;
        z7 = true;
        if (z7) {
            this.f4265u.springBack(i10, i11, 0, 0, 0, getScrollRange());
        }
        super.scrollTo(i10, i11);
        if (z6) {
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f4246A = false;
    }

    /* JADX WARN: Code duplicated, block: B:102:0x01d4  */
    /* JADX WARN: Code duplicated, block: B:49:0x00df  */
    /* JADX WARN: Code duplicated, block: B:70:0x012a  */
    @Override // android.view.View
    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        float f4;
        int i6;
        int width;
        int i7;
        int scaledMinimumFlingVelocity;
        int scaledMaximumFlingVelocity;
        boolean z6;
        NestedScrollView nestedScrollView;
        float yVelocity;
        NestedScrollView nestedScrollView2;
        float f7;
        long j6;
        float fSqrt;
        int i8;
        if (motionEvent.getAction() != 8 || this.C) {
            return false;
        }
        if ((motionEvent.getSource() & 2) == 2) {
            float axisValue = motionEvent.getAxisValue(9);
            width = (int) motionEvent.getX();
            i6 = 9;
            f4 = axisValue;
        } else if ((motionEvent.getSource() & 4194304) == 4194304) {
            float axisValue2 = motionEvent.getAxisValue(26);
            width = getWidth() / 2;
            f4 = axisValue2;
            i6 = 26;
        } else {
            f4 = 0.0f;
            i6 = 0;
            width = 0;
        }
        if (f4 == 0.0f) {
            return false;
        }
        r(-((int) (getVerticalScrollFactorCompat() * f4)), i6, motionEvent, width, 1, (motionEvent.getSource() & 8194) == 8194);
        if (i6 != 0) {
            C0024c c0024c = this.f4263S;
            NestedScrollView nestedScrollView3 = (NestedScrollView) c0024c.f1472b.f7289s;
            int[] iArr = c0024c.f1478h;
            int source = motionEvent.getSource();
            int deviceId = motionEvent.getDeviceId();
            int i9 = 1;
            if (c0024c.f1476f == source && c0024c.f1477g == deviceId && c0024c.f1475e == i6) {
                z6 = false;
                i7 = 0;
            } else {
                Context context = c0024c.f1471a;
                ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
                int deviceId2 = motionEvent.getDeviceId();
                i7 = 0;
                int source2 = motionEvent.getSource();
                int i10 = Build.VERSION.SDK_INT;
                if (i10 >= 34) {
                    int i11 = A.f1433a;
                    scaledMinimumFlingVelocity = AbstractC0037p.h(viewConfiguration, deviceId2, i6, source2);
                } else {
                    int i12 = A.f1433a;
                    InputDevice device = InputDevice.getDevice(deviceId2);
                    if (device == null || device.getMotionRange(i6, source2) == null) {
                        scaledMinimumFlingVelocity = Integer.MAX_VALUE;
                    } else {
                        Resources resources = context.getResources();
                        int identifier = (source2 == 4194304 && i6 == 26) ? resources.getIdentifier("config_viewMinRotaryEncoderFlingVelocity", "dimen", "android") : -1;
                        Objects.requireNonNull(viewConfiguration);
                        if (identifier == -1) {
                            scaledMinimumFlingVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
                        } else if (identifier == 0 || (scaledMinimumFlingVelocity = resources.getDimensionPixelSize(identifier)) < 0) {
                            scaledMinimumFlingVelocity = Integer.MAX_VALUE;
                        }
                    }
                }
                iArr[0] = scaledMinimumFlingVelocity;
                int deviceId3 = motionEvent.getDeviceId();
                int source3 = motionEvent.getSource();
                if (i10 >= 34) {
                    scaledMaximumFlingVelocity = AbstractC0037p.g(viewConfiguration, deviceId3, i6, source3);
                } else {
                    InputDevice device2 = InputDevice.getDevice(deviceId3);
                    if (device2 == null || device2.getMotionRange(i6, source3) == null) {
                        scaledMaximumFlingVelocity = Integer.MIN_VALUE;
                    } else {
                        Resources resources2 = context.getResources();
                        int identifier2 = (source3 == 4194304 && i6 == 26) ? resources2.getIdentifier("config_viewMaxRotaryEncoderFlingVelocity", "dimen", "android") : -1;
                        Objects.requireNonNull(viewConfiguration);
                        if (identifier2 == -1) {
                            scaledMaximumFlingVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
                        } else if (identifier2 == 0 || (scaledMaximumFlingVelocity = resources2.getDimensionPixelSize(identifier2)) < 0) {
                            scaledMaximumFlingVelocity = Integer.MIN_VALUE;
                        }
                    }
                }
                iArr[1] = scaledMaximumFlingVelocity;
                c0024c.f1476f = source;
                c0024c.f1477g = deviceId;
                c0024c.f1475e = i6;
                z6 = true;
            }
            if (iArr[i7] == Integer.MAX_VALUE) {
                VelocityTracker velocityTracker = c0024c.f1473c;
                if (velocityTracker == null) {
                    return true;
                }
                velocityTracker.recycle();
                c0024c.f1473c = null;
                return true;
            }
            if (c0024c.f1473c == null) {
                c0024c.f1473c = VelocityTracker.obtain();
            }
            VelocityTracker velocityTracker2 = c0024c.f1473c;
            Map map = AbstractC0038q.f1498a;
            velocityTracker2.addMovement(motionEvent);
            int i13 = 20;
            if (Build.VERSION.SDK_INT < 34 && motionEvent.getSource() == 4194304) {
                Map map2 = AbstractC0038q.f1498a;
                if (!map2.containsKey(velocityTracker2)) {
                    map2.put(velocityTracker2, new r());
                }
                r rVar = (r) map2.get(velocityTracker2);
                long[] jArr = rVar.f1500b;
                long eventTime = motionEvent.getEventTime();
                if (rVar.f1502d != 0 && eventTime - jArr[rVar.f1503e] > 40) {
                    rVar.f1502d = i7;
                    rVar.f1501c = 0.0f;
                }
                int i14 = (rVar.f1503e + 1) % 20;
                rVar.f1503e = i14;
                int i15 = rVar.f1502d;
                if (i15 != 20) {
                    rVar.f1502d = i15 + 1;
                }
                rVar.f1499a[i14] = motionEvent.getAxisValue(26);
                jArr[rVar.f1503e] = eventTime;
            }
            velocityTracker2.computeCurrentVelocity(PipesIterator.DEFAULT_QUEUE_SIZE, Float.MAX_VALUE);
            r rVar2 = (r) AbstractC0038q.f1498a.get(velocityTracker2);
            if (rVar2 != null) {
                float[] fArr = rVar2.f1499a;
                long[] jArr2 = rVar2.f1500b;
                int i16 = rVar2.f1502d;
                if (i16 < 2) {
                    nestedScrollView = nestedScrollView3;
                    i8 = 1000;
                    fSqrt = 0.0f;
                } else {
                    int i17 = rVar2.f1503e;
                    int i18 = ((i17 + 20) - (i16 - 1)) % 20;
                    long j7 = jArr2[i17];
                    while (true) {
                        j6 = jArr2[i18];
                        if (j7 - j6 <= 100) {
                            break;
                        }
                        rVar2.f1502d--;
                        i18 = (i18 + 1) % 20;
                    }
                    int i19 = rVar2.f1502d;
                    if (i19 < 2) {
                        nestedScrollView = nestedScrollView3;
                        i8 = 1000;
                        fSqrt = 0.0f;
                    } else if (i19 == 2) {
                        int i20 = (i18 + 1) % 20;
                        long j8 = jArr2[i20];
                        if (j6 == j8) {
                            nestedScrollView = nestedScrollView3;
                            i8 = 1000;
                            fSqrt = 0.0f;
                        } else {
                            nestedScrollView = nestedScrollView3;
                            i8 = 1000;
                            fSqrt = fArr[i20] / (j8 - j6);
                        }
                    } else {
                        float f8 = 0.0f;
                        int i21 = 0;
                        int i22 = 0;
                        while (true) {
                            if (i21 >= rVar2.f1502d - 1) {
                                break;
                            }
                            int i23 = i21 + i18;
                            long j9 = jArr2[i23 % 20];
                            int i24 = (i23 + 1) % i13;
                            if (jArr2[i24] != j9) {
                                i22++;
                                float fSqrt2 = (f8 < 0.0f ? -1.0f : 1.0f) * ((float) Math.sqrt(Math.abs(f8) * 2.0f));
                                float f9 = fArr[i24] / (jArr2[i24] - j9);
                                float fAbs = (Math.abs(f9) * (f9 - fSqrt2)) + f8;
                                if (i22 == i9) {
                                    fAbs *= 0.5f;
                                }
                                f8 = fAbs;
                            }
                            i21++;
                            nestedScrollView3 = nestedScrollView3;
                            i13 = 20;
                            i9 = 1;
                        }
                        nestedScrollView = nestedScrollView3;
                        fSqrt = ((float) Math.sqrt(Math.abs(f8) * 2.0f)) * (f8 < 0.0f ? -1.0f : 1.0f);
                        i8 = PipesIterator.DEFAULT_QUEUE_SIZE;
                    }
                }
                float f10 = fSqrt * i8;
                rVar2.f1501c = f10;
                if (f10 < (-Math.abs((float) r6))) {
                    rVar2.f1501c = -Math.abs(Float.MAX_VALUE);
                } else if (rVar2.f1501c > Math.abs((float) r6)) {
                    rVar2.f1501c = Math.abs((float) r6);
                }
            } else {
                nestedScrollView = nestedScrollView3;
            }
            if (Build.VERSION.SDK_INT >= 34) {
                yVelocity = AbstractC0037p.d(velocityTracker2, i6);
            } else if (i6 == 0) {
                yVelocity = velocityTracker2.getXVelocity();
            } else if (i6 == 1) {
                yVelocity = velocityTracker2.getYVelocity();
            } else {
                r rVar3 = (r) AbstractC0038q.f1498a.get(velocityTracker2);
                yVelocity = (rVar3 == null || i6 != 26) ? 0.0f : rVar3.f1501c;
            }
            float f11 = yVelocity * (-nestedScrollView.getVerticalScrollFactorCompat());
            float fSignum = Math.signum(f11);
            if (z6 || !(fSignum == Math.signum(c0024c.f1474d) || fSignum == 0.0f)) {
                nestedScrollView2 = nestedScrollView;
                nestedScrollView2.f4265u.abortAnimation();
            } else {
                nestedScrollView2 = nestedScrollView;
            }
            if (Math.abs(f11) >= iArr[0]) {
                int i25 = iArr[1];
                float fMax = Math.max(-i25, Math.min(f11, i25));
                if (fMax == 0.0f) {
                    f7 = 0.0f;
                } else {
                    nestedScrollView2.f4265u.abortAnimation();
                    nestedScrollView2.i((int) fMax);
                    f7 = fMax;
                }
                c0024c.f1474d = f7;
                return true;
            }
        }
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:34:0x0083  */
    /* JADX WARN: Code duplicated, block: B:36:0x008b  */
    /* JADX WARN: Code duplicated, block: B:39:0x00a7  */
    /* JADX WARN: Code duplicated, block: B:62:0x0117  */
    /* JADX WARN: Code duplicated, block: B:70:0x012d  */
    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        VelocityTracker velocityTracker;
        VelocityTracker velocityTracker2;
        int action = motionEvent.getAction();
        boolean z6 = true;
        if (action == 2 && this.C) {
            return true;
        }
        int i6 = action & 255;
        if (i6 == 0) {
            int y = (int) motionEvent.getY();
            int x5 = (int) motionEvent.getX();
            if (getChildCount() > 0) {
                int scrollY = getScrollY();
                View childAt = getChildAt(0);
                if (y < childAt.getTop() - scrollY || y >= childAt.getBottom() - scrollY || x5 < childAt.getLeft() || x5 >= childAt.getRight()) {
                    if (!v(motionEvent) && this.f4265u.isFinished()) {
                        z6 = false;
                    }
                    this.C = z6;
                    velocityTracker = this.f4248D;
                    if (velocityTracker != null) {
                        velocityTracker.recycle();
                        this.f4248D = null;
                    }
                } else {
                    this.y = y;
                    this.f4254J = motionEvent.getPointerId(0);
                    VelocityTracker velocityTracker3 = this.f4248D;
                    if (velocityTracker3 == null) {
                        this.f4248D = VelocityTracker.obtain();
                    } else {
                        velocityTracker3.clear();
                    }
                    this.f4248D.addMovement(motionEvent);
                    this.f4265u.computeScrollOffset();
                    if (!v(motionEvent) && this.f4265u.isFinished()) {
                        z6 = false;
                    }
                    this.C = z6;
                    u(2, 0);
                }
            } else {
                if (!v(motionEvent)) {
                    z6 = false;
                }
                this.C = z6;
                velocityTracker = this.f4248D;
                if (velocityTracker != null) {
                    velocityTracker.recycle();
                    this.f4248D = null;
                }
            }
        } else if (i6 == 1) {
            this.C = false;
            this.f4254J = -1;
            velocityTracker2 = this.f4248D;
            if (velocityTracker2 != null) {
                velocityTracker2.recycle();
                this.f4248D = null;
            }
            if (this.f4265u.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                postInvalidateOnAnimation();
            }
            w(0);
        } else if (i6 == 2) {
            int i7 = this.f4254J;
            if (i7 != -1) {
                int iFindPointerIndex = motionEvent.findPointerIndex(i7);
                if (iFindPointerIndex == -1) {
                    Log.e("NestedScrollView", "Invalid pointerId=" + i7 + " in onInterceptTouchEvent");
                } else {
                    int y5 = (int) motionEvent.getY(iFindPointerIndex);
                    if (Math.abs(y5 - this.y) > this.f4251G && (2 & getNestedScrollAxes()) == 0) {
                        this.C = true;
                        this.y = y5;
                        if (this.f4248D == null) {
                            this.f4248D = VelocityTracker.obtain();
                        }
                        this.f4248D.addMovement(motionEvent);
                        this.f4257M = 0;
                        ViewParent parent = getParent();
                        if (parent != null) {
                            parent.requestDisallowInterceptTouchEvent(true);
                        }
                    }
                }
            }
        } else if (i6 == 3) {
            this.C = false;
            this.f4254J = -1;
            velocityTracker2 = this.f4248D;
            if (velocityTracker2 != null) {
                velocityTracker2.recycle();
                this.f4248D = null;
            }
            if (this.f4265u.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                postInvalidateOnAnimation();
            }
            w(0);
        } else if (i6 == 6) {
            n(motionEvent);
        }
        return this.C;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z6, int i6, int i7, int i8, int i9) {
        int measuredHeight;
        super.onLayout(z6, i6, i7, i8, i9);
        int i10 = 0;
        this.f4269z = false;
        View view = this.f4247B;
        if (view != null && k(view, this)) {
            View view2 = this.f4247B;
            Rect rect = this.t;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int iH = h(rect);
            if (iH != 0) {
                scrollBy(0, iH);
            }
        }
        this.f4247B = null;
        if (!this.f4246A) {
            if (this.f4259O != null) {
                scrollTo(getScrollX(), this.f4259O.r);
                this.f4259O = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                measuredHeight = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            } else {
                measuredHeight = 0;
            }
            int paddingTop = ((i9 - i7) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            if (paddingTop < measuredHeight && scrollY >= 0) {
                i10 = paddingTop + scrollY > measuredHeight ? measuredHeight - paddingTop : scrollY;
            }
            if (i10 != scrollY) {
                scrollTo(getScrollX(), i10);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.f4246A = true;
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i6, int i7) {
        super.onMeasure(i6, i7);
        if (this.f4249E && View.MeasureSpec.getMode(i7) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(ViewGroup.getChildMeasureSpec(i6, getPaddingRight() + getPaddingLeft() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f4, float f7, boolean z6) {
        if (z6) {
            return false;
        }
        dispatchNestedFling(0.0f, f7, true);
        i((int) f7);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f4, float f7) {
        return dispatchNestedPreFling(f4, f7);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i6, int i7, int[] iArr) {
        this.f4261Q.a(i6, i7, 0, iArr, null);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i6, int i7, int i8, int i9) {
        m(i9, 0, null);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i6) {
        a(view, view2, i6, 0);
    }

    @Override // android.view.View
    public final void onOverScrolled(int i6, int i7, boolean z6, boolean z7) {
        super.scrollTo(i6, i7);
    }

    @Override // android.view.ViewGroup
    public final boolean onRequestFocusInDescendants(int i6, Rect rect) {
        if (i6 == 2) {
            i6 = 130;
        } else if (i6 == 1) {
            i6 = 33;
        }
        View viewFindNextFocus = rect == null ? FocusFinder.getInstance().findNextFocus(this, null, i6) : FocusFinder.getInstance().findNextFocusFromRect(this, rect, i6);
        if (viewFindNextFocus != null && l(viewFindNextFocus, 0, getHeight())) {
            return viewFindNextFocus.requestFocus(i6, rect);
        }
        return false;
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof g)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        g gVar = (g) parcelable;
        super.onRestoreInstanceState(gVar.getSuperState());
        this.f4259O = gVar;
        requestLayout();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        g gVar = new g(super.onSaveInstanceState());
        gVar.r = getScrollY();
        return gVar;
    }

    @Override // android.view.View
    public final void onScrollChanged(int i6, int i7, int i8, int i9) {
        super.onScrollChanged(i6, i7, i8, i9);
    }

    @Override // android.view.View
    public final void onSizeChanged(int i6, int i7, int i8, int i9) {
        super.onSizeChanged(i6, i7, i8, i9);
        View viewFindFocus = findFocus();
        if (viewFindFocus == null || this == viewFindFocus || !l(viewFindFocus, 0, i9)) {
            return;
        }
        Rect rect = this.t;
        viewFindFocus.getDrawingRect(rect);
        offsetDescendantRectToMyCoords(viewFindFocus, rect);
        int iH = h(rect);
        if (iH != 0) {
            if (this.f4250F) {
                t(0, iH, false);
            } else {
                scrollBy(0, iH);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i6) {
        return f(view, view2, i6, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        b(view, 0);
    }

    /* JADX WARN: Code duplicated, block: B:49:0x011f  */
    /* JADX WARN: Code duplicated, block: B:56:0x0135  */
    /* JADX WARN: Code duplicated, block: B:59:0x013c  */
    /* JADX WARN: Code duplicated, block: B:60:0x0140  */
    /* JADX WARN: Code duplicated, block: B:63:0x0147  */
    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        ViewParent parent;
        float fZ;
        int iRound;
        int i6;
        ViewParent parent2;
        if (this.f4248D == null) {
            this.f4248D = VelocityTracker.obtain();
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f4257M = 0;
        }
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
        float f4 = 0.0f;
        motionEventObtain.offsetLocation(0.0f, this.f4257M);
        if (actionMasked != 0) {
            EdgeEffect edgeEffect = this.f4266v;
            EdgeEffect edgeEffect2 = this.f4267w;
            if (actionMasked == 1) {
                VelocityTracker velocityTracker = this.f4248D;
                velocityTracker.computeCurrentVelocity(PipesIterator.DEFAULT_QUEUE_SIZE, this.f4253I);
                int yVelocity = (int) velocityTracker.getYVelocity(this.f4254J);
                if (Math.abs(yVelocity) >= this.f4252H) {
                    if (a.q(edgeEffect) != 0.0f) {
                        if (s(edgeEffect, yVelocity)) {
                            edgeEffect.onAbsorb(yVelocity);
                        } else {
                            i(-yVelocity);
                        }
                    } else if (a.q(edgeEffect2) != 0.0f) {
                        int i7 = -yVelocity;
                        if (s(edgeEffect2, i7)) {
                            edgeEffect2.onAbsorb(i7);
                        } else {
                            i(i7);
                        }
                    } else {
                        int i8 = -yVelocity;
                        float f7 = i8;
                        if (!dispatchNestedPreFling(0.0f, f7)) {
                            dispatchNestedFling(0.0f, f7, true);
                            i(i8);
                        }
                    }
                } else if (this.f4265u.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    postInvalidateOnAnimation();
                }
                this.f4254J = -1;
                this.C = false;
                VelocityTracker velocityTracker2 = this.f4248D;
                if (velocityTracker2 != null) {
                    velocityTracker2.recycle();
                    this.f4248D = null;
                }
                w(0);
                this.f4266v.onRelease();
                this.f4267w.onRelease();
            } else if (actionMasked == 2) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.f4254J);
                if (iFindPointerIndex == -1) {
                    Log.e("NestedScrollView", "Invalid pointerId=" + this.f4254J + " in onTouchEvent");
                } else {
                    int y = (int) motionEvent.getY(iFindPointerIndex);
                    int i9 = this.y - y;
                    float x5 = motionEvent.getX(iFindPointerIndex) / getWidth();
                    float height = i9 / getHeight();
                    if (a.q(edgeEffect) != 0.0f) {
                        fZ = -a.z(edgeEffect, -height, x5);
                        if (a.q(edgeEffect) == 0.0f) {
                            edgeEffect.onRelease();
                        }
                    } else if (a.q(edgeEffect2) != 0.0f) {
                        fZ = a.z(edgeEffect2, height, 1.0f - x5);
                        if (a.q(edgeEffect2) == 0.0f) {
                            edgeEffect2.onRelease();
                        }
                    } else {
                        iRound = Math.round(f4 * getHeight());
                        if (iRound != 0) {
                            invalidate();
                        }
                        i6 = i9 - iRound;
                        if (!this.C && Math.abs(i6) > this.f4251G) {
                            parent2 = getParent();
                            if (parent2 != null) {
                                parent2.requestDisallowInterceptTouchEvent(true);
                            }
                            this.C = true;
                            if (i6 > 0) {
                                i6 -= this.f4251G;
                            } else {
                                i6 += this.f4251G;
                            }
                        }
                        if (this.C) {
                            int iR = r(i6, 1, motionEvent, (int) motionEvent.getX(iFindPointerIndex), 0, false);
                            this.y = y - iR;
                            this.f4257M += iR;
                        }
                    }
                    f4 = fZ;
                    iRound = Math.round(f4 * getHeight());
                    if (iRound != 0) {
                        invalidate();
                    }
                    i6 = i9 - iRound;
                    if (!this.C) {
                        parent2 = getParent();
                        if (parent2 != null) {
                            parent2.requestDisallowInterceptTouchEvent(true);
                        }
                        this.C = true;
                        if (i6 > 0) {
                            i6 -= this.f4251G;
                        } else {
                            i6 += this.f4251G;
                        }
                    }
                    if (this.C) {
                        int iR2 = r(i6, 1, motionEvent, (int) motionEvent.getX(iFindPointerIndex), 0, false);
                        this.y = y - iR2;
                        this.f4257M += iR2;
                    }
                }
            } else if (actionMasked == 3) {
                if (this.C && getChildCount() > 0) {
                    if (this.f4265u.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                        postInvalidateOnAnimation();
                    }
                }
                this.f4254J = -1;
                this.C = false;
                VelocityTracker velocityTracker3 = this.f4248D;
                if (velocityTracker3 != null) {
                    velocityTracker3.recycle();
                    this.f4248D = null;
                }
                w(0);
                this.f4266v.onRelease();
                this.f4267w.onRelease();
            } else if (actionMasked == 5) {
                int actionIndex = motionEvent.getActionIndex();
                this.y = (int) motionEvent.getY(actionIndex);
                this.f4254J = motionEvent.getPointerId(actionIndex);
            } else if (actionMasked == 6) {
                n(motionEvent);
                this.y = (int) motionEvent.getY(motionEvent.findPointerIndex(this.f4254J));
            }
        } else {
            if (getChildCount() == 0) {
                return false;
            }
            if (this.C && (parent = getParent()) != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
            if (!this.f4265u.isFinished()) {
                this.f4265u.abortAnimation();
                w(1);
            }
            int y5 = (int) motionEvent.getY();
            int pointerId = motionEvent.getPointerId(0);
            this.y = y5;
            this.f4254J = pointerId;
            u(2, 0);
        }
        VelocityTracker velocityTracker4 = this.f4248D;
        if (velocityTracker4 != null) {
            velocityTracker4.addMovement(motionEventObtain);
        }
        motionEventObtain.recycle();
        return true;
    }

    public final void p(int i6) {
        boolean z6 = i6 == 130;
        int height = getHeight();
        Rect rect = this.t;
        if (z6) {
            rect.top = getScrollY() + height;
            int childCount = getChildCount();
            if (childCount > 0) {
                View childAt = getChildAt(childCount - 1);
                int paddingBottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
                if (rect.top + height > paddingBottom) {
                    rect.top = paddingBottom - height;
                }
            }
        } else {
            int scrollY = getScrollY() - height;
            rect.top = scrollY;
            if (scrollY < 0) {
                rect.top = 0;
            }
        }
        int i7 = rect.top;
        int i8 = height + i7;
        rect.bottom = i8;
        q(i6, i7, i8);
    }

    /* JADX WARN: Code duplicated, block: B:32:0x0068  */
    public final boolean q(int i6, int i7, int i8) {
        boolean z6;
        int height = getHeight();
        int scrollY = getScrollY();
        int i9 = height + scrollY;
        boolean z7 = i6 == 33;
        ArrayList<View> focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z8 = false;
        for (int i10 = 0; i10 < size; i10++) {
            View view2 = focusables.get(i10);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i7 < bottom && top < i8) {
                boolean z9 = i7 < top && bottom < i8;
                if (view == null) {
                    view = view2;
                    z8 = z9;
                } else {
                    boolean z10 = (z7 && top < view.getTop()) || (!z7 && bottom > view.getBottom());
                    if (z8) {
                        if (z9 && z10) {
                            view = view2;
                        }
                    } else if (z9) {
                        view = view2;
                        z8 = true;
                    } else if (z10) {
                        view = view2;
                    }
                }
            }
        }
        View view3 = view == null ? this : view;
        if (i7 < scrollY || i8 > i9) {
            r(z7 ? i7 - scrollY : i8 - i9, -1, null, 0, 1, true);
            z6 = true;
        } else {
            z6 = false;
        }
        if (view3 != findFocus()) {
            view3.requestFocus(i6);
        }
        return z6;
    }

    /* JADX WARN: Code duplicated, block: B:53:0x0116  */
    /* JADX WARN: Code duplicated, block: B:60:0x0127  */
    public final int r(int i6, int i7, MotionEvent motionEvent, int i8, int i9, boolean z6) {
        int i10;
        int i11;
        boolean z7;
        boolean z8;
        VelocityTracker velocityTracker;
        if (i9 == 1) {
            u(2, i9);
        }
        boolean zA = this.f4261Q.a(0, i6, i9, this.f4256L, this.f4255K);
        int[] iArr = this.f4255K;
        int[] iArr2 = this.f4256L;
        if (zA) {
            i10 = i6 - iArr2[1];
            i11 = iArr[1];
        } else {
            i10 = i6;
            i11 = 0;
        }
        int scrollY = getScrollY();
        int scrollRange = getScrollRange();
        int overScrollMode = getOverScrollMode();
        boolean z9 = (overScrollMode == 0 || (overScrollMode == 1 && getScrollRange() > 0)) && !z6;
        boolean z10 = o(i10, 0, scrollY, scrollRange) && this.f4261Q.c(i9) == null;
        int scrollY2 = getScrollY() - scrollY;
        if (motionEvent != null && scrollY2 != 0) {
            getScrollFeedbackProvider().f1497a.onScrollProgress(motionEvent.getDeviceId(), motionEvent.getSource(), i7, scrollY2);
        }
        iArr2[1] = 0;
        this.f4261Q.b(0, scrollY2, 0, i10 - scrollY2, this.f4255K, i9, iArr2);
        int i12 = i11 + iArr[1];
        int i13 = i10 - iArr2[1];
        int i14 = scrollY + i13;
        EdgeEffect edgeEffect = this.f4267w;
        EdgeEffect edgeEffect2 = this.f4266v;
        if (i14 >= 0) {
            if (i14 > scrollRange && z9) {
                a.z(edgeEffect, i13 / getHeight(), 1.0f - (i8 / getWidth()));
                if (motionEvent != null) {
                    z7 = false;
                    getScrollFeedbackProvider().f1497a.onScrollLimit(motionEvent.getDeviceId(), motionEvent.getSource(), i7, false);
                } else {
                    z7 = false;
                }
                if (!edgeEffect2.isFinished()) {
                    edgeEffect2.onRelease();
                }
            }
            if (edgeEffect2.isFinished() || !edgeEffect.isFinished()) {
                postInvalidateOnAnimation();
                z8 = z7;
            } else {
                z8 = z10;
            }
            if (z8 && i9 == 0 && (velocityTracker = this.f4248D) != null) {
                velocityTracker.clear();
            }
            if (i9 == 1) {
                w(i9);
                edgeEffect2.onRelease();
                edgeEffect.onRelease();
            }
            return i12;
        }
        if (z9) {
            a.z(edgeEffect2, (-i13) / getHeight(), i8 / getWidth());
            if (motionEvent != null) {
                getScrollFeedbackProvider().f1497a.onScrollLimit(motionEvent.getDeviceId(), motionEvent.getSource(), i7, true);
            }
            if (!edgeEffect.isFinished()) {
                edgeEffect.onRelease();
            }
        }
        z7 = false;
        if (edgeEffect2.isFinished()) {
            postInvalidateOnAnimation();
            z8 = z7;
        } else {
            postInvalidateOnAnimation();
            z8 = z7;
        }
        if (z8) {
            velocityTracker.clear();
        }
        if (i9 == 1) {
            w(i9);
            edgeEffect2.onRelease();
            edgeEffect.onRelease();
        }
        return i12;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        if (this.f4269z) {
            this.f4247B = view2;
        } else {
            Rect rect = this.t;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int iH = h(rect);
            if (iH != 0) {
                scrollBy(0, iH);
            }
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z6) {
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        int iH = h(rect);
        boolean z7 = iH != 0;
        if (z7) {
            if (z6) {
                scrollBy(0, iH);
                return z7;
            }
            t(0, iH, false);
        }
        return z7;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z6) {
        VelocityTracker velocityTracker;
        if (z6 && (velocityTracker = this.f4248D) != null) {
            velocityTracker.recycle();
            this.f4248D = null;
        }
        super.requestDisallowInterceptTouchEvent(z6);
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        this.f4269z = true;
        super.requestLayout();
    }

    public final boolean s(EdgeEffect edgeEffect, int i6) {
        if (i6 > 0) {
            return true;
        }
        float fQ = a.q(edgeEffect) * getHeight();
        float fAbs = Math.abs(-i6) * 0.35f;
        float f4 = this.r * 0.015f;
        double dLog = Math.log(fAbs / f4);
        double d6 = f4243T;
        return ((float) (Math.exp((d6 / (d6 - 1.0d)) * dLog) * ((double) f4))) < fQ;
    }

    @Override // android.view.View
    public final void scrollTo(int i6, int i7) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int width = (getWidth() - getPaddingLeft()) - getPaddingRight();
            int width2 = childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
            int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int height2 = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            if (width >= width2 || i6 < 0) {
                i6 = 0;
            } else if (width + i6 > width2) {
                i6 = width2 - width;
            }
            if (height >= height2 || i7 < 0) {
                i7 = 0;
            } else if (height + i7 > height2) {
                i7 = height2 - height;
            }
            if (i6 == getScrollX() && i7 == getScrollY()) {
                return;
            }
            super.scrollTo(i6, i7);
        }
    }

    public void setFillViewport(boolean z6) {
        if (z6 != this.f4249E) {
            this.f4249E = z6;
            requestLayout();
        }
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z6) {
        C0028g c0028g = this.f4261Q;
        if (c0028g.f1486a) {
            NestedScrollView nestedScrollView = (NestedScrollView) c0028g.f1489d;
            Field field = AbstractC0046z.f1508a;
            nestedScrollView.stopNestedScroll();
        }
        c0028g.f1486a = z6;
    }

    public void setSmoothScrollingEnabled(boolean z6) {
        this.f4250F = z6;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return true;
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i6) {
        return u(i6, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        w(0);
    }

    public final void t(int i6, int i7, boolean z6) {
        if (getChildCount() == 0) {
            return;
        }
        if (AnimationUtils.currentAnimationTimeMillis() - this.f4264s > 250) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int height = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            int iMax = Math.max(0, Math.min(i7 + scrollY, Math.max(0, height - height2))) - scrollY;
            this.f4265u.startScroll(getScrollX(), scrollY, 0, iMax, 250);
            if (z6) {
                u(2, 1);
            } else {
                w(1);
            }
            this.f4258N = getScrollY();
            postInvalidateOnAnimation();
        } else {
            if (!this.f4265u.isFinished()) {
                this.f4265u.abortAnimation();
                w(1);
            }
            scrollBy(i6, i7);
        }
        this.f4264s = AnimationUtils.currentAnimationTimeMillis();
    }

    public final boolean u(int i6, int i7) {
        boolean zOnStartNestedScroll;
        C0028g c0028g = this.f4261Q;
        View view = (NestedScrollView) c0028g.f1489d;
        if (c0028g.c(i7) != null) {
            return true;
        }
        if (c0028g.f1486a) {
            View view2 = view;
            for (ViewParent parent = view.getParent(); parent != null; parent = parent.getParent()) {
                boolean z6 = parent instanceof InterfaceC0029h;
                if (z6) {
                    zOnStartNestedScroll = ((InterfaceC0029h) parent).f(view2, view, i6, i7);
                } else if (i7 == 0) {
                    try {
                        zOnStartNestedScroll = parent.onStartNestedScroll(view2, view, i6);
                    } catch (AbstractMethodError e6) {
                        Log.e("ViewParentCompat", "ViewParent " + parent + " does not implement interface method onStartNestedScroll", e6);
                        zOnStartNestedScroll = false;
                    }
                } else {
                    zOnStartNestedScroll = false;
                }
                if (zOnStartNestedScroll) {
                    if (i7 == 0) {
                        c0028g.f1487b = parent;
                    } else if (i7 == 1) {
                        c0028g.f1488c = parent;
                    }
                    if (z6) {
                        ((InterfaceC0029h) parent).a(view2, view, i6, i7);
                        return true;
                    }
                    if (i7 != 0) {
                        return true;
                    }
                    try {
                        parent.onNestedScrollAccepted(view2, view, i6);
                        return true;
                    } catch (AbstractMethodError e7) {
                        Log.e("ViewParentCompat", "ViewParent " + parent + " does not implement interface method onNestedScrollAccepted", e7);
                        return true;
                    }
                }
                if (parent instanceof View) {
                    view2 = (View) parent;
                }
            }
        }
        return false;
    }

    public final boolean v(MotionEvent motionEvent) {
        boolean z6;
        EdgeEffect edgeEffect = this.f4266v;
        if (a.q(edgeEffect) != 0.0f) {
            a.z(edgeEffect, 0.0f, motionEvent.getX() / getWidth());
            z6 = true;
        } else {
            z6 = false;
        }
        EdgeEffect edgeEffect2 = this.f4267w;
        if (a.q(edgeEffect2) == 0.0f) {
            return z6;
        }
        a.z(edgeEffect2, 0.0f, 1.0f - (motionEvent.getX() / getWidth()));
        return true;
    }

    public final void w(int i6) {
        C0028g c0028g = this.f4261Q;
        ViewParent viewParentC = c0028g.c(i6);
        if (viewParentC != null) {
            NestedScrollView nestedScrollView = (NestedScrollView) c0028g.f1489d;
            if (viewParentC instanceof InterfaceC0029h) {
                ((InterfaceC0029h) viewParentC).b(nestedScrollView, i6);
            } else if (i6 == 0) {
                try {
                    viewParentC.onStopNestedScroll(nestedScrollView);
                } catch (AbstractMethodError e6) {
                    Log.e("ViewParentCompat", "ViewParent " + viewParentC + " does not implement interface method onStopNestedScroll", e6);
                }
            }
            if (i6 == 0) {
                c0028g.f1487b = null;
            } else {
                if (i6 != 1) {
                    return;
                }
                c0028g.f1488c = null;
            }
        }
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i6) {
        if (getChildCount() <= 0) {
            super.addView(view, i6);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i6, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i6, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void setOnScrollChangeListener(f fVar) {
    }
}
