package androidx.core.graphics.drawable;

import B.a;
import B.c;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import h6.h;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import org.apache.tika.metadata.TikaCoreProperties;

/* JADX INFO: loaded from: classes.dex */
public class IconCompat extends CustomVersionedParcelable {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final PorterDuff.Mode f4232k = PorterDuff.Mode.SRC_IN;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f4233a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f4234b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public byte[] f4235c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Parcelable f4236d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f4237e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f4238f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ColorStateList f4239g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public PorterDuff.Mode f4240h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public String f4241i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public String f4242j;

    public IconCompat() {
        this.f4233a = -1;
        this.f4235c = null;
        this.f4236d = null;
        this.f4237e = 0;
        this.f4238f = 0;
        this.f4239g = null;
        this.f4240h = f4232k;
        this.f4241i = null;
    }

    public static IconCompat c(Bundle bundle) {
        int i6 = bundle.getInt("type");
        IconCompat iconCompat = new IconCompat(i6);
        iconCompat.f4237e = bundle.getInt("int1");
        iconCompat.f4238f = bundle.getInt("int2");
        iconCompat.f4242j = bundle.getString("string1");
        if (bundle.containsKey("tint_list")) {
            iconCompat.f4239g = (ColorStateList) bundle.getParcelable("tint_list");
        }
        if (bundle.containsKey("tint_mode")) {
            iconCompat.f4240h = PorterDuff.Mode.valueOf(bundle.getString("tint_mode"));
        }
        switch (i6) {
            case -1:
            case 1:
            case 5:
                iconCompat.f4234b = bundle.getParcelable("obj");
                return iconCompat;
            case 0:
            default:
                Log.w("IconCompat", "Unknown type " + i6);
                return null;
            case 2:
            case 4:
            case 6:
                iconCompat.f4234b = bundle.getString("obj");
                return iconCompat;
            case 3:
                iconCompat.f4234b = bundle.getByteArray("obj");
                return iconCompat;
        }
    }

    public static IconCompat d(Icon icon) {
        icon.getClass();
        int I6 = h.I(icon);
        if (I6 == 2) {
            return g(null, h.G(icon), h.F(icon));
        }
        if (I6 == 4) {
            Uri uriJ = h.J(icon);
            uriJ.getClass();
            String string = uriJ.toString();
            string.getClass();
            IconCompat iconCompat = new IconCompat(4);
            iconCompat.f4234b = string;
            return iconCompat;
        }
        if (I6 != 6) {
            IconCompat iconCompat2 = new IconCompat(-1);
            iconCompat2.f4234b = icon;
            return iconCompat2;
        }
        Uri uriJ2 = h.J(icon);
        uriJ2.getClass();
        String string2 = uriJ2.toString();
        string2.getClass();
        IconCompat iconCompat3 = new IconCompat(6);
        iconCompat3.f4234b = string2;
        return iconCompat3;
    }

    public static Bitmap e(Bitmap bitmap, boolean z6) {
        int iMin = (int) (Math.min(bitmap.getWidth(), bitmap.getHeight()) * 0.6666667f);
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(iMin, iMin, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmapCreateBitmap);
        Paint paint = new Paint(3);
        float f4 = iMin;
        float f7 = 0.5f * f4;
        float f8 = 0.9166667f * f7;
        if (z6) {
            float f9 = 0.010416667f * f4;
            paint.setColor(0);
            paint.setShadowLayer(f9, 0.0f, f4 * 0.020833334f, 1023410176);
            canvas.drawCircle(f7, f7, f8, paint);
            paint.setShadowLayer(f9, 0.0f, 0.0f, 503316480);
            canvas.drawCircle(f7, f7, f8, paint);
            paint.clearShadowLayer();
        }
        paint.setColor(-16777216);
        Shader.TileMode tileMode = Shader.TileMode.CLAMP;
        BitmapShader bitmapShader = new BitmapShader(bitmap, tileMode, tileMode);
        Matrix matrix = new Matrix();
        matrix.setTranslate((-(bitmap.getWidth() - iMin)) / 2.0f, (-(bitmap.getHeight() - iMin)) / 2.0f);
        bitmapShader.setLocalMatrix(matrix);
        paint.setShader(bitmapShader);
        canvas.drawCircle(f7, f7, f8, paint);
        canvas.setBitmap(null);
        return bitmapCreateBitmap;
    }

    public static IconCompat f(Bitmap bitmap) {
        bitmap.getClass();
        IconCompat iconCompat = new IconCompat(1);
        iconCompat.f4234b = bitmap;
        return iconCompat;
    }

    public static IconCompat g(Resources resources, String str, int i6) {
        str.getClass();
        if (i6 == 0) {
            throw new IllegalArgumentException("Drawable resource ID must not be 0");
        }
        IconCompat iconCompat = new IconCompat(2);
        iconCompat.f4237e = i6;
        if (resources != null) {
            try {
                iconCompat.f4234b = resources.getResourceName(i6);
            } catch (Resources.NotFoundException unused) {
                throw new IllegalArgumentException("Icon resource cannot be found");
            }
        } else {
            iconCompat.f4234b = str;
        }
        iconCompat.f4242j = str;
        return iconCompat;
    }

    public final int h() {
        int i6 = this.f4233a;
        if (i6 == -1) {
            return h.F(this.f4234b);
        }
        if (i6 == 2) {
            return this.f4237e;
        }
        throw new IllegalStateException("called getResId() on " + this);
    }

    public final Uri i() {
        int i6 = this.f4233a;
        if (i6 == -1) {
            return h.J(this.f4234b);
        }
        if (i6 == 4 || i6 == 6) {
            return Uri.parse((String) this.f4234b);
        }
        throw new IllegalStateException("called getUri() on " + this);
    }

    public final Icon j(Context context) {
        Icon iconCreateWithBitmap;
        String strG;
        InputStream inputStreamOpenInputStream;
        switch (this.f4233a) {
            case -1:
                return (Icon) this.f4234b;
            case 0:
            default:
                throw new IllegalArgumentException("Unknown type");
            case 1:
                iconCreateWithBitmap = Icon.createWithBitmap((Bitmap) this.f4234b);
                break;
            case 2:
                int i6 = this.f4233a;
                if (i6 == -1) {
                    strG = h.G(this.f4234b);
                } else {
                    if (i6 != 2) {
                        throw new IllegalStateException("called getResPackage() on " + this);
                    }
                    String str = this.f4242j;
                    strG = (str == null || TextUtils.isEmpty(str)) ? ((String) this.f4234b).split(TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER, -1)[0] : this.f4242j;
                }
                iconCreateWithBitmap = Icon.createWithResource(strG, this.f4237e);
                break;
            case 3:
                iconCreateWithBitmap = Icon.createWithData((byte[]) this.f4234b, this.f4237e, this.f4238f);
                break;
            case 4:
                iconCreateWithBitmap = Icon.createWithContentUri((String) this.f4234b);
                break;
            case 5:
                iconCreateWithBitmap = Build.VERSION.SDK_INT < 26 ? Icon.createWithBitmap(e((Bitmap) this.f4234b, false)) : a.b((Bitmap) this.f4234b);
                break;
            case 6:
                if (Build.VERSION.SDK_INT >= 30) {
                    iconCreateWithBitmap = c.a(i());
                } else {
                    if (context == null) {
                        throw new IllegalArgumentException("Context is required to resolve the file uri of the icon: " + i());
                    }
                    Uri uriI = i();
                    String scheme = uriI.getScheme();
                    if ("content".equals(scheme) || "file".equals(scheme)) {
                        try {
                            inputStreamOpenInputStream = context.getContentResolver().openInputStream(uriI);
                        } catch (Exception e6) {
                            Log.w("IconCompat", "Unable to load image from URI: " + uriI, e6);
                            inputStreamOpenInputStream = null;
                        }
                    } else {
                        try {
                            inputStreamOpenInputStream = new FileInputStream(new File((String) this.f4234b));
                        } catch (FileNotFoundException e7) {
                            Log.w("IconCompat", "Unable to load image from path: " + uriI, e7);
                            inputStreamOpenInputStream = null;
                        }
                    }
                    if (inputStreamOpenInputStream == null) {
                        throw new IllegalStateException("Cannot load adaptive icon from uri: " + i());
                    }
                    if (Build.VERSION.SDK_INT < 26) {
                        iconCreateWithBitmap = Icon.createWithBitmap(e(BitmapFactory.decodeStream(inputStreamOpenInputStream), false));
                    } else {
                        iconCreateWithBitmap = a.b(BitmapFactory.decodeStream(inputStreamOpenInputStream));
                    }
                }
                break;
        }
        ColorStateList colorStateList = this.f4239g;
        if (colorStateList != null) {
            iconCreateWithBitmap.setTintList(colorStateList);
        }
        PorterDuff.Mode mode = this.f4240h;
        if (mode != f4232k) {
            iconCreateWithBitmap.setTintMode(mode);
        }
        return iconCreateWithBitmap;
    }

    public final String toString() {
        String str;
        if (this.f4233a == -1) {
            return String.valueOf(this.f4234b);
        }
        StringBuilder sb = new StringBuilder("Icon(typ=");
        switch (this.f4233a) {
            case 1:
                str = "BITMAP";
                break;
            case 2:
                str = "RESOURCE";
                break;
            case 3:
                str = "DATA";
                break;
            case 4:
                str = "URI";
                break;
            case 5:
                str = "BITMAP_MASKABLE";
                break;
            case 6:
                str = "URI_MASKABLE";
                break;
            default:
                str = "UNKNOWN";
                break;
        }
        sb.append(str);
        switch (this.f4233a) {
            case 1:
            case 5:
                sb.append(" size=");
                sb.append(((Bitmap) this.f4234b).getWidth());
                sb.append("x");
                sb.append(((Bitmap) this.f4234b).getHeight());
                break;
            case 2:
                sb.append(" pkg=");
                sb.append(this.f4242j);
                sb.append(" id=");
                sb.append(String.format("0x%08x", Integer.valueOf(h())));
                break;
            case 3:
                sb.append(" len=");
                sb.append(this.f4237e);
                if (this.f4238f != 0) {
                    sb.append(" off=");
                    sb.append(this.f4238f);
                }
                break;
            case 4:
            case 6:
                sb.append(" uri=");
                sb.append(this.f4234b);
                break;
        }
        if (this.f4239g != null) {
            sb.append(" tint=");
            sb.append(this.f4239g);
        }
        if (this.f4240h != f4232k) {
            sb.append(" mode=");
            sb.append(this.f4240h);
        }
        sb.append(")");
        return sb.toString();
    }

    public IconCompat(int i6) {
        this.f4235c = null;
        this.f4236d = null;
        this.f4237e = 0;
        this.f4238f = 0;
        this.f4239g = null;
        this.f4240h = f4232k;
        this.f4241i = null;
        this.f4233a = i6;
    }
}
