package androidx.core.graphics.drawable;

import S1.a;
import S1.b;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcel;
import android.os.Parcelable;
import java.nio.charset.Charset;
import org.apache.tika.metadata.TikaCoreProperties;

/* JADX INFO: loaded from: classes.dex */
public class IconCompatParcelizer {
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static IconCompat read(a aVar) {
        IconCompat iconCompat = new IconCompat();
        iconCompat.f4233a = aVar.f(iconCompat.f4233a, 1);
        byte[] bArr = iconCompat.f4235c;
        if (aVar.e(2)) {
            Parcel parcel = ((b) aVar).f3487e;
            int i6 = parcel.readInt();
            if (i6 < 0) {
                bArr = null;
            } else {
                byte[] bArr2 = new byte[i6];
                parcel.readByteArray(bArr2);
                bArr = bArr2;
            }
        }
        iconCompat.f4235c = bArr;
        iconCompat.f4236d = aVar.g(iconCompat.f4236d, 3);
        iconCompat.f4237e = aVar.f(iconCompat.f4237e, 4);
        iconCompat.f4238f = aVar.f(iconCompat.f4238f, 5);
        iconCompat.f4239g = (ColorStateList) aVar.g(iconCompat.f4239g, 6);
        String string = iconCompat.f4241i;
        if (aVar.e(7)) {
            string = ((b) aVar).f3487e.readString();
        }
        iconCompat.f4241i = string;
        String string2 = iconCompat.f4242j;
        if (aVar.e(8)) {
            string2 = ((b) aVar).f3487e.readString();
        }
        iconCompat.f4242j = string2;
        iconCompat.f4240h = PorterDuff.Mode.valueOf(iconCompat.f4241i);
        switch (iconCompat.f4233a) {
            case -1:
                Parcelable parcelable = iconCompat.f4236d;
                if (parcelable == null) {
                    throw new IllegalArgumentException("Invalid icon");
                }
                iconCompat.f4234b = parcelable;
                return iconCompat;
            case 0:
            default:
                return iconCompat;
            case 1:
            case 5:
                Parcelable parcelable2 = iconCompat.f4236d;
                if (parcelable2 != null) {
                    iconCompat.f4234b = parcelable2;
                    return iconCompat;
                }
                byte[] bArr3 = iconCompat.f4235c;
                iconCompat.f4234b = bArr3;
                iconCompat.f4233a = 3;
                iconCompat.f4237e = 0;
                iconCompat.f4238f = bArr3.length;
                return iconCompat;
            case 2:
            case 4:
            case 6:
                String str = new String(iconCompat.f4235c, Charset.forName("UTF-16"));
                iconCompat.f4234b = str;
                if (iconCompat.f4233a == 2 && iconCompat.f4242j == null) {
                    iconCompat.f4242j = str.split(TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER, -1)[0];
                }
                return iconCompat;
            case 3:
                iconCompat.f4234b = iconCompat.f4235c;
                return iconCompat;
        }
    }

    public static void write(IconCompat iconCompat, a aVar) {
        aVar.getClass();
        iconCompat.f4241i = iconCompat.f4240h.name();
        switch (iconCompat.f4233a) {
            case -1:
                iconCompat.f4236d = (Parcelable) iconCompat.f4234b;
                break;
            case 1:
            case 5:
                iconCompat.f4236d = (Parcelable) iconCompat.f4234b;
                break;
            case 2:
                iconCompat.f4235c = ((String) iconCompat.f4234b).getBytes(Charset.forName("UTF-16"));
                break;
            case 3:
                iconCompat.f4235c = (byte[]) iconCompat.f4234b;
                break;
            case 4:
            case 6:
                iconCompat.f4235c = iconCompat.f4234b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i6 = iconCompat.f4233a;
        if (-1 != i6) {
            aVar.j(i6, 1);
        }
        byte[] bArr = iconCompat.f4235c;
        if (bArr != null) {
            aVar.i(2);
            Parcel parcel = ((b) aVar).f3487e;
            parcel.writeInt(bArr.length);
            parcel.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.f4236d;
        if (parcelable != null) {
            aVar.k(parcelable, 3);
        }
        int i7 = iconCompat.f4237e;
        if (i7 != 0) {
            aVar.j(i7, 4);
        }
        int i8 = iconCompat.f4238f;
        if (i8 != 0) {
            aVar.j(i8, 5);
        }
        ColorStateList colorStateList = iconCompat.f4239g;
        if (colorStateList != null) {
            aVar.k(colorStateList, 6);
        }
        String str = iconCompat.f4241i;
        if (str != null) {
            aVar.i(7);
            ((b) aVar).f3487e.writeString(str);
        }
        String str2 = iconCompat.f4242j;
        if (str2 != null) {
            aVar.i(8);
            ((b) aVar).f3487e.writeString(str2);
        }
    }
}
