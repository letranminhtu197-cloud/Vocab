package androidx.work;

import A5.h;
import C2.j;
import android.content.Context;
import java.util.concurrent.ExecutorService;
import p018d2.H;
import p018d2.x;
import p025e2.v;
import p121u.k;

/* JADX INFO: loaded from: classes.dex */
public abstract class Worker extends x {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Worker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
        h.e(context, "context");
        h.e(workerParameters, "workerParams");
    }

    @Override // p018d2.x
    public final k a() {
        ExecutorService executorService = this.f5297b.f4518c;
        h.d(executorService, "getBackgroundExecutor(...)");
        return v.w(new j(executorService, new H(this, 1), 14));
    }

    @Override // p018d2.x
    public final k b() {
        ExecutorService executorService = this.f5297b.f4518c;
        h.d(executorService, "getBackgroundExecutor(...)");
        return v.w(new j(executorService, new H(this, 0), 14));
    }

    public abstract p018d2.v c();
}
