package androidx.work.impl;

import A5.e;
import A5.o;
import C1.C0008i;
import C1.z;
import androidx.work.impl.WorkDatabase_Impl;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import p025e2.C0298b;
import p025e2.q;
import p025e2.s;
import p071l2.d;
import p071l2.f;
import p071l2.g;
import p071l2.m;
import p071l2.n;
import p071l2.t;
import p071l2.v;
import p074l5.j;
import p154z5.a;

/* JADX INFO: loaded from: classes.dex */
public final class WorkDatabase_Impl extends WorkDatabase {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final j f4522k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final j f4523l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final j f4524m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final j f4525n;
    public final j o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final j f4526p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final j f4527q;

    public WorkDatabase_Impl() {
        final int i6 = 0;
        this.f4522k = new j(new a(this) { // from class: e2.r

            /* JADX INFO: renamed from: s, reason: collision with root package name */
            public final /* synthetic */ WorkDatabase_Impl f5473s;

            {
                this.f5473s = this;
            }

            @Override // p154z5.a
            public final Object b() {
                switch (i6) {
                    case 0:
                        return new t(this.f5473s);
                    case 1:
                        return new d(this.f5473s);
                    case 2:
                        return new v(this.f5473s);
                    case 3:
                        return new p071l2.j(this.f5473s);
                    case 4:
                        return new m(this.f5473s);
                    case 5:
                        return new n(this.f5473s);
                    default:
                        return new f(this.f5473s);
                }
            }
        });
        final int i7 = 1;
        this.f4523l = new j(new a(this) { // from class: e2.r

            /* JADX INFO: renamed from: s, reason: collision with root package name */
            public final /* synthetic */ WorkDatabase_Impl f5473s;

            {
                this.f5473s = this;
            }

            @Override // p154z5.a
            public final Object b() {
                switch (i7) {
                    case 0:
                        return new t(this.f5473s);
                    case 1:
                        return new d(this.f5473s);
                    case 2:
                        return new v(this.f5473s);
                    case 3:
                        return new p071l2.j(this.f5473s);
                    case 4:
                        return new m(this.f5473s);
                    case 5:
                        return new n(this.f5473s);
                    default:
                        return new f(this.f5473s);
                }
            }
        });
        final int i8 = 2;
        this.f4524m = new j(new a(this) { // from class: e2.r

            /* JADX INFO: renamed from: s, reason: collision with root package name */
            public final /* synthetic */ WorkDatabase_Impl f5473s;

            {
                this.f5473s = this;
            }

            @Override // p154z5.a
            public final Object b() {
                switch (i8) {
                    case 0:
                        return new t(this.f5473s);
                    case 1:
                        return new d(this.f5473s);
                    case 2:
                        return new v(this.f5473s);
                    case 3:
                        return new p071l2.j(this.f5473s);
                    case 4:
                        return new m(this.f5473s);
                    case 5:
                        return new n(this.f5473s);
                    default:
                        return new f(this.f5473s);
                }
            }
        });
        final int i9 = 3;
        this.f4525n = new j(new a(this) { // from class: e2.r

            /* JADX INFO: renamed from: s, reason: collision with root package name */
            public final /* synthetic */ WorkDatabase_Impl f5473s;

            {
                this.f5473s = this;
            }

            @Override // p154z5.a
            public final Object b() {
                switch (i9) {
                    case 0:
                        return new t(this.f5473s);
                    case 1:
                        return new d(this.f5473s);
                    case 2:
                        return new v(this.f5473s);
                    case 3:
                        return new p071l2.j(this.f5473s);
                    case 4:
                        return new m(this.f5473s);
                    case 5:
                        return new n(this.f5473s);
                    default:
                        return new f(this.f5473s);
                }
            }
        });
        final int i10 = 4;
        this.o = new j(new a(this) { // from class: e2.r

            /* JADX INFO: renamed from: s, reason: collision with root package name */
            public final /* synthetic */ WorkDatabase_Impl f5473s;

            {
                this.f5473s = this;
            }

            @Override // p154z5.a
            public final Object b() {
                switch (i10) {
                    case 0:
                        return new t(this.f5473s);
                    case 1:
                        return new d(this.f5473s);
                    case 2:
                        return new v(this.f5473s);
                    case 3:
                        return new p071l2.j(this.f5473s);
                    case 4:
                        return new m(this.f5473s);
                    case 5:
                        return new n(this.f5473s);
                    default:
                        return new f(this.f5473s);
                }
            }
        });
        final int i11 = 5;
        this.f4526p = new j(new a(this) { // from class: e2.r

            /* JADX INFO: renamed from: s, reason: collision with root package name */
            public final /* synthetic */ WorkDatabase_Impl f5473s;

            {
                this.f5473s = this;
            }

            @Override // p154z5.a
            public final Object b() {
                switch (i11) {
                    case 0:
                        return new t(this.f5473s);
                    case 1:
                        return new d(this.f5473s);
                    case 2:
                        return new v(this.f5473s);
                    case 3:
                        return new p071l2.j(this.f5473s);
                    case 4:
                        return new m(this.f5473s);
                    case 5:
                        return new n(this.f5473s);
                    default:
                        return new f(this.f5473s);
                }
            }
        });
        final int i12 = 6;
        this.f4527q = new j(new a(this) { // from class: e2.r

            /* JADX INFO: renamed from: s, reason: collision with root package name */
            public final /* synthetic */ WorkDatabase_Impl f5473s;

            {
                this.f5473s = this;
            }

            @Override // p154z5.a
            public final Object b() {
                switch (i12) {
                    case 0:
                        return new t(this.f5473s);
                    case 1:
                        return new d(this.f5473s);
                    case 2:
                        return new v(this.f5473s);
                    case 3:
                        return new p071l2.j(this.f5473s);
                    case 4:
                        return new m(this.f5473s);
                    case 5:
                        return new n(this.f5473s);
                    default:
                        return new f(this.f5473s);
                }
            }
        });
    }

    @Override // C1.x
    public final List c(LinkedHashMap linkedHashMap) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new C0298b(13, 14, 10));
        arrayList.add(new q(0));
        int i6 = 17;
        arrayList.add(new C0298b(16, i6, 11));
        int i7 = 18;
        arrayList.add(new C0298b(i6, i7, 12));
        arrayList.add(new C0298b(i7, 19, 13));
        arrayList.add(new q(1));
        arrayList.add(new C0298b(20, 21, 14));
        int i8 = 23;
        arrayList.add(new C0298b(22, i8, 15));
        arrayList.add(new C0298b(i8, 24, 16));
        return arrayList;
    }

    @Override // C1.x
    public final C0008i d() {
        return new C0008i(this, new LinkedHashMap(), new LinkedHashMap(), "Dependency", "WorkSpec", "WorkTag", "SystemIdInfo", "WorkName", "WorkProgress", "Preference");
    }

    @Override // C1.x
    public final z e() {
        return new s(this);
    }

    @Override // C1.x
    public final Set i() {
        return new LinkedHashSet();
    }

    @Override // C1.x
    public final LinkedHashMap j() {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        e eVarA = o.a(t.class);
        p081m5.m mVar = p081m5.m.r;
        linkedHashMap.put(eVarA, mVar);
        linkedHashMap.put(o.a(d.class), mVar);
        linkedHashMap.put(o.a(v.class), mVar);
        linkedHashMap.put(o.a(p071l2.j.class), mVar);
        linkedHashMap.put(o.a(m.class), mVar);
        linkedHashMap.put(o.a(n.class), mVar);
        linkedHashMap.put(o.a(f.class), mVar);
        linkedHashMap.put(o.a(g.class), mVar);
        return linkedHashMap;
    }

    @Override // androidx.work.impl.WorkDatabase
    public final d q() {
        return (d) this.f4523l.getValue();
    }

    @Override // androidx.work.impl.WorkDatabase
    public final f r() {
        return (f) this.f4527q.getValue();
    }

    @Override // androidx.work.impl.WorkDatabase
    public final p071l2.j s() {
        return (p071l2.j) this.f4525n.getValue();
    }

    @Override // androidx.work.impl.WorkDatabase
    public final m t() {
        return (m) this.o.getValue();
    }

    @Override // androidx.work.impl.WorkDatabase
    public final n u() {
        return (n) this.f4526p.getValue();
    }

    @Override // androidx.work.impl.WorkDatabase
    public final t v() {
        return (t) this.f4522k.getValue();
    }

    @Override // androidx.work.impl.WorkDatabase
    public final v w() {
        return (v) this.f4524m.getValue();
    }
}
