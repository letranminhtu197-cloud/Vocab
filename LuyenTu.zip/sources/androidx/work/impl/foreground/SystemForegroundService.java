package androidx.work.impl.foreground;

import A5.h;
import B4.e;
import C1.C;
import E.a;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;
import androidx.lifecycle.AbstractServiceC0199v;
import java.util.UUID;
import p018d2.l;
import p018d2.y;
import p025e2.t;
import p025e2.v;
import p065k2.b;

/* JADX INFO: loaded from: classes.dex */
public class SystemForegroundService extends AbstractServiceC0199v {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final String f4533v = y.g("SystemFgService");

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f4534s;
    public b t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public NotificationManager f4535u;

    public final void a() {
        this.f4535u = (NotificationManager) getApplicationContext().getSystemService("notification");
        b bVar = new b(getApplicationContext());
        this.t = bVar;
        if (bVar.f7284z != null) {
            y.e().c(b.f7278A, "A callback already exists.");
        } else {
            bVar.f7284z = this;
        }
    }

    @Override // androidx.lifecycle.AbstractServiceC0199v, android.app.Service
    public final void onCreate() {
        super.onCreate();
        a();
    }

    @Override // androidx.lifecycle.AbstractServiceC0199v, android.app.Service
    public final void onDestroy() {
        super.onDestroy();
        this.t.e();
    }

    @Override // android.app.Service
    public final int onStartCommand(Intent intent, int i6, int i7) {
        super.onStartCommand(intent, i6, i7);
        boolean z6 = this.f4534s;
        String str = f4533v;
        if (z6) {
            y.e().f(str, "Re-initializing SystemForegroundService after a request to shut-down.");
            this.t.e();
            a();
            this.f4534s = false;
        }
        if (intent == null) {
            return 3;
        }
        b bVar = this.t;
        bVar.getClass();
        String str2 = b.f7278A;
        String action = intent.getAction();
        if ("ACTION_START_FOREGROUND".equals(action)) {
            y.e().f(str2, "Started foreground service " + intent);
            String stringExtra = intent.getStringExtra("KEY_WORKSPEC_ID");
            ((C) bVar.f7279s.r).execute(new a(bVar, stringExtra, 10, false));
            bVar.d(intent);
            return 3;
        }
        if ("ACTION_NOTIFY".equals(action)) {
            bVar.d(intent);
            return 3;
        }
        if (!"ACTION_CANCEL_WORK".equals(action)) {
            if (!"ACTION_STOP_FOREGROUND".equals(action)) {
                return 3;
            }
            y.e().f(str2, "Stopping foreground service");
            SystemForegroundService systemForegroundService = bVar.f7284z;
            if (systemForegroundService == null) {
                return 3;
            }
            systemForegroundService.f4534s = true;
            y.e().a(str, "Shutting down.");
            if (Build.VERSION.SDK_INT >= 26) {
                systemForegroundService.stopForeground(true);
            }
            systemForegroundService.stopSelf(i7);
            return 3;
        }
        y.e().f(str2, "Stopping foreground work for " + intent);
        String stringExtra2 = intent.getStringExtra("KEY_WORKSPEC_ID");
        if (stringExtra2 == null || TextUtils.isEmpty(stringExtra2)) {
            return 3;
        }
        t tVar = bVar.r;
        UUID uuidFromString = UUID.fromString(stringExtra2);
        tVar.getClass();
        h.e(uuidFromString, "id");
        l lVar = tVar.f5479b.f5252m;
        C c2 = (C) tVar.f5481d.r;
        h.d(c2, "getSerialTaskExecutor(...)");
        v.C(lVar, "CancelWorkById", c2, new e(tVar, uuidFromString, 7));
        return 3;
    }

    @Override // android.app.Service
    public final void onTimeout(int i6) {
        if (Build.VERSION.SDK_INT >= 35) {
            return;
        }
        this.t.f(i6, 2048);
    }

    public final void onTimeout(int i6, int i7) {
        this.t.f(i6, i7);
    }
}
