package androidx.work.impl.diagnostics;

import A4.d;
import A5.h;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.work.impl.workers.DiagnosticsWorker;
import java.util.List;
import p018d2.G;
import p018d2.n;
import p018d2.y;
import p025e2.m;
import p025e2.t;

/* JADX INFO: loaded from: classes.dex */
public class DiagnosticsReceiver extends BroadcastReceiver {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final String f4532a = y.g("DiagnosticsRcvr");

    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        if (intent == null) {
            return;
        }
        y yVarE = y.e();
        String str = f4532a;
        yVarE.a(str, "Requesting diagnostics");
        try {
            h.e(context, "context");
            t tVarX0 = t.x0(context);
            List listG = G.G(new d(DiagnosticsWorker.class).v());
            if (listG.isEmpty()) {
                throw new IllegalArgumentException("enqueue needs at least one WorkRequest.");
            }
            new m(tVarX0, null, n.f5281s, listG).f0();
        } catch (IllegalStateException e6) {
            y.e().d(str, "WorkManager is not initialized", e6);
        }
    }
}
