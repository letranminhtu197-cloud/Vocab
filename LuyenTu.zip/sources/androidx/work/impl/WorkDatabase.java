package androidx.work.impl;

import C1.x;
import p071l2.d;
import p071l2.f;
import p071l2.j;
import p071l2.m;
import p071l2.n;
import p071l2.t;
import p071l2.v;

/* JADX INFO: loaded from: classes.dex */
public abstract class WorkDatabase extends x {
    public abstract d q();

    public abstract f r();

    public abstract j s();

    public abstract m t();

    public abstract n u();

    public abstract t v();

    public abstract v w();
}
