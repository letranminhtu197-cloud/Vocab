package androidx.work.impl.workers;

import A5.h;
import B2.d;
import B4.j;
import K5.AbstractC0114s;
import K5.AbstractC0120y;
import X2.a;
import android.content.Context;
import android.os.Build;
import androidx.work.CoroutineWorker;
import androidx.work.WorkerParameters;
import java.util.ArrayList;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicInteger;
import p018d2.l;
import p018d2.t;
import p018d2.u;
import p018d2.w;
import p018d2.x;
import p018d2.y;
import p044h2.n;
import p071l2.p;
import p090o2.b;
import p090o2.e;
import p090o2.f;
import p090o2.g;
import p090o2.k;
import p116s5.c;

/* JADX INFO: loaded from: classes.dex */
public final class ConstraintTrackingWorker extends CoroutineWorker {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final WorkerParameters f4537g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ConstraintTrackingWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
        h.e(context, "appContext");
        h.e(workerParameters, "workerParameters");
        this.f4537g = workerParameters;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public static final Object e(ConstraintTrackingWorker constraintTrackingWorker, x xVar, n nVar, p pVar, c cVar) {
        p090o2.c cVar2;
        if (cVar instanceof p090o2.c) {
            cVar2 = (p090o2.c) cVar;
            int i6 = cVar2.f8022w;
            if ((i6 & Integer.MIN_VALUE) != 0) {
                cVar2.f8022w = i6 - Integer.MIN_VALUE;
            } else {
                cVar2 = new p090o2.c(constraintTrackingWorker, cVar);
            }
        } else {
            cVar2 = new p090o2.c(constraintTrackingWorker, cVar);
        }
        Object objF = cVar2.f8020u;
        int i7 = cVar2.f8022w;
        if (i7 == 0) {
            a.O(objF);
            e eVar = new e(xVar, nVar, pVar, null);
            cVar2.f8022w = 1;
            objF = AbstractC0120y.f(eVar, cVar2);
            p109r5.a aVar = p109r5.a.r;
            if (objF == aVar) {
                return aVar;
            }
        } else {
            if (i7 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            a.O(objF);
        }
        h.d(objF, "coroutineScope(...)");
        return objF;
    }

    /* JADX WARN: Code duplicated, block: B:66:0x016d  */
    /* JADX WARN: Code duplicated, block: B:68:0x0173  */
    /* JADX WARN: Code duplicated, block: B:69:0x0176  */
    /* JADX WARN: Code duplicated, block: B:71:0x017c  */
    /* JADX WARN: Code duplicated, block: B:72:0x0181  */
    /* JADX WARN: Code duplicated, block: B:74:0x0185  */
    /* JADX WARN: Code duplicated, block: B:76:0x0190  */
    /* JADX WARN: Code duplicated, block: B:80:0x019c  */
    /* JADX WARN: Code duplicated, block: B:81:0x01a2  */
    /* JADX WARN: Code duplicated, block: B:8:0x0020  */
    public static final Object f(ConstraintTrackingWorker constraintTrackingWorker, c cVar) {
        f fVar;
        x xVarA;
        int i6;
        AtomicInteger atomicInteger = constraintTrackingWorker.f5298c;
        WorkerParameters workerParameters = constraintTrackingWorker.f4537g;
        Context context = constraintTrackingWorker.f5296a;
        WorkerParameters workerParameters2 = constraintTrackingWorker.f5297b;
        if (cVar instanceof f) {
            fVar = (f) cVar;
            int i7 = fVar.f8036x;
            if ((i7 & Integer.MIN_VALUE) != 0) {
                fVar.f8036x = i7 - Integer.MIN_VALUE;
            } else {
                fVar = new f(constraintTrackingWorker, cVar);
            }
        } else {
            fVar = new f(constraintTrackingWorker, cVar);
        }
        f fVar2 = fVar;
        Object objX = fVar2.f8034v;
        int i8 = fVar2.f8036x;
        if (i8 == 0) {
            a.O(objX);
            Object obj = workerParameters2.f4517b.f5274a.get("androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME");
            String str = obj instanceof String ? (String) obj : null;
            if (str == null || str.length() == 0) {
                y.e().c(k.f8047a, "No worker to delegate to.");
                return new t();
            }
            p025e2.t tVarX0 = p025e2.t.x0(context);
            p071l2.t tVarV = tVarX0.f5480c.v();
            String string = workerParameters2.f4516a.toString();
            h.d(string, "toString(...)");
            p pVarB = tVarV.b(string);
            if (pVarB == null) {
                return new t();
            }
            d dVar = tVarX0.f5487j;
            h.d(dVar, "getTrackers(...)");
            n nVar = new n(dVar);
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = nVar.f6022a;
            int size = arrayList2.size();
            int i9 = 0;
            while (i9 < size) {
                Object obj2 = arrayList2.get(i9);
                i9++;
                if (((p051i2.e) obj2).c(pVarB)) {
                    arrayList.add(obj2);
                }
            }
            if (!arrayList.isEmpty()) {
                y.e().a(p044h2.p.f6026a, "Work " + pVarB.f7686a + " constrained by " + p081m5.f.E0(arrayList, null, null, null, new j(6), 31));
            }
            if (!arrayList.isEmpty()) {
                String str2 = k.f8047a;
                y.e().a(str2, "Constraints not met for delegate " + str + ". Requesting retry.");
                return new u();
            }
            y.e().a(k.f8047a, "Constraints met for delegate ".concat(str));
            try {
                l lVar = workerParameters2.f4521f;
                h.d(context, "getApplicationContext(...)");
                xVarA = lVar.a(context, str, workerParameters);
                p084n2.a aVar = (p084n2.a) workerParameters.f4520e.f6369u;
                h.d(aVar, "getMainThreadExecutor(...)");
                try {
                    AbstractC0114s abstractC0114sJ = AbstractC0120y.j(aVar);
                    try {
                        g gVar = new g(constraintTrackingWorker, xVarA, nVar, pVarB, null);
                        fVar2.f8033u = xVarA;
                        fVar2.f8036x = 1;
                        objX = AbstractC0120y.x(abstractC0114sJ, fVar2, gVar);
                        p109r5.a aVar2 = p109r5.a.r;
                        if (objX == aVar2) {
                            return aVar2;
                        }
                        xVarA = xVarA;
                    } catch (CancellationException e6) {
                        e = e6;
                        xVarA = xVarA;
                        if (atomicInteger.get() == -256 || (e instanceof p090o2.a)) {
                            if (Build.VERSION.SDK_INT < 31) {
                                i6 = -512;
                            } else if (atomicInteger.get() != -256) {
                                i6 = atomicInteger.get();
                            } else {
                                if (!(e instanceof p090o2.a)) {
                                    throw new IllegalStateException("Unreachable");
                                }
                                i6 = ((p090o2.a) e).r;
                            }
                            xVarA.f5298c.compareAndSet(-256, i6);
                        }
                        if (e instanceof p090o2.a) {
                            return new u();
                        }
                        throw e;
                    }
                } catch (CancellationException e7) {
                    e = e7;
                }
            } catch (Throwable unused) {
                y.e().a(k.f8047a, "No worker to delegate to.");
                tVarX0.f5479b.getClass();
                return new t();
            }
        } else {
            if (i8 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            xVarA = fVar2.f8033u;
            try {
                a.O(objX);
            } catch (CancellationException e8) {
                e = e8;
                if (atomicInteger.get() == -256) {
                    if (Build.VERSION.SDK_INT < 31) {
                        i6 = -512;
                    } else if (atomicInteger.get() != -256) {
                        i6 = atomicInteger.get();
                    } else {
                        if (!(e instanceof p090o2.a)) {
                            throw new IllegalStateException("Unreachable");
                        }
                        i6 = ((p090o2.a) e).r;
                    }
                    xVarA.f5298c.compareAndSet(-256, i6);
                } else {
                    if (Build.VERSION.SDK_INT < 31) {
                        i6 = -512;
                    } else if (atomicInteger.get() != -256) {
                        i6 = atomicInteger.get();
                    } else {
                        if (!(e instanceof p090o2.a)) {
                            throw new IllegalStateException("Unreachable");
                        }
                        i6 = ((p090o2.a) e).r;
                    }
                    xVarA.f5298c.compareAndSet(-256, i6);
                }
                if (e instanceof p090o2.a) {
                    return new u();
                }
                throw e;
            }
        }
        return (w) objX;
    }

    @Override // androidx.work.CoroutineWorker
    public final Object c(q5.c cVar) {
        ExecutorService executorService = this.f5297b.f4518c;
        h.d(executorService, "getBackgroundExecutor(...)");
        return AbstractC0120y.x(AbstractC0120y.j(executorService), (c) cVar, new b(this, null));
    }
}
