package androidx.work.impl.workers;

import A5.h;
import X2.a;
import android.content.Context;
import android.support.v4.media.session.b;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import com.google.android.gms.internal.play_billing.AbstractC0252u0;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import p018d2.C0292e;
import p018d2.E;
import p018d2.EnumC0288a;
import p018d2.F;
import p018d2.G;
import p018d2.v;
import p018d2.y;
import p018d2.z;
import p025e2.t;
import p071l2.j;
import p071l2.m;
import p078m2.f;
import p090o2.l;
import p154z5.c;

/* JADX INFO: loaded from: classes.dex */
public final class DiagnosticsWorker extends Worker {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public DiagnosticsWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
        h.e(context, "context");
        h.e(workerParameters, "parameters");
    }

    @Override // androidx.work.Worker
    public final v c() {
        t tVarX0 = t.x0(this.f5296a);
        WorkDatabase workDatabase = tVarX0.f5480c;
        h.d(workDatabase, "getWorkDatabase(...)");
        p071l2.t tVarV = workDatabase.v();
        m mVarT = workDatabase.t();
        p071l2.v vVarW = workDatabase.w();
        j jVarS = workDatabase.s();
        tVarX0.f5479b.f5243d.getClass();
        final long jCurrentTimeMillis = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(1L);
        List list = (List) a.I(tVarV.f7708a, true, false, new c() { // from class: l2.s
            @Override // p154z5.c
            public final Object a(Object obj) throws Exception {
                long j6 = jCurrentTimeMillis;
                L1.a aVar = (L1.a) obj;
                h.e(aVar, "_connection");
                L1.c cVarI = aVar.I("SELECT * FROM workspec WHERE last_enqueue_time >= ? AND state IN (2, 3, 5) ORDER BY last_enqueue_time DESC");
                try {
                    cVarI.c(j6, 1);
                    int iQ = AbstractC0252u0.q(cVarI, "id");
                    int iQ2 = AbstractC0252u0.q(cVarI, "state");
                    int iQ3 = AbstractC0252u0.q(cVarI, "worker_class_name");
                    int iQ4 = AbstractC0252u0.q(cVarI, "input_merger_class_name");
                    int iQ5 = AbstractC0252u0.q(cVarI, "input");
                    int iQ6 = AbstractC0252u0.q(cVarI, "output");
                    int iQ7 = AbstractC0252u0.q(cVarI, "initial_delay");
                    int iQ8 = AbstractC0252u0.q(cVarI, "interval_duration");
                    int iQ9 = AbstractC0252u0.q(cVarI, "flex_duration");
                    int iQ10 = AbstractC0252u0.q(cVarI, "run_attempt_count");
                    int iQ11 = AbstractC0252u0.q(cVarI, "backoff_policy");
                    int iQ12 = AbstractC0252u0.q(cVarI, "backoff_delay_duration");
                    int iQ13 = AbstractC0252u0.q(cVarI, "last_enqueue_time");
                    int iQ14 = AbstractC0252u0.q(cVarI, "minimum_retention_duration");
                    int iQ15 = AbstractC0252u0.q(cVarI, "schedule_requested_at");
                    int iQ16 = AbstractC0252u0.q(cVarI, "run_in_foreground");
                    int iQ17 = AbstractC0252u0.q(cVarI, "out_of_quota_policy");
                    int iQ18 = AbstractC0252u0.q(cVarI, "period_count");
                    int iQ19 = AbstractC0252u0.q(cVarI, "generation");
                    int iQ20 = AbstractC0252u0.q(cVarI, "next_schedule_time_override");
                    int iQ21 = AbstractC0252u0.q(cVarI, "next_schedule_time_override_generation");
                    int iQ22 = AbstractC0252u0.q(cVarI, "stop_reason");
                    int iQ23 = AbstractC0252u0.q(cVarI, "trace_tag");
                    int iQ24 = AbstractC0252u0.q(cVarI, "backoff_on_system_interruptions");
                    int iQ25 = AbstractC0252u0.q(cVarI, "required_network_type");
                    int iQ26 = AbstractC0252u0.q(cVarI, "required_network_request");
                    int iQ27 = AbstractC0252u0.q(cVarI, "requires_charging");
                    int iQ28 = AbstractC0252u0.q(cVarI, "requires_device_idle");
                    int iQ29 = AbstractC0252u0.q(cVarI, "requires_battery_not_low");
                    int iQ30 = AbstractC0252u0.q(cVarI, "requires_storage_not_low");
                    int iQ31 = AbstractC0252u0.q(cVarI, "trigger_content_update_delay");
                    int iQ32 = AbstractC0252u0.q(cVarI, "trigger_max_content_delay");
                    int iQ33 = AbstractC0252u0.q(cVarI, "content_uri_triggers");
                    ArrayList arrayList = new ArrayList();
                    while (cVarI.E()) {
                        String strM = cVarI.m(iQ);
                        ArrayList arrayList2 = arrayList;
                        int i6 = iQ;
                        F fD = G.D((int) cVarI.getLong(iQ2));
                        String strM2 = cVarI.m(iQ3);
                        String strM3 = cVarI.m(iQ4);
                        byte[] blob = cVarI.getBlob(iQ5);
                        p018d2.j jVar = p018d2.j.f5273b;
                        p018d2.j jVarF = b.F(blob);
                        p018d2.j jVarF2 = b.F(cVarI.getBlob(iQ6));
                        long j7 = cVarI.getLong(iQ7);
                        long j8 = cVarI.getLong(iQ8);
                        long j9 = cVarI.getLong(iQ9);
                        int i7 = (int) cVarI.getLong(iQ10);
                        EnumC0288a enumC0288aA = G.A((int) cVarI.getLong(iQ11));
                        long j10 = cVarI.getLong(iQ12);
                        long j11 = cVarI.getLong(iQ13);
                        long j12 = cVarI.getLong(iQ14);
                        int i8 = iQ15;
                        long j13 = cVarI.getLong(i8);
                        int i9 = iQ14;
                        int i10 = iQ16;
                        boolean z6 = ((int) cVarI.getLong(i10)) != 0;
                        int i11 = iQ17;
                        E eC = G.C((int) cVarI.getLong(i11));
                        int i12 = iQ18;
                        int i13 = iQ2;
                        int i14 = (int) cVarI.getLong(i12);
                        int i15 = iQ19;
                        int i16 = (int) cVarI.getLong(i15);
                        long j14 = cVarI.getLong(iQ20);
                        int i17 = iQ21;
                        int i18 = (int) cVarI.getLong(i17);
                        iQ21 = i17;
                        iQ22 = iQ22;
                        int i19 = (int) cVarI.getLong(iQ22);
                        int i20 = iQ23;
                        Boolean boolValueOf = null;
                        String strM4 = cVarI.isNull(i20) ? null : cVarI.m(i20);
                        int i21 = iQ24;
                        Integer numValueOf = cVarI.isNull(i21) ? null : Integer.valueOf((int) cVarI.getLong(i21));
                        if (numValueOf != null) {
                            boolValueOf = Boolean.valueOf(numValueOf.intValue() != 0);
                        }
                        Boolean bool = boolValueOf;
                        int i22 = iQ25;
                        z zVarB = G.B((int) cVarI.getLong(i22));
                        int i23 = iQ26;
                        f fVarB0 = G.b0(cVarI.getBlob(i23));
                        int i24 = iQ27;
                        boolean z7 = ((int) cVarI.getLong(i24)) != 0;
                        int i25 = iQ28;
                        boolean z8 = ((int) cVarI.getLong(i25)) != 0;
                        int i26 = iQ29;
                        boolean z9 = ((int) cVarI.getLong(i26)) != 0;
                        iQ29 = i26;
                        int i27 = iQ30;
                        int i28 = iQ31;
                        int i29 = iQ32;
                        iQ31 = i28;
                        int i30 = iQ33;
                        p pVar = new p(strM, fD, strM2, strM3, jVarF, jVarF2, j7, j8, j9, new C0292e(fVarB0, zVarB, z7, z8, z9, ((int) cVarI.getLong(i27)) != 0, cVarI.getLong(i28), cVarI.getLong(i29), G.c(cVarI.getBlob(i30))), i7, enumC0288aA, j10, j11, j12, j13, z6, eC, i14, i16, j14, i18, i19, strM4, bool);
                        iQ33 = i30;
                        iQ32 = i29;
                        arrayList = arrayList2;
                        arrayList.add(pVar);
                        iQ30 = i27;
                        iQ14 = i9;
                        iQ15 = i8;
                        iQ16 = i10;
                        iQ17 = i11;
                        iQ19 = i15;
                        iQ23 = i20;
                        iQ24 = i21;
                        iQ25 = i22;
                        iQ26 = i23;
                        iQ27 = i24;
                        iQ = i6;
                        iQ28 = i25;
                        iQ2 = i13;
                        iQ18 = i12;
                    }
                    return arrayList;
                } finally {
                    cVarI.close();
                }
            }
        });
        List list2 = (List) a.I(tVarV.f7708a, true, false, new B4.j(13));
        List list3 = (List) a.I(tVarV.f7708a, true, false, new B4.j(17));
        if (!list.isEmpty()) {
            y yVarE = y.e();
            String str = l.f8048a;
            yVarE.f(str, "Recently completed work:\n\n");
            y.e().f(str, l.a(mVarT, vVarW, jVarS, list));
        }
        if (!list2.isEmpty()) {
            y yVarE2 = y.e();
            String str2 = l.f8048a;
            yVarE2.f(str2, "Running work:\n\n");
            y.e().f(str2, l.a(mVarT, vVarW, jVarS, list2));
        }
        if (!list3.isEmpty()) {
            y yVarE3 = y.e();
            String str3 = l.f8048a;
            yVarE3.f(str3, "Enqueued work:\n\n");
            y.e().f(str3, l.a(mVarT, vVarW, jVarS, list3));
        }
        return new v(p018d2.j.f5273b);
    }
}
