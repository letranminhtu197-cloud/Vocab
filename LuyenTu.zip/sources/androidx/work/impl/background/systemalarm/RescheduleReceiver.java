package androidx.work.impl.background.systemalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import p018d2.y;
import p025e2.t;

/* JADX INFO: loaded from: classes.dex */
public class RescheduleReceiver extends BroadcastReceiver {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final String f4528a = y.g("RescheduleReceiver");

    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        y.e().a(f4528a, "Received intent " + intent);
        try {
            t tVarX0 = t.x0(context);
            BroadcastReceiver.PendingResult pendingResultGoAsync = goAsync();
            synchronized (t.f5477m) {
                try {
                    BroadcastReceiver.PendingResult pendingResult = tVarX0.f5486i;
                    if (pendingResult != null) {
                        pendingResult.finish();
                    }
                    tVarX0.f5486i = pendingResultGoAsync;
                    if (tVarX0.f5485h) {
                        pendingResultGoAsync.finish();
                        tVarX0.f5486i = null;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        } catch (IllegalStateException e6) {
            y.e().d(f4528a, "Cannot reschedule jobs. WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().", e6);
        }
    }
}
