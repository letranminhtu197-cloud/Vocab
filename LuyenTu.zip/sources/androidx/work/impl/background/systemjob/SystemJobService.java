package androidx.work.impl.background.systemjob;

import B.b;
import B2.a;
import C1.C;
import V4.d;
import android.app.Application;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.Build;
import android.os.Looper;
import android.os.PersistableBundle;
import com.google.crypto.tink.shaded.protobuf.T;
import java.util.Arrays;
import java.util.HashMap;
import p018d2.C0296i;
import p018d2.l;
import p018d2.y;
import p025e2.C0299c;
import p025e2.C0304h;
import p025e2.InterfaceC0297a;
import p025e2.t;
import p053i4.v;
import p071l2.k;

/* JADX INFO: loaded from: classes.dex */
public class SystemJobService extends JobService implements InterfaceC0297a {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final String f4529v = y.g("SystemJobService");
    public t r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final HashMap f4530s = new HashMap();
    public final C0296i t = new C0296i(1);

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public d f4531u;

    public static void a(String str) {
        if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
            throw new IllegalStateException(T.j("Cannot invoke ", str, " on a background thread"));
        }
    }

    public static k c(JobParameters jobParameters) {
        try {
            PersistableBundle extras = jobParameters.getExtras();
            if (extras == null || !extras.containsKey("EXTRA_WORK_SPEC_ID")) {
                return null;
            }
            return new k(extras.getString("EXTRA_WORK_SPEC_ID"), extras.getInt("EXTRA_WORK_SPEC_GENERATION"));
        } catch (NullPointerException unused) {
            return null;
        }
    }

    @Override // p025e2.InterfaceC0297a
    public final void b(k kVar, boolean z6) {
        a("onExecuted");
        y.e().a(f4529v, kVar.f7677a + " executed on JobScheduler");
        JobParameters jobParameters = (JobParameters) this.f4530s.remove(kVar);
        this.t.d(kVar);
        if (jobParameters != null) {
            jobFinished(jobParameters, z6);
        }
    }

    @Override // android.app.Service
    public final void onCreate() {
        super.onCreate();
        try {
            t tVarX0 = t.x0(getApplicationContext());
            this.r = tVarX0;
            C0299c c0299c = tVarX0.f5483f;
            this.f4531u = new d(c0299c, tVarX0.f5481d);
            c0299c.a(this);
        } catch (IllegalStateException e6) {
            if (!Application.class.equals(getApplication().getClass())) {
                throw new IllegalStateException("WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate().", e6);
            }
            y.e().h(f4529v, "Could not find WorkManager instance; this may be because an auto-backup is in progress. Ignoring JobScheduler commands for now. Please make sure that you are initializing WorkManager if you have manually disabled WorkManagerInitializer.");
        }
    }

    @Override // android.app.Service
    public final void onDestroy() {
        super.onDestroy();
        t tVar = this.r;
        if (tVar != null) {
            C0299c c0299c = tVar.f5483f;
            synchronized (c0299c.f5445k) {
                c0299c.f5444j.remove(this);
            }
        }
    }

    @Override // android.app.job.JobService
    public final boolean onStartJob(JobParameters jobParameters) {
        a("onStartJob");
        t tVar = this.r;
        String str = f4529v;
        if (tVar == null) {
            y.e().a(str, "WorkManager is not initialized; requesting retry.");
            jobFinished(jobParameters, true);
            return false;
        }
        k kVarC = c(jobParameters);
        if (kVarC == null) {
            y.e().c(str, "WorkSpec id not found!");
            return false;
        }
        HashMap map = this.f4530s;
        if (map.containsKey(kVarC)) {
            y.e().a(str, "Job is already being executed by SystemJobService: " + kVarC);
            return false;
        }
        y.e().a(str, "onStartJob for " + kVarC);
        map.put(kVarC, jobParameters);
        int i6 = Build.VERSION.SDK_INT;
        l lVar = new l();
        if (jobParameters.getTriggeredContentUris() != null) {
            Arrays.asList(jobParameters.getTriggeredContentUris());
        }
        if (jobParameters.getTriggeredContentAuthorities() != null) {
            Arrays.asList(jobParameters.getTriggeredContentAuthorities());
        }
        if (i6 >= 28) {
            b.h(jobParameters);
        }
        d dVar = this.f4531u;
        C0304h c0304hF = this.t.f(kVarC);
        dVar.getClass();
        ((C) ((v) dVar.t).r).execute(new a(dVar, c0304hF, lVar, 5));
        return true;
    }

    @Override // android.app.job.JobService
    public final boolean onStopJob(JobParameters jobParameters) {
        boolean zContains;
        a("onStopJob");
        if (this.r == null) {
            y.e().a(f4529v, "WorkManager is not initialized; requesting retry.");
            return true;
        }
        k kVarC = c(jobParameters);
        if (kVarC == null) {
            y.e().c(f4529v, "WorkSpec id not found!");
            return false;
        }
        y.e().a(f4529v, "onStopJob for " + kVarC);
        this.f4530s.remove(kVarC);
        C0304h c0304hD = this.t.d(kVarC);
        if (c0304hD != null) {
            int iA = Build.VERSION.SDK_INT >= 31 ? p037g2.d.a(jobParameters) : -512;
            d dVar = this.f4531u;
            dVar.getClass();
            dVar.X(c0304hD, iA);
        }
        C0299c c0299c = this.r.f5483f;
        String str = kVarC.f7677a;
        synchronized (c0299c.f5445k) {
            zContains = c0299c.f5443i.contains(str);
        }
        return !zContains;
    }
}
