package androidx.work;

import A5.h;
import P1.b;
import android.content.Context;
import java.util.Collections;
import java.util.List;
import p018d2.C0289b;
import p018d2.l;
import p018d2.y;
import p025e2.t;
import p025e2.v;

/* JADX INFO: loaded from: classes.dex */
public final class WorkManagerInitializer implements b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final String f4515a = y.g("WrkMgrInitializer");

    @Override // P1.b
    public final List a() {
        return Collections.EMPTY_LIST;
    }

    @Override // P1.b
    public final Object b(Context context) {
        y.e().a(f4515a, "Initializing WorkManager with default configuration.");
        C0289b c0289b = new C0289b(new l());
        h.e(context, "context");
        synchronized (t.f5477m) {
            try {
                t tVar = t.f5475k;
                if (tVar != null && t.f5476l != null) {
                    throw new IllegalStateException("WorkManager is already initialized.  Did you try to initialize it manually without disabling WorkManagerInitializer? See WorkManager#initialize(Context, Configuration) or the class level Javadoc for more information.");
                }
                if (tVar == null) {
                    Context applicationContext = context.getApplicationContext();
                    if (t.f5476l == null) {
                        t.f5476l = v.h(applicationContext, c0289b);
                    }
                    t.f5475k = t.f5476l;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return t.x0(context);
    }
}
