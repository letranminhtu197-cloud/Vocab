package androidx.work;

import A5.h;
import K5.AbstractC0114s;
import K5.AbstractC0120y;
import K5.a0;
import android.content.Context;
import com.google.android.gms.internal.play_billing.AbstractC0252u0;
import p018d2.C0293f;
import p018d2.C0294g;
import p018d2.C0295h;
import p018d2.x;
import p025e2.v;
import p121u.k;
import q5.c;

/* JADX INFO: loaded from: classes.dex */
public abstract class CoroutineWorker extends x {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final WorkerParameters f4513e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final C0293f f4514f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public CoroutineWorker(Context context, WorkerParameters workerParameters) {
        super(context, workerParameters);
        h.e(context, "appContext");
        h.e(workerParameters, "params");
        this.f4513e = workerParameters;
        this.f4514f = C0293f.t;
    }

    @Override // p018d2.x
    public final k a() {
        AbstractC0114s abstractC0114sD = d();
        a0 a0VarC = AbstractC0120y.c();
        abstractC0114sD.getClass();
        return AbstractC0252u0.w(v.E(abstractC0114sD, a0VarC), new C0294g(this, null));
    }

    @Override // p018d2.x
    public final k b() {
        q5.h hVarD = !h.a(d(), C0293f.t) ? d() : this.f4513e.f4519d;
        h.b(hVarD);
        return AbstractC0252u0.w(hVarD.o(AbstractC0120y.c()), new C0295h(this, null));
    }

    public abstract Object c(c cVar);

    public AbstractC0114s d() {
        return this.f4514f;
    }
}
