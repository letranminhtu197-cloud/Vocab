package androidx.work;

import java.util.UUID;
import java.util.concurrent.ExecutorService;
import p018d2.j;
import p018d2.l;
import p053i4.v;
import q5.h;

/* JADX INFO: loaded from: classes.dex */
public final class WorkerParameters {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public UUID f4516a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public j f4517b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ExecutorService f4518c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public h f4519d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public v f4520e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public l f4521f;
}
