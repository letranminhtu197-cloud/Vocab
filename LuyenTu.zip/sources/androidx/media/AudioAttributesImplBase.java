package androidx.media;

import com.google.crypto.tink.shaded.protobuf.T;
import java.util.Arrays;
import org.apache.tika.fork.ContentHandlerProxy;

/* JADX INFO: loaded from: classes.dex */
public class AudioAttributesImplBase implements AudioAttributesImpl {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f4484a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f4485b = 0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f4486c = 0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f4487d = -1;

    @Override // androidx.media.AudioAttributesImpl
    public final int a() {
        int i6 = this.f4487d;
        return i6 != -1 ? i6 : AudioAttributesCompat.c(this.f4486c, this.f4484a);
    }

    @Override // androidx.media.AudioAttributesImpl
    public final Object b() {
        return null;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof AudioAttributesImplBase)) {
            return false;
        }
        AudioAttributesImplBase audioAttributesImplBase = (AudioAttributesImplBase) obj;
        if (this.f4485b == audioAttributesImplBase.f4485b) {
            int i6 = this.f4486c;
            int i7 = audioAttributesImplBase.f4486c;
            int iA = audioAttributesImplBase.a();
            if (iA == 6) {
                i7 |= 4;
            } else if (iA == 7) {
                i7 |= 1;
            }
            if (i6 == (i7 & 273) && this.f4484a == audioAttributesImplBase.f4484a && this.f4487d == audioAttributesImplBase.f4487d) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f4485b), Integer.valueOf(this.f4486c), Integer.valueOf(this.f4484a), Integer.valueOf(this.f4487d)});
    }

    public final String toString() {
        String strG;
        StringBuilder sb = new StringBuilder("AudioAttributesCompat:");
        if (this.f4487d != -1) {
            sb.append(" stream=");
            sb.append(this.f4487d);
            sb.append(" derived");
        }
        sb.append(" usage=");
        int i6 = this.f4484a;
        int i7 = AudioAttributesCompat.f4480b;
        switch (i6) {
            case 0:
                strG = "USAGE_UNKNOWN";
                break;
            case 1:
                strG = "USAGE_MEDIA";
                break;
            case 2:
                strG = "USAGE_VOICE_COMMUNICATION";
                break;
            case 3:
                strG = "USAGE_VOICE_COMMUNICATION_SIGNALLING";
                break;
            case 4:
                strG = "USAGE_ALARM";
                break;
            case 5:
                strG = "USAGE_NOTIFICATION";
                break;
            case 6:
                strG = "USAGE_NOTIFICATION_RINGTONE";
                break;
            case 7:
                strG = "USAGE_NOTIFICATION_COMMUNICATION_REQUEST";
                break;
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                strG = "USAGE_NOTIFICATION_COMMUNICATION_INSTANT";
                break;
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                strG = "USAGE_NOTIFICATION_COMMUNICATION_DELAYED";
                break;
            case 10:
                strG = "USAGE_NOTIFICATION_EVENT";
                break;
            case 11:
                strG = "USAGE_ASSISTANCE_ACCESSIBILITY";
                break;
            case 12:
                strG = "USAGE_ASSISTANCE_NAVIGATION_GUIDANCE";
                break;
            case 13:
                strG = "USAGE_ASSISTANCE_SONIFICATION";
                break;
            case 14:
                strG = "USAGE_GAME";
                break;
            case 15:
            default:
                strG = T.g("unknown usage ", i6);
                break;
            case 16:
                strG = "USAGE_ASSISTANT";
                break;
        }
        sb.append(strG);
        sb.append(" content=");
        sb.append(this.f4485b);
        sb.append(" flags=0x");
        sb.append(Integer.toHexString(this.f4486c).toUpperCase());
        return sb.toString();
    }
}
