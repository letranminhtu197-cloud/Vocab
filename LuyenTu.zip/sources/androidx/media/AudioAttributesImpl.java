package androidx.media;

import S1.c;

/* JADX INFO: loaded from: classes.dex */
public interface AudioAttributesImpl extends c {
    int a();

    Object b();
}
