package androidx.media;

import android.media.AudioAttributes;

/* JADX INFO: loaded from: classes.dex */
public class AudioAttributesImplApi21 implements AudioAttributesImpl {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public AudioAttributes f4482a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f4483b = -1;

    public AudioAttributesImplApi21() {
    }

    @Override // androidx.media.AudioAttributesImpl
    public final int a() {
        int i6 = this.f4483b;
        return i6 != -1 ? i6 : AudioAttributesCompat.c(this.f4482a.getFlags(), this.f4482a.getUsage());
    }

    @Override // androidx.media.AudioAttributesImpl
    public final Object b() {
        return this.f4482a;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof AudioAttributesImplApi21) {
            return this.f4482a.equals(((AudioAttributesImplApi21) obj).f4482a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f4482a.hashCode();
    }

    public final String toString() {
        return "AudioAttributesCompat: audioattributes=" + this.f4482a;
    }

    public AudioAttributesImplApi21(AudioAttributes audioAttributes) {
        this.f4482a = audioAttributes;
    }
}
