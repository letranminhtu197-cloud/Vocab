package androidx.media;

import S1.c;
import android.util.SparseIntArray;
import org.apache.tika.fork.ContentHandlerProxy;

/* JADX INFO: loaded from: classes.dex */
public class AudioAttributesCompat implements c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final /* synthetic */ int f4480b = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public AudioAttributesImpl f4481a;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        sparseIntArray.put(5, 1);
        sparseIntArray.put(6, 2);
        sparseIntArray.put(7, 2);
        sparseIntArray.put(8, 1);
        sparseIntArray.put(9, 1);
        sparseIntArray.put(10, 1);
    }

    public static int c(int i6, int i7) {
        if ((i6 & 1) == 1) {
            return 7;
        }
        if ((i6 & 4) == 4) {
            return 6;
        }
        switch (i7) {
            case 2:
                return 0;
            case 3:
                return 8;
            case 4:
                return 4;
            case 5:
            case 7:
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
            case 10:
                return 5;
            case 6:
                return 2;
            case 11:
                return 10;
            case 12:
            default:
                return 3;
            case 13:
                return 1;
        }
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof AudioAttributesCompat)) {
            return false;
        }
        AudioAttributesCompat audioAttributesCompat = (AudioAttributesCompat) obj;
        AudioAttributesImpl audioAttributesImpl = this.f4481a;
        if (audioAttributesImpl == null) {
            return audioAttributesCompat.f4481a == null;
        }
        return audioAttributesImpl.equals(audioAttributesCompat.f4481a);
    }

    public final int hashCode() {
        return this.f4481a.hashCode();
    }

    public final String toString() {
        return this.f4481a.toString();
    }
}
