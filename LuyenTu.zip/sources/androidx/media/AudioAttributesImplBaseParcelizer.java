package androidx.media;

import S1.a;

/* JADX INFO: loaded from: classes.dex */
public class AudioAttributesImplBaseParcelizer {
    public static AudioAttributesImplBase read(a aVar) {
        AudioAttributesImplBase audioAttributesImplBase = new AudioAttributesImplBase();
        audioAttributesImplBase.f4484a = aVar.f(audioAttributesImplBase.f4484a, 1);
        audioAttributesImplBase.f4485b = aVar.f(audioAttributesImplBase.f4485b, 2);
        audioAttributesImplBase.f4486c = aVar.f(audioAttributesImplBase.f4486c, 3);
        audioAttributesImplBase.f4487d = aVar.f(audioAttributesImplBase.f4487d, 4);
        return audioAttributesImplBase;
    }

    public static void write(AudioAttributesImplBase audioAttributesImplBase, a aVar) {
        aVar.getClass();
        aVar.j(audioAttributesImplBase.f4484a, 1);
        aVar.j(audioAttributesImplBase.f4485b, 2);
        aVar.j(audioAttributesImplBase.f4486c, 3);
        aVar.j(audioAttributesImplBase.f4487d, 4);
    }
}
