package androidx.datastore.preferences.protobuf;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import org.apache.tika.fork.ForkServer;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0160g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f4343a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public C0161h f4344b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final FileInputStream f4345c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final byte[] f4346d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f4347e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f4348f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f4349g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f4350h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f4351i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f4352j = Integer.MAX_VALUE;

    public C0160g(FileInputStream fileInputStream) {
        Charset charset = AbstractC0174v.f4391a;
        this.f4345c = fileInputStream;
        this.f4346d = new byte[4096];
        this.f4347e = 0;
        this.f4349g = 0;
        this.f4351i = 0;
    }

    public final int A() {
        return s();
    }

    public final long B() {
        return t();
    }

    public final void C() {
        int i6 = this.f4347e + this.f4348f;
        this.f4347e = i6;
        int i7 = this.f4351i + i6;
        int i8 = this.f4352j;
        if (i7 <= i8) {
            this.f4348f = 0;
            return;
        }
        int i9 = i7 - i8;
        this.f4348f = i9;
        this.f4347e = i6 - i9;
    }

    public final void D(int i6) {
        if (G(i6)) {
            return;
        }
        if (i6 <= (Integer.MAX_VALUE - this.f4351i) - this.f4349g) {
            throw C0176x.f();
        }
        throw new C0176x("Protocol message was too large.  May be malicious.  Use CodedInputStream.setSizeLimit() to increase the size limit.");
    }

    public final boolean E(int i6) throws C0176x {
        int iZ;
        int i7 = i6 & 7;
        int i8 = 0;
        if (i7 == 0) {
            int i9 = this.f4347e - this.f4349g;
            byte[] bArr = this.f4346d;
            if (i9 >= 10) {
                while (i8 < 10) {
                    int i10 = this.f4349g;
                    this.f4349g = i10 + 1;
                    if (bArr[i10] < 0) {
                        i8++;
                    }
                }
                throw C0176x.c();
            }
            while (i8 < 10) {
                if (this.f4349g == this.f4347e) {
                    D(1);
                }
                int i11 = this.f4349g;
                this.f4349g = i11 + 1;
                if (bArr[i11] < 0) {
                    i8++;
                }
            }
            throw C0176x.c();
            return true;
        }
        if (i7 == 1) {
            F(8);
            return true;
        }
        if (i7 == 2) {
            F(s());
            return true;
        }
        if (i7 != 3) {
            if (i7 == 4) {
                return false;
            }
            if (i7 != 5) {
                throw C0176x.b();
            }
            F(4);
            return true;
        }
        do {
            iZ = z();
            if (iZ == 0) {
                break;
            }
        } while (E(iZ));
        a(((i6 >>> 3) << 3) | 4);
        return true;
    }

    public final void F(int i6) throws C0176x {
        int i7 = this.f4347e;
        int i8 = this.f4349g;
        int i9 = i7 - i8;
        if (i6 <= i9 && i6 >= 0) {
            this.f4349g = i8 + i6;
            return;
        }
        FileInputStream fileInputStream = this.f4345c;
        if (i6 < 0) {
            throw C0176x.d();
        }
        int i10 = this.f4351i;
        int i11 = i10 + i8;
        int i12 = i11 + i6;
        int i13 = this.f4352j;
        if (i12 > i13) {
            F((i13 - i10) - i8);
            throw C0176x.f();
        }
        this.f4351i = i11;
        this.f4347e = 0;
        this.f4349g = 0;
        while (i9 < i6) {
            long j6 = i6 - i9;
            try {
                long jSkip = fileInputStream.skip(j6);
                if (jSkip < 0 || jSkip > j6) {
                    throw new IllegalStateException(fileInputStream.getClass() + "#skip returned invalid result: " + jSkip + "\nThe InputStream implementation is buggy.");
                }
                if (jSkip == 0) {
                    break;
                } else {
                    i9 += (int) jSkip;
                }
            } finally {
                this.f4351i += i9;
                C();
            }
        }
        if (i9 >= i6) {
            return;
        }
        int i14 = this.f4347e;
        int i15 = i14 - this.f4349g;
        this.f4349g = i14;
        D(1);
        while (true) {
            int i16 = i6 - i15;
            int i17 = this.f4347e;
            if (i16 <= i17) {
                this.f4349g = i16;
                return;
            } else {
                i15 += i17;
                this.f4349g = i17;
                D(1);
            }
        }
    }

    public final boolean G(int i6) throws IOException {
        int i7 = this.f4349g;
        int i8 = i7 + i6;
        int i9 = this.f4347e;
        if (i8 <= i9) {
            throw new IllegalStateException(com.google.crypto.tink.shaded.protobuf.T.h("refillBuffer() called when ", i6, " bytes were already available in buffer"));
        }
        int i10 = this.f4351i;
        if (i6 <= (Integer.MAX_VALUE - i10) - i7 && i10 + i7 + i6 <= this.f4352j) {
            byte[] bArr = this.f4346d;
            if (i7 > 0) {
                if (i9 > i7) {
                    System.arraycopy(bArr, i7, bArr, 0, i9 - i7);
                }
                this.f4351i += i7;
                this.f4347e -= i7;
                this.f4349g = 0;
            }
            int i11 = this.f4347e;
            int iMin = Math.min(bArr.length - i11, (Integer.MAX_VALUE - this.f4351i) - i11);
            FileInputStream fileInputStream = this.f4345c;
            int i12 = fileInputStream.read(bArr, i11, iMin);
            if (i12 == 0 || i12 < -1 || i12 > bArr.length) {
                throw new IllegalStateException(fileInputStream.getClass() + "#read(byte[]) returned invalid result: " + i12 + "\nThe InputStream implementation is buggy.");
            }
            if (i12 > 0) {
                this.f4347e += i12;
                C();
                if (this.f4347e >= i6) {
                    return true;
                }
                return G(i6);
            }
        }
        return false;
    }

    public final void a(int i6) {
        if (this.f4350h != i6) {
            throw new C0176x("Protocol message end-group tag did not match expected tag.");
        }
    }

    public final int b() {
        return this.f4351i + this.f4349g;
    }

    public final boolean c() {
        return this.f4349g == this.f4347e && !G(1);
    }

    public final void d(int i6) {
        this.f4352j = i6;
        C();
    }

    public final int e(int i6) {
        if (i6 < 0) {
            throw C0176x.d();
        }
        int i7 = this.f4351i + this.f4349g + i6;
        int i8 = this.f4352j;
        if (i7 > i8) {
            throw C0176x.f();
        }
        this.f4352j = i7;
        C();
        return i8;
    }

    public final boolean f() {
        return t() != 0;
    }

    public final double g() {
        return Double.longBitsToDouble(r());
    }

    public final int h() {
        return s();
    }

    public final int i() {
        return q();
    }

    public final long j() {
        return r();
    }

    public final float k() {
        return Float.intBitsToFloat(q());
    }

    public final int l() {
        return s();
    }

    public final long m() {
        return t();
    }

    public final byte[] n(int i6) {
        byte[] bArrO = o(i6);
        if (bArrO != null) {
            return bArrO;
        }
        int i7 = this.f4349g;
        int i8 = this.f4347e;
        int length = i8 - i7;
        this.f4351i += i8;
        this.f4349g = 0;
        this.f4347e = 0;
        ArrayList arrayListP = p(i6 - length);
        byte[] bArr = new byte[i6];
        System.arraycopy(this.f4346d, i7, bArr, 0, length);
        int size = arrayListP.size();
        int i9 = 0;
        while (i9 < size) {
            Object obj = arrayListP.get(i9);
            i9++;
            byte[] bArr2 = (byte[]) obj;
            System.arraycopy(bArr2, 0, bArr, length, bArr2.length);
            length += bArr2.length;
        }
        return bArr;
    }

    public final byte[] o(int i6) {
        if (i6 == 0) {
            return AbstractC0174v.f4392b;
        }
        if (i6 < 0) {
            throw C0176x.d();
        }
        int i7 = this.f4351i;
        int i8 = this.f4349g;
        int i9 = i7 + i8 + i6;
        if (i9 - Integer.MAX_VALUE > 0) {
            throw new C0176x("Protocol message was too large.  May be malicious.  Use CodedInputStream.setSizeLimit() to increase the size limit.");
        }
        int i10 = this.f4352j;
        if (i9 > i10) {
            F((i10 - i7) - i8);
            throw C0176x.f();
        }
        int i11 = this.f4347e - i8;
        int i12 = i6 - i11;
        FileInputStream fileInputStream = this.f4345c;
        if (i12 >= 4096 && i12 > fileInputStream.available()) {
            return null;
        }
        byte[] bArr = new byte[i6];
        System.arraycopy(this.f4346d, this.f4349g, bArr, 0, i11);
        this.f4351i += this.f4347e;
        this.f4349g = 0;
        this.f4347e = 0;
        while (i11 < i6) {
            int i13 = fileInputStream.read(bArr, i11, i6 - i11);
            if (i13 == -1) {
                throw C0176x.f();
            }
            this.f4351i += i13;
            i11 += i13;
        }
        return bArr;
    }

    public final ArrayList p(int i6) {
        ArrayList arrayList = new ArrayList();
        while (i6 > 0) {
            int iMin = Math.min(i6, 4096);
            byte[] bArr = new byte[iMin];
            int i7 = 0;
            while (i7 < iMin) {
                int i8 = this.f4345c.read(bArr, i7, iMin - i7);
                if (i8 == -1) {
                    throw C0176x.f();
                }
                this.f4351i += i8;
                i7 += i8;
            }
            i6 -= iMin;
            arrayList.add(bArr);
        }
        return arrayList;
    }

    public final int q() {
        int i6 = this.f4349g;
        if (this.f4347e - i6 < 4) {
            D(4);
            i6 = this.f4349g;
        }
        this.f4349g = i6 + 4;
        byte[] bArr = this.f4346d;
        return ((bArr[i6 + 3] & ForkServer.ERROR) << 24) | (bArr[i6] & ForkServer.ERROR) | ((bArr[i6 + 1] & ForkServer.ERROR) << 8) | ((bArr[i6 + 2] & ForkServer.ERROR) << 16);
    }

    public final long r() {
        int i6 = this.f4349g;
        if (this.f4347e - i6 < 8) {
            D(8);
            i6 = this.f4349g;
        }
        this.f4349g = i6 + 8;
        byte[] bArr = this.f4346d;
        return ((((long) bArr[i6 + 7]) & 255) << 56) | (((long) bArr[i6]) & 255) | ((((long) bArr[i6 + 1]) & 255) << 8) | ((((long) bArr[i6 + 2]) & 255) << 16) | ((((long) bArr[i6 + 3]) & 255) << 24) | ((((long) bArr[i6 + 4]) & 255) << 32) | ((((long) bArr[i6 + 5]) & 255) << 40) | ((((long) bArr[i6 + 6]) & 255) << 48);
    }

    public final int s() {
        int i6;
        int i7 = this.f4349g;
        int i8 = this.f4347e;
        if (i8 != i7) {
            int i9 = i7 + 1;
            byte[] bArr = this.f4346d;
            byte b6 = bArr[i7];
            if (b6 >= 0) {
                this.f4349g = i9;
                return b6;
            }
            if (i8 - i9 >= 9) {
                int i10 = i7 + 2;
                int i11 = (bArr[i9] << 7) ^ b6;
                if (i11 < 0) {
                    i6 = i11 ^ (-128);
                } else {
                    int i12 = i7 + 3;
                    int i13 = (bArr[i10] << 14) ^ i11;
                    if (i13 >= 0) {
                        i6 = i13 ^ 16256;
                    } else {
                        int i14 = i7 + 4;
                        int i15 = i13 ^ (bArr[i12] << 21);
                        if (i15 < 0) {
                            i6 = (-2080896) ^ i15;
                        } else {
                            i12 = i7 + 5;
                            byte b7 = bArr[i14];
                            int i16 = (i15 ^ (b7 << 28)) ^ 266354560;
                            if (b7 < 0) {
                                i14 = i7 + 6;
                                if (bArr[i12] < 0) {
                                    i12 = i7 + 7;
                                    if (bArr[i14] < 0) {
                                        i14 = i7 + 8;
                                        if (bArr[i12] < 0) {
                                            i12 = i7 + 9;
                                            if (bArr[i14] < 0) {
                                                int i17 = i7 + 10;
                                                if (bArr[i12] >= 0) {
                                                    i10 = i17;
                                                    i6 = i16;
                                                }
                                            }
                                        }
                                    }
                                }
                                i6 = i16;
                            }
                            i6 = i16;
                        }
                        i10 = i14;
                    }
                    i10 = i12;
                }
                this.f4349g = i10;
                return i6;
            }
        }
        return (int) u();
    }

    public final long t() {
        long j6;
        long j7;
        long j8;
        long j9;
        int i6 = this.f4349g;
        int i7 = this.f4347e;
        if (i7 != i6) {
            int i8 = i6 + 1;
            byte[] bArr = this.f4346d;
            byte b6 = bArr[i6];
            if (b6 >= 0) {
                this.f4349g = i8;
                return b6;
            }
            if (i7 - i8 >= 9) {
                int i9 = i6 + 2;
                int i10 = (bArr[i8] << 7) ^ b6;
                if (i10 < 0) {
                    j6 = i10 ^ (-128);
                } else {
                    int i11 = i6 + 3;
                    int i12 = (bArr[i9] << 14) ^ i10;
                    if (i12 >= 0) {
                        j6 = i12 ^ 16256;
                        i9 = i11;
                    } else {
                        int i13 = i6 + 4;
                        int i14 = i12 ^ (bArr[i11] << 21);
                        if (i14 < 0) {
                            j9 = (-2080896) ^ i14;
                        } else {
                            long j10 = i14;
                            i9 = i6 + 5;
                            long j11 = j10 ^ (((long) bArr[i13]) << 28);
                            if (j11 >= 0) {
                                j8 = 266354560;
                            } else {
                                i13 = i6 + 6;
                                long j12 = j11 ^ (((long) bArr[i9]) << 35);
                                if (j12 < 0) {
                                    j7 = -34093383808L;
                                } else {
                                    i9 = i6 + 7;
                                    j11 = j12 ^ (((long) bArr[i13]) << 42);
                                    if (j11 >= 0) {
                                        j8 = 4363953127296L;
                                    } else {
                                        i13 = i6 + 8;
                                        j12 = j11 ^ (((long) bArr[i9]) << 49);
                                        if (j12 < 0) {
                                            j7 = -558586000294016L;
                                        } else {
                                            i9 = i6 + 9;
                                            long j13 = (j12 ^ (((long) bArr[i13]) << 56)) ^ 71499008037633920L;
                                            if (j13 < 0) {
                                                int i15 = i6 + 10;
                                                if (bArr[i9] >= 0) {
                                                    i9 = i15;
                                                }
                                            }
                                            j6 = j13;
                                        }
                                    }
                                }
                                j9 = j7 ^ j12;
                            }
                            j6 = j8 ^ j11;
                        }
                        i9 = i13;
                        j6 = j9;
                    }
                }
                this.f4349g = i9;
                return j6;
            }
        }
        return u();
    }

    public final long u() throws C0176x {
        long j6 = 0;
        for (int i6 = 0; i6 < 64; i6 += 7) {
            if (this.f4349g == this.f4347e) {
                D(1);
            }
            int i7 = this.f4349g;
            this.f4349g = i7 + 1;
            byte b6 = this.f4346d[i7];
            j6 |= ((long) (b6 & 127)) << i6;
            if ((b6 & 128) == 0) {
                return j6;
            }
        }
        throw C0176x.c();
    }

    public final int v() {
        return q();
    }

    public final long w() {
        return r();
    }

    public final int x() {
        int iS = s();
        return (-(iS & 1)) ^ (iS >>> 1);
    }

    public final long y() {
        long jT = t();
        return (-(jT & 1)) ^ (jT >>> 1);
    }

    public final int z() {
        if (c()) {
            this.f4350h = 0;
            return 0;
        }
        int iS = s();
        this.f4350h = iS;
        if ((iS >>> 3) != 0) {
            return iS;
        }
        throw new C0176x("Protocol message contained an invalid tag (zero).");
    }
}
