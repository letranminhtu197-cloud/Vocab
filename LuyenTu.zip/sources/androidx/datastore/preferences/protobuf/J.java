package androidx.datastore.preferences.protobuf;

import java.util.Map;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.pipes.PipesServer;

/* JADX INFO: loaded from: classes.dex */
public final class J {
    /* JADX WARN: Code duplicated, block: B:44:0x0128  */
    /* JADX WARN: Code duplicated, block: B:49:0x0137  */
    /* JADX WARN: Code duplicated, block: B:50:0x0148  */
    /* JADX WARN: Code duplicated, block: B:51:0x0159  */
    /* JADX WARN: Code duplicated, block: B:53:0x0161  */
    /* JADX WARN: Code duplicated, block: B:55:0x0169  */
    /* JADX WARN: Code duplicated, block: B:56:0x0175  */
    /* JADX WARN: Code duplicated, block: B:57:0x0181  */
    /* JADX WARN: Code duplicated, block: B:59:0x0185  */
    /* JADX WARN: Code duplicated, block: B:60:0x018d  */
    /* JADX WARN: Code duplicated, block: B:62:0x0197  */
    /* JADX WARN: Code duplicated, block: B:63:0x01a2  */
    /* JADX WARN: Code duplicated, block: B:64:0x01a9  */
    /* JADX WARN: Code duplicated, block: B:66:0x01ad  */
    /* JADX WARN: Code duplicated, block: B:67:0x01b4  */
    /* JADX WARN: Code duplicated, block: B:68:0x01bb  */
    /* JADX WARN: Code duplicated, block: B:69:0x01c1  */
    /* JADX WARN: Code duplicated, block: B:70:0x01c7  */
    /* JADX WARN: Code duplicated, block: B:71:0x01cd  */
    /* JADX WARN: Code duplicated, block: B:72:0x01d8  */
    /* JADX WARN: Code duplicated, block: B:73:0x01e3  */
    /* JADX WARN: Code duplicated, block: B:74:0x01ee  */
    /* JADX WARN: Code duplicated, block: B:75:0x01f5  */
    /* JADX WARN: Code duplicated, block: B:80:0x0131 A[SYNTHETIC] */
    public static int a(Object obj, Object obj2, int i6) {
        int iA;
        int iA2;
        int iZ;
        int i7;
        w0 w0Var;
        int iY;
        int iA3;
        int iZ2;
        I i8 = (I) obj;
        H h7 = (H) obj2;
        int iJ = 0;
        if (i8.isEmpty()) {
            return 0;
        }
        for (Map.Entry entry : i8.entrySet()) {
            Object key = entry.getKey();
            Object value = entry.getValue();
            h7.getClass();
            int iY2 = C0163j.y(i6);
            G g7 = h7.f4281a;
            w0 w0Var2 = g7.f4278a;
            int i9 = C0168o.f4372c;
            int iA4 = 1;
            int iY3 = C0163j.y(1);
            t0 t0Var = w0.f4393u;
            if (w0Var2 == t0Var) {
                iY3 *= 2;
            }
            switch (w0Var2.ordinal()) {
                case 0:
                    ((Double) key).getClass();
                    iA = 8;
                    i7 = iA + iY3;
                    w0Var = g7.f4279b;
                    iY = C0163j.y(2);
                    if (w0Var == t0Var) {
                        iY *= 2;
                    }
                    switch (w0Var.ordinal()) {
                        case 0:
                            ((Double) value).getClass();
                            iA4 = 8;
                            int i10 = iA4 + iY + i7;
                            iJ = A3.a.j(i10, i10, iY2, iJ);
                            break;
                        case 1:
                            ((Float) value).getClass();
                            iA4 = 4;
                            int i11 = iA4 + iY + i7;
                            iJ = A3.a.j(i11, i11, iY2, iJ);
                            break;
                        case 2:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i12 = iA4 + iY + i7;
                            iJ = A3.a.j(i12, i12, iY2, iJ);
                            break;
                        case 3:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i13 = iA4 + iY + i7;
                            iJ = A3.a.j(i13, i13, iY2, iJ);
                            break;
                        case 4:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i14 = iA4 + iY + i7;
                            iJ = A3.a.j(i14, i14, iY2, iJ);
                            break;
                        case 5:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i15 = iA4 + iY + i7;
                            iJ = A3.a.j(i15, i15, iY2, iJ);
                            break;
                        case 6:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i16 = iA4 + iY + i7;
                            iJ = A3.a.j(i16, i16, iY2, iJ);
                            break;
                        case 7:
                            ((Boolean) value).getClass();
                            int i17 = iA4 + iY + i7;
                            iJ = A3.a.j(i17, i17, iY2, iJ);
                            break;
                        case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA4 = C0163j.x((String) value);
                            }
                            int i18 = iA4 + iY + i7;
                            iJ = A3.a.j(i18, i18, iY2, iJ);
                            break;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            iA4 = ((AbstractC0154a) value).a();
                            int i19 = iA4 + iY + i7;
                            iJ = A3.a.j(i19, i19, iY2, iJ);
                            break;
                        case 10:
                            iA3 = ((AbstractC0154a) value).a();
                            iZ2 = C0163j.z(iA3);
                            iA4 = iZ2 + iA3;
                            int i110 = iA4 + iY + i7;
                            iJ = A3.a.j(i110, i110, iY2, iJ);
                            break;
                        case 11:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA3 = ((byte[]) value).length;
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                            }
                            int i111 = iA4 + iY + i7;
                            iJ = A3.a.j(i111, i111, iY2, iJ);
                            break;
                        case 12:
                            iA4 = C0163j.z(((Integer) value).intValue());
                            int i112 = iA4 + iY + i7;
                            iJ = A3.a.j(i112, i112, iY2, iJ);
                            break;
                        case 13:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i113 = iA4 + iY + i7;
                            iJ = A3.a.j(i113, i113, iY2, iJ);
                            break;
                        case 14:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i114 = iA4 + iY + i7;
                            iJ = A3.a.j(i114, i114, iY2, iJ);
                            break;
                        case 15:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i115 = iA4 + iY + i7;
                            iJ = A3.a.j(i115, i115, iY2, iJ);
                            break;
                        case 16:
                            int iIntValue = ((Integer) value).intValue();
                            iA4 = C0163j.z((iIntValue >> 31) ^ (iIntValue << 1));
                            int i116 = iA4 + iY + i7;
                            iJ = A3.a.j(i116, i116, iY2, iJ);
                            break;
                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                            long jLongValue = ((Long) value).longValue();
                            iA4 = C0163j.A((jLongValue >> 63) ^ (jLongValue << 1));
                            int i117 = iA4 + iY + i7;
                            iJ = A3.a.j(i117, i117, iY2, iJ);
                            break;
                        default:
                            throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                    }
                    break;
                case 1:
                    ((Float) key).getClass();
                    iA = 4;
                    i7 = iA + iY3;
                    w0Var = g7.f4279b;
                    iY = C0163j.y(2);
                    if (w0Var == t0Var) {
                        iY *= 2;
                    }
                    switch (w0Var.ordinal()) {
                        case 0:
                            ((Double) value).getClass();
                            iA4 = 8;
                            int i118 = iA4 + iY + i7;
                            iJ = A3.a.j(i118, i118, iY2, iJ);
                            break;
                        case 1:
                            ((Float) value).getClass();
                            iA4 = 4;
                            int i119 = iA4 + iY + i7;
                            iJ = A3.a.j(i119, i119, iY2, iJ);
                            break;
                        case 2:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i1110 = iA4 + iY + i7;
                            iJ = A3.a.j(i1110, i1110, iY2, iJ);
                            break;
                        case 3:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i1111 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111, i1111, iY2, iJ);
                            break;
                        case 4:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i1112 = iA4 + iY + i7;
                            iJ = A3.a.j(i1112, i1112, iY2, iJ);
                            break;
                        case 5:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i1113 = iA4 + iY + i7;
                            iJ = A3.a.j(i1113, i1113, iY2, iJ);
                            break;
                        case 6:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i1114 = iA4 + iY + i7;
                            iJ = A3.a.j(i1114, i1114, iY2, iJ);
                            break;
                        case 7:
                            ((Boolean) value).getClass();
                            int i1115 = iA4 + iY + i7;
                            iJ = A3.a.j(i1115, i1115, iY2, iJ);
                            break;
                        case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA4 = C0163j.x((String) value);
                            }
                            int i1116 = iA4 + iY + i7;
                            iJ = A3.a.j(i1116, i1116, iY2, iJ);
                            break;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            iA4 = ((AbstractC0154a) value).a();
                            int i1117 = iA4 + iY + i7;
                            iJ = A3.a.j(i1117, i1117, iY2, iJ);
                            break;
                        case 10:
                            iA3 = ((AbstractC0154a) value).a();
                            iZ2 = C0163j.z(iA3);
                            iA4 = iZ2 + iA3;
                            int i1118 = iA4 + iY + i7;
                            iJ = A3.a.j(i1118, i1118, iY2, iJ);
                            break;
                        case 11:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA3 = ((byte[]) value).length;
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                            }
                            int i1119 = iA4 + iY + i7;
                            iJ = A3.a.j(i1119, i1119, iY2, iJ);
                            break;
                        case 12:
                            iA4 = C0163j.z(((Integer) value).intValue());
                            int i11110 = iA4 + iY + i7;
                            iJ = A3.a.j(i11110, i11110, iY2, iJ);
                            break;
                        case 13:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i11111 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111, i11111, iY2, iJ);
                            break;
                        case 14:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i11112 = iA4 + iY + i7;
                            iJ = A3.a.j(i11112, i11112, iY2, iJ);
                            break;
                        case 15:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i11113 = iA4 + iY + i7;
                            iJ = A3.a.j(i11113, i11113, iY2, iJ);
                            break;
                        case 16:
                            int iIntValue2 = ((Integer) value).intValue();
                            iA4 = C0163j.z((iIntValue2 >> 31) ^ (iIntValue2 << 1));
                            int i11114 = iA4 + iY + i7;
                            iJ = A3.a.j(i11114, i11114, iY2, iJ);
                            break;
                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                            long jLongValue2 = ((Long) value).longValue();
                            iA4 = C0163j.A((jLongValue2 >> 63) ^ (jLongValue2 << 1));
                            int i11115 = iA4 + iY + i7;
                            iJ = A3.a.j(i11115, i11115, iY2, iJ);
                            break;
                        default:
                            throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                    }
                    break;
                case 2:
                    iA = C0163j.A(((Long) key).longValue());
                    i7 = iA + iY3;
                    w0Var = g7.f4279b;
                    iY = C0163j.y(2);
                    if (w0Var == t0Var) {
                        iY *= 2;
                    }
                    switch (w0Var.ordinal()) {
                        case 0:
                            ((Double) value).getClass();
                            iA4 = 8;
                            int i11116 = iA4 + iY + i7;
                            iJ = A3.a.j(i11116, i11116, iY2, iJ);
                            break;
                        case 1:
                            ((Float) value).getClass();
                            iA4 = 4;
                            int i11117 = iA4 + iY + i7;
                            iJ = A3.a.j(i11117, i11117, iY2, iJ);
                            break;
                        case 2:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i11118 = iA4 + iY + i7;
                            iJ = A3.a.j(i11118, i11118, iY2, iJ);
                            break;
                        case 3:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i11119 = iA4 + iY + i7;
                            iJ = A3.a.j(i11119, i11119, iY2, iJ);
                            break;
                        case 4:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i111110, i111110, iY2, iJ);
                            break;
                        case 5:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111, i111111, iY2, iJ);
                            break;
                        case 6:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i111112, i111112, iY2, iJ);
                            break;
                        case 7:
                            ((Boolean) value).getClass();
                            int i111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i111113, i111113, iY2, iJ);
                            break;
                        case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA4 = C0163j.x((String) value);
                            }
                            int i111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i111114, i111114, iY2, iJ);
                            break;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            iA4 = ((AbstractC0154a) value).a();
                            int i111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i111115, i111115, iY2, iJ);
                            break;
                        case 10:
                            iA3 = ((AbstractC0154a) value).a();
                            iZ2 = C0163j.z(iA3);
                            iA4 = iZ2 + iA3;
                            int i111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i111116, i111116, iY2, iJ);
                            break;
                        case 11:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA3 = ((byte[]) value).length;
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                            }
                            int i111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i111117, i111117, iY2, iJ);
                            break;
                        case 12:
                            iA4 = C0163j.z(((Integer) value).intValue());
                            int i111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i111118, i111118, iY2, iJ);
                            break;
                        case 13:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i111119, i111119, iY2, iJ);
                            break;
                        case 14:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i1111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111110, i1111110, iY2, iJ);
                            break;
                        case 15:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i1111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111, i1111111, iY2, iJ);
                            break;
                        case 16:
                            int iIntValue3 = ((Integer) value).intValue();
                            iA4 = C0163j.z((iIntValue3 >> 31) ^ (iIntValue3 << 1));
                            int i1111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111112, i1111112, iY2, iJ);
                            break;
                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                            long jLongValue3 = ((Long) value).longValue();
                            iA4 = C0163j.A((jLongValue3 >> 63) ^ (jLongValue3 << 1));
                            int i1111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111113, i1111113, iY2, iJ);
                            break;
                        default:
                            throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                    }
                    break;
                case 3:
                    iA = C0163j.A(((Long) key).longValue());
                    i7 = iA + iY3;
                    w0Var = g7.f4279b;
                    iY = C0163j.y(2);
                    if (w0Var == t0Var) {
                        iY *= 2;
                    }
                    switch (w0Var.ordinal()) {
                        case 0:
                            ((Double) value).getClass();
                            iA4 = 8;
                            int i1111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111114, i1111114, iY2, iJ);
                            break;
                        case 1:
                            ((Float) value).getClass();
                            iA4 = 4;
                            int i1111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111115, i1111115, iY2, iJ);
                            break;
                        case 2:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i1111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111116, i1111116, iY2, iJ);
                            break;
                        case 3:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i1111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111117, i1111117, iY2, iJ);
                            break;
                        case 4:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i1111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111118, i1111118, iY2, iJ);
                            break;
                        case 5:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i1111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111119, i1111119, iY2, iJ);
                            break;
                        case 6:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i11111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111110, i11111110, iY2, iJ);
                            break;
                        case 7:
                            ((Boolean) value).getClass();
                            int i11111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111, i11111111, iY2, iJ);
                            break;
                        case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA4 = C0163j.x((String) value);
                            }
                            int i11111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111112, i11111112, iY2, iJ);
                            break;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            iA4 = ((AbstractC0154a) value).a();
                            int i11111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111113, i11111113, iY2, iJ);
                            break;
                        case 10:
                            iA3 = ((AbstractC0154a) value).a();
                            iZ2 = C0163j.z(iA3);
                            iA4 = iZ2 + iA3;
                            int i11111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111114, i11111114, iY2, iJ);
                            break;
                        case 11:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA3 = ((byte[]) value).length;
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                            }
                            int i11111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111115, i11111115, iY2, iJ);
                            break;
                        case 12:
                            iA4 = C0163j.z(((Integer) value).intValue());
                            int i11111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111116, i11111116, iY2, iJ);
                            break;
                        case 13:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i11111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111117, i11111117, iY2, iJ);
                            break;
                        case 14:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i11111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111118, i11111118, iY2, iJ);
                            break;
                        case 15:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i11111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111119, i11111119, iY2, iJ);
                            break;
                        case 16:
                            int iIntValue4 = ((Integer) value).intValue();
                            iA4 = C0163j.z((iIntValue4 >> 31) ^ (iIntValue4 << 1));
                            int i111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111110, i111111110, iY2, iJ);
                            break;
                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                            long jLongValue4 = ((Long) value).longValue();
                            iA4 = C0163j.A((jLongValue4 >> 63) ^ (jLongValue4 << 1));
                            int i111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111, i111111111, iY2, iJ);
                            break;
                        default:
                            throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                    }
                    break;
                case 4:
                    iA = C0163j.w(((Integer) key).intValue());
                    i7 = iA + iY3;
                    w0Var = g7.f4279b;
                    iY = C0163j.y(2);
                    if (w0Var == t0Var) {
                        iY *= 2;
                    }
                    switch (w0Var.ordinal()) {
                        case 0:
                            ((Double) value).getClass();
                            iA4 = 8;
                            int i111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111112, i111111112, iY2, iJ);
                            break;
                        case 1:
                            ((Float) value).getClass();
                            iA4 = 4;
                            int i111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111113, i111111113, iY2, iJ);
                            break;
                        case 2:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111114, i111111114, iY2, iJ);
                            break;
                        case 3:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111115, i111111115, iY2, iJ);
                            break;
                        case 4:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111116, i111111116, iY2, iJ);
                            break;
                        case 5:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111117, i111111117, iY2, iJ);
                            break;
                        case 6:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111118, i111111118, iY2, iJ);
                            break;
                        case 7:
                            ((Boolean) value).getClass();
                            int i111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111119, i111111119, iY2, iJ);
                            break;
                        case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA4 = C0163j.x((String) value);
                            }
                            int i1111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111110, i1111111110, iY2, iJ);
                            break;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            iA4 = ((AbstractC0154a) value).a();
                            int i1111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111, i1111111111, iY2, iJ);
                            break;
                        case 10:
                            iA3 = ((AbstractC0154a) value).a();
                            iZ2 = C0163j.z(iA3);
                            iA4 = iZ2 + iA3;
                            int i1111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111112, i1111111112, iY2, iJ);
                            break;
                        case 11:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA3 = ((byte[]) value).length;
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                            }
                            int i1111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111113, i1111111113, iY2, iJ);
                            break;
                        case 12:
                            iA4 = C0163j.z(((Integer) value).intValue());
                            int i1111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111114, i1111111114, iY2, iJ);
                            break;
                        case 13:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i1111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111115, i1111111115, iY2, iJ);
                            break;
                        case 14:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i1111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111116, i1111111116, iY2, iJ);
                            break;
                        case 15:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i1111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111117, i1111111117, iY2, iJ);
                            break;
                        case 16:
                            int iIntValue5 = ((Integer) value).intValue();
                            iA4 = C0163j.z((iIntValue5 >> 31) ^ (iIntValue5 << 1));
                            int i1111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111118, i1111111118, iY2, iJ);
                            break;
                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                            long jLongValue5 = ((Long) value).longValue();
                            iA4 = C0163j.A((jLongValue5 >> 63) ^ (jLongValue5 << 1));
                            int i1111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111119, i1111111119, iY2, iJ);
                            break;
                        default:
                            throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                    }
                    break;
                case 5:
                    ((Long) key).getClass();
                    iA = 8;
                    i7 = iA + iY3;
                    w0Var = g7.f4279b;
                    iY = C0163j.y(2);
                    if (w0Var == t0Var) {
                        iY *= 2;
                    }
                    switch (w0Var.ordinal()) {
                        case 0:
                            ((Double) value).getClass();
                            iA4 = 8;
                            int i11111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111110, i11111111110, iY2, iJ);
                            break;
                        case 1:
                            ((Float) value).getClass();
                            iA4 = 4;
                            int i11111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111, i11111111111, iY2, iJ);
                            break;
                        case 2:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i11111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111112, i11111111112, iY2, iJ);
                            break;
                        case 3:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i11111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111113, i11111111113, iY2, iJ);
                            break;
                        case 4:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i11111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111114, i11111111114, iY2, iJ);
                            break;
                        case 5:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i11111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111115, i11111111115, iY2, iJ);
                            break;
                        case 6:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i11111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111116, i11111111116, iY2, iJ);
                            break;
                        case 7:
                            ((Boolean) value).getClass();
                            int i11111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111117, i11111111117, iY2, iJ);
                            break;
                        case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA4 = C0163j.x((String) value);
                            }
                            int i11111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111118, i11111111118, iY2, iJ);
                            break;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            iA4 = ((AbstractC0154a) value).a();
                            int i11111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111119, i11111111119, iY2, iJ);
                            break;
                        case 10:
                            iA3 = ((AbstractC0154a) value).a();
                            iZ2 = C0163j.z(iA3);
                            iA4 = iZ2 + iA3;
                            int i111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111110, i111111111110, iY2, iJ);
                            break;
                        case 11:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA3 = ((byte[]) value).length;
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                            }
                            int i111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111, i111111111111, iY2, iJ);
                            break;
                        case 12:
                            iA4 = C0163j.z(((Integer) value).intValue());
                            int i111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111112, i111111111112, iY2, iJ);
                            break;
                        case 13:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111113, i111111111113, iY2, iJ);
                            break;
                        case 14:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111114, i111111111114, iY2, iJ);
                            break;
                        case 15:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111115, i111111111115, iY2, iJ);
                            break;
                        case 16:
                            int iIntValue6 = ((Integer) value).intValue();
                            iA4 = C0163j.z((iIntValue6 >> 31) ^ (iIntValue6 << 1));
                            int i111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111116, i111111111116, iY2, iJ);
                            break;
                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                            long jLongValue6 = ((Long) value).longValue();
                            iA4 = C0163j.A((jLongValue6 >> 63) ^ (jLongValue6 << 1));
                            int i111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111117, i111111111117, iY2, iJ);
                            break;
                        default:
                            throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                    }
                    break;
                case 6:
                    ((Integer) key).getClass();
                    iA = 4;
                    i7 = iA + iY3;
                    w0Var = g7.f4279b;
                    iY = C0163j.y(2);
                    if (w0Var == t0Var) {
                        iY *= 2;
                    }
                    switch (w0Var.ordinal()) {
                        case 0:
                            ((Double) value).getClass();
                            iA4 = 8;
                            int i111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111118, i111111111118, iY2, iJ);
                            break;
                        case 1:
                            ((Float) value).getClass();
                            iA4 = 4;
                            int i111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111119, i111111111119, iY2, iJ);
                            break;
                        case 2:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i1111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111110, i1111111111110, iY2, iJ);
                            break;
                        case 3:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i1111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111, i1111111111111, iY2, iJ);
                            break;
                        case 4:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i1111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111112, i1111111111112, iY2, iJ);
                            break;
                        case 5:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i1111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111113, i1111111111113, iY2, iJ);
                            break;
                        case 6:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i1111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111114, i1111111111114, iY2, iJ);
                            break;
                        case 7:
                            ((Boolean) value).getClass();
                            int i1111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111115, i1111111111115, iY2, iJ);
                            break;
                        case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA4 = C0163j.x((String) value);
                            }
                            int i1111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111116, i1111111111116, iY2, iJ);
                            break;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            iA4 = ((AbstractC0154a) value).a();
                            int i1111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111117, i1111111111117, iY2, iJ);
                            break;
                        case 10:
                            iA3 = ((AbstractC0154a) value).a();
                            iZ2 = C0163j.z(iA3);
                            iA4 = iZ2 + iA3;
                            int i1111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111118, i1111111111118, iY2, iJ);
                            break;
                        case 11:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA3 = ((byte[]) value).length;
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                            }
                            int i1111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111119, i1111111111119, iY2, iJ);
                            break;
                        case 12:
                            iA4 = C0163j.z(((Integer) value).intValue());
                            int i11111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111110, i11111111111110, iY2, iJ);
                            break;
                        case 13:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i11111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111, i11111111111111, iY2, iJ);
                            break;
                        case 14:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i11111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111112, i11111111111112, iY2, iJ);
                            break;
                        case 15:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i11111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111113, i11111111111113, iY2, iJ);
                            break;
                        case 16:
                            int iIntValue7 = ((Integer) value).intValue();
                            iA4 = C0163j.z((iIntValue7 >> 31) ^ (iIntValue7 << 1));
                            int i11111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111114, i11111111111114, iY2, iJ);
                            break;
                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                            long jLongValue7 = ((Long) value).longValue();
                            iA4 = C0163j.A((jLongValue7 >> 63) ^ (jLongValue7 << 1));
                            int i11111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111115, i11111111111115, iY2, iJ);
                            break;
                        default:
                            throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                    }
                    break;
                case 7:
                    ((Boolean) key).getClass();
                    iA = 1;
                    i7 = iA + iY3;
                    w0Var = g7.f4279b;
                    iY = C0163j.y(2);
                    if (w0Var == t0Var) {
                        iY *= 2;
                    }
                    switch (w0Var.ordinal()) {
                        case 0:
                            ((Double) value).getClass();
                            iA4 = 8;
                            int i11111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111116, i11111111111116, iY2, iJ);
                            break;
                        case 1:
                            ((Float) value).getClass();
                            iA4 = 4;
                            int i11111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111117, i11111111111117, iY2, iJ);
                            break;
                        case 2:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i11111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111118, i11111111111118, iY2, iJ);
                            break;
                        case 3:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i11111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111119, i11111111111119, iY2, iJ);
                            break;
                        case 4:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111110, i111111111111110, iY2, iJ);
                            break;
                        case 5:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111, i111111111111111, iY2, iJ);
                            break;
                        case 6:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111112, i111111111111112, iY2, iJ);
                            break;
                        case 7:
                            ((Boolean) value).getClass();
                            int i111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111113, i111111111111113, iY2, iJ);
                            break;
                        case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA4 = C0163j.x((String) value);
                            }
                            int i111111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111114, i111111111111114, iY2, iJ);
                            break;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            iA4 = ((AbstractC0154a) value).a();
                            int i111111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111115, i111111111111115, iY2, iJ);
                            break;
                        case 10:
                            iA3 = ((AbstractC0154a) value).a();
                            iZ2 = C0163j.z(iA3);
                            iA4 = iZ2 + iA3;
                            int i111111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111116, i111111111111116, iY2, iJ);
                            break;
                        case 11:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA3 = ((byte[]) value).length;
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                            }
                            int i111111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111117, i111111111111117, iY2, iJ);
                            break;
                        case 12:
                            iA4 = C0163j.z(((Integer) value).intValue());
                            int i111111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111118, i111111111111118, iY2, iJ);
                            break;
                        case 13:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i111111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111119, i111111111111119, iY2, iJ);
                            break;
                        case 14:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i1111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111110, i1111111111111110, iY2, iJ);
                            break;
                        case 15:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i1111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111, i1111111111111111, iY2, iJ);
                            break;
                        case 16:
                            int iIntValue8 = ((Integer) value).intValue();
                            iA4 = C0163j.z((iIntValue8 >> 31) ^ (iIntValue8 << 1));
                            int i1111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111112, i1111111111111112, iY2, iJ);
                            break;
                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                            long jLongValue8 = ((Long) value).longValue();
                            iA4 = C0163j.A((jLongValue8 >> 63) ^ (jLongValue8 << 1));
                            int i1111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111113, i1111111111111113, iY2, iJ);
                            break;
                        default:
                            throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                    }
                    break;
                case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                    iA = key instanceof C0159f ? C0163j.s((C0159f) key) : C0163j.x((String) key);
                    i7 = iA + iY3;
                    w0Var = g7.f4279b;
                    iY = C0163j.y(2);
                    if (w0Var == t0Var) {
                        iY *= 2;
                    }
                    switch (w0Var.ordinal()) {
                        case 0:
                            ((Double) value).getClass();
                            iA4 = 8;
                            int i1111111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111114, i1111111111111114, iY2, iJ);
                            break;
                        case 1:
                            ((Float) value).getClass();
                            iA4 = 4;
                            int i1111111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111115, i1111111111111115, iY2, iJ);
                            break;
                        case 2:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i1111111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111116, i1111111111111116, iY2, iJ);
                            break;
                        case 3:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i1111111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111117, i1111111111111117, iY2, iJ);
                            break;
                        case 4:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i1111111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111118, i1111111111111118, iY2, iJ);
                            break;
                        case 5:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i1111111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111119, i1111111111111119, iY2, iJ);
                            break;
                        case 6:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i11111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111110, i11111111111111110, iY2, iJ);
                            break;
                        case 7:
                            ((Boolean) value).getClass();
                            int i11111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111, i11111111111111111, iY2, iJ);
                            break;
                        case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA4 = C0163j.x((String) value);
                            }
                            int i11111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111112, i11111111111111112, iY2, iJ);
                            break;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            iA4 = ((AbstractC0154a) value).a();
                            int i11111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111113, i11111111111111113, iY2, iJ);
                            break;
                        case 10:
                            iA3 = ((AbstractC0154a) value).a();
                            iZ2 = C0163j.z(iA3);
                            iA4 = iZ2 + iA3;
                            int i11111111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111114, i11111111111111114, iY2, iJ);
                            break;
                        case 11:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA3 = ((byte[]) value).length;
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                            }
                            int i11111111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111115, i11111111111111115, iY2, iJ);
                            break;
                        case 12:
                            iA4 = C0163j.z(((Integer) value).intValue());
                            int i11111111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111116, i11111111111111116, iY2, iJ);
                            break;
                        case 13:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i11111111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111117, i11111111111111117, iY2, iJ);
                            break;
                        case 14:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i11111111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111118, i11111111111111118, iY2, iJ);
                            break;
                        case 15:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i11111111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111119, i11111111111111119, iY2, iJ);
                            break;
                        case 16:
                            int iIntValue9 = ((Integer) value).intValue();
                            iA4 = C0163j.z((iIntValue9 >> 31) ^ (iIntValue9 << 1));
                            int i111111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111110, i111111111111111110, iY2, iJ);
                            break;
                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                            long jLongValue9 = ((Long) value).longValue();
                            iA4 = C0163j.A((jLongValue9 >> 63) ^ (jLongValue9 << 1));
                            int i111111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111, i111111111111111111, iY2, iJ);
                            break;
                        default:
                            throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                    }
                    break;
                case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                    iA = ((AbstractC0154a) key).a();
                    i7 = iA + iY3;
                    w0Var = g7.f4279b;
                    iY = C0163j.y(2);
                    if (w0Var == t0Var) {
                        iY *= 2;
                    }
                    switch (w0Var.ordinal()) {
                        case 0:
                            ((Double) value).getClass();
                            iA4 = 8;
                            int i111111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111112, i111111111111111112, iY2, iJ);
                            break;
                        case 1:
                            ((Float) value).getClass();
                            iA4 = 4;
                            int i111111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111113, i111111111111111113, iY2, iJ);
                            break;
                        case 2:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i111111111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111114, i111111111111111114, iY2, iJ);
                            break;
                        case 3:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i111111111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111115, i111111111111111115, iY2, iJ);
                            break;
                        case 4:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i111111111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111116, i111111111111111116, iY2, iJ);
                            break;
                        case 5:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i111111111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111117, i111111111111111117, iY2, iJ);
                            break;
                        case 6:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i111111111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111118, i111111111111111118, iY2, iJ);
                            break;
                        case 7:
                            ((Boolean) value).getClass();
                            int i111111111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111119, i111111111111111119, iY2, iJ);
                            break;
                        case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA4 = C0163j.x((String) value);
                            }
                            int i1111111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111110, i1111111111111111110, iY2, iJ);
                            break;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            iA4 = ((AbstractC0154a) value).a();
                            int i1111111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111, i1111111111111111111, iY2, iJ);
                            break;
                        case 10:
                            iA3 = ((AbstractC0154a) value).a();
                            iZ2 = C0163j.z(iA3);
                            iA4 = iZ2 + iA3;
                            int i1111111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111112, i1111111111111111112, iY2, iJ);
                            break;
                        case 11:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA3 = ((byte[]) value).length;
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                            }
                            int i1111111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111113, i1111111111111111113, iY2, iJ);
                            break;
                        case 12:
                            iA4 = C0163j.z(((Integer) value).intValue());
                            int i1111111111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111114, i1111111111111111114, iY2, iJ);
                            break;
                        case 13:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i1111111111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111115, i1111111111111111115, iY2, iJ);
                            break;
                        case 14:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i1111111111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111116, i1111111111111111116, iY2, iJ);
                            break;
                        case 15:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i1111111111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111117, i1111111111111111117, iY2, iJ);
                            break;
                        case 16:
                            int iIntValue10 = ((Integer) value).intValue();
                            iA4 = C0163j.z((iIntValue10 >> 31) ^ (iIntValue10 << 1));
                            int i1111111111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111118, i1111111111111111118, iY2, iJ);
                            break;
                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                            long jLongValue10 = ((Long) value).longValue();
                            iA4 = C0163j.A((jLongValue10 >> 63) ^ (jLongValue10 << 1));
                            int i1111111111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111119, i1111111111111111119, iY2, iJ);
                            break;
                        default:
                            throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                    }
                    break;
                case 10:
                    iA2 = ((AbstractC0154a) key).a();
                    iZ = C0163j.z(iA2);
                    iA = iA2 + iZ;
                    i7 = iA + iY3;
                    w0Var = g7.f4279b;
                    iY = C0163j.y(2);
                    if (w0Var == t0Var) {
                        iY *= 2;
                    }
                    switch (w0Var.ordinal()) {
                        case 0:
                            ((Double) value).getClass();
                            iA4 = 8;
                            int i11111111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111110, i11111111111111111110, iY2, iJ);
                            break;
                        case 1:
                            ((Float) value).getClass();
                            iA4 = 4;
                            int i11111111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111, i11111111111111111111, iY2, iJ);
                            break;
                        case 2:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i11111111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111112, i11111111111111111112, iY2, iJ);
                            break;
                        case 3:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i11111111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111113, i11111111111111111113, iY2, iJ);
                            break;
                        case 4:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i11111111111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111114, i11111111111111111114, iY2, iJ);
                            break;
                        case 5:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i11111111111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111115, i11111111111111111115, iY2, iJ);
                            break;
                        case 6:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i11111111111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111116, i11111111111111111116, iY2, iJ);
                            break;
                        case 7:
                            ((Boolean) value).getClass();
                            int i11111111111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111117, i11111111111111111117, iY2, iJ);
                            break;
                        case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA4 = C0163j.x((String) value);
                            }
                            int i11111111111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111118, i11111111111111111118, iY2, iJ);
                            break;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            iA4 = ((AbstractC0154a) value).a();
                            int i11111111111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111119, i11111111111111111119, iY2, iJ);
                            break;
                        case 10:
                            iA3 = ((AbstractC0154a) value).a();
                            iZ2 = C0163j.z(iA3);
                            iA4 = iZ2 + iA3;
                            int i111111111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111110, i111111111111111111110, iY2, iJ);
                            break;
                        case 11:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA3 = ((byte[]) value).length;
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                            }
                            int i111111111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111, i111111111111111111111, iY2, iJ);
                            break;
                        case 12:
                            iA4 = C0163j.z(((Integer) value).intValue());
                            int i111111111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111112, i111111111111111111112, iY2, iJ);
                            break;
                        case 13:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i111111111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111113, i111111111111111111113, iY2, iJ);
                            break;
                        case 14:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i111111111111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111114, i111111111111111111114, iY2, iJ);
                            break;
                        case 15:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i111111111111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111115, i111111111111111111115, iY2, iJ);
                            break;
                        case 16:
                            int iIntValue11 = ((Integer) value).intValue();
                            iA4 = C0163j.z((iIntValue11 >> 31) ^ (iIntValue11 << 1));
                            int i111111111111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111116, i111111111111111111116, iY2, iJ);
                            break;
                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                            long jLongValue11 = ((Long) value).longValue();
                            iA4 = C0163j.A((jLongValue11 >> 63) ^ (jLongValue11 << 1));
                            int i111111111111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111117, i111111111111111111117, iY2, iJ);
                            break;
                        default:
                            throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                    }
                    break;
                case 11:
                    if (key instanceof C0159f) {
                        iA = C0163j.s((C0159f) key);
                    } else {
                        iA2 = ((byte[]) key).length;
                        iZ = C0163j.z(iA2);
                        iA = iA2 + iZ;
                    }
                    i7 = iA + iY3;
                    w0Var = g7.f4279b;
                    iY = C0163j.y(2);
                    if (w0Var == t0Var) {
                        iY *= 2;
                    }
                    switch (w0Var.ordinal()) {
                        case 0:
                            ((Double) value).getClass();
                            iA4 = 8;
                            int i111111111111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111118, i111111111111111111118, iY2, iJ);
                            break;
                        case 1:
                            ((Float) value).getClass();
                            iA4 = 4;
                            int i111111111111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111119, i111111111111111111119, iY2, iJ);
                            break;
                        case 2:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i1111111111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111110, i1111111111111111111110, iY2, iJ);
                            break;
                        case 3:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i1111111111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111, i1111111111111111111111, iY2, iJ);
                            break;
                        case 4:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i1111111111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111112, i1111111111111111111112, iY2, iJ);
                            break;
                        case 5:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i1111111111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111113, i1111111111111111111113, iY2, iJ);
                            break;
                        case 6:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i1111111111111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111114, i1111111111111111111114, iY2, iJ);
                            break;
                        case 7:
                            ((Boolean) value).getClass();
                            int i1111111111111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111115, i1111111111111111111115, iY2, iJ);
                            break;
                        case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA4 = C0163j.x((String) value);
                            }
                            int i1111111111111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111116, i1111111111111111111116, iY2, iJ);
                            break;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            iA4 = ((AbstractC0154a) value).a();
                            int i1111111111111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111117, i1111111111111111111117, iY2, iJ);
                            break;
                        case 10:
                            iA3 = ((AbstractC0154a) value).a();
                            iZ2 = C0163j.z(iA3);
                            iA4 = iZ2 + iA3;
                            int i1111111111111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111118, i1111111111111111111118, iY2, iJ);
                            break;
                        case 11:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA3 = ((byte[]) value).length;
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                            }
                            int i1111111111111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111119, i1111111111111111111119, iY2, iJ);
                            break;
                        case 12:
                            iA4 = C0163j.z(((Integer) value).intValue());
                            int i11111111111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111110, i11111111111111111111110, iY2, iJ);
                            break;
                        case 13:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i11111111111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111, i11111111111111111111111, iY2, iJ);
                            break;
                        case 14:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i11111111111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111112, i11111111111111111111112, iY2, iJ);
                            break;
                        case 15:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i11111111111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111113, i11111111111111111111113, iY2, iJ);
                            break;
                        case 16:
                            int iIntValue12 = ((Integer) value).intValue();
                            iA4 = C0163j.z((iIntValue12 >> 31) ^ (iIntValue12 << 1));
                            int i11111111111111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111114, i11111111111111111111114, iY2, iJ);
                            break;
                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                            long jLongValue12 = ((Long) value).longValue();
                            iA4 = C0163j.A((jLongValue12 >> 63) ^ (jLongValue12 << 1));
                            int i11111111111111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111115, i11111111111111111111115, iY2, iJ);
                            break;
                        default:
                            throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                    }
                    break;
                case 12:
                    iA = C0163j.z(((Integer) key).intValue());
                    i7 = iA + iY3;
                    w0Var = g7.f4279b;
                    iY = C0163j.y(2);
                    if (w0Var == t0Var) {
                        iY *= 2;
                    }
                    switch (w0Var.ordinal()) {
                        case 0:
                            ((Double) value).getClass();
                            iA4 = 8;
                            int i11111111111111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111116, i11111111111111111111116, iY2, iJ);
                            break;
                        case 1:
                            ((Float) value).getClass();
                            iA4 = 4;
                            int i11111111111111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111117, i11111111111111111111117, iY2, iJ);
                            break;
                        case 2:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i11111111111111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111118, i11111111111111111111118, iY2, iJ);
                            break;
                        case 3:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i11111111111111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111119, i11111111111111111111119, iY2, iJ);
                            break;
                        case 4:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i111111111111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111110, i111111111111111111111110, iY2, iJ);
                            break;
                        case 5:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i111111111111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111, i111111111111111111111111, iY2, iJ);
                            break;
                        case 6:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i111111111111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111112, i111111111111111111111112, iY2, iJ);
                            break;
                        case 7:
                            ((Boolean) value).getClass();
                            int i111111111111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111113, i111111111111111111111113, iY2, iJ);
                            break;
                        case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA4 = C0163j.x((String) value);
                            }
                            int i111111111111111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111114, i111111111111111111111114, iY2, iJ);
                            break;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            iA4 = ((AbstractC0154a) value).a();
                            int i111111111111111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111115, i111111111111111111111115, iY2, iJ);
                            break;
                        case 10:
                            iA3 = ((AbstractC0154a) value).a();
                            iZ2 = C0163j.z(iA3);
                            iA4 = iZ2 + iA3;
                            int i111111111111111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111116, i111111111111111111111116, iY2, iJ);
                            break;
                        case 11:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA3 = ((byte[]) value).length;
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                            }
                            int i111111111111111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111117, i111111111111111111111117, iY2, iJ);
                            break;
                        case 12:
                            iA4 = C0163j.z(((Integer) value).intValue());
                            int i111111111111111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111118, i111111111111111111111118, iY2, iJ);
                            break;
                        case 13:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i111111111111111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111119, i111111111111111111111119, iY2, iJ);
                            break;
                        case 14:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i1111111111111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111110, i1111111111111111111111110, iY2, iJ);
                            break;
                        case 15:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i1111111111111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111, i1111111111111111111111111, iY2, iJ);
                            break;
                        case 16:
                            int iIntValue13 = ((Integer) value).intValue();
                            iA4 = C0163j.z((iIntValue13 >> 31) ^ (iIntValue13 << 1));
                            int i1111111111111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111112, i1111111111111111111111112, iY2, iJ);
                            break;
                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                            long jLongValue13 = ((Long) value).longValue();
                            iA4 = C0163j.A((jLongValue13 >> 63) ^ (jLongValue13 << 1));
                            int i1111111111111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111113, i1111111111111111111111113, iY2, iJ);
                            break;
                        default:
                            throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                    }
                    break;
                case 13:
                    iA = C0163j.w(((Integer) key).intValue());
                    i7 = iA + iY3;
                    w0Var = g7.f4279b;
                    iY = C0163j.y(2);
                    if (w0Var == t0Var) {
                        iY *= 2;
                    }
                    switch (w0Var.ordinal()) {
                        case 0:
                            ((Double) value).getClass();
                            iA4 = 8;
                            int i1111111111111111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111114, i1111111111111111111111114, iY2, iJ);
                            break;
                        case 1:
                            ((Float) value).getClass();
                            iA4 = 4;
                            int i1111111111111111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111115, i1111111111111111111111115, iY2, iJ);
                            break;
                        case 2:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i1111111111111111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111116, i1111111111111111111111116, iY2, iJ);
                            break;
                        case 3:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i1111111111111111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111117, i1111111111111111111111117, iY2, iJ);
                            break;
                        case 4:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i1111111111111111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111118, i1111111111111111111111118, iY2, iJ);
                            break;
                        case 5:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i1111111111111111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111119, i1111111111111111111111119, iY2, iJ);
                            break;
                        case 6:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i11111111111111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111110, i11111111111111111111111110, iY2, iJ);
                            break;
                        case 7:
                            ((Boolean) value).getClass();
                            int i11111111111111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111, i11111111111111111111111111, iY2, iJ);
                            break;
                        case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA4 = C0163j.x((String) value);
                            }
                            int i11111111111111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111112, i11111111111111111111111112, iY2, iJ);
                            break;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            iA4 = ((AbstractC0154a) value).a();
                            int i11111111111111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111113, i11111111111111111111111113, iY2, iJ);
                            break;
                        case 10:
                            iA3 = ((AbstractC0154a) value).a();
                            iZ2 = C0163j.z(iA3);
                            iA4 = iZ2 + iA3;
                            int i11111111111111111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111114, i11111111111111111111111114, iY2, iJ);
                            break;
                        case 11:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA3 = ((byte[]) value).length;
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                            }
                            int i11111111111111111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111115, i11111111111111111111111115, iY2, iJ);
                            break;
                        case 12:
                            iA4 = C0163j.z(((Integer) value).intValue());
                            int i11111111111111111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111116, i11111111111111111111111116, iY2, iJ);
                            break;
                        case 13:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i11111111111111111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111117, i11111111111111111111111117, iY2, iJ);
                            break;
                        case 14:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i11111111111111111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111118, i11111111111111111111111118, iY2, iJ);
                            break;
                        case 15:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i11111111111111111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111119, i11111111111111111111111119, iY2, iJ);
                            break;
                        case 16:
                            int iIntValue14 = ((Integer) value).intValue();
                            iA4 = C0163j.z((iIntValue14 >> 31) ^ (iIntValue14 << 1));
                            int i111111111111111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111110, i111111111111111111111111110, iY2, iJ);
                            break;
                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                            long jLongValue14 = ((Long) value).longValue();
                            iA4 = C0163j.A((jLongValue14 >> 63) ^ (jLongValue14 << 1));
                            int i111111111111111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111, i111111111111111111111111111, iY2, iJ);
                            break;
                        default:
                            throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                    }
                    break;
                case 14:
                    ((Integer) key).getClass();
                    iA = 4;
                    i7 = iA + iY3;
                    w0Var = g7.f4279b;
                    iY = C0163j.y(2);
                    if (w0Var == t0Var) {
                        iY *= 2;
                    }
                    switch (w0Var.ordinal()) {
                        case 0:
                            ((Double) value).getClass();
                            iA4 = 8;
                            int i111111111111111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111112, i111111111111111111111111112, iY2, iJ);
                            break;
                        case 1:
                            ((Float) value).getClass();
                            iA4 = 4;
                            int i111111111111111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111113, i111111111111111111111111113, iY2, iJ);
                            break;
                        case 2:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i111111111111111111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111114, i111111111111111111111111114, iY2, iJ);
                            break;
                        case 3:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i111111111111111111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111115, i111111111111111111111111115, iY2, iJ);
                            break;
                        case 4:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i111111111111111111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111116, i111111111111111111111111116, iY2, iJ);
                            break;
                        case 5:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i111111111111111111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111117, i111111111111111111111111117, iY2, iJ);
                            break;
                        case 6:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i111111111111111111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111118, i111111111111111111111111118, iY2, iJ);
                            break;
                        case 7:
                            ((Boolean) value).getClass();
                            int i111111111111111111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111119, i111111111111111111111111119, iY2, iJ);
                            break;
                        case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA4 = C0163j.x((String) value);
                            }
                            int i1111111111111111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111110, i1111111111111111111111111110, iY2, iJ);
                            break;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            iA4 = ((AbstractC0154a) value).a();
                            int i1111111111111111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111111, i1111111111111111111111111111, iY2, iJ);
                            break;
                        case 10:
                            iA3 = ((AbstractC0154a) value).a();
                            iZ2 = C0163j.z(iA3);
                            iA4 = iZ2 + iA3;
                            int i1111111111111111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111112, i1111111111111111111111111112, iY2, iJ);
                            break;
                        case 11:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA3 = ((byte[]) value).length;
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                            }
                            int i1111111111111111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111113, i1111111111111111111111111113, iY2, iJ);
                            break;
                        case 12:
                            iA4 = C0163j.z(((Integer) value).intValue());
                            int i1111111111111111111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111114, i1111111111111111111111111114, iY2, iJ);
                            break;
                        case 13:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i1111111111111111111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111115, i1111111111111111111111111115, iY2, iJ);
                            break;
                        case 14:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i1111111111111111111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111116, i1111111111111111111111111116, iY2, iJ);
                            break;
                        case 15:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i1111111111111111111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111117, i1111111111111111111111111117, iY2, iJ);
                            break;
                        case 16:
                            int iIntValue15 = ((Integer) value).intValue();
                            iA4 = C0163j.z((iIntValue15 >> 31) ^ (iIntValue15 << 1));
                            int i1111111111111111111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111118, i1111111111111111111111111118, iY2, iJ);
                            break;
                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                            long jLongValue15 = ((Long) value).longValue();
                            iA4 = C0163j.A((jLongValue15 >> 63) ^ (jLongValue15 << 1));
                            int i1111111111111111111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111119, i1111111111111111111111111119, iY2, iJ);
                            break;
                        default:
                            throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                    }
                    break;
                case 15:
                    ((Long) key).getClass();
                    iA = 8;
                    i7 = iA + iY3;
                    w0Var = g7.f4279b;
                    iY = C0163j.y(2);
                    if (w0Var == t0Var) {
                        iY *= 2;
                    }
                    switch (w0Var.ordinal()) {
                        case 0:
                            ((Double) value).getClass();
                            iA4 = 8;
                            int i11111111111111111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111110, i11111111111111111111111111110, iY2, iJ);
                            break;
                        case 1:
                            ((Float) value).getClass();
                            iA4 = 4;
                            int i11111111111111111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111111, i11111111111111111111111111111, iY2, iJ);
                            break;
                        case 2:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i11111111111111111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111112, i11111111111111111111111111112, iY2, iJ);
                            break;
                        case 3:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i11111111111111111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111113, i11111111111111111111111111113, iY2, iJ);
                            break;
                        case 4:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i11111111111111111111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111114, i11111111111111111111111111114, iY2, iJ);
                            break;
                        case 5:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i11111111111111111111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111115, i11111111111111111111111111115, iY2, iJ);
                            break;
                        case 6:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i11111111111111111111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111116, i11111111111111111111111111116, iY2, iJ);
                            break;
                        case 7:
                            ((Boolean) value).getClass();
                            int i11111111111111111111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111117, i11111111111111111111111111117, iY2, iJ);
                            break;
                        case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA4 = C0163j.x((String) value);
                            }
                            int i11111111111111111111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111118, i11111111111111111111111111118, iY2, iJ);
                            break;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            iA4 = ((AbstractC0154a) value).a();
                            int i11111111111111111111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111119, i11111111111111111111111111119, iY2, iJ);
                            break;
                        case 10:
                            iA3 = ((AbstractC0154a) value).a();
                            iZ2 = C0163j.z(iA3);
                            iA4 = iZ2 + iA3;
                            int i111111111111111111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111110, i111111111111111111111111111110, iY2, iJ);
                            break;
                        case 11:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA3 = ((byte[]) value).length;
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                            }
                            int i111111111111111111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111111, i111111111111111111111111111111, iY2, iJ);
                            break;
                        case 12:
                            iA4 = C0163j.z(((Integer) value).intValue());
                            int i111111111111111111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111112, i111111111111111111111111111112, iY2, iJ);
                            break;
                        case 13:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i111111111111111111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111113, i111111111111111111111111111113, iY2, iJ);
                            break;
                        case 14:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i111111111111111111111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111114, i111111111111111111111111111114, iY2, iJ);
                            break;
                        case 15:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i111111111111111111111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111115, i111111111111111111111111111115, iY2, iJ);
                            break;
                        case 16:
                            int iIntValue16 = ((Integer) value).intValue();
                            iA4 = C0163j.z((iIntValue16 >> 31) ^ (iIntValue16 << 1));
                            int i111111111111111111111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111116, i111111111111111111111111111116, iY2, iJ);
                            break;
                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                            long jLongValue16 = ((Long) value).longValue();
                            iA4 = C0163j.A((jLongValue16 >> 63) ^ (jLongValue16 << 1));
                            int i111111111111111111111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111117, i111111111111111111111111111117, iY2, iJ);
                            break;
                        default:
                            throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                    }
                    break;
                case 16:
                    int iIntValue17 = ((Integer) key).intValue();
                    iA = C0163j.z((iIntValue17 >> 31) ^ (iIntValue17 << 1));
                    i7 = iA + iY3;
                    w0Var = g7.f4279b;
                    iY = C0163j.y(2);
                    if (w0Var == t0Var) {
                        iY *= 2;
                    }
                    switch (w0Var.ordinal()) {
                        case 0:
                            ((Double) value).getClass();
                            iA4 = 8;
                            int i111111111111111111111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111118, i111111111111111111111111111118, iY2, iJ);
                            break;
                        case 1:
                            ((Float) value).getClass();
                            iA4 = 4;
                            int i111111111111111111111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111119, i111111111111111111111111111119, iY2, iJ);
                            break;
                        case 2:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i1111111111111111111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111111110, i1111111111111111111111111111110, iY2, iJ);
                            break;
                        case 3:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i1111111111111111111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111111111, i1111111111111111111111111111111, iY2, iJ);
                            break;
                        case 4:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i1111111111111111111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111111112, i1111111111111111111111111111112, iY2, iJ);
                            break;
                        case 5:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i1111111111111111111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111111113, i1111111111111111111111111111113, iY2, iJ);
                            break;
                        case 6:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i1111111111111111111111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111111114, i1111111111111111111111111111114, iY2, iJ);
                            break;
                        case 7:
                            ((Boolean) value).getClass();
                            int i1111111111111111111111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111111115, i1111111111111111111111111111115, iY2, iJ);
                            break;
                        case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA4 = C0163j.x((String) value);
                            }
                            int i1111111111111111111111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111111116, i1111111111111111111111111111116, iY2, iJ);
                            break;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            iA4 = ((AbstractC0154a) value).a();
                            int i1111111111111111111111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111111117, i1111111111111111111111111111117, iY2, iJ);
                            break;
                        case 10:
                            iA3 = ((AbstractC0154a) value).a();
                            iZ2 = C0163j.z(iA3);
                            iA4 = iZ2 + iA3;
                            int i1111111111111111111111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111111118, i1111111111111111111111111111118, iY2, iJ);
                            break;
                        case 11:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA3 = ((byte[]) value).length;
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                            }
                            int i1111111111111111111111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111111119, i1111111111111111111111111111119, iY2, iJ);
                            break;
                        case 12:
                            iA4 = C0163j.z(((Integer) value).intValue());
                            int i11111111111111111111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111111110, i11111111111111111111111111111110, iY2, iJ);
                            break;
                        case 13:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i11111111111111111111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111111111, i11111111111111111111111111111111, iY2, iJ);
                            break;
                        case 14:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i11111111111111111111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111111112, i11111111111111111111111111111112, iY2, iJ);
                            break;
                        case 15:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i11111111111111111111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111111113, i11111111111111111111111111111113, iY2, iJ);
                            break;
                        case 16:
                            int iIntValue18 = ((Integer) value).intValue();
                            iA4 = C0163j.z((iIntValue18 >> 31) ^ (iIntValue18 << 1));
                            int i11111111111111111111111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111111114, i11111111111111111111111111111114, iY2, iJ);
                            break;
                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                            long jLongValue17 = ((Long) value).longValue();
                            iA4 = C0163j.A((jLongValue17 >> 63) ^ (jLongValue17 << 1));
                            int i11111111111111111111111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111111115, i11111111111111111111111111111115, iY2, iJ);
                            break;
                        default:
                            throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                    }
                    break;
                case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                    long jLongValue18 = ((Long) key).longValue();
                    iA = C0163j.A((jLongValue18 << 1) ^ (jLongValue18 >> 63));
                    i7 = iA + iY3;
                    w0Var = g7.f4279b;
                    iY = C0163j.y(2);
                    if (w0Var == t0Var) {
                        iY *= 2;
                    }
                    switch (w0Var.ordinal()) {
                        case 0:
                            ((Double) value).getClass();
                            iA4 = 8;
                            int i11111111111111111111111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111111116, i11111111111111111111111111111116, iY2, iJ);
                            break;
                        case 1:
                            ((Float) value).getClass();
                            iA4 = 4;
                            int i11111111111111111111111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111111117, i11111111111111111111111111111117, iY2, iJ);
                            break;
                        case 2:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i11111111111111111111111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111111118, i11111111111111111111111111111118, iY2, iJ);
                            break;
                        case 3:
                            iA4 = C0163j.A(((Long) value).longValue());
                            int i11111111111111111111111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i11111111111111111111111111111119, i11111111111111111111111111111119, iY2, iJ);
                            break;
                        case 4:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i111111111111111111111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111111110, i111111111111111111111111111111110, iY2, iJ);
                            break;
                        case 5:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i111111111111111111111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111111111, i111111111111111111111111111111111, iY2, iJ);
                            break;
                        case 6:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i111111111111111111111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111111112, i111111111111111111111111111111112, iY2, iJ);
                            break;
                        case 7:
                            ((Boolean) value).getClass();
                            int i111111111111111111111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111111113, i111111111111111111111111111111113, iY2, iJ);
                            break;
                        case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA4 = C0163j.x((String) value);
                            }
                            int i111111111111111111111111111111114 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111111114, i111111111111111111111111111111114, iY2, iJ);
                            break;
                        case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                            iA4 = ((AbstractC0154a) value).a();
                            int i111111111111111111111111111111115 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111111115, i111111111111111111111111111111115, iY2, iJ);
                            break;
                        case 10:
                            iA3 = ((AbstractC0154a) value).a();
                            iZ2 = C0163j.z(iA3);
                            iA4 = iZ2 + iA3;
                            int i111111111111111111111111111111116 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111111116, i111111111111111111111111111111116, iY2, iJ);
                            break;
                        case 11:
                            if (value instanceof C0159f) {
                                iA4 = C0163j.s((C0159f) value);
                            } else {
                                iA3 = ((byte[]) value).length;
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                            }
                            int i111111111111111111111111111111117 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111111117, i111111111111111111111111111111117, iY2, iJ);
                            break;
                        case 12:
                            iA4 = C0163j.z(((Integer) value).intValue());
                            int i111111111111111111111111111111118 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111111118, i111111111111111111111111111111118, iY2, iJ);
                            break;
                        case 13:
                            iA4 = C0163j.w(((Integer) value).intValue());
                            int i111111111111111111111111111111119 = iA4 + iY + i7;
                            iJ = A3.a.j(i111111111111111111111111111111119, i111111111111111111111111111111119, iY2, iJ);
                            break;
                        case 14:
                            ((Integer) value).getClass();
                            iA4 = 4;
                            int i1111111111111111111111111111111110 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111111111110, i1111111111111111111111111111111110, iY2, iJ);
                            break;
                        case 15:
                            ((Long) value).getClass();
                            iA4 = 8;
                            int i1111111111111111111111111111111111 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111111111111, i1111111111111111111111111111111111, iY2, iJ);
                            break;
                        case 16:
                            int iIntValue19 = ((Integer) value).intValue();
                            iA4 = C0163j.z((iIntValue19 >> 31) ^ (iIntValue19 << 1));
                            int i1111111111111111111111111111111112 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111111111112, i1111111111111111111111111111111112, iY2, iJ);
                            break;
                        case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                            long jLongValue19 = ((Long) value).longValue();
                            iA4 = C0163j.A((jLongValue19 >> 63) ^ (jLongValue19 << 1));
                            int i1111111111111111111111111111111113 = iA4 + iY + i7;
                            iJ = A3.a.j(i1111111111111111111111111111111113, i1111111111111111111111111111111113, iY2, iJ);
                            break;
                        default:
                            throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                    }
                    break;
                default:
                    throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
            }
        }
        return iJ;
    }

    public static I b(Object obj, Object obj2) {
        I iC = (I) obj;
        I i6 = (I) obj2;
        if (!i6.isEmpty()) {
            if (!iC.r) {
                iC = iC.c();
            }
            iC.a();
            if (!i6.isEmpty()) {
                iC.putAll(i6);
            }
        }
        return iC;
    }
}
