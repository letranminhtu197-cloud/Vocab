package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public abstract class Q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final P f4306a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final P f4307b;

    static {
        P p6 = null;
        try {
            p6 = (P) Class.forName("androidx.datastore.preferences.protobuf.NewInstanceSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f4306a = p6;
        f4307b = new P();
    }
}
