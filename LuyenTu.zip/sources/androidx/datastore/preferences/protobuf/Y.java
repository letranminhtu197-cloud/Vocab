package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;

/* JADX INFO: loaded from: classes.dex */
public abstract class Y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Class f4317a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final g0 f4318b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final g0 f4319c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final g0 f4320d;

    static {
        Class<?> cls;
        try {
            cls = Class.forName("androidx.datastore.preferences.protobuf.GeneratedMessageV3");
        } catch (Throwable unused) {
            cls = null;
        }
        f4317a = cls;
        f4318b = v(false);
        f4319c = v(true);
        f4320d = new g0();
    }

    public static void A(int i6, List list, F f4, boolean z6) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0163j c0163j = (C0163j) f4.f4277a;
        int i7 = 0;
        if (!z6) {
            while (i7 < list.size()) {
                double dDoubleValue = ((Double) list.get(i7)).doubleValue();
                c0163j.getClass();
                c0163j.K(Double.doubleToRawLongBits(dDoubleValue), i6);
                i7++;
            }
            return;
        }
        c0163j.R(i6, 2);
        int i8 = 0;
        for (int i9 = 0; i9 < list.size(); i9++) {
            ((Double) list.get(i9)).getClass();
            Logger logger = C0163j.f4358h;
            i8 += 8;
        }
        c0163j.T(i8);
        while (i7 < list.size()) {
            c0163j.L(Double.doubleToRawLongBits(((Double) list.get(i7)).doubleValue()));
            i7++;
        }
    }

    public static void B(int i6, List list, F f4, boolean z6) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0163j c0163j = (C0163j) f4.f4277a;
        int i7 = 0;
        if (!z6) {
            while (i7 < list.size()) {
                c0163j.M(i6, ((Integer) list.get(i7)).intValue());
                i7++;
            }
            return;
        }
        c0163j.R(i6, 2);
        int iW = 0;
        for (int i8 = 0; i8 < list.size(); i8++) {
            iW += C0163j.w(((Integer) list.get(i8)).intValue());
        }
        c0163j.T(iW);
        while (i7 < list.size()) {
            c0163j.N(((Integer) list.get(i7)).intValue());
            i7++;
        }
    }

    public static void C(int i6, List list, F f4, boolean z6) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0163j c0163j = (C0163j) f4.f4277a;
        int i7 = 0;
        if (!z6) {
            while (i7 < list.size()) {
                c0163j.I(i6, ((Integer) list.get(i7)).intValue());
                i7++;
            }
            return;
        }
        c0163j.R(i6, 2);
        int i8 = 0;
        for (int i9 = 0; i9 < list.size(); i9++) {
            ((Integer) list.get(i9)).getClass();
            Logger logger = C0163j.f4358h;
            i8 += 4;
        }
        c0163j.T(i8);
        while (i7 < list.size()) {
            c0163j.J(((Integer) list.get(i7)).intValue());
            i7++;
        }
    }

    public static void D(int i6, List list, F f4, boolean z6) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0163j c0163j = (C0163j) f4.f4277a;
        int i7 = 0;
        if (!z6) {
            while (i7 < list.size()) {
                c0163j.K(((Long) list.get(i7)).longValue(), i6);
                i7++;
            }
            return;
        }
        c0163j.R(i6, 2);
        int i8 = 0;
        for (int i9 = 0; i9 < list.size(); i9++) {
            ((Long) list.get(i9)).getClass();
            Logger logger = C0163j.f4358h;
            i8 += 8;
        }
        c0163j.T(i8);
        while (i7 < list.size()) {
            c0163j.L(((Long) list.get(i7)).longValue());
            i7++;
        }
    }

    public static void E(int i6, List list, F f4, boolean z6) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0163j c0163j = (C0163j) f4.f4277a;
        int i7 = 0;
        if (!z6) {
            while (i7 < list.size()) {
                float fFloatValue = ((Float) list.get(i7)).floatValue();
                c0163j.getClass();
                c0163j.I(i6, Float.floatToRawIntBits(fFloatValue));
                i7++;
            }
            return;
        }
        c0163j.R(i6, 2);
        int i8 = 0;
        for (int i9 = 0; i9 < list.size(); i9++) {
            ((Float) list.get(i9)).getClass();
            Logger logger = C0163j.f4358h;
            i8 += 4;
        }
        c0163j.T(i8);
        while (i7 < list.size()) {
            c0163j.J(Float.floatToRawIntBits(((Float) list.get(i7)).floatValue()));
            i7++;
        }
    }

    public static void F(int i6, List list, F f4, X x5) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        f4.getClass();
        for (int i7 = 0; i7 < list.size(); i7++) {
            f4.b(i6, list.get(i7), x5);
        }
    }

    public static void G(int i6, List list, F f4, boolean z6) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0163j c0163j = (C0163j) f4.f4277a;
        int i7 = 0;
        if (!z6) {
            while (i7 < list.size()) {
                c0163j.M(i6, ((Integer) list.get(i7)).intValue());
                i7++;
            }
            return;
        }
        c0163j.R(i6, 2);
        int iW = 0;
        for (int i8 = 0; i8 < list.size(); i8++) {
            iW += C0163j.w(((Integer) list.get(i8)).intValue());
        }
        c0163j.T(iW);
        while (i7 < list.size()) {
            c0163j.N(((Integer) list.get(i7)).intValue());
            i7++;
        }
    }

    public static void H(int i6, List list, F f4, boolean z6) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0163j c0163j = (C0163j) f4.f4277a;
        int i7 = 0;
        if (!z6) {
            while (i7 < list.size()) {
                c0163j.U(((Long) list.get(i7)).longValue(), i6);
                i7++;
            }
            return;
        }
        c0163j.R(i6, 2);
        int iA = 0;
        for (int i8 = 0; i8 < list.size(); i8++) {
            iA += C0163j.A(((Long) list.get(i8)).longValue());
        }
        c0163j.T(iA);
        while (i7 < list.size()) {
            c0163j.V(((Long) list.get(i7)).longValue());
            i7++;
        }
    }

    public static void I(int i6, List list, F f4, X x5) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        f4.getClass();
        for (int i7 = 0; i7 < list.size(); i7++) {
            ((C0163j) f4.f4277a).O(i6, (AbstractC0154a) list.get(i7), x5);
        }
    }

    public static void J(int i6, List list, F f4, boolean z6) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0163j c0163j = (C0163j) f4.f4277a;
        int i7 = 0;
        if (!z6) {
            while (i7 < list.size()) {
                c0163j.I(i6, ((Integer) list.get(i7)).intValue());
                i7++;
            }
            return;
        }
        c0163j.R(i6, 2);
        int i8 = 0;
        for (int i9 = 0; i9 < list.size(); i9++) {
            ((Integer) list.get(i9)).getClass();
            Logger logger = C0163j.f4358h;
            i8 += 4;
        }
        c0163j.T(i8);
        while (i7 < list.size()) {
            c0163j.J(((Integer) list.get(i7)).intValue());
            i7++;
        }
    }

    public static void K(int i6, List list, F f4, boolean z6) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0163j c0163j = (C0163j) f4.f4277a;
        int i7 = 0;
        if (!z6) {
            while (i7 < list.size()) {
                c0163j.K(((Long) list.get(i7)).longValue(), i6);
                i7++;
            }
            return;
        }
        c0163j.R(i6, 2);
        int i8 = 0;
        for (int i9 = 0; i9 < list.size(); i9++) {
            ((Long) list.get(i9)).getClass();
            Logger logger = C0163j.f4358h;
            i8 += 8;
        }
        c0163j.T(i8);
        while (i7 < list.size()) {
            c0163j.L(((Long) list.get(i7)).longValue());
            i7++;
        }
    }

    public static void L(int i6, List list, F f4, boolean z6) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0163j c0163j = (C0163j) f4.f4277a;
        int i7 = 0;
        if (!z6) {
            while (i7 < list.size()) {
                int iIntValue = ((Integer) list.get(i7)).intValue();
                c0163j.S(i6, (iIntValue >> 31) ^ (iIntValue << 1));
                i7++;
            }
            return;
        }
        c0163j.R(i6, 2);
        int iZ = 0;
        for (int i8 = 0; i8 < list.size(); i8++) {
            int iIntValue2 = ((Integer) list.get(i8)).intValue();
            iZ += C0163j.z((iIntValue2 >> 31) ^ (iIntValue2 << 1));
        }
        c0163j.T(iZ);
        while (i7 < list.size()) {
            int iIntValue3 = ((Integer) list.get(i7)).intValue();
            c0163j.T((iIntValue3 >> 31) ^ (iIntValue3 << 1));
            i7++;
        }
    }

    public static void M(int i6, List list, F f4, boolean z6) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0163j c0163j = (C0163j) f4.f4277a;
        int i7 = 0;
        if (!z6) {
            while (i7 < list.size()) {
                long jLongValue = ((Long) list.get(i7)).longValue();
                c0163j.U((jLongValue >> 63) ^ (jLongValue << 1), i6);
                i7++;
            }
            return;
        }
        c0163j.R(i6, 2);
        int iA = 0;
        for (int i8 = 0; i8 < list.size(); i8++) {
            long jLongValue2 = ((Long) list.get(i8)).longValue();
            iA += C0163j.A((jLongValue2 >> 63) ^ (jLongValue2 << 1));
        }
        c0163j.T(iA);
        while (i7 < list.size()) {
            long jLongValue3 = ((Long) list.get(i7)).longValue();
            c0163j.V((jLongValue3 >> 63) ^ (jLongValue3 << 1));
            i7++;
        }
    }

    public static void N(int i6, List list, F f4) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0163j c0163j = (C0163j) f4.f4277a;
        int i7 = 0;
        if (!(list instanceof A)) {
            while (i7 < list.size()) {
                c0163j.P((String) list.get(i7), i6);
                i7++;
            }
            return;
        }
        A a5 = (A) list;
        while (i7 < list.size()) {
            Object objE = a5.e(i7);
            if (objE instanceof String) {
                c0163j.P((String) objE, i6);
            } else {
                c0163j.G(i6, (C0159f) objE);
            }
            i7++;
        }
    }

    public static void O(int i6, List list, F f4, boolean z6) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0163j c0163j = (C0163j) f4.f4277a;
        int i7 = 0;
        if (!z6) {
            while (i7 < list.size()) {
                c0163j.S(i6, ((Integer) list.get(i7)).intValue());
                i7++;
            }
            return;
        }
        c0163j.R(i6, 2);
        int iZ = 0;
        for (int i8 = 0; i8 < list.size(); i8++) {
            iZ += C0163j.z(((Integer) list.get(i8)).intValue());
        }
        c0163j.T(iZ);
        while (i7 < list.size()) {
            c0163j.T(((Integer) list.get(i7)).intValue());
            i7++;
        }
    }

    public static void P(int i6, List list, F f4, boolean z6) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0163j c0163j = (C0163j) f4.f4277a;
        int i7 = 0;
        if (!z6) {
            while (i7 < list.size()) {
                c0163j.U(((Long) list.get(i7)).longValue(), i6);
                i7++;
            }
            return;
        }
        c0163j.R(i6, 2);
        int iA = 0;
        for (int i8 = 0; i8 < list.size(); i8++) {
            iA += C0163j.A(((Long) list.get(i8)).longValue());
        }
        c0163j.T(iA);
        while (i7 < list.size()) {
            c0163j.V(((Long) list.get(i7)).longValue());
            i7++;
        }
    }

    public static int a(int i6, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        int iY = C0163j.y(i6) * size;
        for (int i7 = 0; i7 < list.size(); i7++) {
            iY += C0163j.s((C0159f) list.get(i7));
        }
        return iY;
    }

    public static int b(int i6, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        return (C0163j.y(i6) * size) + c(list);
    }

    public static int c(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        int iW = 0;
        for (int i6 = 0; i6 < size; i6++) {
            iW += C0163j.w(((Integer) list.get(i6)).intValue());
        }
        return iW;
    }

    public static int d(int i6, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        return C0163j.t(i6) * size;
    }

    public static int e(List list) {
        return list.size() * 4;
    }

    public static int f(int i6, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        return C0163j.u(i6) * size;
    }

    public static int g(List list) {
        return list.size() * 8;
    }

    public static int h(int i6, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        return (C0163j.y(i6) * size) + i(list);
    }

    public static int i(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        int iW = 0;
        for (int i6 = 0; i6 < size; i6++) {
            iW += C0163j.w(((Integer) list.get(i6)).intValue());
        }
        return iW;
    }

    public static int j(int i6, List list) {
        if (list.size() == 0) {
            return 0;
        }
        return (C0163j.y(i6) * list.size()) + k(list);
    }

    public static int k(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        int iA = 0;
        for (int i6 = 0; i6 < size; i6++) {
            iA += C0163j.A(((Long) list.get(i6)).longValue());
        }
        return iA;
    }

    public static int l(int i6, List list, X x5) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        int iY = C0163j.y(i6) * size;
        for (int i7 = 0; i7 < size; i7++) {
            int iB = ((AbstractC0154a) list.get(i7)).b(x5);
            iY += C0163j.z(iB) + iB;
        }
        return iY;
    }

    public static int m(int i6, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        return (C0163j.y(i6) * size) + n(list);
    }

    public static int n(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        int iZ = 0;
        for (int i6 = 0; i6 < size; i6++) {
            int iIntValue = ((Integer) list.get(i6)).intValue();
            iZ += C0163j.z((iIntValue >> 31) ^ (iIntValue << 1));
        }
        return iZ;
    }

    public static int o(int i6, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        return (C0163j.y(i6) * size) + p(list);
    }

    public static int p(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        int iA = 0;
        for (int i6 = 0; i6 < size; i6++) {
            long jLongValue = ((Long) list.get(i6)).longValue();
            iA += C0163j.A((jLongValue >> 63) ^ (jLongValue << 1));
        }
        return iA;
    }

    public static int q(int i6, List list) {
        int size = list.size();
        int i7 = 0;
        if (size == 0) {
            return 0;
        }
        int iY = C0163j.y(i6) * size;
        if (!(list instanceof A)) {
            while (i7 < size) {
                Object obj = list.get(i7);
                iY = (obj instanceof C0159f ? C0163j.s((C0159f) obj) : C0163j.x((String) obj)) + iY;
                i7++;
            }
            return iY;
        }
        A a5 = (A) list;
        while (i7 < size) {
            Object objE = a5.e(i7);
            iY = (objE instanceof C0159f ? C0163j.s((C0159f) objE) : C0163j.x((String) objE)) + iY;
            i7++;
        }
        return iY;
    }

    public static int r(int i6, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        return (C0163j.y(i6) * size) + s(list);
    }

    public static int s(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        int iZ = 0;
        for (int i6 = 0; i6 < size; i6++) {
            iZ += C0163j.z(((Integer) list.get(i6)).intValue());
        }
        return iZ;
    }

    public static int t(int i6, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        return (C0163j.y(i6) * size) + u(list);
    }

    public static int u(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        int iA = 0;
        for (int i6 = 0; i6 < size; i6++) {
            iA += C0163j.A(((Long) list.get(i6)).longValue());
        }
        return iA;
    }

    public static g0 v(boolean z6) {
        Class<?> cls;
        try {
            cls = Class.forName("androidx.datastore.preferences.protobuf.UnknownFieldSetSchema");
        } catch (Throwable unused) {
            cls = null;
        }
        if (cls != null) {
            try {
                return (g0) cls.getConstructor(Boolean.TYPE).newInstance(Boolean.valueOf(z6));
            } catch (Throwable unused2) {
            }
        }
        return null;
    }

    public static void w(g0 g0Var, Object obj, Object obj2) {
        g0Var.getClass();
        AbstractC0172t abstractC0172t = (AbstractC0172t) obj;
        f0 f0Var = abstractC0172t.unknownFields;
        f0 f0Var2 = ((AbstractC0172t) obj2).unknownFields;
        if (!f0Var2.equals(f0.f4337f)) {
            int i6 = f0Var.f4338a + f0Var2.f4338a;
            int[] iArrCopyOf = Arrays.copyOf(f0Var.f4339b, i6);
            System.arraycopy(f0Var2.f4339b, 0, iArrCopyOf, f0Var.f4338a, f0Var2.f4338a);
            Object[] objArrCopyOf = Arrays.copyOf(f0Var.f4340c, i6);
            System.arraycopy(f0Var2.f4340c, 0, objArrCopyOf, f0Var.f4338a, f0Var2.f4338a);
            f0Var = new f0(i6, iArrCopyOf, objArrCopyOf, true);
        }
        abstractC0172t.unknownFields = f0Var;
    }

    public static boolean x(Object obj, Object obj2) {
        if (obj != obj2) {
            return obj != null && obj.equals(obj2);
        }
        return true;
    }

    public static void y(int i6, List list, F f4, boolean z6) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0163j c0163j = (C0163j) f4.f4277a;
        int i7 = 0;
        if (!z6) {
            while (i7 < list.size()) {
                c0163j.F(i6, ((Boolean) list.get(i7)).booleanValue());
                i7++;
            }
            return;
        }
        c0163j.R(i6, 2);
        int i8 = 0;
        for (int i9 = 0; i9 < list.size(); i9++) {
            ((Boolean) list.get(i9)).getClass();
            Logger logger = C0163j.f4358h;
            i8++;
        }
        c0163j.T(i8);
        while (i7 < list.size()) {
            c0163j.D(((Boolean) list.get(i7)).booleanValue() ? (byte) 1 : (byte) 0);
            i7++;
        }
    }

    public static void z(int i6, List list, F f4) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        f4.getClass();
        for (int i7 = 0; i7 < list.size(); i7++) {
            ((C0163j) f4.f4277a).G(i6, (C0159f) list.get(i7));
        }
    }
}
