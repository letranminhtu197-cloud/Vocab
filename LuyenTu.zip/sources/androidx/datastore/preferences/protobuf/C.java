package androidx.datastore.preferences.protobuf;

import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class C extends D {
    @Override // androidx.datastore.preferences.protobuf.D
    public final void a(long j6, Object obj) {
        ((AbstractC0155b) ((InterfaceC0173u) o0.f4378d.i(j6, obj))).r = false;
    }

    @Override // androidx.datastore.preferences.protobuf.D
    public final void b(long j6, Object obj, Object obj2) {
        n0 n0Var = o0.f4378d;
        InterfaceC0173u interfaceC0173uA = (InterfaceC0173u) n0Var.i(j6, obj);
        InterfaceC0173u interfaceC0173u = (InterfaceC0173u) n0Var.i(j6, obj2);
        int size = interfaceC0173uA.size();
        int size2 = interfaceC0173u.size();
        if (size > 0 && size2 > 0) {
            if (!((AbstractC0155b) interfaceC0173uA).r) {
                interfaceC0173uA = interfaceC0173uA.a(size2 + size);
            }
            interfaceC0173uA.addAll(interfaceC0173u);
        }
        if (size > 0) {
            interfaceC0173u = interfaceC0173uA;
        }
        o0.o(j6, obj, interfaceC0173u);
    }

    @Override // androidx.datastore.preferences.protobuf.D
    public final List c(long j6, Object obj) {
        InterfaceC0173u interfaceC0173u = (InterfaceC0173u) o0.f4378d.i(j6, obj);
        if (((AbstractC0155b) interfaceC0173u).r) {
            return interfaceC0173u;
        }
        int size = interfaceC0173u.size();
        InterfaceC0173u interfaceC0173uA = interfaceC0173u.a(size == 0 ? 10 : size * 2);
        o0.o(j6, obj, interfaceC0173uA);
        return interfaceC0173uA;
    }
}
