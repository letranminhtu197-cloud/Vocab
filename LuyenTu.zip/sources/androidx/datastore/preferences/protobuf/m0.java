package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public final class m0 extends n0 {
    @Override // androidx.datastore.preferences.protobuf.n0
    public final boolean c(long j6, Object obj) {
        return this.f4371a.getBoolean(obj, j6);
    }

    @Override // androidx.datastore.preferences.protobuf.n0
    public final byte d(long j6, Object obj) {
        return this.f4371a.getByte(obj, j6);
    }

    @Override // androidx.datastore.preferences.protobuf.n0
    public final double e(long j6, Object obj) {
        return this.f4371a.getDouble(obj, j6);
    }

    @Override // androidx.datastore.preferences.protobuf.n0
    public final float f(long j6, Object obj) {
        return this.f4371a.getFloat(obj, j6);
    }

    @Override // androidx.datastore.preferences.protobuf.n0
    public final void k(Object obj, long j6, boolean z6) {
        this.f4371a.putBoolean(obj, j6, z6);
    }

    @Override // androidx.datastore.preferences.protobuf.n0
    public final void l(Object obj, long j6, byte b6) {
        this.f4371a.putByte(obj, j6, b6);
    }

    @Override // androidx.datastore.preferences.protobuf.n0
    public final void m(Object obj, long j6, double d6) {
        this.f4371a.putDouble(obj, j6, d6);
    }

    @Override // androidx.datastore.preferences.protobuf.n0
    public final void n(Object obj, long j6, float f4) {
        this.f4371a.putFloat(obj, j6, f4);
    }
}
