package androidx.datastore.preferences.protobuf;

/* JADX WARN: Enum visitor error
jadx.core.utils.exceptions.JadxRuntimeException: Init of enum field 'EF0' uses external variables
	at jadx.core.dex.visitors.EnumVisitor.createEnumFieldByConstructor(EnumVisitor.java:485)
	at jadx.core.dex.visitors.EnumVisitor.processEnumFieldByRegister(EnumVisitor.java:422)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromFilledArray(EnumVisitor.java:351)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromInsn(EnumVisitor.java:284)
	at jadx.core.dex.visitors.EnumVisitor.convertToEnum(EnumVisitor.java:153)
	at jadx.core.dex.visitors.EnumVisitor.visit(EnumVisitor.java:102)
 */
/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC0169p {

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final EnumC0169p f4383s;
    public static final EnumC0169p t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final EnumC0169p[] f4384u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final /* synthetic */ EnumC0169p[] f4385v;
    public final int r;

    /* JADX INFO: Fake field, exist only in values array */
    EnumC0169p EF0;

    static {
        EnumC0177y enumC0177y = EnumC0177y.DOUBLE;
        EnumC0169p enumC0169p = new EnumC0169p("DOUBLE", 0, 0, 1, enumC0177y);
        EnumC0177y enumC0177y2 = EnumC0177y.FLOAT;
        EnumC0169p enumC0169p2 = new EnumC0169p("FLOAT", 1, 1, 1, enumC0177y2);
        EnumC0177y enumC0177y3 = EnumC0177y.LONG;
        EnumC0169p enumC0169p3 = new EnumC0169p("INT64", 2, 2, 1, enumC0177y3);
        EnumC0169p enumC0169p4 = new EnumC0169p("UINT64", 3, 3, 1, enumC0177y3);
        EnumC0177y enumC0177y4 = EnumC0177y.INT;
        EnumC0169p enumC0169p5 = new EnumC0169p("INT32", 4, 4, 1, enumC0177y4);
        EnumC0169p enumC0169p6 = new EnumC0169p("FIXED64", 5, 5, 1, enumC0177y3);
        EnumC0169p enumC0169p7 = new EnumC0169p("FIXED32", 6, 6, 1, enumC0177y4);
        EnumC0177y enumC0177y5 = EnumC0177y.BOOLEAN;
        EnumC0169p enumC0169p8 = new EnumC0169p("BOOL", 7, 7, 1, enumC0177y5);
        EnumC0177y enumC0177y6 = EnumC0177y.STRING;
        EnumC0169p enumC0169p9 = new EnumC0169p("STRING", 8, 8, 1, enumC0177y6);
        EnumC0177y enumC0177y7 = EnumC0177y.MESSAGE;
        EnumC0169p enumC0169p10 = new EnumC0169p("MESSAGE", 9, 9, 1, enumC0177y7);
        EnumC0177y enumC0177y8 = EnumC0177y.BYTE_STRING;
        EnumC0169p enumC0169p11 = new EnumC0169p("BYTES", 10, 10, 1, enumC0177y8);
        EnumC0169p enumC0169p12 = new EnumC0169p("UINT32", 11, 11, 1, enumC0177y4);
        EnumC0177y enumC0177y9 = EnumC0177y.ENUM;
        EnumC0169p enumC0169p13 = new EnumC0169p("ENUM", 12, 12, 1, enumC0177y9);
        EnumC0169p enumC0169p14 = new EnumC0169p("SFIXED32", 13, 13, 1, enumC0177y4);
        EnumC0169p enumC0169p15 = new EnumC0169p("SFIXED64", 14, 14, 1, enumC0177y3);
        EnumC0169p enumC0169p16 = new EnumC0169p("SINT32", 15, 15, 1, enumC0177y4);
        EnumC0169p enumC0169p17 = new EnumC0169p("SINT64", 16, 16, 1, enumC0177y3);
        EnumC0169p enumC0169p18 = new EnumC0169p("GROUP", 17, 17, 1, enumC0177y7);
        EnumC0169p enumC0169p19 = new EnumC0169p("DOUBLE_LIST", 18, 18, 2, enumC0177y);
        EnumC0169p enumC0169p20 = new EnumC0169p("FLOAT_LIST", 19, 19, 2, enumC0177y2);
        EnumC0169p enumC0169p21 = new EnumC0169p("INT64_LIST", 20, 20, 2, enumC0177y3);
        EnumC0169p enumC0169p22 = new EnumC0169p("UINT64_LIST", 21, 21, 2, enumC0177y3);
        EnumC0169p enumC0169p23 = new EnumC0169p("INT32_LIST", 22, 22, 2, enumC0177y4);
        EnumC0169p enumC0169p24 = new EnumC0169p("FIXED64_LIST", 23, 23, 2, enumC0177y3);
        EnumC0169p enumC0169p25 = new EnumC0169p("FIXED32_LIST", 24, 24, 2, enumC0177y4);
        EnumC0169p enumC0169p26 = new EnumC0169p("BOOL_LIST", 25, 25, 2, enumC0177y5);
        EnumC0169p enumC0169p27 = new EnumC0169p("STRING_LIST", 26, 26, 2, enumC0177y6);
        EnumC0169p enumC0169p28 = new EnumC0169p("MESSAGE_LIST", 27, 27, 2, enumC0177y7);
        EnumC0169p enumC0169p29 = new EnumC0169p("BYTES_LIST", 28, 28, 2, enumC0177y8);
        EnumC0169p enumC0169p30 = new EnumC0169p("UINT32_LIST", 29, 29, 2, enumC0177y4);
        EnumC0169p enumC0169p31 = new EnumC0169p("ENUM_LIST", 30, 30, 2, enumC0177y9);
        EnumC0169p enumC0169p32 = new EnumC0169p("SFIXED32_LIST", 31, 31, 2, enumC0177y4);
        EnumC0169p enumC0169p33 = new EnumC0169p("SFIXED64_LIST", 32, 32, 2, enumC0177y3);
        EnumC0169p enumC0169p34 = new EnumC0169p("SINT32_LIST", 33, 33, 2, enumC0177y4);
        EnumC0169p enumC0169p35 = new EnumC0169p("SINT64_LIST", 34, 34, 2, enumC0177y3);
        EnumC0169p enumC0169p36 = new EnumC0169p("DOUBLE_LIST_PACKED", 35, 35, 3, enumC0177y);
        f4383s = enumC0169p36;
        EnumC0169p enumC0169p37 = new EnumC0169p("FLOAT_LIST_PACKED", 36, 36, 3, enumC0177y2);
        EnumC0169p enumC0169p38 = new EnumC0169p("INT64_LIST_PACKED", 37, 37, 3, enumC0177y3);
        EnumC0169p enumC0169p39 = new EnumC0169p("UINT64_LIST_PACKED", 38, 38, 3, enumC0177y3);
        EnumC0169p enumC0169p40 = new EnumC0169p("INT32_LIST_PACKED", 39, 39, 3, enumC0177y4);
        EnumC0169p enumC0169p41 = new EnumC0169p("FIXED64_LIST_PACKED", 40, 40, 3, enumC0177y3);
        EnumC0169p enumC0169p42 = new EnumC0169p("FIXED32_LIST_PACKED", 41, 41, 3, enumC0177y4);
        EnumC0169p enumC0169p43 = new EnumC0169p("BOOL_LIST_PACKED", 42, 42, 3, enumC0177y5);
        EnumC0169p enumC0169p44 = new EnumC0169p("UINT32_LIST_PACKED", 43, 43, 3, enumC0177y4);
        EnumC0169p enumC0169p45 = new EnumC0169p("ENUM_LIST_PACKED", 44, 44, 3, enumC0177y9);
        EnumC0169p enumC0169p46 = new EnumC0169p("SFIXED32_LIST_PACKED", 45, 45, 3, enumC0177y4);
        EnumC0169p enumC0169p47 = new EnumC0169p("SFIXED64_LIST_PACKED", 46, 46, 3, enumC0177y3);
        EnumC0169p enumC0169p48 = new EnumC0169p("SINT32_LIST_PACKED", 47, 47, 3, enumC0177y4);
        EnumC0169p enumC0169p49 = new EnumC0169p("SINT64_LIST_PACKED", 48, 48, 3, enumC0177y3);
        t = enumC0169p49;
        f4385v = new EnumC0169p[]{enumC0169p, enumC0169p2, enumC0169p3, enumC0169p4, enumC0169p5, enumC0169p6, enumC0169p7, enumC0169p8, enumC0169p9, enumC0169p10, enumC0169p11, enumC0169p12, enumC0169p13, enumC0169p14, enumC0169p15, enumC0169p16, enumC0169p17, enumC0169p18, enumC0169p19, enumC0169p20, enumC0169p21, enumC0169p22, enumC0169p23, enumC0169p24, enumC0169p25, enumC0169p26, enumC0169p27, enumC0169p28, enumC0169p29, enumC0169p30, enumC0169p31, enumC0169p32, enumC0169p33, enumC0169p34, enumC0169p35, enumC0169p36, enumC0169p37, enumC0169p38, enumC0169p39, enumC0169p40, enumC0169p41, enumC0169p42, enumC0169p43, enumC0169p44, enumC0169p45, enumC0169p46, enumC0169p47, enumC0169p48, enumC0169p49, new EnumC0169p("GROUP_LIST", 49, 49, 2, enumC0177y7), new EnumC0169p("MAP", 50, 50, 4, EnumC0177y.VOID)};
        EnumC0169p[] enumC0169pArrValues = values();
        f4384u = new EnumC0169p[enumC0169pArrValues.length];
        for (EnumC0169p enumC0169p50 : enumC0169pArrValues) {
            f4384u[enumC0169p50.r] = enumC0169p50;
        }
    }

    public EnumC0169p(String str, int i6, int i7, int i8, EnumC0177y enumC0177y) {
        super(str, i6);
        this.r = i7;
        int iB = p005b0.i.b(i8);
        if (iB == 1 || iB == 3) {
            enumC0177y.getClass();
        }
        if (i8 == 1) {
            enumC0177y.ordinal();
        }
    }

    public static EnumC0169p valueOf(String str) {
        return (EnumC0169p) Enum.valueOf(EnumC0169p.class, str);
    }

    public static EnumC0169p[] values() {
        return (EnumC0169p[]) f4385v.clone();
    }
}
