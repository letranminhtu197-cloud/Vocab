package androidx.datastore.preferences.protobuf;

import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class c0 implements Map.Entry, Comparable {
    public final Comparable r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public Object f4328s;
    public final /* synthetic */ Z t;

    public c0(Z z6, Comparable comparable, Object obj) {
        this.t = z6;
        this.r = comparable;
        this.f4328s = obj;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        return this.r.compareTo(((c0) obj).r);
    }

    @Override // java.util.Map.Entry
    public final boolean equals(Object obj) {
        boolean zEquals;
        boolean zEquals2;
        if (obj != this) {
            if (obj instanceof Map.Entry) {
                Map.Entry entry = (Map.Entry) obj;
                Object key = entry.getKey();
                Comparable comparable = this.r;
                if (comparable == null) {
                    zEquals = key == null;
                } else {
                    zEquals = comparable.equals(key);
                }
                if (zEquals) {
                    Object obj2 = this.f4328s;
                    Object value = entry.getValue();
                    if (obj2 == null) {
                        zEquals2 = value == null;
                    } else {
                        zEquals2 = obj2.equals(value);
                    }
                    if (zEquals2) {
                    }
                }
            }
            return false;
        }
        return true;
    }

    @Override // java.util.Map.Entry
    public final Object getKey() {
        return this.r;
    }

    @Override // java.util.Map.Entry
    public final Object getValue() {
        return this.f4328s;
    }

    @Override // java.util.Map.Entry
    public final int hashCode() {
        Comparable comparable = this.r;
        int iHashCode = comparable == null ? 0 : comparable.hashCode();
        Object obj = this.f4328s;
        return (obj != null ? obj.hashCode() : 0) ^ iHashCode;
    }

    @Override // java.util.Map.Entry
    public final Object setValue(Object obj) {
        this.t.c();
        Object obj2 = this.f4328s;
        this.f4328s = obj;
        return obj2;
    }

    public final String toString() {
        return this.r + "=" + this.f4328s;
    }
}
