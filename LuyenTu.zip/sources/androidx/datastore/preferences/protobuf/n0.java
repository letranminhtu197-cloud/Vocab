package androidx.datastore.preferences.protobuf;

import java.lang.reflect.Field;
import sun.misc.Unsafe;

/* JADX INFO: loaded from: classes.dex */
public abstract class n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Unsafe f4371a;

    public n0(Unsafe unsafe) {
        this.f4371a = unsafe;
    }

    public final int a(Class cls) {
        return this.f4371a.arrayBaseOffset(cls);
    }

    public final int b(Class cls) {
        return this.f4371a.arrayIndexScale(cls);
    }

    public abstract boolean c(long j6, Object obj);

    public abstract byte d(long j6, Object obj);

    public abstract double e(long j6, Object obj);

    public abstract float f(long j6, Object obj);

    public final int g(long j6, Object obj) {
        return this.f4371a.getInt(obj, j6);
    }

    public final long h(long j6, Object obj) {
        return this.f4371a.getLong(obj, j6);
    }

    public final Object i(long j6, Object obj) {
        return this.f4371a.getObject(obj, j6);
    }

    public final long j(Field field) {
        return this.f4371a.objectFieldOffset(field);
    }

    public abstract void k(Object obj, long j6, boolean z6);

    public abstract void l(Object obj, long j6, byte b6);

    public abstract void m(Object obj, long j6, double d6);

    public abstract void n(Object obj, long j6, float f4);

    public final void o(int i6, long j6, Object obj) {
        this.f4371a.putInt(obj, j6, i6);
    }

    public final void p(Object obj, long j6, long j7) {
        this.f4371a.putLong(obj, j6, j7);
    }

    public final void q(long j6, Object obj, Object obj2) {
        this.f4371a.putObject(obj, j6, obj2);
    }
}
