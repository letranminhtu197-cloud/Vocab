package androidx.datastore.preferences.protobuf;

import java.util.concurrent.ConcurrentHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class U {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final U f4308c = new U();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ConcurrentHashMap f4310b = new ConcurrentHashMap();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final F f4309a = new F();

    public final X a(Class cls) {
        X xV;
        Class cls2;
        AbstractC0174v.a(cls, "messageType");
        ConcurrentHashMap concurrentHashMap = this.f4310b;
        X x5 = (X) concurrentHashMap.get(cls);
        if (x5 != null) {
            return x5;
        }
        F f4 = this.f4309a;
        f4.getClass();
        Class cls3 = Y.f4317a;
        if (!AbstractC0172t.class.isAssignableFrom(cls) && (cls2 = Y.f4317a) != null && !cls2.isAssignableFrom(cls)) {
            throw new IllegalArgumentException("Message classes must extend GeneratedMessage or GeneratedMessageLite");
        }
        W wA = ((E) f4.f4277a).a(cls);
        int i6 = wA.f4316d;
        AbstractC0154a abstractC0154a = wA.f4313a;
        if ((i6 & 2) == 2) {
            if (AbstractC0172t.class.isAssignableFrom(cls)) {
                xV = new O(Y.f4320d, AbstractC0167n.f4369a, abstractC0154a);
            } else {
                g0 g0Var = Y.f4318b;
                C0166m c0166m = AbstractC0167n.f4370b;
                if (c0166m == null) {
                    throw new IllegalStateException("Protobuf runtime is not correctly loaded.");
                }
                xV = new O(g0Var, c0166m, abstractC0154a);
            }
        } else if (AbstractC0172t.class.isAssignableFrom(cls)) {
            xV = (wA.f4316d & 1) == 1 ? N.v(wA, Q.f4307b, D.f4274b, Y.f4320d, AbstractC0167n.f4369a, K.f4285b) : N.v(wA, Q.f4307b, D.f4274b, Y.f4320d, null, K.f4285b);
        } else if ((wA.f4316d & 1) == 1) {
            P p6 = Q.f4306a;
            B b6 = D.f4273a;
            g0 g0Var2 = Y.f4318b;
            C0166m c0166m2 = AbstractC0167n.f4370b;
            if (c0166m2 == null) {
                throw new IllegalStateException("Protobuf runtime is not correctly loaded.");
            }
            xV = N.v(wA, p6, b6, g0Var2, c0166m2, K.f4284a);
        } else {
            xV = N.v(wA, Q.f4306a, D.f4273a, Y.f4319c, null, K.f4284a);
        }
        X x6 = (X) concurrentHashMap.putIfAbsent(cls, xV);
        return x6 != null ? x6 : xV;
    }
}
