package androidx.datastore.preferences.protobuf;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0167n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final C0166m f4369a = new C0166m();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final C0166m f4370b;

    static {
        C0166m c0166m = null;
        try {
            c0166m = (C0166m) Class.forName("androidx.datastore.preferences.protobuf.ExtensionSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f4370b = c0166m;
    }
}
