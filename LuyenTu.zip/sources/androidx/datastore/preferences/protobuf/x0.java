package androidx.datastore.preferences.protobuf;

import java.io.Serializable;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: loaded from: classes.dex */
public enum x0 {
    INT(0),
    LONG(0L),
    FLOAT(Float.valueOf(0.0f)),
    DOUBLE(Double.valueOf(0.0d)),
    BOOLEAN(Boolean.FALSE),
    STRING(StringUtils.EMPTY),
    BYTE_STRING(C0159f.t),
    ENUM(null),
    MESSAGE(null);

    public final Object r;

    x0(Serializable serializable) {
        this.r = serializable;
    }
}
