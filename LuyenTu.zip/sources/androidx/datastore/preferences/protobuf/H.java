package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public final class H {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final G f4281a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f4282b;

    public H(w0 w0Var, w0 w0Var2, p005b0.j jVar) {
        this.f4281a = new G(w0Var, w0Var2, jVar);
        this.f4282b = jVar;
    }
}
