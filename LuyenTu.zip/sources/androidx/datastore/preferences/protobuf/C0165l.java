package androidx.datastore.preferences.protobuf;

import java.util.Collections;
import java.util.Map;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0165l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static volatile C0165l f4366a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final C0165l f4367b;

    static {
        try {
            Class.forName("androidx.datastore.preferences.protobuf.Extension");
        } catch (ClassNotFoundException unused) {
        }
        C0165l c0165l = new C0165l();
        Map map = Collections.EMPTY_MAP;
        f4367b = c0165l;
    }

    public static C0165l a() {
        C0165l c0165l;
        C0165l c0165l2 = f4366a;
        if (c0165l2 != null) {
            return c0165l2;
        }
        synchronized (C0165l.class) {
            try {
                c0165l = f4366a;
                if (c0165l == null) {
                    Class cls = AbstractC0164k.f4365a;
                    if (cls != null) {
                        try {
                            c0165l = (C0165l) cls.getDeclaredMethod("getEmptyRegistry", null).invoke(null, null);
                        } catch (Exception unused) {
                            c0165l = f4367b;
                        }
                    } else {
                        c0165l = f4367b;
                    }
                    f4366a = c0165l;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return c0165l;
    }
}
