package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public abstract class K {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final J f4284a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final J f4285b;

    static {
        J j6 = null;
        try {
            j6 = (J) Class.forName("androidx.datastore.preferences.protobuf.MapFieldSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f4284a = j6;
        f4285b = new J();
    }
}
