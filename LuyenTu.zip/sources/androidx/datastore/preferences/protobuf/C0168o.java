package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.pipes.PipesServer;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0168o {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final /* synthetic */ int f4372c = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Z f4373a = new Z(16);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f4374b;

    static {
        new C0168o(0);
    }

    public C0168o() {
    }

    public static void b(C0163j c0163j, w0 w0Var, int i6, Object obj) throws IOException {
        if (w0Var == w0.f4393u) {
            c0163j.R(i6, 3);
            ((AbstractC0154a) obj).c(c0163j);
            c0163j.R(i6, 4);
        }
        c0163j.R(i6, w0Var.f4396s);
        switch (w0Var.ordinal()) {
            case 0:
                c0163j.L(Double.doubleToRawLongBits(((Double) obj).doubleValue()));
                break;
            case 1:
                c0163j.J(Float.floatToRawIntBits(((Float) obj).floatValue()));
                break;
            case 2:
                c0163j.V(((Long) obj).longValue());
                break;
            case 3:
                c0163j.V(((Long) obj).longValue());
                break;
            case 4:
                c0163j.N(((Integer) obj).intValue());
                break;
            case 5:
                c0163j.L(((Long) obj).longValue());
                break;
            case 6:
                c0163j.J(((Integer) obj).intValue());
                break;
            case 7:
                c0163j.D(((Boolean) obj).booleanValue() ? (byte) 1 : (byte) 0);
                break;
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                if (!(obj instanceof C0159f)) {
                    c0163j.Q((String) obj);
                } else {
                    c0163j.H((C0159f) obj);
                }
                break;
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                ((AbstractC0154a) obj).c(c0163j);
                break;
            case 10:
                AbstractC0154a abstractC0154a = (AbstractC0154a) obj;
                c0163j.getClass();
                c0163j.T(abstractC0154a.a());
                abstractC0154a.c(c0163j);
                break;
            case 11:
                if (!(obj instanceof C0159f)) {
                    byte[] bArr = (byte[]) obj;
                    int length = bArr.length;
                    c0163j.T(length);
                    c0163j.E(bArr, 0, length);
                } else {
                    c0163j.H((C0159f) obj);
                }
                break;
            case 12:
                c0163j.T(((Integer) obj).intValue());
                break;
            case 13:
                c0163j.N(((Integer) obj).intValue());
                break;
            case 14:
                c0163j.J(((Integer) obj).intValue());
                break;
            case 15:
                c0163j.L(((Long) obj).longValue());
                break;
            case 16:
                int iIntValue = ((Integer) obj).intValue();
                c0163j.T((iIntValue >> 31) ^ (iIntValue << 1));
                break;
            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                long jLongValue = ((Long) obj).longValue();
                c0163j.V((jLongValue >> 63) ^ (jLongValue << 1));
                break;
        }
    }

    public final void a() {
        if (this.f4374b) {
            return;
        }
        Z z6 = this.f4373a;
        if (!z6.f4323u) {
            if (z6.f4322s.size() > 0) {
                z6.d(0).getKey().getClass();
                throw new ClassCastException();
            }
            Iterator it = z6.e().iterator();
            if (it.hasNext()) {
                ((Map.Entry) it.next()).getKey().getClass();
                throw new ClassCastException();
            }
        }
        if (!z6.f4323u) {
            z6.t = z6.t.isEmpty() ? Collections.EMPTY_MAP : Collections.unmodifiableMap(z6.t);
            z6.f4325w = z6.f4325w.isEmpty() ? Collections.EMPTY_MAP : Collections.unmodifiableMap(z6.f4325w);
            z6.f4323u = true;
        }
        this.f4374b = true;
    }

    public final Object clone() {
        C0168o c0168o = new C0168o();
        Z z6 = this.f4373a;
        if (z6.f4322s.size() > 0) {
            Map.Entry entryD = z6.d(0);
            if (entryD.getKey() != null) {
                throw new ClassCastException();
            }
            entryD.getValue();
            throw null;
        }
        Iterator it = z6.e().iterator();
        if (!it.hasNext()) {
            return c0168o;
        }
        Map.Entry entry = (Map.Entry) it.next();
        if (entry.getKey() != null) {
            throw new ClassCastException();
        }
        entry.getValue();
        throw null;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof C0168o) {
            return this.f4373a.equals(((C0168o) obj).f4373a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f4373a.hashCode();
    }

    public C0168o(int i6) {
        a();
        a();
    }
}
