package androidx.datastore.preferences.protobuf;

import java.util.AbstractList;
import java.util.Arrays;
import java.util.RandomAccess;

/* JADX INFO: loaded from: classes.dex */
public final class V extends AbstractC0155b implements RandomAccess {

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final V f4311u;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public Object[] f4312s;
    public int t;

    static {
        V v6 = new V(0, new Object[0]);
        f4311u = v6;
        v6.r = false;
    }

    public V(int i6, Object[] objArr) {
        this.f4312s = objArr;
        this.t = i6;
    }

    @Override // androidx.datastore.preferences.protobuf.InterfaceC0173u
    public final InterfaceC0173u a(int i6) {
        if (i6 < this.t) {
            throw new IllegalArgumentException();
        }
        return new V(this.t, Arrays.copyOf(this.f4312s, i6));
    }

    @Override // androidx.datastore.preferences.protobuf.AbstractC0155b, java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean add(Object obj) {
        b();
        int i6 = this.t;
        Object[] objArr = this.f4312s;
        if (i6 == objArr.length) {
            this.f4312s = Arrays.copyOf(objArr, ((i6 * 3) / 2) + 1);
        }
        Object[] objArr2 = this.f4312s;
        int i7 = this.t;
        this.t = i7 + 1;
        objArr2[i7] = obj;
        ((AbstractList) this).modCount++;
        return true;
    }

    public final void c(int i6) {
        if (i6 < 0 || i6 >= this.t) {
            StringBuilder sbN = com.google.crypto.tink.shaded.protobuf.T.n("Index:", i6, ", Size:");
            sbN.append(this.t);
            throw new IndexOutOfBoundsException(sbN.toString());
        }
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object get(int i6) {
        c(i6);
        return this.f4312s[i6];
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object remove(int i6) {
        b();
        c(i6);
        Object[] objArr = this.f4312s;
        Object obj = objArr[i6];
        int i7 = this.t;
        if (i6 < i7 - 1) {
            System.arraycopy(objArr, i6 + 1, objArr, i6, (i7 - i6) - 1);
        }
        this.t--;
        ((AbstractList) this).modCount++;
        return obj;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object set(int i6, Object obj) {
        b();
        c(i6);
        Object[] objArr = this.f4312s;
        Object obj2 = objArr[i6];
        objArr[i6] = obj;
        ((AbstractList) this).modCount++;
        return obj2;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.t;
    }

    @Override // java.util.AbstractList, java.util.List
    public final void add(int i6, Object obj) {
        int i7;
        b();
        if (i6 >= 0 && i6 <= (i7 = this.t)) {
            Object[] objArr = this.f4312s;
            if (i7 < objArr.length) {
                System.arraycopy(objArr, i6, objArr, i6 + 1, i7 - i6);
            } else {
                Object[] objArr2 = new Object[((i7 * 3) / 2) + 1];
                System.arraycopy(objArr, 0, objArr2, 0, i6);
                System.arraycopy(this.f4312s, i6, objArr2, i6 + 1, this.t - i6);
                this.f4312s = objArr2;
            }
            this.f4312s[i6] = obj;
            this.t++;
            ((AbstractList) this).modCount++;
            return;
        }
        StringBuilder sbN = com.google.crypto.tink.shaded.protobuf.T.n("Index:", i6, ", Size:");
        sbN.append(this.t);
        throw new IndexOutOfBoundsException(sbN.toString());
    }
}
