package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public final class p0 extends M {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f4386c;

    public static int m(long j6, byte[] bArr, int i6, int i7) {
        if (i7 == 0) {
            M m6 = r0.f4390a;
            if (i6 > -12) {
                return -1;
            }
            return i6;
        }
        if (i7 == 1) {
            return r0.c(i6, o0.f(j6, bArr));
        }
        if (i7 == 2) {
            return r0.d(i6, o0.f(j6, bArr), o0.f(j6 + 1, bArr));
        }
        throw new AssertionError();
    }

    /* JADX WARN: Code duplicated, block: B:100:0x0048 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:104:0x0110 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:105:0x00f8 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:106:0x0126 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:107:0x0121 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:108:0x0142 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:109:0x013d A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:110:0x0114 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:111:0x012a A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:112:0x0158 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:119:0x010d A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:13:0x0028  */
    /* JADX WARN: Code duplicated, block: B:17:0x0038  */
    /* JADX WARN: Code duplicated, block: B:19:0x003f A[LOOP:2: B:16:0x0036->B:19:0x003f, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:24:0x0051  */
    /* JADX WARN: Code duplicated, block: B:31:0x006c  */
    /* JADX WARN: Code duplicated, block: B:36:0x008a  */
    /* JADX WARN: Code duplicated, block: B:52:0x00f1  */
    /* JADX WARN: Code duplicated, block: B:56:0x0100  */
    /* JADX WARN: Code duplicated, block: B:58:0x0104 A[LOOP:5: B:55:0x00fe->B:58:0x0104, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:63:0x0116  */
    /* JADX WARN: Code duplicated, block: B:70:0x012e  */
    /* JADX WARN: Code duplicated, block: B:75:0x0146  */
    /* JADX WARN: Code duplicated, block: B:85:0x004b A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:86:0x0064 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:87:0x005f A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:88:0x0031 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:89:0x004f A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:90:0x0086 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:91:0x0081 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:92:0x00a9 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:93:0x0068 A[SYNTHETIC] */
    @Override // androidx.datastore.preferences.protobuf.M
    public final String e(byte[] bArr, int i6, int i7) throws C0176x {
        int i8;
        int i9;
        byte b6;
        int i10;
        int i11;
        byte b7;
        int i12;
        int i13;
        byte bF;
        int i14;
        byte bF2;
        switch (this.f4386c) {
            case 0:
                if ((i6 | i7 | ((bArr.length - i6) - i7)) < 0) {
                    throw new ArrayIndexOutOfBoundsException(String.format("buffer length=%d, index=%d, size=%d", Integer.valueOf(bArr.length), Integer.valueOf(i6), Integer.valueOf(i7)));
                }
                int i15 = i6 + i7;
                char[] cArr = new char[i7];
                int i16 = 0;
                while (i6 < i15) {
                    byte b8 = bArr[i6];
                    if (b8 < 0) {
                        i8 = i16;
                        while (i6 < i15) {
                            i9 = i6 + 1;
                            b6 = bArr[i6];
                            if (b6 >= 0) {
                                i10 = i8 + 1;
                                cArr[i8] = (char) b6;
                                i11 = i9;
                                while (i11 < i15) {
                                    b7 = bArr[i11];
                                    if (b7 >= 0) {
                                        i11++;
                                        cArr[i10] = (char) b7;
                                        i10++;
                                    } else {
                                        i8 = i10;
                                        i6 = i11;
                                    }
                                }
                                i8 = i10;
                                i6 = i11;
                            } else if (b6 < -32) {
                                if (i9 < i15) {
                                    throw C0176x.a();
                                }
                                i6 += 2;
                                M.b(b6, bArr[i9], cArr, i8);
                                i8++;
                            } else if (b6 < -16) {
                                if (i9 < i15 - 1) {
                                    throw C0176x.a();
                                }
                                int i17 = i6 + 2;
                                i6 += 3;
                                M.c(b6, bArr[i9], bArr[i17], cArr, i8);
                                i8++;
                            } else {
                                if (i9 < i15 - 2) {
                                    throw C0176x.a();
                                }
                                byte b9 = bArr[i9];
                                int i18 = i6 + 3;
                                byte b10 = bArr[i6 + 2];
                                i6 += 4;
                                M.a(b6, b9, b10, bArr[i18], cArr, i8);
                                i8 += 2;
                            }
                        }
                        return new String(cArr, 0, i8);
                    }
                    i6++;
                    cArr[i16] = (char) b8;
                    i16++;
                }
                i8 = i16;
                while (i6 < i15) {
                    i9 = i6 + 1;
                    b6 = bArr[i6];
                    if (b6 >= 0) {
                        i10 = i8 + 1;
                        cArr[i8] = (char) b6;
                        i11 = i9;
                        while (i11 < i15) {
                            b7 = bArr[i11];
                            if (b7 >= 0) {
                                i11++;
                                cArr[i10] = (char) b7;
                                i10++;
                            } else {
                                i8 = i10;
                                i6 = i11;
                            }
                        }
                        i8 = i10;
                        i6 = i11;
                    } else if (b6 < -32) {
                        if (i9 < i15) {
                            throw C0176x.a();
                        }
                        i6 += 2;
                        M.b(b6, bArr[i9], cArr, i8);
                        i8++;
                    } else if (b6 < -16) {
                        if (i9 < i15 - 1) {
                            throw C0176x.a();
                        }
                        int i19 = i6 + 2;
                        i6 += 3;
                        M.c(b6, bArr[i9], bArr[i19], cArr, i8);
                        i8++;
                    } else {
                        if (i9 < i15 - 2) {
                            throw C0176x.a();
                        }
                        byte b11 = bArr[i9];
                        int i110 = i6 + 3;
                        byte b12 = bArr[i6 + 2];
                        i6 += 4;
                        M.a(b6, b11, b12, bArr[i110], cArr, i8);
                        i8 += 2;
                    }
                }
                return new String(cArr, 0, i8);
            default:
                if ((i6 | i7 | ((bArr.length - i6) - i7)) < 0) {
                    throw new ArrayIndexOutOfBoundsException(String.format("buffer length=%d, index=%d, size=%d", Integer.valueOf(bArr.length), Integer.valueOf(i6), Integer.valueOf(i7)));
                }
                int i20 = i6 + i7;
                char[] cArr2 = new char[i7];
                int i21 = 0;
                while (i6 < i20) {
                    byte bF3 = o0.f(i6, bArr);
                    if (bF3 < 0) {
                        i12 = i21;
                        while (i6 < i20) {
                            i13 = i6 + 1;
                            bF = o0.f(i6, bArr);
                            if (bF >= 0) {
                                i14 = i12 + 1;
                                cArr2[i12] = (char) bF;
                                while (i13 < i20) {
                                    bF2 = o0.f(i13, bArr);
                                    if (bF2 >= 0) {
                                        i13++;
                                        cArr2[i14] = (char) bF2;
                                        i14++;
                                    } else {
                                        i12 = i14;
                                        i6 = i13;
                                    }
                                }
                                i12 = i14;
                                i6 = i13;
                            } else if (bF < -32) {
                                if (i13 < i20) {
                                    throw C0176x.a();
                                }
                                i6 += 2;
                                M.b(bF, o0.f(i13, bArr), cArr2, i12);
                                i12++;
                            } else if (bF < -16) {
                                if (i13 < i20 - 1) {
                                    throw C0176x.a();
                                }
                                int i22 = i6 + 2;
                                i6 += 3;
                                M.c(bF, o0.f(i13, bArr), o0.f(i22, bArr), cArr2, i12);
                                i12++;
                            } else {
                                if (i13 < i20 - 2) {
                                    throw C0176x.a();
                                }
                                byte bF4 = o0.f(i13, bArr);
                                int i23 = i6 + 3;
                                byte bF5 = o0.f(i6 + 2, bArr);
                                i6 += 4;
                                M.a(bF, bF4, bF5, o0.f(i23, bArr), cArr2, i12);
                                i12 += 2;
                            }
                        }
                        return new String(cArr2, 0, i12);
                    }
                    i6++;
                    cArr2[i21] = (char) bF3;
                    i21++;
                }
                i12 = i21;
                while (i6 < i20) {
                    i13 = i6 + 1;
                    bF = o0.f(i6, bArr);
                    if (bF >= 0) {
                        i14 = i12 + 1;
                        cArr2[i12] = (char) bF;
                        while (i13 < i20) {
                            bF2 = o0.f(i13, bArr);
                            if (bF2 >= 0) {
                                i13++;
                                cArr2[i14] = (char) bF2;
                                i14++;
                            } else {
                                i12 = i14;
                                i6 = i13;
                            }
                        }
                        i12 = i14;
                        i6 = i13;
                    } else if (bF < -32) {
                        if (i13 < i20) {
                            throw C0176x.a();
                        }
                        i6 += 2;
                        M.b(bF, o0.f(i13, bArr), cArr2, i12);
                        i12++;
                    } else if (bF < -16) {
                        if (i13 < i20 - 1) {
                            throw C0176x.a();
                        }
                        int i24 = i6 + 2;
                        i6 += 3;
                        M.c(bF, o0.f(i13, bArr), o0.f(i24, bArr), cArr2, i12);
                        i12++;
                    } else {
                        if (i13 < i20 - 2) {
                            throw C0176x.a();
                        }
                        byte bF6 = o0.f(i13, bArr);
                        int i25 = i6 + 3;
                        byte bF7 = o0.f(i6 + 2, bArr);
                        i6 += 4;
                        M.a(bF, bF6, bF7, o0.f(i25, bArr), cArr2, i12);
                        i12 += 2;
                    }
                }
                return new String(cArr2, 0, i12);
        }
    }

    @Override // androidx.datastore.preferences.protobuf.M
    public final int f(String str, byte[] bArr, int i6, int i7) {
        int i8;
        int i9;
        char cCharAt;
        long j6;
        char c2;
        long j7;
        long j8;
        char c6;
        int i10;
        char cCharAt2;
        switch (this.f4386c) {
            case 0:
                int length = str.length();
                int i11 = i7 + i6;
                int i12 = 0;
                while (i12 < length && (i9 = i12 + i6) < i11 && (cCharAt = str.charAt(i12)) < 128) {
                    bArr[i9] = (byte) cCharAt;
                    i12++;
                }
                if (i12 == length) {
                    return i6 + length;
                }
                int i13 = i6 + i12;
                while (i12 < length) {
                    char cCharAt3 = str.charAt(i12);
                    if (cCharAt3 < 128 && i13 < i11) {
                        bArr[i13] = (byte) cCharAt3;
                        i13++;
                    } else if (cCharAt3 < 2048 && i13 <= i11 - 2) {
                        int i14 = i13 + 1;
                        bArr[i13] = (byte) ((cCharAt3 >>> 6) | 960);
                        i13 += 2;
                        bArr[i14] = (byte) ((cCharAt3 & '?') | 128);
                    } else {
                        if ((cCharAt3 >= 55296 && 57343 >= cCharAt3) || i13 > i11 - 3) {
                            if (i13 > i11 - 4) {
                                if (55296 <= cCharAt3 && cCharAt3 <= 57343 && ((i8 = i12 + 1) == str.length() || !Character.isSurrogatePair(cCharAt3, str.charAt(i8)))) {
                                    throw new q0(i12, length);
                                }
                                throw new ArrayIndexOutOfBoundsException("Failed writing " + cCharAt3 + " at index " + i13);
                            }
                            int i15 = i12 + 1;
                            if (i15 != str.length()) {
                                char cCharAt4 = str.charAt(i15);
                                if (Character.isSurrogatePair(cCharAt3, cCharAt4)) {
                                    int codePoint = Character.toCodePoint(cCharAt3, cCharAt4);
                                    bArr[i13] = (byte) ((codePoint >>> 18) | 240);
                                    bArr[i13 + 1] = (byte) (((codePoint >>> 12) & 63) | 128);
                                    int i16 = i13 + 3;
                                    bArr[i13 + 2] = (byte) (((codePoint >>> 6) & 63) | 128);
                                    i13 += 4;
                                    bArr[i16] = (byte) ((codePoint & 63) | 128);
                                    i12 = i15;
                                } else {
                                    i12 = i15;
                                }
                            }
                            throw new q0(i12 - 1, length);
                        }
                        bArr[i13] = (byte) ((cCharAt3 >>> '\f') | 480);
                        int i17 = i13 + 2;
                        bArr[i13 + 1] = (byte) (((cCharAt3 >>> 6) & 63) | 128);
                        i13 += 3;
                        bArr[i17] = (byte) ((cCharAt3 & '?') | 128);
                    }
                    i12++;
                }
                return i13;
            default:
                long j9 = i6;
                long j10 = ((long) i7) + j9;
                int length2 = str.length();
                if (length2 > i7 || bArr.length - i7 < i6) {
                    throw new ArrayIndexOutOfBoundsException("Failed writing " + str.charAt(length2 - 1) + " at index " + (i6 + i7));
                }
                int i18 = 0;
                while (true) {
                    j6 = 1;
                    c2 = 128;
                    if (i18 < length2 && (cCharAt2 = str.charAt(i18)) < 128) {
                        o0.j(bArr, j9, (byte) cCharAt2);
                        i18++;
                        j9 = 1 + j9;
                    }
                }
                if (i18 == length2) {
                    return (int) j9;
                }
                while (i18 < length2) {
                    char cCharAt5 = str.charAt(i18);
                    if (cCharAt5 < c2 && j9 < j10) {
                        o0.j(bArr, j9, (byte) cCharAt5);
                        c6 = c2;
                        j7 = j6;
                        j8 = j9 + j6;
                    } else if (cCharAt5 >= 2048 || j9 > j10 - 2) {
                        j7 = j6;
                        if ((cCharAt5 >= 55296 && 57343 >= cCharAt5) || j9 > j10 - 3) {
                            long j11 = j9;
                            if (j11 > j10 - 4) {
                                if (55296 <= cCharAt5 && cCharAt5 <= 57343 && ((i10 = i18 + 1) == length2 || !Character.isSurrogatePair(cCharAt5, str.charAt(i10)))) {
                                    throw new q0(i18, length2);
                                }
                                throw new ArrayIndexOutOfBoundsException("Failed writing " + cCharAt5 + " at index " + j11);
                            }
                            int i19 = i18 + 1;
                            if (i19 != length2) {
                                char cCharAt6 = str.charAt(i19);
                                if (Character.isSurrogatePair(cCharAt5, cCharAt6)) {
                                    int codePoint2 = Character.toCodePoint(cCharAt5, cCharAt6);
                                    o0.j(bArr, j11, (byte) ((codePoint2 >>> 18) | 240));
                                    c6 = 128;
                                    o0.j(bArr, j11 + j7, (byte) (((codePoint2 >>> 12) & 63) | 128));
                                    o0.j(bArr, j11 + 2, (byte) (((codePoint2 >>> 6) & 63) | 128));
                                    o0.j(bArr, j11 + 3, (byte) ((codePoint2 & 63) | 128));
                                    j8 = j11 + 4;
                                    i18 = i19;
                                } else {
                                    i18 = i19;
                                }
                            }
                            throw new q0(i18 - 1, length2);
                        }
                        o0.j(bArr, j9, (byte) ((cCharAt5 >>> '\f') | 480));
                        long j12 = j9;
                        o0.j(bArr, j9 + j7, (byte) (((cCharAt5 >>> 6) & 63) | 128));
                        j8 = j12 + 3;
                        o0.j(bArr, j12 + 2, (byte) ((cCharAt5 & '?') | 128));
                        c6 = 128;
                    } else {
                        j7 = j6;
                        o0.j(bArr, j9, (byte) ((cCharAt5 >>> 6) | 960));
                        o0.j(bArr, j9 + j7, (byte) ((cCharAt5 & '?') | c2));
                        j8 = j9 + 2;
                        c6 = c2;
                    }
                    i18++;
                    c2 = c6;
                    j9 = j8;
                    j6 = j7;
                }
                return (int) j9;
        }
    }

    /* JADX WARN: Code duplicated, block: B:117:0x0047 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:118:0x0054 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:119:0x00c7 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:120:0x00c7 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:121:0x0073 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:126:0x009b A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:127:0x00c7 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:128:0x00c7 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:129:0x00c7 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:130:0x00c7 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:133:0x00c4 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:25:0x004a  */
    /* JADX WARN: Code duplicated, block: B:27:0x0052 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:29:0x0057  */
    /* JADX WARN: Code duplicated, block: B:31:0x005d  */
    /* JADX WARN: Code duplicated, block: B:34:0x0067  */
    /* JADX WARN: Code duplicated, block: B:35:0x006a  */
    /* JADX WARN: Code duplicated, block: B:37:0x0070  */
    /* JADX WARN: Code duplicated, block: B:40:0x0078  */
    /* JADX WARN: Code duplicated, block: B:51:0x0097  */
    /* JADX WARN: Code duplicated, block: B:54:0x00a0  */
    /* JADX WARN: Code duplicated, block: B:56:0x00aa  */
    /* JADX WARN: Code duplicated, block: B:58:0x00b3  */
    /* JADX WARN: Code duplicated, block: B:60:0x00ba  */
    @Override // androidx.datastore.preferences.protobuf.M
    public final int i(byte[] bArr, int i6, int i7) {
        int i8;
        int i9;
        long j6;
        long j7;
        byte bF;
        long j8;
        byte bF2;
        long j9;
        int i10 = i6;
        switch (this.f4386c) {
            case 0:
                break;
            default:
                if ((i10 | i7 | (bArr.length - i7)) < 0) {
                    throw new ArrayIndexOutOfBoundsException(String.format("Array length=%d, index=%d, limit=%d", Integer.valueOf(bArr.length), Integer.valueOf(i10), Integer.valueOf(i7)));
                }
                long j10 = i10;
                int i11 = (int) (((long) i7) - j10);
                long j11 = 1;
                if (i11 < 16) {
                    i8 = 0;
                } else {
                    long j12 = j10;
                    i8 = 0;
                    while (true) {
                        if (i8 < i11) {
                            long j13 = j12 + 1;
                            if (o0.f(j12, bArr) >= 0) {
                                i8++;
                                j12 = j13;
                            }
                        } else {
                            i8 = i11;
                        }
                    }
                }
                int i12 = i11 - i8;
                long j14 = j10 + ((long) i8);
                while (true) {
                    byte bF3 = 0;
                    while (i12 > 0) {
                        long j15 = j14 + j11;
                        bF3 = o0.f(j14, bArr);
                        if (bF3 < 0) {
                            j14 = j15;
                            if (i12 == 0) {
                                return 0;
                            }
                            i9 = i12 - 1;
                            if (bF3 < -32) {
                                if (i9 == 0) {
                                    return bF3;
                                }
                                i12 -= 2;
                                if (bF3 >= -62) {
                                    j9 = j14 + j11;
                                    if (o0.f(j14, bArr) > -65) {
                                        j6 = j11;
                                        j14 = j9;
                                        j11 = j6;
                                    }
                                }
                                return -1;
                            }
                            if (bF3 < -16) {
                                if (i9 < 2) {
                                    return m(j14, bArr, bF3, i9);
                                }
                                i12 -= 3;
                                j6 = j11;
                                long j16 = j14 + j6;
                                bF2 = o0.f(j14, bArr);
                                if (bF2 > -65 && ((bF3 != -32 || bF2 >= -96) && (bF3 != -19 || bF2 < -96))) {
                                    j14 += 2;
                                    if (o0.f(j16, bArr) <= -65) {
                                        j11 = j6;
                                    }
                                }
                                return -1;
                            }
                            j6 = j11;
                            if (i9 < 3) {
                                return m(j14, bArr, bF3, i9);
                            }
                            i12 -= 4;
                            j7 = j14 + j6;
                            bF = o0.f(j14, bArr);
                            if (bF <= -65) {
                                if ((((bF + 112) + (bF3 << 28)) >> 30) == 0) {
                                    j8 = 2 + j14;
                                    if (o0.f(j7, bArr) <= -65) {
                                        j14 += 3;
                                        if (o0.f(j8, bArr) > -65) {
                                            j11 = j6;
                                        }
                                    }
                                }
                            }
                            return -1;
                        }
                        i12--;
                        j14 = j15;
                    }
                    if (i12 == 0) {
                        return 0;
                    }
                    i9 = i12 - 1;
                    if (bF3 < -32) {
                        if (i9 == 0) {
                            return bF3;
                        }
                        i12 -= 2;
                        if (bF3 >= -62) {
                            j9 = j14 + j11;
                            if (o0.f(j14, bArr) > -65) {
                                j6 = j11;
                                j14 = j9;
                                j11 = j6;
                            }
                        }
                        return -1;
                    }
                    if (bF3 < -16) {
                        if (i9 < 2) {
                            return m(j14, bArr, bF3, i9);
                        }
                        i12 -= 3;
                        j6 = j11;
                        long j17 = j14 + j6;
                        bF2 = o0.f(j14, bArr);
                        if (bF2 > -65) {
                        }
                        return -1;
                    }
                    j6 = j11;
                    if (i9 < 3) {
                        return m(j14, bArr, bF3, i9);
                    }
                    i12 -= 4;
                    j7 = j14 + j6;
                    bF = o0.f(j14, bArr);
                    if (bF <= -65) {
                        if ((((bF + 112) + (bF3 << 28)) >> 30) == 0) {
                            j8 = 2 + j14;
                            if (o0.f(j7, bArr) <= -65) {
                                j14 += 3;
                                if (o0.f(j8, bArr) > -65) {
                                    j11 = j6;
                                }
                            }
                        }
                    }
                    return -1;
                }
        }
        while (i10 < i7 && bArr[i10] >= 0) {
            i10++;
        }
        if (i10 < i7) {
            while (i10 < i7) {
                int i13 = i10 + 1;
                byte b6 = bArr[i10];
                if (b6 < 0) {
                    if (b6 < -32) {
                        if (i13 >= i7) {
                            return b6;
                        }
                        if (b6 >= -62) {
                            i10 += 2;
                            if (bArr[i13] > -65) {
                            }
                        }
                        return -1;
                    }
                    if (b6 < -16) {
                        if (i13 >= i7 - 1) {
                            return r0.a(bArr, i13, i7);
                        }
                        int i14 = i10 + 2;
                        byte b7 = bArr[i13];
                        if (b7 <= -65 && ((b6 != -32 || b7 >= -96) && (b6 != -19 || b7 < -96))) {
                            i10 += 3;
                            if (bArr[i14] > -65) {
                            }
                        }
                        return -1;
                    }
                    if (i13 >= i7 - 2) {
                        return r0.a(bArr, i13, i7);
                    }
                    int i15 = i10 + 2;
                    byte b8 = bArr[i13];
                    if (b8 <= -65) {
                        if ((((b8 + 112) + (b6 << 28)) >> 30) == 0) {
                            int i16 = i10 + 3;
                            if (bArr[i15] <= -65) {
                                i10 += 4;
                                if (bArr[i16] > -65) {
                                }
                            }
                        }
                    }
                    return -1;
                }
                i10 = i13;
            }
        }
        return 0;
    }
}
