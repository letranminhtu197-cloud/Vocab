package androidx.datastore.preferences.protobuf;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.v, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0174v {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Charset f4391a = Charset.forName("UTF-8");

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final byte[] f4392b;

    static {
        Charset.forName("ISO-8859-1");
        byte[] bArr = new byte[0];
        f4392b = bArr;
        ByteBuffer.wrap(bArr);
        if (0 + 0 <= Integer.MAX_VALUE) {
            return;
        }
        try {
            throw C0176x.f();
        } catch (C0176x e6) {
            throw new IllegalArgumentException(e6);
        }
    }

    public static void a(Object obj, String str) {
        if (obj == null) {
            throw new NullPointerException(str);
        }
    }

    public static int b(long j6) {
        return (int) (j6 ^ (j6 >>> 32));
    }

    public static AbstractC0172t c(Object obj, Object obj2) {
        AbstractC0172t abstractC0172t = (AbstractC0172t) ((AbstractC0154a) obj);
        r rVar = (r) abstractC0172t.d(5);
        rVar.c();
        r.d(rVar.f4389s, abstractC0172t);
        AbstractC0154a abstractC0154a = (AbstractC0154a) obj2;
        if (!rVar.r.getClass().isInstance(abstractC0154a)) {
            throw new IllegalArgumentException("mergeFrom(MessageLite) can only merge messages of the same type.");
        }
        rVar.c();
        r.d(rVar.f4389s, (AbstractC0172t) abstractC0154a);
        return rVar.b();
    }
}
