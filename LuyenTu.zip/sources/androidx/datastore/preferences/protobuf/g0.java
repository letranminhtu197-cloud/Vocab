package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public final class g0 {
    public static boolean a(Object obj, C0161h c0161h) throws C0176x {
        int iD = c0161h.d();
        int i6 = iD >>> 3;
        int i7 = iD & 7;
        if (i7 == 0) {
            ((f0) obj).c(i6 << 3, Long.valueOf(c0161h.B()));
            return true;
        }
        if (i7 == 1) {
            ((f0) obj).c((i6 << 3) | 1, Long.valueOf(c0161h.s()));
            return true;
        }
        if (i7 == 2) {
            ((f0) obj).c((i6 << 3) | 2, c0161h.i());
            return true;
        }
        if (i7 != 3) {
            if (i7 == 4) {
                return false;
            }
            if (i7 != 5) {
                throw C0176x.b();
            }
            ((f0) obj).c((i6 << 3) | 5, Integer.valueOf(c0161h.q()));
            return true;
        }
        f0 f0VarB = f0.b();
        int i8 = i6 << 3;
        int i9 = i8 | 4;
        while (c0161h.c() != Integer.MAX_VALUE && a(f0VarB, c0161h)) {
        }
        if (i9 != c0161h.d()) {
            throw new C0176x("Protocol message end-group tag did not match expected tag.");
        }
        f0VarB.f4342e = false;
        ((f0) obj).c(i8 | 3, f0VarB);
        return true;
    }
}
