package androidx.datastore.preferences.protobuf;

import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public interface A extends List {
    A d();

    Object e(int i6);

    List f();

    void t(C0159f c0159f);
}
