package androidx.datastore.preferences.protobuf;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Iterator;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C0159f implements Iterable, Serializable {
    public static final C0159f t = new C0159f(AbstractC0174v.f4392b);

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final C0158e f4335u;
    public int r = 0;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final byte[] f4336s;

    static {
        f4335u = AbstractC0156c.a() ? new C0158e(1) : new C0158e(0);
    }

    public C0159f(byte[] bArr) {
        bArr.getClass();
        this.f4336s = bArr;
    }

    public static C0159f b(byte[] bArr, int i6, int i7) {
        byte[] bArrCopyOfRange;
        int i8 = i6 + i7;
        int length = bArr.length;
        if (((i8 - i6) | i6 | i8 | (length - i8)) < 0) {
            if (i6 < 0) {
                throw new IndexOutOfBoundsException(com.google.crypto.tink.shaded.protobuf.T.h("Beginning index: ", i6, " < 0"));
            }
            if (i8 < i6) {
                throw new IndexOutOfBoundsException(A3.a.k(i6, i8, "Beginning index larger than ending index: ", ", "));
            }
            throw new IndexOutOfBoundsException(A3.a.k(i8, length, "End index: ", " >= "));
        }
        switch (f4335u.f4333a) {
            case 0:
                bArrCopyOfRange = Arrays.copyOfRange(bArr, i6, i7 + i6);
                break;
            default:
                bArrCopyOfRange = new byte[i7];
                System.arraycopy(bArr, i6, bArrCopyOfRange, 0, i7);
                break;
        }
        return new C0159f(bArrCopyOfRange);
    }

    public int c() {
        return 0;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0159f) || size() != ((C0159f) obj).size()) {
            return false;
        }
        if (size() == 0) {
            return true;
        }
        if (!(obj instanceof C0159f)) {
            return obj.equals(this);
        }
        C0159f c0159f = (C0159f) obj;
        int i6 = this.r;
        int i7 = c0159f.r;
        if (i6 != 0 && i7 != 0 && i6 != i7) {
            return false;
        }
        int size = size();
        if (size > c0159f.size()) {
            throw new IllegalArgumentException("Length too large: " + size + size());
        }
        if (size > c0159f.size()) {
            StringBuilder sbN = com.google.crypto.tink.shaded.protobuf.T.n("Ran off end of other: 0, ", size, ", ");
            sbN.append(c0159f.size());
            throw new IllegalArgumentException(sbN.toString());
        }
        byte[] bArr = c0159f.f4336s;
        int iC = c() + size;
        int iC2 = c();
        int iC3 = c0159f.c();
        while (iC2 < iC) {
            if (this.f4336s[iC2] != bArr[iC3]) {
                return false;
            }
            iC2++;
            iC3++;
        }
        return true;
    }

    public final int hashCode() {
        int i6 = this.r;
        if (i6 != 0) {
            return i6;
        }
        int size = size();
        int iC = c();
        int i7 = size;
        for (int i8 = iC; i8 < iC + size; i8++) {
            i7 = (i7 * 31) + this.f4336s[i8];
        }
        if (i7 == 0) {
            i7 = 1;
        }
        this.r = i7;
        return i7;
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        return new C0157d(this);
    }

    public int size() {
        return this.f4336s.length;
    }

    public final String toString() {
        return String.format("<ByteString@%s size=%d>", Integer.toHexString(System.identityHashCode(this)), Integer.valueOf(size()));
    }
}
