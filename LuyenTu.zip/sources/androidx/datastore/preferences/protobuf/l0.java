package androidx.datastore.preferences.protobuf;

import sun.misc.Unsafe;

/* JADX INFO: loaded from: classes.dex */
public final class l0 extends n0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f4368b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ l0(Unsafe unsafe, int i6) {
        super(unsafe);
        this.f4368b = i6;
    }

    @Override // androidx.datastore.preferences.protobuf.n0
    public final boolean c(long j6, Object obj) {
        switch (this.f4368b) {
            case 0:
                if (o0.f4382h) {
                    if (o0.g(j6, obj) == 0) {
                        return false;
                    }
                } else if (o0.h(j6, obj) == 0) {
                    return false;
                }
                return true;
            default:
                if (o0.f4382h) {
                    if (o0.g(j6, obj) == 0) {
                        return false;
                    }
                } else if (o0.h(j6, obj) == 0) {
                    return false;
                }
                return true;
        }
    }

    @Override // androidx.datastore.preferences.protobuf.n0
    public final byte d(long j6, Object obj) {
        switch (this.f4368b) {
            case 0:
                return o0.f4382h ? o0.g(j6, obj) : o0.h(j6, obj);
            default:
                return o0.f4382h ? o0.g(j6, obj) : o0.h(j6, obj);
        }
    }

    @Override // androidx.datastore.preferences.protobuf.n0
    public final double e(long j6, Object obj) {
        switch (this.f4368b) {
            case 0:
                break;
        }
        return Double.longBitsToDouble(h(j6, obj));
    }

    @Override // androidx.datastore.preferences.protobuf.n0
    public final float f(long j6, Object obj) {
        switch (this.f4368b) {
            case 0:
                break;
        }
        return Float.intBitsToFloat(g(j6, obj));
    }

    @Override // androidx.datastore.preferences.protobuf.n0
    public final void k(Object obj, long j6, boolean z6) {
        switch (this.f4368b) {
            case 0:
                if (!o0.f4382h) {
                    o0.l(obj, j6, z6 ? (byte) 1 : (byte) 0);
                } else {
                    o0.k(obj, j6, z6 ? (byte) 1 : (byte) 0);
                }
                break;
            default:
                if (!o0.f4382h) {
                    o0.l(obj, j6, z6 ? (byte) 1 : (byte) 0);
                } else {
                    o0.k(obj, j6, z6 ? (byte) 1 : (byte) 0);
                }
                break;
        }
    }

    @Override // androidx.datastore.preferences.protobuf.n0
    public final void l(Object obj, long j6, byte b6) {
        switch (this.f4368b) {
            case 0:
                if (!o0.f4382h) {
                    o0.l(obj, j6, b6);
                } else {
                    o0.k(obj, j6, b6);
                }
                break;
            default:
                if (!o0.f4382h) {
                    o0.l(obj, j6, b6);
                } else {
                    o0.k(obj, j6, b6);
                }
                break;
        }
    }

    @Override // androidx.datastore.preferences.protobuf.n0
    public final void m(Object obj, long j6, double d6) {
        switch (this.f4368b) {
            case 0:
                p(obj, j6, Double.doubleToLongBits(d6));
                break;
            default:
                p(obj, j6, Double.doubleToLongBits(d6));
                break;
        }
    }

    @Override // androidx.datastore.preferences.protobuf.n0
    public final void n(Object obj, long j6, float f4) {
        switch (this.f4368b) {
            case 0:
                o(Float.floatToIntBits(f4), j6, obj);
                break;
            default:
                o(Float.floatToIntBits(f4), j6, obj);
                break;
        }
    }
}
