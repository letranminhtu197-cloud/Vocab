package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public final class G {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final w0 f4278a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final w0 f4279b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f4280c;

    public G(w0 w0Var, w0 w0Var2, Object obj) {
        this.f4278a = w0Var;
        this.f4279b = w0Var2;
        this.f4280c = obj;
    }
}
