package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public final class O implements X {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final AbstractC0154a f4303a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final g0 f4304b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final C0166m f4305c;

    public O(g0 g0Var, C0166m c0166m, AbstractC0154a abstractC0154a) {
        this.f4304b = g0Var;
        c0166m.getClass();
        this.f4305c = c0166m;
        this.f4303a = abstractC0154a;
    }

    @Override // androidx.datastore.preferences.protobuf.X
    public final void a(Object obj) {
        this.f4304b.getClass();
        ((AbstractC0172t) obj).unknownFields.f4342e = false;
        this.f4305c.getClass();
        A3.a.o(obj);
        throw null;
    }

    @Override // androidx.datastore.preferences.protobuf.X
    public final boolean b(Object obj) {
        this.f4305c.getClass();
        A3.a.o(obj);
        throw null;
    }

    @Override // androidx.datastore.preferences.protobuf.X
    public final void c(Object obj, F f4) {
        this.f4305c.getClass();
        A3.a.o(obj);
        throw null;
    }

    @Override // androidx.datastore.preferences.protobuf.X
    public final int d(AbstractC0172t abstractC0172t) {
        this.f4304b.getClass();
        return abstractC0172t.unknownFields.hashCode();
    }

    @Override // androidx.datastore.preferences.protobuf.X
    public final int e(AbstractC0154a abstractC0154a) {
        this.f4304b.getClass();
        f0 f0Var = ((AbstractC0172t) abstractC0154a).unknownFields;
        int i6 = f0Var.f4341d;
        if (i6 != -1) {
            return i6;
        }
        int iR = 0;
        for (int i7 = 0; i7 < f0Var.f4338a; i7++) {
            int i8 = f0Var.f4339b[i7] >>> 3;
            iR += C0163j.r(3, (C0159f) f0Var.f4340c[i7]) + C0163j.z(i8) + C0163j.y(2) + (C0163j.y(1) * 2);
        }
        f0Var.f4341d = iR;
        return iR;
    }

    @Override // androidx.datastore.preferences.protobuf.X
    public final boolean f(AbstractC0172t abstractC0172t, AbstractC0172t abstractC0172t2) {
        this.f4304b.getClass();
        return abstractC0172t.unknownFields.equals(abstractC0172t2.unknownFields);
    }

    @Override // androidx.datastore.preferences.protobuf.X
    public final void g(Object obj, C0161h c0161h, C0165l c0165l) {
        this.f4304b.getClass();
        AbstractC0172t abstractC0172t = (AbstractC0172t) obj;
        if (abstractC0172t.unknownFields == f0.f4337f) {
            abstractC0172t.unknownFields = f0.b();
        }
        this.f4305c.getClass();
        obj.getClass();
        throw new ClassCastException();
    }

    @Override // androidx.datastore.preferences.protobuf.X
    public final void h(AbstractC0172t abstractC0172t, AbstractC0172t abstractC0172t2) {
        Y.w(this.f4304b, abstractC0172t, abstractC0172t2);
    }

    @Override // androidx.datastore.preferences.protobuf.X
    public final Object newInstance() {
        return ((r) ((AbstractC0172t) this.f4303a).d(5)).b();
    }
}
