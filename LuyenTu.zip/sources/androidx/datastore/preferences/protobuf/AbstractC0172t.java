package androidx.datastore.preferences.protobuf;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.t, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0172t extends AbstractC0154a {
    private static Map<Object, AbstractC0172t> defaultInstanceMap = new ConcurrentHashMap();
    protected int memoizedSerializedSize;
    protected f0 unknownFields;

    public AbstractC0172t() {
        this.memoizedHashCode = 0;
        this.unknownFields = f0.f4337f;
        this.memoizedSerializedSize = -1;
    }

    public static AbstractC0172t e(Class cls) {
        AbstractC0172t abstractC0172t = defaultInstanceMap.get(cls);
        if (abstractC0172t == null) {
            try {
                Class.forName(cls.getName(), true, cls.getClassLoader());
                abstractC0172t = defaultInstanceMap.get(cls);
            } catch (ClassNotFoundException e6) {
                throw new IllegalStateException("Class initialization cannot fail.", e6);
            }
        }
        if (abstractC0172t != null) {
            return abstractC0172t;
        }
        AbstractC0172t abstractC0172t2 = (AbstractC0172t) ((AbstractC0172t) o0.a(cls)).d(6);
        if (abstractC0172t2 == null) {
            throw new IllegalStateException();
        }
        defaultInstanceMap.put(cls, abstractC0172t2);
        return abstractC0172t2;
    }

    public static Object f(Method method, AbstractC0172t abstractC0172t, Object... objArr) {
        try {
            return method.invoke(abstractC0172t, objArr);
        } catch (IllegalAccessException e6) {
            throw new RuntimeException("Couldn't use Java reflection to implement protocol message reflection.", e6);
        } catch (InvocationTargetException e7) {
            Throwable cause = e7.getCause();
            if (cause instanceof RuntimeException) {
                throw ((RuntimeException) cause);
            }
            if (cause instanceof Error) {
                throw ((Error) cause);
            }
            throw new RuntimeException("Unexpected exception thrown by generated accessor method.", cause);
        }
    }

    public static void h(Class cls, AbstractC0172t abstractC0172t) {
        defaultInstanceMap.put(cls, abstractC0172t);
    }

    @Override // androidx.datastore.preferences.protobuf.AbstractC0154a
    public final int a() {
        if (this.memoizedSerializedSize == -1) {
            U u6 = U.f4308c;
            u6.getClass();
            this.memoizedSerializedSize = u6.a(getClass()).e(this);
        }
        return this.memoizedSerializedSize;
    }

    @Override // androidx.datastore.preferences.protobuf.AbstractC0154a
    public final void c(C0163j c0163j) {
        U u6 = U.f4308c;
        u6.getClass();
        X xA = u6.a(getClass());
        F f4 = c0163j.f4360c;
        if (f4 == null) {
            f4 = new F(c0163j);
        }
        xA.c(this, f4);
    }

    public abstract Object d(int i6);

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!((AbstractC0172t) d(6)).getClass().isInstance(obj)) {
            return false;
        }
        U u6 = U.f4308c;
        u6.getClass();
        return u6.a(getClass()).f(this, (AbstractC0172t) obj);
    }

    public final boolean g() {
        byte bByteValue = ((Byte) d(1)).byteValue();
        if (bByteValue == 1) {
            return true;
        }
        if (bByteValue == 0) {
            return false;
        }
        U u6 = U.f4308c;
        u6.getClass();
        boolean zB = u6.a(getClass()).b(this);
        d(2);
        return zB;
    }

    public final int hashCode() {
        int i6 = this.memoizedHashCode;
        if (i6 != 0) {
            return i6;
        }
        U u6 = U.f4308c;
        u6.getClass();
        int iD = u6.a(getClass()).d(this);
        this.memoizedHashCode = iD;
        return iD;
    }

    public final String toString() {
        String string = super.toString();
        StringBuilder sb = new StringBuilder();
        sb.append("# ");
        sb.append(string);
        M.k(this, sb, 0);
        return sb.toString();
    }
}
