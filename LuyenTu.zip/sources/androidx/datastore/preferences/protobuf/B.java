package androidx.datastore.preferences.protobuf;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class B extends D {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Class f4272c = Collections.unmodifiableList(Collections.EMPTY_LIST).getClass();

    public static List d(int i6, long j6, Object obj) {
        List list = (List) o0.f4378d.i(j6, obj);
        if (list.isEmpty()) {
            List c0178z = list instanceof A ? new C0178z(i6) : new ArrayList(i6);
            o0.o(j6, obj, c0178z);
            return c0178z;
        }
        if (f4272c.isAssignableFrom(list.getClass())) {
            ArrayList arrayList = new ArrayList(list.size() + i6);
            arrayList.addAll(list);
            o0.o(j6, obj, arrayList);
            return arrayList;
        }
        if (!(list instanceof j0)) {
            return list;
        }
        C0178z c0178z2 = new C0178z(list.size() + i6);
        c0178z2.addAll((j0) list);
        o0.o(j6, obj, c0178z2);
        return c0178z2;
    }

    @Override // androidx.datastore.preferences.protobuf.D
    public final void a(long j6, Object obj) {
        Object objUnmodifiableList;
        List list = (List) o0.f4378d.i(j6, obj);
        if (list instanceof A) {
            objUnmodifiableList = ((A) list).d();
        } else if (f4272c.isAssignableFrom(list.getClass())) {
            return;
        } else {
            objUnmodifiableList = Collections.unmodifiableList(list);
        }
        o0.o(j6, obj, objUnmodifiableList);
    }

    @Override // androidx.datastore.preferences.protobuf.D
    public final void b(long j6, Object obj, Object obj2) {
        List list = (List) o0.f4378d.i(j6, obj2);
        List listD = d(list.size(), j6, obj);
        int size = listD.size();
        int size2 = list.size();
        if (size > 0 && size2 > 0) {
            listD.addAll(list);
        }
        if (size > 0) {
            list = listD;
        }
        o0.o(j6, obj, list);
    }

    @Override // androidx.datastore.preferences.protobuf.D
    public final List c(long j6, Object obj) {
        return d(10, j6, obj);
    }
}
