package androidx.datastore.preferences.protobuf;

import java.io.Serializable;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.y, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public enum EnumC0177y {
    VOID(Void.class, null),
    INT(Integer.class, 0),
    LONG(Long.class, 0L),
    FLOAT(Float.class, Float.valueOf(0.0f)),
    DOUBLE(Double.class, Double.valueOf(0.0d)),
    BOOLEAN(Boolean.class, Boolean.FALSE),
    STRING(String.class, StringUtils.EMPTY),
    BYTE_STRING(C0159f.class, C0159f.t),
    ENUM(Integer.class, null),
    MESSAGE(Object.class, null);

    public final Object r;

    EnumC0177y(Class cls, Serializable serializable) {
        this.r = serializable;
    }
}
