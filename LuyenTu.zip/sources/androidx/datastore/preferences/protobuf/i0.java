package androidx.datastore.preferences.protobuf;

import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public final class i0 implements Iterator {
    public Iterator r;

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.r.hasNext();
    }

    @Override // java.util.Iterator
    public final Object next() {
        return (String) this.r.next();
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException();
    }
}
