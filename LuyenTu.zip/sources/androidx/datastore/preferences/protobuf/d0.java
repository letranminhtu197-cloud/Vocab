package androidx.datastore.preferences.protobuf;

import java.util.Iterator;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class d0 implements Iterator {
    public int r = -1;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f4331s;
    public Iterator t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ Z f4332u;

    public d0(Z z6) {
        this.f4332u = z6;
    }

    public final Iterator a() {
        if (this.t == null) {
            this.t = this.f4332u.t.entrySet().iterator();
        }
        return this.t;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        int i6 = this.r + 1;
        Z z6 = this.f4332u;
        return i6 < z6.f4322s.size() || (!z6.t.isEmpty() && a().hasNext());
    }

    @Override // java.util.Iterator
    public final Object next() {
        this.f4331s = true;
        int i6 = this.r + 1;
        this.r = i6;
        Z z6 = this.f4332u;
        return i6 < z6.f4322s.size() ? (Map.Entry) z6.f4322s.get(this.r) : (Map.Entry) a().next();
    }

    @Override // java.util.Iterator
    public final void remove() {
        if (!this.f4331s) {
            throw new IllegalStateException("remove() was called before next()");
        }
        this.f4331s = false;
        int i6 = Z.f4321x;
        Z z6 = this.f4332u;
        z6.c();
        if (this.r >= z6.f4322s.size()) {
            a().remove();
            return;
        }
        int i7 = this.r;
        this.r = i7 - 1;
        z6.h(i7);
    }
}
