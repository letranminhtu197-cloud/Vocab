package androidx.datastore.preferences.protobuf;

import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public abstract class D {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final B f4273a = new B();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final C f4274b = new C();

    public abstract void a(long j6, Object obj);

    public abstract void b(long j6, Object obj, Object obj2);

    public abstract List c(long j6, Object obj);
}
