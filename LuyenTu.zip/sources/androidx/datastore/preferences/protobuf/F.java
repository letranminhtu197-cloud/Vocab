package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.nio.charset.Charset;

/* JADX INFO: loaded from: classes.dex */
public final class F {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final C0170q f4276b = new C0170q(1);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f4277a;

    public F(C0163j c0163j) {
        AbstractC0174v.a(c0163j, "output");
        this.f4277a = c0163j;
        c0163j.f4360c = this;
    }

    public void a(int i6, C0159f c0159f) {
        ((C0163j) this.f4277a).G(i6, c0159f);
    }

    public void b(int i6, Object obj, X x5) throws IOException {
        C0163j c0163j = (C0163j) this.f4277a;
        c0163j.R(i6, 3);
        x5.c((AbstractC0154a) obj, c0163j.f4360c);
        c0163j.R(i6, 4);
    }

    public F() {
        L l6;
        try {
            l6 = (L) Class.forName("androidx.datastore.preferences.protobuf.DescriptorMessageInfoFactory").getDeclaredMethod("getInstance", null).invoke(null, null);
        } catch (Exception unused) {
            l6 = f4276b;
        }
        L[] lArr = {C0170q.f4387b, l6};
        E e6 = new E();
        e6.f4275a = lArr;
        Charset charset = AbstractC0174v.f4391a;
        this.f4277a = e6;
    }
}
