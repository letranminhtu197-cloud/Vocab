package androidx.datastore.preferences.protobuf;

import java.util.AbstractList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;

/* JADX INFO: loaded from: classes.dex */
public final class j0 extends AbstractList implements A, RandomAccess {
    public final C0178z r;

    public j0(C0178z c0178z) {
        this.r = c0178z;
    }

    @Override // androidx.datastore.preferences.protobuf.A
    public final A d() {
        return this;
    }

    @Override // androidx.datastore.preferences.protobuf.A
    public final Object e(int i6) {
        return this.r.f4413s.get(i6);
    }

    @Override // androidx.datastore.preferences.protobuf.A
    public final List f() {
        return Collections.unmodifiableList(this.r.f4413s);
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object get(int i6) {
        return (String) this.r.get(i6);
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.List
    public final Iterator iterator() {
        i0 i0Var = new i0();
        i0Var.r = this.r.iterator();
        return i0Var;
    }

    @Override // java.util.AbstractList, java.util.List
    public final ListIterator listIterator(int i6) {
        h0 h0Var = new h0();
        h0Var.r = this.r.listIterator(i6);
        return h0Var;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.r.size();
    }

    @Override // androidx.datastore.preferences.protobuf.A
    public final void t(C0159f c0159f) {
        throw new UnsupportedOperationException();
    }
}
