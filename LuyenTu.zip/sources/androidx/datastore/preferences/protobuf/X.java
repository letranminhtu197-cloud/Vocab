package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public interface X {
    void a(Object obj);

    boolean b(Object obj);

    void c(Object obj, F f4);

    int d(AbstractC0172t abstractC0172t);

    int e(AbstractC0154a abstractC0154a);

    boolean f(AbstractC0172t abstractC0172t, AbstractC0172t abstractC0172t2);

    void g(Object obj, C0161h c0161h, C0165l c0165l);

    void h(AbstractC0172t abstractC0172t, AbstractC0172t abstractC0172t2);

    Object newInstance();
}
