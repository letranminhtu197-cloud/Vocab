package androidx.datastore.preferences.protobuf;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0154a {
    protected int memoizedHashCode;

    public abstract int a();

    public final int b(X x5) {
        AbstractC0172t abstractC0172t = (AbstractC0172t) this;
        int i6 = abstractC0172t.memoizedSerializedSize;
        if (i6 != -1) {
            return i6;
        }
        int iE = x5.e(this);
        abstractC0172t.memoizedSerializedSize = iE;
        return iE;
    }

    public abstract void c(C0163j c0163j);
}
