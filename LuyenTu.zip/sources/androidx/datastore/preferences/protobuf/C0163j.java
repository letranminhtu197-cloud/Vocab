package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0163j extends M {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final Logger f4358h = Logger.getLogger(C0163j.class.getName());

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final boolean f4359i = o0.f4380f;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public F f4360c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final byte[] f4361d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f4362e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f4363f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Z.o f4364g;

    public C0163j(Z.o oVar, int i6) {
        if (i6 < 0) {
            throw new IllegalArgumentException("bufferSize must be >= 0");
        }
        int iMax = Math.max(i6, 20);
        this.f4361d = new byte[iMax];
        this.f4362e = iMax;
        this.f4364g = oVar;
    }

    public static int A(long j6) {
        int i6;
        if (((-128) & j6) == 0) {
            return 1;
        }
        if (j6 < 0) {
            return 10;
        }
        if (((-34359738368L) & j6) != 0) {
            j6 >>>= 28;
            i6 = 6;
        } else {
            i6 = 2;
        }
        if (((-2097152) & j6) != 0) {
            i6 += 2;
            j6 >>>= 14;
        }
        return (j6 & (-16384)) != 0 ? i6 + 1 : i6;
    }

    public static int r(int i6, C0159f c0159f) {
        return s(c0159f) + y(i6);
    }

    public static int s(C0159f c0159f) {
        int size = c0159f.size();
        return z(size) + size;
    }

    public static int t(int i6) {
        return y(i6) + 4;
    }

    public static int u(int i6) {
        return y(i6) + 8;
    }

    public static int v(int i6, AbstractC0154a abstractC0154a, X x5) {
        return abstractC0154a.b(x5) + (y(i6) * 2);
    }

    public static int w(int i6) {
        if (i6 >= 0) {
            return z(i6);
        }
        return 10;
    }

    public static int x(String str) {
        int length;
        try {
            length = r0.b(str);
        } catch (q0 unused) {
            length = str.getBytes(AbstractC0174v.f4391a).length;
        }
        return z(length) + length;
    }

    public static int y(int i6) {
        return z(i6 << 3);
    }

    public static int z(int i6) {
        if ((i6 & (-128)) == 0) {
            return 1;
        }
        if ((i6 & (-16384)) == 0) {
            return 2;
        }
        if (((-2097152) & i6) == 0) {
            return 3;
        }
        return (i6 & (-268435456)) == 0 ? 4 : 5;
    }

    public final void B() throws IOException {
        this.f4364g.write(this.f4361d, 0, this.f4363f);
        this.f4363f = 0;
    }

    public final void C(int i6) throws IOException {
        if (this.f4362e - this.f4363f < i6) {
            B();
        }
    }

    public final void D(byte b6) throws IOException {
        if (this.f4363f == this.f4362e) {
            B();
        }
        int i6 = this.f4363f;
        this.f4363f = i6 + 1;
        this.f4361d[i6] = b6;
    }

    public final void E(byte[] bArr, int i6, int i7) throws IOException {
        int i8 = this.f4363f;
        int i9 = this.f4362e;
        int i10 = i9 - i8;
        byte[] bArr2 = this.f4361d;
        if (i10 >= i7) {
            System.arraycopy(bArr, i6, bArr2, i8, i7);
            this.f4363f += i7;
            return;
        }
        System.arraycopy(bArr, i6, bArr2, i8, i10);
        int i11 = i6 + i10;
        int i12 = i7 - i10;
        this.f4363f = i9;
        B();
        if (i12 > i9) {
            this.f4364g.write(bArr, i11, i12);
        } else {
            System.arraycopy(bArr, i11, bArr2, 0, i12);
            this.f4363f = i12;
        }
    }

    public final void F(int i6, boolean z6) throws IOException {
        C(11);
        o(i6, 0);
        byte b6 = z6 ? (byte) 1 : (byte) 0;
        int i7 = this.f4363f;
        this.f4363f = i7 + 1;
        this.f4361d[i7] = b6;
    }

    public final void G(int i6, C0159f c0159f) throws IOException {
        R(i6, 2);
        H(c0159f);
    }

    public final void H(C0159f c0159f) throws IOException {
        T(c0159f.size());
        l(c0159f.f4336s, c0159f.c(), c0159f.size());
    }

    public final void I(int i6, int i7) throws IOException {
        C(14);
        o(i6, 5);
        m(i7);
    }

    public final void J(int i6) throws IOException {
        C(4);
        m(i6);
    }

    public final void K(long j6, int i6) throws IOException {
        C(18);
        o(i6, 1);
        n(j6);
    }

    public final void L(long j6) throws IOException {
        C(8);
        n(j6);
    }

    public final void M(int i6, int i7) throws IOException {
        C(20);
        o(i6, 0);
        if (i7 >= 0) {
            p(i7);
        } else {
            q(i7);
        }
    }

    public final void N(int i6) throws IOException {
        if (i6 >= 0) {
            T(i6);
        } else {
            V(i6);
        }
    }

    public final void O(int i6, AbstractC0154a abstractC0154a, X x5) throws IOException {
        R(i6, 2);
        T(abstractC0154a.b(x5));
        x5.c(abstractC0154a, this.f4360c);
    }

    public final void P(String str, int i6) throws IOException {
        R(i6, 2);
        Q(str);
    }

    public final void Q(String str) throws IOException {
        try {
            int length = str.length() * 3;
            int iZ = z(length);
            int i6 = iZ + length;
            int i7 = this.f4362e;
            if (i6 > i7) {
                byte[] bArr = new byte[length];
                int iF = r0.f4390a.f(str, bArr, 0, length);
                T(iF);
                E(bArr, 0, iF);
                return;
            }
            if (i6 > i7 - this.f4363f) {
                B();
            }
            int iZ2 = z(str.length());
            int i8 = this.f4363f;
            byte[] bArr2 = this.f4361d;
            try {
                if (iZ2 == iZ) {
                    int i9 = i8 + iZ2;
                    this.f4363f = i9;
                    int iF2 = r0.f4390a.f(str, bArr2, i9, i7 - i9);
                    this.f4363f = i8;
                    p((iF2 - i8) - iZ2);
                    this.f4363f = iF2;
                } else {
                    int iB = r0.b(str);
                    p(iB);
                    this.f4363f = r0.f4390a.f(str, bArr2, this.f4363f, iB);
                }
            } catch (q0 e6) {
                this.f4363f = i8;
                throw e6;
            } catch (ArrayIndexOutOfBoundsException e7) {
                throw new C0162i(e7);
            }
        } catch (q0 e8) {
            f4358h.log(Level.WARNING, "Converting ill-formed UTF-16. Your Protocol Buffer will not round trip correctly!", (Throwable) e8);
            byte[] bytes = str.getBytes(AbstractC0174v.f4391a);
            try {
                T(bytes.length);
                l(bytes, 0, bytes.length);
            } catch (C0162i e9) {
                throw e9;
            } catch (IndexOutOfBoundsException e10) {
                throw new C0162i(e10);
            }
        }
    }

    public final void R(int i6, int i7) throws IOException {
        T((i6 << 3) | i7);
    }

    public final void S(int i6, int i7) throws IOException {
        C(20);
        o(i6, 0);
        p(i7);
    }

    public final void T(int i6) throws IOException {
        C(5);
        p(i6);
    }

    public final void U(long j6, int i6) throws IOException {
        C(20);
        o(i6, 0);
        q(j6);
    }

    public final void V(long j6) throws IOException {
        C(10);
        q(j6);
    }

    @Override // androidx.datastore.preferences.protobuf.M
    public final void l(byte[] bArr, int i6, int i7) throws IOException {
        E(bArr, i6, i7);
    }

    public final void m(int i6) {
        int i7 = this.f4363f;
        int i8 = i7 + 1;
        this.f4363f = i8;
        byte[] bArr = this.f4361d;
        bArr[i7] = (byte) (i6 & 255);
        int i9 = i7 + 2;
        this.f4363f = i9;
        bArr[i8] = (byte) ((i6 >> 8) & 255);
        int i10 = i7 + 3;
        this.f4363f = i10;
        bArr[i9] = (byte) ((i6 >> 16) & 255);
        this.f4363f = i7 + 4;
        bArr[i10] = (byte) ((i6 >> 24) & 255);
    }

    public final void n(long j6) {
        int i6 = this.f4363f;
        int i7 = i6 + 1;
        this.f4363f = i7;
        byte[] bArr = this.f4361d;
        bArr[i6] = (byte) (j6 & 255);
        int i8 = i6 + 2;
        this.f4363f = i8;
        bArr[i7] = (byte) ((j6 >> 8) & 255);
        int i9 = i6 + 3;
        this.f4363f = i9;
        bArr[i8] = (byte) ((j6 >> 16) & 255);
        int i10 = i6 + 4;
        this.f4363f = i10;
        bArr[i9] = (byte) (255 & (j6 >> 24));
        int i11 = i6 + 5;
        this.f4363f = i11;
        bArr[i10] = (byte) (((int) (j6 >> 32)) & 255);
        int i12 = i6 + 6;
        this.f4363f = i12;
        bArr[i11] = (byte) (((int) (j6 >> 40)) & 255);
        int i13 = i6 + 7;
        this.f4363f = i13;
        bArr[i12] = (byte) (((int) (j6 >> 48)) & 255);
        this.f4363f = i6 + 8;
        bArr[i13] = (byte) (((int) (j6 >> 56)) & 255);
    }

    public final void o(int i6, int i7) {
        p((i6 << 3) | i7);
    }

    public final void p(int i6) {
        boolean z6 = f4359i;
        byte[] bArr = this.f4361d;
        if (z6) {
            while ((i6 & (-128)) != 0) {
                int i7 = this.f4363f;
                this.f4363f = i7 + 1;
                o0.j(bArr, i7, (byte) ((i6 & 127) | 128));
                i6 >>>= 7;
            }
            int i8 = this.f4363f;
            this.f4363f = i8 + 1;
            o0.j(bArr, i8, (byte) i6);
            return;
        }
        while ((i6 & (-128)) != 0) {
            int i9 = this.f4363f;
            this.f4363f = i9 + 1;
            bArr[i9] = (byte) ((i6 & 127) | 128);
            i6 >>>= 7;
        }
        int i10 = this.f4363f;
        this.f4363f = i10 + 1;
        bArr[i10] = (byte) i6;
    }

    public final void q(long j6) {
        boolean z6 = f4359i;
        byte[] bArr = this.f4361d;
        if (z6) {
            while ((j6 & (-128)) != 0) {
                int i6 = this.f4363f;
                this.f4363f = i6 + 1;
                o0.j(bArr, i6, (byte) ((((int) j6) & 127) | 128));
                j6 >>>= 7;
            }
            int i7 = this.f4363f;
            this.f4363f = i7 + 1;
            o0.j(bArr, i7, (byte) j6);
            return;
        }
        while ((j6 & (-128)) != 0) {
            int i8 = this.f4363f;
            this.f4363f = i8 + 1;
            bArr[i8] = (byte) ((((int) j6) & 127) | 128);
            j6 >>>= 7;
        }
        int i9 = this.f4363f;
        this.f4363f = i9 + 1;
        bArr[i9] = (byte) j6;
    }
}
