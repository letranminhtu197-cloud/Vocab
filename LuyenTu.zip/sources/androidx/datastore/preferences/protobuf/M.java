package androidx.datastore.preferences.protobuf;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.parser.external.ExternalParsersConfigReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: loaded from: classes.dex */
public abstract class M {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a0 f4286a = new a0();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final b0 f4287b = new b0();

    public static void a(byte b6, byte b7, byte b8, byte b9, char[] cArr, int i6) throws C0176x {
        if (!h(b7)) {
            if ((((b7 + 112) + (b6 << 28)) >> 30) == 0 && !h(b8) && !h(b9)) {
                int i7 = ((b6 & 7) << 18) | ((b7 & 63) << 12) | ((b8 & 63) << 6) | (b9 & 63);
                cArr[i6] = (char) ((i7 >>> 10) + 55232);
                cArr[i6 + 1] = (char) ((i7 & 1023) + 56320);
                return;
            }
        }
        throw C0176x.a();
    }

    public static void b(byte b6, byte b7, char[] cArr, int i6) throws C0176x {
        if (b6 < -62 || h(b7)) {
            throw C0176x.a();
        }
        cArr[i6] = (char) (((b6 & 31) << 6) | (b7 & 63));
    }

    public static void c(byte b6, byte b7, byte b8, char[] cArr, int i6) throws C0176x {
        if (h(b7) || ((b6 == -32 && b7 < -96) || ((b6 == -19 && b7 >= -96) || h(b8)))) {
            throw C0176x.a();
        }
        cArr[i6] = (char) (((b6 & 15) << 12) | ((b7 & 63) << 6) | (b8 & 63));
    }

    public static final String d(String str) {
        StringBuilder sb = new StringBuilder();
        for (int i6 = 0; i6 < str.length(); i6++) {
            char cCharAt = str.charAt(i6);
            if (Character.isUpperCase(cCharAt)) {
                sb.append("_");
            }
            sb.append(Character.toLowerCase(cCharAt));
        }
        return sb.toString();
    }

    public static String g(C0159f c0159f) {
        StringBuilder sb = new StringBuilder(c0159f.size());
        for (int i6 = 0; i6 < c0159f.size(); i6++) {
            byte b6 = c0159f.f4336s[i6];
            if (b6 == 34) {
                sb.append("\\\"");
            } else if (b6 == 39) {
                sb.append("\\'");
            } else if (b6 != 92) {
                switch (b6) {
                    case 7:
                        sb.append("\\a");
                        break;
                    case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                        sb.append("\\b");
                        break;
                    case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                        sb.append("\\t");
                        break;
                    case 10:
                        sb.append("\\n");
                        break;
                    case 11:
                        sb.append("\\v");
                        break;
                    case 12:
                        sb.append("\\f");
                        break;
                    case 13:
                        sb.append("\\r");
                        break;
                    default:
                        if (b6 < 32 || b6 > 126) {
                            sb.append('\\');
                            sb.append((char) (((b6 >>> 6) & 3) + 48));
                            sb.append((char) (((b6 >>> 3) & 7) + 48));
                            sb.append((char) ((b6 & 7) + 48));
                        } else {
                            sb.append((char) b6);
                        }
                        break;
                }
            } else {
                sb.append("\\\\");
            }
        }
        return sb.toString();
    }

    public static boolean h(byte b6) {
        return b6 > -65;
    }

    public static final void j(StringBuilder sb, int i6, String str, Object obj) {
        if (obj instanceof List) {
            Iterator it = ((List) obj).iterator();
            while (it.hasNext()) {
                j(sb, i6, str, it.next());
            }
            return;
        }
        if (obj instanceof Map) {
            Iterator it2 = ((Map) obj).entrySet().iterator();
            while (it2.hasNext()) {
                j(sb, i6, str, (Map.Entry) it2.next());
            }
            return;
        }
        sb.append('\n');
        int i7 = 0;
        for (int i8 = 0; i8 < i6; i8++) {
            sb.append(' ');
        }
        sb.append(str);
        if (obj instanceof String) {
            sb.append(": \"");
            C0159f c0159f = C0159f.t;
            sb.append(g(new C0159f(((String) obj).getBytes(AbstractC0174v.f4391a))));
            sb.append('\"');
            return;
        }
        if (obj instanceof C0159f) {
            sb.append(": \"");
            sb.append(g((C0159f) obj));
            sb.append('\"');
            return;
        }
        if (obj instanceof AbstractC0172t) {
            sb.append(" {");
            k((AbstractC0172t) obj, sb, i6 + 2);
            sb.append("\n");
            while (i7 < i6) {
                sb.append(' ');
                i7++;
            }
            sb.append("}");
            return;
        }
        if (!(obj instanceof Map.Entry)) {
            sb.append(": ");
            sb.append(obj.toString());
            return;
        }
        sb.append(" {");
        Map.Entry entry = (Map.Entry) obj;
        int i9 = i6 + 2;
        j(sb, i9, ExternalParsersConfigReaderMetKeys.METADATA_KEY_ATTR, entry.getKey());
        j(sb, i9, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, entry.getValue());
        sb.append("\n");
        while (i7 < i6) {
            sb.append(' ');
            i7++;
        }
        sb.append("}");
    }

    /* JADX WARN: Code duplicated, block: B:57:0x01af  */
    /* JADX WARN: Code duplicated, block: B:58:0x01b1  */
    public static void k(AbstractC0172t abstractC0172t, StringBuilder sb, int i6) {
        boolean zEquals;
        HashMap map = new HashMap();
        HashMap map2 = new HashMap();
        TreeSet<String> treeSet = new TreeSet();
        for (Method method : abstractC0172t.getClass().getDeclaredMethods()) {
            map2.put(method.getName(), method);
            if (method.getParameterTypes().length == 0) {
                map.put(method.getName(), method);
                if (method.getName().startsWith("get")) {
                    treeSet.add(method.getName());
                }
            }
        }
        for (String str : treeSet) {
            String strReplaceFirst = str.replaceFirst("get", StringUtils.EMPTY);
            boolean zBooleanValue = true;
            if (strReplaceFirst.endsWith("List") && !strReplaceFirst.endsWith("OrBuilderList") && !strReplaceFirst.equals("List")) {
                String str2 = strReplaceFirst.substring(0, 1).toLowerCase() + strReplaceFirst.substring(1, strReplaceFirst.length() - 4);
                Method method2 = (Method) map.get(str);
                if (method2 != null && method2.getReturnType().equals(List.class)) {
                    j(sb, i6, d(str2), AbstractC0172t.f(method2, abstractC0172t, new Object[0]));
                }
            }
            if (strReplaceFirst.endsWith("Map") && !strReplaceFirst.equals("Map")) {
                String str3 = strReplaceFirst.substring(0, 1).toLowerCase() + strReplaceFirst.substring(1, strReplaceFirst.length() - 3);
                Method method3 = (Method) map.get(str);
                if (method3 != null && method3.getReturnType().equals(Map.class) && !method3.isAnnotationPresent(Deprecated.class) && Modifier.isPublic(method3.getModifiers())) {
                    j(sb, i6, d(str3), AbstractC0172t.f(method3, abstractC0172t, new Object[0]));
                }
            }
            if (((Method) map2.get("set".concat(strReplaceFirst))) != null) {
                if (strReplaceFirst.endsWith("Bytes")) {
                    if (map.containsKey("get" + strReplaceFirst.substring(0, strReplaceFirst.length() - 5))) {
                    }
                }
                String str4 = strReplaceFirst.substring(0, 1).toLowerCase() + strReplaceFirst.substring(1);
                Method method4 = (Method) map.get("get".concat(strReplaceFirst));
                Method method5 = (Method) map.get("has".concat(strReplaceFirst));
                if (method4 != null) {
                    Object objF = AbstractC0172t.f(method4, abstractC0172t, new Object[0]);
                    if (method5 == null) {
                        if (objF instanceof Boolean) {
                            zEquals = !((Boolean) objF).booleanValue();
                        } else if (objF instanceof Integer) {
                            if (((Integer) objF).intValue() == 0) {
                                zEquals = true;
                            } else {
                                zEquals = false;
                            }
                        } else if (objF instanceof Float) {
                            if (((Float) objF).floatValue() == 0.0f) {
                                zEquals = true;
                            } else {
                                zEquals = false;
                            }
                        } else if (objF instanceof Double) {
                            if (((Double) objF).doubleValue() == 0.0d) {
                                zEquals = true;
                            } else {
                                zEquals = false;
                            }
                        } else if (objF instanceof String) {
                            zEquals = objF.equals(StringUtils.EMPTY);
                        } else if (objF instanceof C0159f) {
                            zEquals = objF.equals(C0159f.t);
                        } else if (!(objF instanceof AbstractC0154a) ? !((objF instanceof Enum) && ((Enum) objF).ordinal() == 0) : objF != ((AbstractC0172t) ((AbstractC0172t) ((AbstractC0154a) objF)).d(6))) {
                            zEquals = false;
                        } else {
                            zEquals = true;
                        }
                        if (zEquals) {
                            zBooleanValue = false;
                        }
                    } else {
                        zBooleanValue = ((Boolean) AbstractC0172t.f(method5, abstractC0172t, new Object[0])).booleanValue();
                    }
                    if (zBooleanValue) {
                        j(sb, i6, d(str4), objF);
                    }
                }
            }
        }
        f0 f0Var = abstractC0172t.unknownFields;
        if (f0Var != null) {
            for (int i7 = 0; i7 < f0Var.f4338a; i7++) {
                j(sb, i6, String.valueOf(f0Var.f4339b[i7] >>> 3), f0Var.f4340c[i7]);
            }
        }
    }

    public abstract String e(byte[] bArr, int i6, int i7);

    public abstract int f(String str, byte[] bArr, int i6, int i7);

    public abstract int i(byte[] bArr, int i6, int i7);

    public abstract void l(byte[] bArr, int i6, int i7);
}
