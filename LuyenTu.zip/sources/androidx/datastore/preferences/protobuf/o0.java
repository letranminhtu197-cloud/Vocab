package androidx.datastore.preferences.protobuf;

import java.lang.reflect.Field;
import java.nio.Buffer;
import java.nio.ByteOrder;
import java.security.AccessController;
import java.util.logging.Level;
import java.util.logging.Logger;
import sun.misc.Unsafe;

/* JADX INFO: loaded from: classes.dex */
public abstract class o0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Logger f4375a = Logger.getLogger(o0.class.getName());

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Unsafe f4376b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Class f4377c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final n0 f4378d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final boolean f4379e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final boolean f4380f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final long f4381g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final boolean f4382h;

    static {
        boolean z6;
        boolean z7;
        n0 n0Var;
        Unsafe unsafeI = i();
        f4376b = unsafeI;
        f4377c = AbstractC0156c.f4326a;
        Class cls = Long.TYPE;
        boolean zE = e(cls);
        Class cls2 = Integer.TYPE;
        boolean zE2 = e(cls2);
        n0 m0Var = null;
        if (unsafeI != null) {
            if (!AbstractC0156c.a()) {
                m0Var = new m0(unsafeI);
            } else if (zE) {
                m0Var = new l0(unsafeI, 1);
            } else if (zE2) {
                m0Var = new l0(unsafeI, 0);
            }
        }
        f4378d = m0Var;
        Class cls3 = Byte.TYPE;
        Class<Field> cls4 = Field.class;
        if (unsafeI == null) {
            z6 = false;
        } else {
            try {
                Class<?> cls5 = unsafeI.getClass();
                cls5.getMethod("objectFieldOffset", cls4);
                cls5.getMethod("getLong", Object.class, cls);
                if (d() == null) {
                    z6 = false;
                } else {
                    if (!AbstractC0156c.a()) {
                        cls5.getMethod("getByte", cls);
                        cls5.getMethod("putByte", cls, cls3);
                        cls5.getMethod("getInt", cls);
                        cls5.getMethod("putInt", cls, cls2);
                        cls5.getMethod("getLong", cls);
                        cls5.getMethod("putLong", cls, cls);
                        cls5.getMethod("copyMemory", cls, cls, cls);
                        cls5.getMethod("copyMemory", Object.class, cls, Object.class, cls, cls);
                    }
                    cls4 = cls4;
                    z6 = true;
                }
            } catch (Throwable th) {
                f4375a.log(Level.WARNING, "platform method missing - proto runtime falling back to safer methods: " + th);
            }
        }
        f4379e = z6;
        Unsafe unsafe = f4376b;
        if (unsafe == null) {
            z7 = false;
        } else {
            try {
                Class<?> cls6 = unsafe.getClass();
                cls6.getMethod("objectFieldOffset", cls4);
                cls6.getMethod("arrayBaseOffset", Class.class);
                cls6.getMethod("arrayIndexScale", Class.class);
                cls6.getMethod("getInt", Object.class, cls);
                cls6.getMethod("putInt", Object.class, cls, cls2);
                cls6.getMethod("getLong", Object.class, cls);
                cls6.getMethod("putLong", Object.class, cls, cls);
                cls6.getMethod("getObject", Object.class, cls);
                cls6.getMethod("putObject", Object.class, cls, Object.class);
                if (!AbstractC0156c.a()) {
                    cls6.getMethod("getByte", Object.class, cls);
                    cls6.getMethod("putByte", Object.class, cls, cls3);
                    cls6.getMethod("getBoolean", Object.class, cls);
                    cls6.getMethod("putBoolean", Object.class, cls, Boolean.TYPE);
                    cls6.getMethod("getFloat", Object.class, cls);
                    cls6.getMethod("putFloat", Object.class, cls, Float.TYPE);
                    cls6.getMethod("getDouble", Object.class, cls);
                    cls6.getMethod("putDouble", Object.class, cls, Double.TYPE);
                }
                z7 = true;
            } catch (Throwable th2) {
                f4375a.log(Level.WARNING, "platform method missing - proto runtime falling back to safer methods: " + th2);
                z7 = false;
            }
        }
        f4380f = z7;
        f4381g = b(byte[].class);
        b(boolean[].class);
        c(boolean[].class);
        b(int[].class);
        c(int[].class);
        b(long[].class);
        c(long[].class);
        b(float[].class);
        c(float[].class);
        b(double[].class);
        c(double[].class);
        b(Object[].class);
        c(Object[].class);
        Field fieldD = d();
        if (fieldD != null && (n0Var = f4378d) != null) {
            n0Var.j(fieldD);
        }
        f4382h = ByteOrder.nativeOrder() == ByteOrder.BIG_ENDIAN;
    }

    public static Object a(Class cls) {
        try {
            return f4376b.allocateInstance(cls);
        } catch (InstantiationException e6) {
            throw new IllegalStateException(e6);
        }
    }

    public static int b(Class cls) {
        if (f4380f) {
            return f4378d.a(cls);
        }
        return -1;
    }

    public static void c(Class cls) {
        if (f4380f) {
            f4378d.b(cls);
        }
    }

    public static Field d() {
        Field declaredField;
        Field declaredField2;
        if (AbstractC0156c.a()) {
            try {
                declaredField2 = Buffer.class.getDeclaredField("effectiveDirectAddress");
            } catch (Throwable unused) {
                declaredField2 = null;
            }
            if (declaredField2 != null) {
                return declaredField2;
            }
        }
        try {
            declaredField = Buffer.class.getDeclaredField("address");
        } catch (Throwable unused2) {
            declaredField = null;
        }
        if (declaredField == null || declaredField.getType() != Long.TYPE) {
            return null;
        }
        return declaredField;
    }

    public static boolean e(Class cls) {
        if (!AbstractC0156c.a()) {
            return false;
        }
        try {
            Class cls2 = f4377c;
            Class cls3 = Boolean.TYPE;
            cls2.getMethod("peekLong", cls, cls3);
            cls2.getMethod("pokeLong", cls, Long.TYPE, cls3);
            Class cls4 = Integer.TYPE;
            cls2.getMethod("pokeInt", cls, cls4, cls3);
            cls2.getMethod("peekInt", cls, cls3);
            cls2.getMethod("pokeByte", cls, Byte.TYPE);
            cls2.getMethod("peekByte", cls);
            cls2.getMethod("pokeByteArray", cls, byte[].class, cls4, cls4);
            cls2.getMethod("peekByteArray", cls, byte[].class, cls4, cls4);
            return true;
        } catch (Throwable unused) {
            return false;
        }
    }

    public static byte f(long j6, byte[] bArr) {
        return f4378d.d(f4381g + j6, bArr);
    }

    public static byte g(long j6, Object obj) {
        return (byte) ((f4378d.g((-4) & j6, obj) >>> ((int) (((~j6) & 3) << 3))) & 255);
    }

    public static byte h(long j6, Object obj) {
        return (byte) ((f4378d.g((-4) & j6, obj) >>> ((int) ((j6 & 3) << 3))) & 255);
    }

    public static Unsafe i() {
        try {
            return (Unsafe) AccessController.doPrivileged(new k0());
        } catch (Throwable unused) {
            return null;
        }
    }

    public static void j(byte[] bArr, long j6, byte b6) {
        f4378d.l(bArr, f4381g + j6, b6);
    }

    public static void k(Object obj, long j6, byte b6) {
        long j7 = (-4) & j6;
        int iG = f4378d.g(j7, obj);
        int i6 = ((~((int) j6)) & 3) << 3;
        m(((255 & b6) << i6) | (iG & (~(255 << i6))), j7, obj);
    }

    public static void l(Object obj, long j6, byte b6) {
        long j7 = (-4) & j6;
        int i6 = (((int) j6) & 3) << 3;
        m(((255 & b6) << i6) | (f4378d.g(j7, obj) & (~(255 << i6))), j7, obj);
    }

    public static void m(int i6, long j6, Object obj) {
        f4378d.o(i6, j6, obj);
    }

    public static void n(Object obj, long j6, long j7) {
        f4378d.p(obj, j6, j7);
    }

    public static void o(long j6, Object obj, Object obj2) {
        f4378d.q(j6, obj, obj2);
    }
}
