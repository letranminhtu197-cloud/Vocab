package androidx.datastore.preferences.protobuf;

import com.google.crypto.tink.shaded.protobuf.AbstractC0266d;
import com.google.crypto.tink.shaded.protobuf.AbstractC0270h;
import com.google.crypto.tink.shaded.protobuf.AbstractC0273k;
import com.google.crypto.tink.shaded.protobuf.AbstractC0275m;
import com.google.crypto.tink.shaded.protobuf.AbstractC0280s;
import com.google.crypto.tink.shaded.protobuf.AbstractC0285x;
import com.google.crypto.tink.shaded.protobuf.C0277o;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.pipes.PipesServer;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0161h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f4353a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f4354b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f4355c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f4356d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f4357e;

    public /* synthetic */ C0161h(int i6) {
        this.f4353a = i6;
    }

    public static void a0(int i6) throws com.google.crypto.tink.shaded.protobuf.C {
        if ((i6 & 3) != 0) {
            throw com.google.crypto.tink.shaded.protobuf.C.f();
        }
    }

    public static void b0(int i6) throws com.google.crypto.tink.shaded.protobuf.C {
        if ((i6 & 7) != 0) {
            throw com.google.crypto.tink.shaded.protobuf.C.f();
        }
    }

    public void A(List list) throws com.google.crypto.tink.shaded.protobuf.C, C0176x {
        int iZ;
        int iB;
        int iB2;
        switch (this.f4353a) {
            case 0:
                C0160g c0160g = (C0160g) this.f4357e;
                int i6 = this.f4354b & 7;
                if (i6 == 0) {
                    do {
                        list.add(Integer.valueOf(c0160g.l()));
                        if (c0160g.c()) {
                            return;
                        } else {
                            iZ = c0160g.z();
                        }
                    } while (iZ == this.f4354b);
                    this.f4356d = iZ;
                    return;
                }
                if (i6 != 2) {
                    throw C0176x.b();
                }
                int iB3 = c0160g.b() + c0160g.A();
                do {
                    list.add(Integer.valueOf(c0160g.l()));
                } while (c0160g.b() < iB3);
                W(iB3);
                return;
            default:
                AbstractC0273k abstractC0273k = (AbstractC0273k) this.f4357e;
                if (!(list instanceof AbstractC0285x)) {
                    int i7 = this.f4354b & 7;
                    if (i7 == 0) {
                        do {
                            list.add(Integer.valueOf(abstractC0273k.t()));
                            if (abstractC0273k.g()) {
                                return;
                            } else {
                                iB = abstractC0273k.B();
                            }
                        } while (iB == this.f4354b);
                        this.f4356d = iB;
                        return;
                    }
                    if (i7 != 2) {
                        throw com.google.crypto.tink.shaded.protobuf.C.c();
                    }
                    int iF = abstractC0273k.f() + abstractC0273k.C();
                    do {
                        list.add(Integer.valueOf(abstractC0273k.t()));
                    } while (abstractC0273k.f() < iF);
                    V(iF);
                    return;
                }
                AbstractC0285x abstractC0285x = (AbstractC0285x) list;
                int i8 = this.f4354b & 7;
                if (i8 == 0) {
                    do {
                        abstractC0285x.c(abstractC0273k.t());
                        if (abstractC0273k.g()) {
                            return;
                        } else {
                            iB2 = abstractC0273k.B();
                        }
                    } while (iB2 == this.f4354b);
                    this.f4356d = iB2;
                    return;
                }
                if (i8 != 2) {
                    throw com.google.crypto.tink.shaded.protobuf.C.c();
                }
                int iF2 = abstractC0273k.f() + abstractC0273k.C();
                do {
                    abstractC0285x.c(abstractC0273k.t());
                } while (abstractC0273k.f() < iF2);
                V(iF2);
                return;
        }
    }

    public long B() throws C0175w {
        Y(0);
        return ((C0160g) this.f4357e).m();
    }

    public void C(List list) throws com.google.crypto.tink.shaded.protobuf.C, C0176x {
        int iZ;
        int iB;
        int iB2;
        switch (this.f4353a) {
            case 0:
                C0160g c0160g = (C0160g) this.f4357e;
                int i6 = this.f4354b & 7;
                if (i6 == 0) {
                    do {
                        list.add(Long.valueOf(c0160g.m()));
                        if (c0160g.c()) {
                            return;
                        } else {
                            iZ = c0160g.z();
                        }
                    } while (iZ == this.f4354b);
                    this.f4356d = iZ;
                    return;
                }
                if (i6 != 2) {
                    throw C0176x.b();
                }
                int iB3 = c0160g.b() + c0160g.A();
                do {
                    list.add(Long.valueOf(c0160g.m()));
                } while (c0160g.b() < iB3);
                W(iB3);
                return;
            default:
                AbstractC0273k abstractC0273k = (AbstractC0273k) this.f4357e;
                if (!(list instanceof com.google.crypto.tink.shaded.protobuf.J)) {
                    int i7 = this.f4354b & 7;
                    if (i7 == 0) {
                        do {
                            list.add(Long.valueOf(abstractC0273k.u()));
                            if (abstractC0273k.g()) {
                                return;
                            } else {
                                iB = abstractC0273k.B();
                            }
                        } while (iB == this.f4354b);
                        this.f4356d = iB;
                        return;
                    }
                    if (i7 != 2) {
                        throw com.google.crypto.tink.shaded.protobuf.C.c();
                    }
                    int iF = abstractC0273k.f() + abstractC0273k.C();
                    do {
                        list.add(Long.valueOf(abstractC0273k.u()));
                    } while (abstractC0273k.f() < iF);
                    V(iF);
                    return;
                }
                com.google.crypto.tink.shaded.protobuf.J j6 = (com.google.crypto.tink.shaded.protobuf.J) list;
                int i8 = this.f4354b & 7;
                if (i8 == 0) {
                    do {
                        j6.c(abstractC0273k.u());
                        if (abstractC0273k.g()) {
                            return;
                        } else {
                            iB2 = abstractC0273k.B();
                        }
                    } while (iB2 == this.f4354b);
                    this.f4356d = iB2;
                    return;
                }
                if (i8 != 2) {
                    throw com.google.crypto.tink.shaded.protobuf.C.c();
                }
                int iF2 = abstractC0273k.f() + abstractC0273k.C();
                do {
                    j6.c(abstractC0273k.u());
                } while (abstractC0273k.f() < iF2);
                V(iF2);
                return;
        }
    }

    public Object D(X x5, C0165l c0165l) throws C0176x {
        C0160g c0160g = (C0160g) this.f4357e;
        int iA = c0160g.A();
        if (c0160g.f4343a >= 100) {
            throw new C0176x("Protocol message had too many levels of nesting.  May be malicious.  Use CodedInputStream.setRecursionLimit() to increase the depth limit.");
        }
        int iE = c0160g.e(iA);
        Object objNewInstance = x5.newInstance();
        c0160g.f4343a++;
        x5.g(objNewInstance, this, c0165l);
        x5.a(objNewInstance);
        c0160g.a(0);
        c0160g.f4343a--;
        c0160g.d(iE);
        return objNewInstance;
    }

    public Object E(X x5, C0165l c0165l) throws C0175w {
        Y(2);
        return D(x5, c0165l);
    }

    public int F() throws C0175w {
        Y(5);
        return ((C0160g) this.f4357e).v();
    }

    public void G(List list) throws com.google.crypto.tink.shaded.protobuf.C, C0176x {
        int iZ;
        int iB;
        int iB2;
        switch (this.f4353a) {
            case 0:
                C0160g c0160g = (C0160g) this.f4357e;
                int i6 = this.f4354b & 7;
                if (i6 == 2) {
                    int iA = c0160g.A();
                    if ((iA & 3) != 0) {
                        throw C0176x.e();
                    }
                    int iB3 = c0160g.b() + iA;
                    do {
                        list.add(Integer.valueOf(c0160g.v()));
                    } while (c0160g.b() < iB3);
                    return;
                }
                if (i6 != 5) {
                    throw C0176x.b();
                }
                do {
                    list.add(Integer.valueOf(c0160g.v()));
                    if (c0160g.c()) {
                        return;
                    } else {
                        iZ = c0160g.z();
                    }
                } while (iZ == this.f4354b);
                this.f4356d = iZ;
                return;
            default:
                AbstractC0273k abstractC0273k = (AbstractC0273k) this.f4357e;
                if (!(list instanceof AbstractC0285x)) {
                    int i7 = this.f4354b & 7;
                    if (i7 == 2) {
                        int iC = abstractC0273k.C();
                        a0(iC);
                        int iF = abstractC0273k.f() + iC;
                        do {
                            list.add(Integer.valueOf(abstractC0273k.v()));
                        } while (abstractC0273k.f() < iF);
                        return;
                    }
                    if (i7 != 5) {
                        throw com.google.crypto.tink.shaded.protobuf.C.c();
                    }
                    do {
                        list.add(Integer.valueOf(abstractC0273k.v()));
                        if (abstractC0273k.g()) {
                            return;
                        } else {
                            iB = abstractC0273k.B();
                        }
                    } while (iB == this.f4354b);
                    this.f4356d = iB;
                    return;
                }
                AbstractC0285x abstractC0285x = (AbstractC0285x) list;
                int i8 = this.f4354b & 7;
                if (i8 == 2) {
                    int iC2 = abstractC0273k.C();
                    a0(iC2);
                    int iF2 = abstractC0273k.f() + iC2;
                    do {
                        abstractC0285x.c(abstractC0273k.v());
                    } while (abstractC0273k.f() < iF2);
                    return;
                }
                if (i8 != 5) {
                    throw com.google.crypto.tink.shaded.protobuf.C.c();
                }
                do {
                    abstractC0285x.c(abstractC0273k.v());
                    if (abstractC0273k.g()) {
                        return;
                    } else {
                        iB2 = abstractC0273k.B();
                    }
                } while (iB2 == this.f4354b);
                this.f4356d = iB2;
                return;
        }
    }

    public long H() throws C0175w {
        Y(1);
        return ((C0160g) this.f4357e).w();
    }

    public void I(List list) throws com.google.crypto.tink.shaded.protobuf.C, C0176x {
        int iZ;
        int iB;
        int iB2;
        switch (this.f4353a) {
            case 0:
                C0160g c0160g = (C0160g) this.f4357e;
                int i6 = this.f4354b & 7;
                if (i6 == 1) {
                    do {
                        list.add(Long.valueOf(c0160g.w()));
                        if (c0160g.c()) {
                            return;
                        } else {
                            iZ = c0160g.z();
                        }
                    } while (iZ == this.f4354b);
                    this.f4356d = iZ;
                    return;
                }
                if (i6 != 2) {
                    throw C0176x.b();
                }
                int iA = c0160g.A();
                if ((iA & 7) != 0) {
                    throw C0176x.e();
                }
                int iB3 = c0160g.b() + iA;
                do {
                    list.add(Long.valueOf(c0160g.w()));
                } while (c0160g.b() < iB3);
                return;
            default:
                AbstractC0273k abstractC0273k = (AbstractC0273k) this.f4357e;
                if (!(list instanceof com.google.crypto.tink.shaded.protobuf.J)) {
                    int i7 = this.f4354b & 7;
                    if (i7 == 1) {
                        do {
                            list.add(Long.valueOf(abstractC0273k.w()));
                            if (abstractC0273k.g()) {
                                return;
                            } else {
                                iB = abstractC0273k.B();
                            }
                        } while (iB == this.f4354b);
                        this.f4356d = iB;
                        return;
                    }
                    if (i7 != 2) {
                        throw com.google.crypto.tink.shaded.protobuf.C.c();
                    }
                    int iC = abstractC0273k.C();
                    b0(iC);
                    int iF = abstractC0273k.f() + iC;
                    do {
                        list.add(Long.valueOf(abstractC0273k.w()));
                    } while (abstractC0273k.f() < iF);
                    return;
                }
                com.google.crypto.tink.shaded.protobuf.J j6 = (com.google.crypto.tink.shaded.protobuf.J) list;
                int i8 = this.f4354b & 7;
                if (i8 == 1) {
                    do {
                        j6.c(abstractC0273k.w());
                        if (abstractC0273k.g()) {
                            return;
                        } else {
                            iB2 = abstractC0273k.B();
                        }
                    } while (iB2 == this.f4354b);
                    this.f4356d = iB2;
                    return;
                }
                if (i8 != 2) {
                    throw com.google.crypto.tink.shaded.protobuf.C.c();
                }
                int iC2 = abstractC0273k.C();
                b0(iC2);
                int iF2 = abstractC0273k.f() + iC2;
                do {
                    j6.c(abstractC0273k.w());
                } while (abstractC0273k.f() < iF2);
                return;
        }
    }

    public int J() throws C0175w {
        Y(0);
        return ((C0160g) this.f4357e).x();
    }

    public void K(List list) throws com.google.crypto.tink.shaded.protobuf.C, C0176x {
        int iZ;
        int iB;
        int iB2;
        switch (this.f4353a) {
            case 0:
                C0160g c0160g = (C0160g) this.f4357e;
                int i6 = this.f4354b & 7;
                if (i6 == 0) {
                    do {
                        list.add(Integer.valueOf(c0160g.x()));
                        if (c0160g.c()) {
                            return;
                        } else {
                            iZ = c0160g.z();
                        }
                    } while (iZ == this.f4354b);
                    this.f4356d = iZ;
                    return;
                }
                if (i6 != 2) {
                    throw C0176x.b();
                }
                int iB3 = c0160g.b() + c0160g.A();
                do {
                    list.add(Integer.valueOf(c0160g.x()));
                } while (c0160g.b() < iB3);
                W(iB3);
                return;
            default:
                AbstractC0273k abstractC0273k = (AbstractC0273k) this.f4357e;
                if (!(list instanceof AbstractC0285x)) {
                    int i7 = this.f4354b & 7;
                    if (i7 == 0) {
                        do {
                            list.add(Integer.valueOf(abstractC0273k.x()));
                            if (abstractC0273k.g()) {
                                return;
                            } else {
                                iB = abstractC0273k.B();
                            }
                        } while (iB == this.f4354b);
                        this.f4356d = iB;
                        return;
                    }
                    if (i7 != 2) {
                        throw com.google.crypto.tink.shaded.protobuf.C.c();
                    }
                    int iF = abstractC0273k.f() + abstractC0273k.C();
                    do {
                        list.add(Integer.valueOf(abstractC0273k.x()));
                    } while (abstractC0273k.f() < iF);
                    V(iF);
                    return;
                }
                AbstractC0285x abstractC0285x = (AbstractC0285x) list;
                int i8 = this.f4354b & 7;
                if (i8 == 0) {
                    do {
                        abstractC0285x.c(abstractC0273k.x());
                        if (abstractC0273k.g()) {
                            return;
                        } else {
                            iB2 = abstractC0273k.B();
                        }
                    } while (iB2 == this.f4354b);
                    this.f4356d = iB2;
                    return;
                }
                if (i8 != 2) {
                    throw com.google.crypto.tink.shaded.protobuf.C.c();
                }
                int iF2 = abstractC0273k.f() + abstractC0273k.C();
                do {
                    abstractC0285x.c(abstractC0273k.x());
                } while (abstractC0273k.f() < iF2);
                V(iF2);
                return;
        }
    }

    public long L() throws C0175w {
        Y(0);
        return ((C0160g) this.f4357e).y();
    }

    public void M(List list) throws com.google.crypto.tink.shaded.protobuf.C, C0176x {
        int iZ;
        int iB;
        int iB2;
        switch (this.f4353a) {
            case 0:
                C0160g c0160g = (C0160g) this.f4357e;
                int i6 = this.f4354b & 7;
                if (i6 == 0) {
                    do {
                        list.add(Long.valueOf(c0160g.y()));
                        if (c0160g.c()) {
                            return;
                        } else {
                            iZ = c0160g.z();
                        }
                    } while (iZ == this.f4354b);
                    this.f4356d = iZ;
                    return;
                }
                if (i6 != 2) {
                    throw C0176x.b();
                }
                int iB3 = c0160g.b() + c0160g.A();
                do {
                    list.add(Long.valueOf(c0160g.y()));
                } while (c0160g.b() < iB3);
                W(iB3);
                return;
            default:
                AbstractC0273k abstractC0273k = (AbstractC0273k) this.f4357e;
                if (!(list instanceof com.google.crypto.tink.shaded.protobuf.J)) {
                    int i7 = this.f4354b & 7;
                    if (i7 == 0) {
                        do {
                            list.add(Long.valueOf(abstractC0273k.y()));
                            if (abstractC0273k.g()) {
                                return;
                            } else {
                                iB = abstractC0273k.B();
                            }
                        } while (iB == this.f4354b);
                        this.f4356d = iB;
                        return;
                    }
                    if (i7 != 2) {
                        throw com.google.crypto.tink.shaded.protobuf.C.c();
                    }
                    int iF = abstractC0273k.f() + abstractC0273k.C();
                    do {
                        list.add(Long.valueOf(abstractC0273k.y()));
                    } while (abstractC0273k.f() < iF);
                    V(iF);
                    return;
                }
                com.google.crypto.tink.shaded.protobuf.J j6 = (com.google.crypto.tink.shaded.protobuf.J) list;
                int i8 = this.f4354b & 7;
                if (i8 == 0) {
                    do {
                        j6.c(abstractC0273k.y());
                        if (abstractC0273k.g()) {
                            return;
                        } else {
                            iB2 = abstractC0273k.B();
                        }
                    } while (iB2 == this.f4354b);
                    this.f4356d = iB2;
                    return;
                }
                if (i8 != 2) {
                    throw com.google.crypto.tink.shaded.protobuf.C.c();
                }
                int iF2 = abstractC0273k.f() + abstractC0273k.C();
                do {
                    j6.c(abstractC0273k.y());
                } while (abstractC0273k.f() < iF2);
                V(iF2);
                return;
        }
    }

    public String N() throws C0175w {
        Y(2);
        C0160g c0160g = (C0160g) this.f4357e;
        byte[] bArr = c0160g.f4346d;
        int iS = c0160g.s();
        if (iS > 0) {
            int i6 = c0160g.f4347e;
            int i7 = c0160g.f4349g;
            if (iS <= i6 - i7) {
                String str = new String(bArr, i7, iS, AbstractC0174v.f4391a);
                c0160g.f4349g += iS;
                return str;
            }
        }
        if (iS == 0) {
            return StringUtils.EMPTY;
        }
        if (iS > c0160g.f4347e) {
            return new String(c0160g.n(iS), AbstractC0174v.f4391a);
        }
        c0160g.D(iS);
        String str2 = new String(bArr, c0160g.f4349g, iS, AbstractC0174v.f4391a);
        c0160g.f4349g += iS;
        return str2;
    }

    public void O(List list, boolean z6) throws com.google.crypto.tink.shaded.protobuf.B, C0175w {
        int iZ;
        int iZ2;
        String strZ;
        int iB;
        int iB2;
        switch (this.f4353a) {
            case 0:
                C0160g c0160g = (C0160g) this.f4357e;
                if ((this.f4354b & 7) != 2) {
                    throw C0176x.b();
                }
                if (!(list instanceof A) || z6) {
                    do {
                        list.add(z6 ? P() : N());
                        if (c0160g.c()) {
                            return;
                        } else {
                            iZ = c0160g.z();
                        }
                    } while (iZ == this.f4354b);
                    this.f4356d = iZ;
                    return;
                }
                A a5 = (A) list;
                do {
                    a5.t(i());
                    if (c0160g.c()) {
                        return;
                    } else {
                        iZ2 = c0160g.z();
                    }
                } while (iZ2 == this.f4354b);
                this.f4356d = iZ2;
                return;
            default:
                AbstractC0273k abstractC0273k = (AbstractC0273k) this.f4357e;
                if ((this.f4354b & 7) != 2) {
                    throw com.google.crypto.tink.shaded.protobuf.C.c();
                }
                if ((list instanceof com.google.crypto.tink.shaded.protobuf.F) && !z6) {
                    com.google.crypto.tink.shaded.protobuf.F f4 = (com.google.crypto.tink.shaded.protobuf.F) list;
                    do {
                        f4.v(j());
                        if (abstractC0273k.g()) {
                            return;
                        } else {
                            iB2 = abstractC0273k.B();
                        }
                    } while (iB2 == this.f4354b);
                    this.f4356d = iB2;
                    return;
                }
                do {
                    if (z6) {
                        X(2);
                        strZ = abstractC0273k.A();
                    } else {
                        X(2);
                        strZ = abstractC0273k.z();
                    }
                    list.add(strZ);
                    if (abstractC0273k.g()) {
                        return;
                    } else {
                        iB = abstractC0273k.B();
                    }
                } while (iB == this.f4354b);
                this.f4356d = iB;
                return;
        }
    }

    public String P() throws C0175w {
        Y(2);
        C0160g c0160g = (C0160g) this.f4357e;
        byte[] bArrN = c0160g.f4346d;
        int iS = c0160g.s();
        int i6 = c0160g.f4349g;
        int i7 = c0160g.f4347e;
        if (iS <= i7 - i6 && iS > 0) {
            c0160g.f4349g = i6 + iS;
        } else {
            if (iS == 0) {
                return StringUtils.EMPTY;
            }
            i6 = 0;
            if (iS <= i7) {
                c0160g.D(iS);
                c0160g.f4349g = iS;
            } else {
                bArrN = c0160g.n(iS);
            }
        }
        return r0.f4390a.e(bArrN, i6, iS);
    }

    public int Q() throws C0175w {
        Y(0);
        return ((C0160g) this.f4357e).A();
    }

    public void R(List list) throws com.google.crypto.tink.shaded.protobuf.C, C0176x {
        int iZ;
        int iB;
        int iB2;
        switch (this.f4353a) {
            case 0:
                C0160g c0160g = (C0160g) this.f4357e;
                int i6 = this.f4354b & 7;
                if (i6 == 0) {
                    do {
                        list.add(Integer.valueOf(c0160g.A()));
                        if (c0160g.c()) {
                            return;
                        } else {
                            iZ = c0160g.z();
                        }
                    } while (iZ == this.f4354b);
                    this.f4356d = iZ;
                    return;
                }
                if (i6 != 2) {
                    throw C0176x.b();
                }
                int iB3 = c0160g.b() + c0160g.A();
                do {
                    list.add(Integer.valueOf(c0160g.A()));
                } while (c0160g.b() < iB3);
                W(iB3);
                return;
            default:
                AbstractC0273k abstractC0273k = (AbstractC0273k) this.f4357e;
                if (!(list instanceof AbstractC0285x)) {
                    int i7 = this.f4354b & 7;
                    if (i7 == 0) {
                        do {
                            list.add(Integer.valueOf(abstractC0273k.C()));
                            if (abstractC0273k.g()) {
                                return;
                            } else {
                                iB = abstractC0273k.B();
                            }
                        } while (iB == this.f4354b);
                        this.f4356d = iB;
                        return;
                    }
                    if (i7 != 2) {
                        throw com.google.crypto.tink.shaded.protobuf.C.c();
                    }
                    int iF = abstractC0273k.f() + abstractC0273k.C();
                    do {
                        list.add(Integer.valueOf(abstractC0273k.C()));
                    } while (abstractC0273k.f() < iF);
                    V(iF);
                    return;
                }
                AbstractC0285x abstractC0285x = (AbstractC0285x) list;
                int i8 = this.f4354b & 7;
                if (i8 == 0) {
                    do {
                        abstractC0285x.c(abstractC0273k.C());
                        if (abstractC0273k.g()) {
                            return;
                        } else {
                            iB2 = abstractC0273k.B();
                        }
                    } while (iB2 == this.f4354b);
                    this.f4356d = iB2;
                    return;
                }
                if (i8 != 2) {
                    throw com.google.crypto.tink.shaded.protobuf.C.c();
                }
                int iF2 = abstractC0273k.f() + abstractC0273k.C();
                do {
                    abstractC0285x.c(abstractC0273k.C());
                } while (abstractC0273k.f() < iF2);
                V(iF2);
                return;
        }
    }

    public long S() throws C0175w {
        Y(0);
        return ((C0160g) this.f4357e).B();
    }

    public void T(List list) throws com.google.crypto.tink.shaded.protobuf.C, C0176x {
        int iZ;
        int iB;
        int iB2;
        switch (this.f4353a) {
            case 0:
                C0160g c0160g = (C0160g) this.f4357e;
                int i6 = this.f4354b & 7;
                if (i6 == 0) {
                    do {
                        list.add(Long.valueOf(c0160g.B()));
                        if (c0160g.c()) {
                            return;
                        } else {
                            iZ = c0160g.z();
                        }
                    } while (iZ == this.f4354b);
                    this.f4356d = iZ;
                    return;
                }
                if (i6 != 2) {
                    throw C0176x.b();
                }
                int iB3 = c0160g.b() + c0160g.A();
                do {
                    list.add(Long.valueOf(c0160g.B()));
                } while (c0160g.b() < iB3);
                W(iB3);
                return;
            default:
                AbstractC0273k abstractC0273k = (AbstractC0273k) this.f4357e;
                if (!(list instanceof com.google.crypto.tink.shaded.protobuf.J)) {
                    int i7 = this.f4354b & 7;
                    if (i7 == 0) {
                        do {
                            list.add(Long.valueOf(abstractC0273k.D()));
                            if (abstractC0273k.g()) {
                                return;
                            } else {
                                iB = abstractC0273k.B();
                            }
                        } while (iB == this.f4354b);
                        this.f4356d = iB;
                        return;
                    }
                    if (i7 != 2) {
                        throw com.google.crypto.tink.shaded.protobuf.C.c();
                    }
                    int iF = abstractC0273k.f() + abstractC0273k.C();
                    do {
                        list.add(Long.valueOf(abstractC0273k.D()));
                    } while (abstractC0273k.f() < iF);
                    V(iF);
                    return;
                }
                com.google.crypto.tink.shaded.protobuf.J j6 = (com.google.crypto.tink.shaded.protobuf.J) list;
                int i8 = this.f4354b & 7;
                if (i8 == 0) {
                    do {
                        j6.c(abstractC0273k.D());
                        if (abstractC0273k.g()) {
                            return;
                        } else {
                            iB2 = abstractC0273k.B();
                        }
                    } while (iB2 == this.f4354b);
                    this.f4356d = iB2;
                    return;
                }
                if (i8 != 2) {
                    throw com.google.crypto.tink.shaded.protobuf.C.c();
                }
                int iF2 = abstractC0273k.f() + abstractC0273k.C();
                do {
                    j6.c(abstractC0273k.D());
                } while (abstractC0273k.f() < iF2);
                V(iF2);
                return;
        }
    }

    public long U() {
        int i6 = this.f4355c;
        if (i6 == 0) {
            throw new NoSuchElementException();
        }
        long[] jArr = (long[]) this.f4357e;
        int i7 = this.f4354b;
        long j6 = jArr[i7];
        this.f4354b = this.f4356d & (i7 + 1);
        this.f4355c = i6 - 1;
        return j6;
    }

    public void V(int i6) throws com.google.crypto.tink.shaded.protobuf.C {
        if (((AbstractC0273k) this.f4357e).f() != i6) {
            throw com.google.crypto.tink.shaded.protobuf.C.g();
        }
    }

    public void W(int i6) throws C0176x {
        if (((C0160g) this.f4357e).b() != i6) {
            throw C0176x.f();
        }
    }

    public void X(int i6) throws com.google.crypto.tink.shaded.protobuf.B {
        if ((this.f4354b & 7) != i6) {
            throw com.google.crypto.tink.shaded.protobuf.C.c();
        }
    }

    public void Y(int i6) throws C0175w {
        if ((this.f4354b & 7) != i6) {
            throw C0176x.b();
        }
    }

    public boolean Z() {
        int i6;
        C0160g c0160g = (C0160g) this.f4357e;
        if (c0160g.c() || (i6 = this.f4354b) == this.f4355c) {
            return false;
        }
        return c0160g.E(i6);
    }

    public void a(int i6) {
        int[] iArr = (int[]) this.f4357e;
        int i7 = this.f4355c;
        iArr[i7] = i6;
        int i8 = this.f4356d & (i7 + 1);
        this.f4355c = i8;
        int i9 = this.f4354b;
        if (i8 == i9) {
            int length = iArr.length;
            int i10 = length - i9;
            int i11 = length << 1;
            if (i11 < 0) {
                throw new RuntimeException("Max array capacity exceeded");
            }
            int[] iArr2 = new int[i11];
            p081m5.e.M(0, i9, length, iArr, iArr2);
            p081m5.e.M(i10, 0, this.f4354b, (int[]) this.f4357e, iArr2);
            this.f4357e = iArr2;
            this.f4354b = 0;
            this.f4355c = length;
            this.f4356d = i11 - 1;
        }
    }

    public void b(E1.i iVar) {
        Object[] objArr = (Object[]) this.f4357e;
        int i6 = this.f4355c;
        objArr[i6] = iVar;
        int i7 = this.f4356d & (i6 + 1);
        this.f4355c = i7;
        int i8 = this.f4354b;
        if (i7 == i8) {
            int length = objArr.length;
            int i9 = length - i8;
            int i10 = length << 1;
            if (i10 < 0) {
                throw new RuntimeException("Max array capacity exceeded");
            }
            Object[] objArr2 = new Object[i10];
            p081m5.e.N(0, i8, length, objArr, objArr2);
            p081m5.e.N(i9, 0, this.f4354b, (Object[]) this.f4357e, objArr2);
            this.f4357e = objArr2;
            this.f4354b = 0;
            this.f4355c = length;
            this.f4356d = i10 - 1;
        }
    }

    public int c() {
        switch (this.f4353a) {
            case 0:
                int i6 = this.f4356d;
                if (i6 != 0) {
                    this.f4354b = i6;
                    this.f4356d = 0;
                } else {
                    this.f4354b = ((C0160g) this.f4357e).z();
                }
                int i7 = this.f4354b;
                if (i7 == 0 || i7 == this.f4355c) {
                    return Integer.MAX_VALUE;
                }
                return i7 >>> 3;
            default:
                int i8 = this.f4356d;
                if (i8 != 0) {
                    this.f4354b = i8;
                    this.f4356d = 0;
                } else {
                    this.f4354b = ((AbstractC0273k) this.f4357e).B();
                }
                int i9 = this.f4354b;
                if (i9 == 0 || i9 == this.f4355c) {
                    return Integer.MAX_VALUE;
                }
                return i9 >>> 3;
        }
    }

    public int d() {
        return this.f4354b;
    }

    public void e(Object obj, com.google.crypto.tink.shaded.protobuf.d0 d0Var, C0277o c0277o) {
        int i6 = this.f4355c;
        this.f4355c = ((this.f4354b >>> 3) << 3) | 4;
        try {
            d0Var.i(obj, this, c0277o);
            if (this.f4354b != this.f4355c) {
                throw com.google.crypto.tink.shaded.protobuf.C.f();
            }
            this.f4355c = i6;
        } catch (Throwable th) {
            this.f4355c = i6;
            throw th;
        }
    }

    public void f(Object obj, com.google.crypto.tink.shaded.protobuf.d0 d0Var, C0277o c0277o) throws com.google.crypto.tink.shaded.protobuf.C {
        AbstractC0273k abstractC0273k = (AbstractC0273k) this.f4357e;
        int iC = abstractC0273k.C();
        if (abstractC0273k.f5025a >= 100) {
            throw new com.google.crypto.tink.shaded.protobuf.C("Protocol message had too many levels of nesting.  May be malicious.  Use CodedInputStream.setRecursionLimit() to increase the depth limit.");
        }
        int iL = abstractC0273k.l(iC);
        abstractC0273k.f5025a++;
        d0Var.i(obj, this, c0277o);
        abstractC0273k.b(0);
        abstractC0273k.f5025a--;
        abstractC0273k.j(iL);
    }

    public boolean g() throws C0175w {
        Y(0);
        return ((C0160g) this.f4357e).f();
    }

    public void h(List list) throws com.google.crypto.tink.shaded.protobuf.C, C0176x {
        int iZ;
        int iB;
        int iB2;
        switch (this.f4353a) {
            case 0:
                C0160g c0160g = (C0160g) this.f4357e;
                int i6 = this.f4354b & 7;
                if (i6 == 0) {
                    do {
                        list.add(Boolean.valueOf(c0160g.f()));
                        if (c0160g.c()) {
                            return;
                        } else {
                            iZ = c0160g.z();
                        }
                    } while (iZ == this.f4354b);
                    this.f4356d = iZ;
                    return;
                }
                if (i6 != 2) {
                    throw C0176x.b();
                }
                int iB3 = c0160g.b() + c0160g.A();
                do {
                    list.add(Boolean.valueOf(c0160g.f()));
                } while (c0160g.b() < iB3);
                W(iB3);
                return;
            default:
                AbstractC0273k abstractC0273k = (AbstractC0273k) this.f4357e;
                if (!(list instanceof AbstractC0266d)) {
                    int i7 = this.f4354b & 7;
                    if (i7 == 0) {
                        do {
                            list.add(Boolean.valueOf(abstractC0273k.m()));
                            if (abstractC0273k.g()) {
                                return;
                            } else {
                                iB = abstractC0273k.B();
                            }
                        } while (iB == this.f4354b);
                        this.f4356d = iB;
                        return;
                    }
                    if (i7 != 2) {
                        throw com.google.crypto.tink.shaded.protobuf.C.c();
                    }
                    int iF = abstractC0273k.f() + abstractC0273k.C();
                    do {
                        list.add(Boolean.valueOf(abstractC0273k.m()));
                    } while (abstractC0273k.f() < iF);
                    V(iF);
                    return;
                }
                AbstractC0266d abstractC0266d = (AbstractC0266d) list;
                int i8 = this.f4354b & 7;
                if (i8 == 0) {
                    do {
                        abstractC0266d.c(abstractC0273k.m());
                        if (abstractC0273k.g()) {
                            return;
                        } else {
                            iB2 = abstractC0273k.B();
                        }
                    } while (iB2 == this.f4354b);
                    this.f4356d = iB2;
                    return;
                }
                if (i8 != 2) {
                    throw com.google.crypto.tink.shaded.protobuf.C.c();
                }
                int iF2 = abstractC0273k.f() + abstractC0273k.C();
                do {
                    abstractC0266d.c(abstractC0273k.m());
                } while (abstractC0273k.f() < iF2);
                V(iF2);
                return;
        }
    }

    public C0159f i() throws C0175w {
        Y(2);
        C0160g c0160g = (C0160g) this.f4357e;
        byte[] bArr = c0160g.f4346d;
        int iS = c0160g.s();
        int i6 = c0160g.f4347e;
        int i7 = c0160g.f4349g;
        if (iS <= i6 - i7 && iS > 0) {
            C0159f c0159fB = C0159f.b(bArr, i7, iS);
            c0160g.f4349g += iS;
            return c0159fB;
        }
        if (iS == 0) {
            return C0159f.t;
        }
        byte[] bArrO = c0160g.o(iS);
        if (bArrO != null) {
            return C0159f.b(bArrO, 0, bArrO.length);
        }
        int i8 = c0160g.f4349g;
        int i9 = c0160g.f4347e;
        int length = i9 - i8;
        c0160g.f4351i += i9;
        c0160g.f4349g = 0;
        c0160g.f4347e = 0;
        ArrayList arrayListP = c0160g.p(iS - length);
        byte[] bArr2 = new byte[iS];
        System.arraycopy(bArr, i8, bArr2, 0, length);
        int size = arrayListP.size();
        int i10 = 0;
        while (i10 < size) {
            Object obj = arrayListP.get(i10);
            i10++;
            byte[] bArr3 = (byte[]) obj;
            System.arraycopy(bArr3, 0, bArr2, length, bArr3.length);
            length += bArr3.length;
        }
        C0159f c0159f = C0159f.t;
        return new C0159f(bArr2);
    }

    public AbstractC0270h j() throws com.google.crypto.tink.shaded.protobuf.B {
        X(2);
        return ((AbstractC0273k) this.f4357e).n();
    }

    public void k(List list) throws com.google.crypto.tink.shaded.protobuf.B, C0175w {
        int iZ;
        int iB;
        switch (this.f4353a) {
            case 0:
                C0160g c0160g = (C0160g) this.f4357e;
                if ((this.f4354b & 7) != 2) {
                    throw C0176x.b();
                }
                do {
                    list.add(i());
                    if (c0160g.c()) {
                        return;
                    } else {
                        iZ = c0160g.z();
                    }
                } while (iZ == this.f4354b);
                this.f4356d = iZ;
                return;
            default:
                AbstractC0273k abstractC0273k = (AbstractC0273k) this.f4357e;
                if ((this.f4354b & 7) != 2) {
                    throw com.google.crypto.tink.shaded.protobuf.C.c();
                }
                do {
                    list.add(j());
                    if (abstractC0273k.g()) {
                        return;
                    } else {
                        iB = abstractC0273k.B();
                    }
                } while (iB == this.f4354b);
                this.f4356d = iB;
                return;
        }
    }

    public double l() throws C0175w {
        Y(1);
        return ((C0160g) this.f4357e).g();
    }

    public void m(List list) throws com.google.crypto.tink.shaded.protobuf.C, C0176x {
        int iZ;
        int iB;
        int iB2;
        switch (this.f4353a) {
            case 0:
                C0160g c0160g = (C0160g) this.f4357e;
                int i6 = this.f4354b & 7;
                if (i6 == 1) {
                    do {
                        list.add(Double.valueOf(c0160g.g()));
                        if (c0160g.c()) {
                            return;
                        } else {
                            iZ = c0160g.z();
                        }
                    } while (iZ == this.f4354b);
                    this.f4356d = iZ;
                    return;
                }
                if (i6 != 2) {
                    throw C0176x.b();
                }
                int iA = c0160g.A();
                if ((iA & 7) != 0) {
                    throw C0176x.e();
                }
                int iB3 = c0160g.b() + iA;
                do {
                    list.add(Double.valueOf(c0160g.g()));
                } while (c0160g.b() < iB3);
                return;
            default:
                AbstractC0273k abstractC0273k = (AbstractC0273k) this.f4357e;
                if (!(list instanceof AbstractC0275m)) {
                    int i7 = this.f4354b & 7;
                    if (i7 == 1) {
                        do {
                            list.add(Double.valueOf(abstractC0273k.o()));
                            if (abstractC0273k.g()) {
                                return;
                            } else {
                                iB = abstractC0273k.B();
                            }
                        } while (iB == this.f4354b);
                        this.f4356d = iB;
                        return;
                    }
                    if (i7 != 2) {
                        throw com.google.crypto.tink.shaded.protobuf.C.c();
                    }
                    int iC = abstractC0273k.C();
                    b0(iC);
                    int iF = abstractC0273k.f() + iC;
                    do {
                        list.add(Double.valueOf(abstractC0273k.o()));
                    } while (abstractC0273k.f() < iF);
                    return;
                }
                AbstractC0275m abstractC0275m = (AbstractC0275m) list;
                int i8 = this.f4354b & 7;
                if (i8 == 1) {
                    do {
                        abstractC0275m.c(abstractC0273k.o());
                        if (abstractC0273k.g()) {
                            return;
                        } else {
                            iB2 = abstractC0273k.B();
                        }
                    } while (iB2 == this.f4354b);
                    this.f4356d = iB2;
                    return;
                }
                if (i8 != 2) {
                    throw com.google.crypto.tink.shaded.protobuf.C.c();
                }
                int iC2 = abstractC0273k.C();
                b0(iC2);
                int iF2 = abstractC0273k.f() + iC2;
                do {
                    abstractC0275m.c(abstractC0273k.o());
                } while (abstractC0273k.f() < iF2);
                return;
        }
    }

    public int n() throws C0175w {
        Y(0);
        return ((C0160g) this.f4357e).h();
    }

    public void o(List list) throws com.google.crypto.tink.shaded.protobuf.C, C0176x {
        int iZ;
        int iB;
        int iB2;
        switch (this.f4353a) {
            case 0:
                C0160g c0160g = (C0160g) this.f4357e;
                int i6 = this.f4354b & 7;
                if (i6 == 0) {
                    do {
                        list.add(Integer.valueOf(c0160g.h()));
                        if (c0160g.c()) {
                            return;
                        } else {
                            iZ = c0160g.z();
                        }
                    } while (iZ == this.f4354b);
                    this.f4356d = iZ;
                    return;
                }
                if (i6 != 2) {
                    throw C0176x.b();
                }
                int iB3 = c0160g.b() + c0160g.A();
                do {
                    list.add(Integer.valueOf(c0160g.h()));
                } while (c0160g.b() < iB3);
                W(iB3);
                return;
            default:
                AbstractC0273k abstractC0273k = (AbstractC0273k) this.f4357e;
                if (!(list instanceof AbstractC0285x)) {
                    int i7 = this.f4354b & 7;
                    if (i7 == 0) {
                        do {
                            list.add(Integer.valueOf(abstractC0273k.p()));
                            if (abstractC0273k.g()) {
                                return;
                            } else {
                                iB = abstractC0273k.B();
                            }
                        } while (iB == this.f4354b);
                        this.f4356d = iB;
                        return;
                    }
                    if (i7 != 2) {
                        throw com.google.crypto.tink.shaded.protobuf.C.c();
                    }
                    int iF = abstractC0273k.f() + abstractC0273k.C();
                    do {
                        list.add(Integer.valueOf(abstractC0273k.p()));
                    } while (abstractC0273k.f() < iF);
                    V(iF);
                    return;
                }
                AbstractC0285x abstractC0285x = (AbstractC0285x) list;
                int i8 = this.f4354b & 7;
                if (i8 == 0) {
                    do {
                        abstractC0285x.c(abstractC0273k.p());
                        if (abstractC0273k.g()) {
                            return;
                        } else {
                            iB2 = abstractC0273k.B();
                        }
                    } while (iB2 == this.f4354b);
                    this.f4356d = iB2;
                    return;
                }
                if (i8 != 2) {
                    throw com.google.crypto.tink.shaded.protobuf.C.c();
                }
                int iF2 = abstractC0273k.f() + abstractC0273k.C();
                do {
                    abstractC0285x.c(abstractC0273k.p());
                } while (abstractC0273k.f() < iF2);
                V(iF2);
                return;
        }
    }

    public Object p(w0 w0Var, Class cls, C0165l c0165l) throws C0175w {
        switch (w0Var.ordinal()) {
            case 0:
                return Double.valueOf(l());
            case 1:
                return Float.valueOf(u());
            case 2:
                return Long.valueOf(B());
            case 3:
                return Long.valueOf(S());
            case 4:
                return Integer.valueOf(z());
            case 5:
                return Long.valueOf(s());
            case 6:
                return Integer.valueOf(q());
            case 7:
                return Boolean.valueOf(g());
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                return P();
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
            default:
                throw new RuntimeException("unsupported field type.");
            case 10:
                Y(2);
                return D(U.f4308c.a(cls), c0165l);
            case 11:
                return i();
            case 12:
                return Integer.valueOf(Q());
            case 13:
                return Integer.valueOf(n());
            case 14:
                return Integer.valueOf(F());
            case 15:
                return Long.valueOf(H());
            case 16:
                return Integer.valueOf(J());
            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                return Long.valueOf(L());
        }
    }

    public int q() throws C0175w {
        Y(5);
        return ((C0160g) this.f4357e).i();
    }

    public void r(List list) throws com.google.crypto.tink.shaded.protobuf.C, C0176x {
        int iZ;
        int iB;
        int iB2;
        switch (this.f4353a) {
            case 0:
                C0160g c0160g = (C0160g) this.f4357e;
                int i6 = this.f4354b & 7;
                if (i6 == 2) {
                    int iA = c0160g.A();
                    if ((iA & 3) != 0) {
                        throw C0176x.e();
                    }
                    int iB3 = c0160g.b() + iA;
                    do {
                        list.add(Integer.valueOf(c0160g.i()));
                    } while (c0160g.b() < iB3);
                    return;
                }
                if (i6 != 5) {
                    throw C0176x.b();
                }
                do {
                    list.add(Integer.valueOf(c0160g.i()));
                    if (c0160g.c()) {
                        return;
                    } else {
                        iZ = c0160g.z();
                    }
                } while (iZ == this.f4354b);
                this.f4356d = iZ;
                return;
            default:
                AbstractC0273k abstractC0273k = (AbstractC0273k) this.f4357e;
                if (!(list instanceof AbstractC0285x)) {
                    int i7 = this.f4354b & 7;
                    if (i7 == 2) {
                        int iC = abstractC0273k.C();
                        a0(iC);
                        int iF = abstractC0273k.f() + iC;
                        do {
                            list.add(Integer.valueOf(abstractC0273k.q()));
                        } while (abstractC0273k.f() < iF);
                        return;
                    }
                    if (i7 != 5) {
                        throw com.google.crypto.tink.shaded.protobuf.C.c();
                    }
                    do {
                        list.add(Integer.valueOf(abstractC0273k.q()));
                        if (abstractC0273k.g()) {
                            return;
                        } else {
                            iB = abstractC0273k.B();
                        }
                    } while (iB == this.f4354b);
                    this.f4356d = iB;
                    return;
                }
                AbstractC0285x abstractC0285x = (AbstractC0285x) list;
                int i8 = this.f4354b & 7;
                if (i8 == 2) {
                    int iC2 = abstractC0273k.C();
                    a0(iC2);
                    int iF2 = abstractC0273k.f() + iC2;
                    do {
                        abstractC0285x.c(abstractC0273k.q());
                    } while (abstractC0273k.f() < iF2);
                    return;
                }
                if (i8 != 5) {
                    throw com.google.crypto.tink.shaded.protobuf.C.c();
                }
                do {
                    abstractC0285x.c(abstractC0273k.q());
                    if (abstractC0273k.g()) {
                        return;
                    } else {
                        iB2 = abstractC0273k.B();
                    }
                } while (iB2 == this.f4354b);
                this.f4356d = iB2;
                return;
        }
    }

    public long s() throws C0175w {
        Y(1);
        return ((C0160g) this.f4357e).j();
    }

    public void t(List list) throws com.google.crypto.tink.shaded.protobuf.C, C0176x {
        int iZ;
        int iB;
        int iB2;
        switch (this.f4353a) {
            case 0:
                C0160g c0160g = (C0160g) this.f4357e;
                int i6 = this.f4354b & 7;
                if (i6 == 1) {
                    do {
                        list.add(Long.valueOf(c0160g.j()));
                        if (c0160g.c()) {
                            return;
                        } else {
                            iZ = c0160g.z();
                        }
                    } while (iZ == this.f4354b);
                    this.f4356d = iZ;
                    return;
                }
                if (i6 != 2) {
                    throw C0176x.b();
                }
                int iA = c0160g.A();
                if ((iA & 7) != 0) {
                    throw C0176x.e();
                }
                int iB3 = c0160g.b() + iA;
                do {
                    list.add(Long.valueOf(c0160g.j()));
                } while (c0160g.b() < iB3);
                return;
            default:
                AbstractC0273k abstractC0273k = (AbstractC0273k) this.f4357e;
                if (!(list instanceof com.google.crypto.tink.shaded.protobuf.J)) {
                    int i7 = this.f4354b & 7;
                    if (i7 == 1) {
                        do {
                            list.add(Long.valueOf(abstractC0273k.r()));
                            if (abstractC0273k.g()) {
                                return;
                            } else {
                                iB = abstractC0273k.B();
                            }
                        } while (iB == this.f4354b);
                        this.f4356d = iB;
                        return;
                    }
                    if (i7 != 2) {
                        throw com.google.crypto.tink.shaded.protobuf.C.c();
                    }
                    int iC = abstractC0273k.C();
                    b0(iC);
                    int iF = abstractC0273k.f() + iC;
                    do {
                        list.add(Long.valueOf(abstractC0273k.r()));
                    } while (abstractC0273k.f() < iF);
                    return;
                }
                com.google.crypto.tink.shaded.protobuf.J j6 = (com.google.crypto.tink.shaded.protobuf.J) list;
                int i8 = this.f4354b & 7;
                if (i8 == 1) {
                    do {
                        j6.c(abstractC0273k.r());
                        if (abstractC0273k.g()) {
                            return;
                        } else {
                            iB2 = abstractC0273k.B();
                        }
                    } while (iB2 == this.f4354b);
                    this.f4356d = iB2;
                    return;
                }
                if (i8 != 2) {
                    throw com.google.crypto.tink.shaded.protobuf.C.c();
                }
                int iC2 = abstractC0273k.C();
                b0(iC2);
                int iF2 = abstractC0273k.f() + iC2;
                do {
                    j6.c(abstractC0273k.r());
                } while (abstractC0273k.f() < iF2);
                return;
        }
    }

    public float u() throws C0175w {
        Y(5);
        return ((C0160g) this.f4357e).k();
    }

    public void v(List list) throws com.google.crypto.tink.shaded.protobuf.C, C0176x {
        int iZ;
        int iB;
        int iB2;
        switch (this.f4353a) {
            case 0:
                C0160g c0160g = (C0160g) this.f4357e;
                int i6 = this.f4354b & 7;
                if (i6 == 2) {
                    int iA = c0160g.A();
                    if ((iA & 3) != 0) {
                        throw C0176x.e();
                    }
                    int iB3 = c0160g.b() + iA;
                    do {
                        list.add(Float.valueOf(c0160g.k()));
                    } while (c0160g.b() < iB3);
                    return;
                }
                if (i6 != 5) {
                    throw C0176x.b();
                }
                do {
                    list.add(Float.valueOf(c0160g.k()));
                    if (c0160g.c()) {
                        return;
                    } else {
                        iZ = c0160g.z();
                    }
                } while (iZ == this.f4354b);
                this.f4356d = iZ;
                return;
            default:
                AbstractC0273k abstractC0273k = (AbstractC0273k) this.f4357e;
                if (!(list instanceof AbstractC0280s)) {
                    int i7 = this.f4354b & 7;
                    if (i7 == 2) {
                        int iC = abstractC0273k.C();
                        a0(iC);
                        int iF = abstractC0273k.f() + iC;
                        do {
                            list.add(Float.valueOf(abstractC0273k.s()));
                        } while (abstractC0273k.f() < iF);
                        return;
                    }
                    if (i7 != 5) {
                        throw com.google.crypto.tink.shaded.protobuf.C.c();
                    }
                    do {
                        list.add(Float.valueOf(abstractC0273k.s()));
                        if (abstractC0273k.g()) {
                            return;
                        } else {
                            iB = abstractC0273k.B();
                        }
                    } while (iB == this.f4354b);
                    this.f4356d = iB;
                    return;
                }
                AbstractC0280s abstractC0280s = (AbstractC0280s) list;
                int i8 = this.f4354b & 7;
                if (i8 == 2) {
                    int iC2 = abstractC0273k.C();
                    a0(iC2);
                    int iF2 = abstractC0273k.f() + iC2;
                    do {
                        abstractC0280s.c(abstractC0273k.s());
                    } while (abstractC0273k.f() < iF2);
                    return;
                }
                if (i8 != 5) {
                    throw com.google.crypto.tink.shaded.protobuf.C.c();
                }
                do {
                    abstractC0280s.c(abstractC0273k.s());
                    if (abstractC0273k.g()) {
                        return;
                    } else {
                        iB2 = abstractC0273k.B();
                    }
                } while (iB2 == this.f4354b);
                this.f4356d = iB2;
                return;
        }
    }

    public Object w(X x5, C0165l c0165l) {
        int i6 = this.f4355c;
        this.f4355c = ((this.f4354b >>> 3) << 3) | 4;
        try {
            Object objNewInstance = x5.newInstance();
            x5.g(objNewInstance, this, c0165l);
            x5.a(objNewInstance);
            if (this.f4354b != this.f4355c) {
                throw C0176x.e();
            }
            this.f4355c = i6;
            return objNewInstance;
        } catch (Throwable th) {
            this.f4355c = i6;
            throw th;
        }
    }

    public Object x(X x5, C0165l c0165l) throws C0175w {
        Y(3);
        return w(x5, c0165l);
    }

    public void y(List list, X x5, C0165l c0165l) throws C0175w {
        int iZ;
        C0160g c0160g = (C0160g) this.f4357e;
        int i6 = this.f4354b;
        if ((i6 & 7) != 3) {
            throw C0176x.b();
        }
        do {
            list.add(w(x5, c0165l));
            if (c0160g.c() || this.f4356d != 0) {
                return;
            } else {
                iZ = c0160g.z();
            }
        } while (iZ == i6);
        this.f4356d = iZ;
    }

    public int z() throws C0175w {
        Y(0);
        return ((C0160g) this.f4357e).l();
    }

    public C0161h() {
        this.f4353a = 3;
        int iHighestOneBit = Integer.bitCount(8) != 1 ? Integer.highestOneBit(7) << 1 : 8;
        this.f4356d = iHighestOneBit - 1;
        this.f4357e = new int[iHighestOneBit];
    }

    public C0161h(C0160g c0160g) {
        this.f4353a = 0;
        this.f4356d = 0;
        Charset charset = AbstractC0174v.f4391a;
        this.f4357e = c0160g;
        c0160g.f4344b = this;
    }

    public C0161h(AbstractC0273k abstractC0273k) {
        this.f4353a = 1;
        this.f4356d = 0;
        com.google.crypto.tink.shaded.protobuf.A.a(abstractC0273k, "input");
        this.f4357e = abstractC0273k;
        abstractC0273k.f5026b = this;
    }
}
