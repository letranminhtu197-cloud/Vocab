package androidx.datastore.preferences.protobuf;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.RandomAccess;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.z, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0178z extends AbstractC0155b implements A, RandomAccess {

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final ArrayList f4413s;

    static {
        new C0178z(10).r = false;
    }

    public C0178z(int i6) {
        this(new ArrayList(i6));
    }

    @Override // androidx.datastore.preferences.protobuf.InterfaceC0173u
    public final InterfaceC0173u a(int i6) {
        ArrayList arrayList = this.f4413s;
        if (i6 < arrayList.size()) {
            throw new IllegalArgumentException();
        }
        ArrayList arrayList2 = new ArrayList(i6);
        arrayList2.addAll(arrayList);
        return new C0178z(arrayList2);
    }

    @Override // java.util.AbstractList, java.util.List
    public final void add(int i6, Object obj) {
        b();
        this.f4413s.add(i6, (String) obj);
        ((AbstractList) this).modCount++;
    }

    @Override // androidx.datastore.preferences.protobuf.AbstractC0155b, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean addAll(Collection collection) {
        return addAll(this.f4413s.size(), collection);
    }

    @Override // androidx.datastore.preferences.protobuf.AbstractC0155b, java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final void clear() {
        b();
        this.f4413s.clear();
        ((AbstractList) this).modCount++;
    }

    @Override // androidx.datastore.preferences.protobuf.A
    public final A d() {
        return this.r ? new j0(this) : this;
    }

    @Override // androidx.datastore.preferences.protobuf.A
    public final Object e(int i6) {
        return this.f4413s.get(i6);
    }

    @Override // androidx.datastore.preferences.protobuf.A
    public final List f() {
        return Collections.unmodifiableList(this.f4413s);
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object get(int i6) {
        ArrayList arrayList = this.f4413s;
        Object obj = arrayList.get(i6);
        if (obj instanceof String) {
            return (String) obj;
        }
        if (!(obj instanceof C0159f)) {
            byte[] bArr = (byte[]) obj;
            String str = new String(bArr, AbstractC0174v.f4391a);
            if (r0.f4390a.i(bArr, 0, bArr.length) == 0) {
                arrayList.set(i6, str);
            }
            return str;
        }
        C0159f c0159f = (C0159f) obj;
        c0159f.getClass();
        String str2 = c0159f.size() == 0 ? StringUtils.EMPTY : new String(c0159f.f4336s, c0159f.c(), c0159f.size(), AbstractC0174v.f4391a);
        int iC = c0159f.c();
        if (r0.f4390a.i(c0159f.f4336s, iC, c0159f.size() + iC) == 0) {
            arrayList.set(i6, str2);
        }
        return str2;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object remove(int i6) {
        b();
        Object objRemove = this.f4413s.remove(i6);
        ((AbstractList) this).modCount++;
        if (objRemove instanceof String) {
            return (String) objRemove;
        }
        if (!(objRemove instanceof C0159f)) {
            return new String((byte[]) objRemove, AbstractC0174v.f4391a);
        }
        C0159f c0159f = (C0159f) objRemove;
        c0159f.getClass();
        return c0159f.size() == 0 ? StringUtils.EMPTY : new String(c0159f.f4336s, c0159f.c(), c0159f.size(), AbstractC0174v.f4391a);
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object set(int i6, Object obj) {
        b();
        Object obj2 = this.f4413s.set(i6, (String) obj);
        if (obj2 instanceof String) {
            return (String) obj2;
        }
        if (!(obj2 instanceof C0159f)) {
            return new String((byte[]) obj2, AbstractC0174v.f4391a);
        }
        C0159f c0159f = (C0159f) obj2;
        c0159f.getClass();
        return c0159f.size() == 0 ? StringUtils.EMPTY : new String(c0159f.f4336s, c0159f.c(), c0159f.size(), AbstractC0174v.f4391a);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.f4413s.size();
    }

    @Override // androidx.datastore.preferences.protobuf.A
    public final void t(C0159f c0159f) {
        b();
        this.f4413s.add(c0159f);
        ((AbstractList) this).modCount++;
    }

    public C0178z(ArrayList arrayList) {
        this.f4413s = arrayList;
    }

    @Override // androidx.datastore.preferences.protobuf.AbstractC0155b, java.util.AbstractList, java.util.List
    public final boolean addAll(int i6, Collection collection) {
        b();
        if (collection instanceof A) {
            collection = ((A) collection).f();
        }
        boolean zAddAll = this.f4413s.addAll(i6, collection);
        ((AbstractList) this).modCount++;
        return zAddAll;
    }
}
