package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public final class W {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final AbstractC0154a f4313a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f4314b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object[] f4315c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f4316d;

    public W(AbstractC0172t abstractC0172t, String str, Object[] objArr) {
        this.f4313a = abstractC0172t;
        this.f4314b = str;
        this.f4315c = objArr;
        char cCharAt = str.charAt(0);
        if (cCharAt < 55296) {
            this.f4316d = cCharAt;
            return;
        }
        int i6 = cCharAt & 8191;
        int i7 = 13;
        int i8 = 1;
        while (true) {
            int i9 = i8 + 1;
            char cCharAt2 = str.charAt(i8);
            if (cCharAt2 < 55296) {
                this.f4316d = i6 | (cCharAt2 << i7);
                return;
            } else {
                i6 |= (cCharAt2 & 8191) << i7;
                i7 += 13;
                i8 = i9;
            }
        }
    }
}
