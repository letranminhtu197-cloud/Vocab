package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public abstract class r implements Cloneable {
    public final AbstractC0172t r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public AbstractC0172t f4389s;
    public boolean t = false;

    public r(AbstractC0172t abstractC0172t) {
        this.r = abstractC0172t;
        this.f4389s = (AbstractC0172t) abstractC0172t.d(4);
    }

    public static void d(AbstractC0172t abstractC0172t, AbstractC0172t abstractC0172t2) {
        U u6 = U.f4308c;
        u6.getClass();
        u6.a(abstractC0172t.getClass()).h(abstractC0172t, abstractC0172t2);
    }

    public final AbstractC0172t a() {
        AbstractC0172t abstractC0172tB = b();
        if (abstractC0172tB.g()) {
            return abstractC0172tB;
        }
        throw new D3.u();
    }

    public final AbstractC0172t b() {
        if (this.t) {
            return this.f4389s;
        }
        AbstractC0172t abstractC0172t = this.f4389s;
        abstractC0172t.getClass();
        U u6 = U.f4308c;
        u6.getClass();
        u6.a(abstractC0172t.getClass()).a(abstractC0172t);
        this.t = true;
        return this.f4389s;
    }

    public final void c() {
        if (this.t) {
            AbstractC0172t abstractC0172t = (AbstractC0172t) this.f4389s.d(4);
            d(abstractC0172t, this.f4389s);
            this.f4389s = abstractC0172t;
            this.t = false;
        }
    }

    public final Object clone() {
        r rVar = (r) this.r.d(5);
        AbstractC0172t abstractC0172tB = b();
        rVar.c();
        d(rVar.f4389s, abstractC0172tB);
        return rVar;
    }
}
