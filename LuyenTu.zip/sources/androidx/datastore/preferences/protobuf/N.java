package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.pipes.PipesConfigBase;
import org.apache.tika.pipes.PipesServer;
import org.apache.tika.utils.StringUtils;
import org.apache.tika.utils.XMLReaderUtils;
import sun.misc.Unsafe;

/* JADX INFO: loaded from: classes.dex */
public final class N implements X {
    public static final int[] o = new int[0];

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final Unsafe f4288p = o0.i();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int[] f4289a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object[] f4290b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f4291c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f4292d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final AbstractC0154a f4293e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f4294f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f4295g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int[] f4296h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f4297i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final int f4298j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final P f4299k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final D f4300l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final g0 f4301m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final J f4302n;

    public N(int[] iArr, Object[] objArr, int i6, int i7, AbstractC0154a abstractC0154a, boolean z6, int[] iArr2, int i8, int i9, P p6, D d6, g0 g0Var, C0166m c0166m, J j6) {
        this.f4289a = iArr;
        this.f4290b = objArr;
        this.f4291c = i6;
        this.f4292d = i7;
        this.f4294f = abstractC0154a instanceof AbstractC0172t;
        this.f4295g = z6;
        this.f4296h = iArr2;
        this.f4297i = i8;
        this.f4298j = i9;
        this.f4299k = p6;
        this.f4300l = d6;
        this.f4301m = g0Var;
        this.f4293e = abstractC0154a;
        this.f4302n = j6;
    }

    public static Field C(Class cls, String str) {
        try {
            return cls.getDeclaredField(str);
        } catch (NoSuchFieldException unused) {
            Field[] declaredFields = cls.getDeclaredFields();
            for (Field field : declaredFields) {
                if (str.equals(field.getName())) {
                    return field;
                }
            }
            StringBuilder sbO = com.google.crypto.tink.shaded.protobuf.T.o("Field ", str, " for ");
            sbO.append(cls.getName());
            sbO.append(" not found. Known fields are ");
            sbO.append(Arrays.toString(declaredFields));
            throw new RuntimeException(sbO.toString());
        }
    }

    public static int F(int i6) {
        return (i6 & 267386880) >>> 20;
    }

    public static void J(int i6, Object obj, F f4) throws IOException {
        if (!(obj instanceof String)) {
            f4.a(i6, (C0159f) obj);
        } else {
            ((C0163j) f4.f4277a).P((String) obj, i6);
        }
    }

    public static List r(long j6, Object obj) {
        return (List) o0.f4378d.i(j6, obj);
    }

    public static N v(W w6, P p6, D d6, g0 g0Var, C0166m c0166m, J j6) {
        if (w6 instanceof W) {
            return w(w6, p6, d6, g0Var, c0166m, j6);
        }
        w6.getClass();
        throw new ClassCastException();
    }

    /* JADX WARN: Code duplicated, block: B:125:0x0283  */
    /* JADX WARN: Code duplicated, block: B:127:0x0287  */
    /* JADX WARN: Code duplicated, block: B:130:0x02a1  */
    /* JADX WARN: Code duplicated, block: B:131:0x02a4  */
    /* JADX WARN: Code duplicated, block: B:166:0x035b  */
    /* JADX WARN: Code duplicated, block: B:181:0x03a5  */
    /* JADX WARN: Code duplicated, block: B:184:0x03ad  */
    public static N w(W w6, P p6, D d6, g0 g0Var, C0166m c0166m, J j6) {
        int i6;
        int iCharAt;
        int iCharAt2;
        int i7;
        int i8;
        int[] iArr;
        int i9;
        int i10;
        int i11;
        int i12;
        char cCharAt;
        int i13;
        char cCharAt2;
        int i14;
        char cCharAt3;
        int i15;
        char cCharAt4;
        int i16;
        char cCharAt5;
        int i17;
        char cCharAt6;
        int i18;
        char cCharAt7;
        int i19;
        char cCharAt8;
        int[] iArr2;
        int i20;
        int i21;
        int i22;
        int i23;
        int iObjectFieldOffset;
        int i24;
        int i25;
        int iObjectFieldOffset2;
        int i26;
        int i27;
        Field fieldC;
        char cCharAt9;
        int i28;
        int i29;
        int i30;
        Object obj;
        Field fieldC2;
        int i31;
        Object obj2;
        Field fieldC3;
        int i32;
        char cCharAt10;
        int i33;
        char cCharAt11;
        int i34;
        int i35;
        char cCharAt12;
        int i36;
        char cCharAt13;
        char cCharAt14;
        int i37 = 0;
        boolean z6 = (w6.f4316d & 1) != 1;
        String str = w6.f4314b;
        int length = str.length();
        int iCharAt3 = str.charAt(0);
        if (iCharAt3 >= 55296) {
            int i38 = iCharAt3 & 8191;
            int i39 = 1;
            int i40 = 13;
            while (true) {
                i6 = i39 + 1;
                cCharAt14 = str.charAt(i39);
                if (cCharAt14 < 55296) {
                    break;
                }
                i38 |= (cCharAt14 & 8191) << i40;
                i40 += 13;
                i39 = i6;
            }
            iCharAt3 = i38 | (cCharAt14 << i40);
        } else {
            i6 = 1;
        }
        int i41 = i6 + 1;
        int iCharAt4 = str.charAt(i6);
        if (iCharAt4 >= 55296) {
            int i42 = iCharAt4 & 8191;
            int i43 = 13;
            while (true) {
                i36 = i41 + 1;
                cCharAt13 = str.charAt(i41);
                if (cCharAt13 < 55296) {
                    break;
                }
                i42 |= (cCharAt13 & 8191) << i43;
                i43 += 13;
                i41 = i36;
            }
            iCharAt4 = i42 | (cCharAt13 << i43);
            i41 = i36;
        }
        if (iCharAt4 == 0) {
            i9 = 0;
            i11 = 0;
            iCharAt = 0;
            iCharAt2 = 0;
            i8 = 0;
            iArr = o;
            i10 = 0;
        } else {
            int i44 = i41 + 1;
            int iCharAt5 = str.charAt(i41);
            if (iCharAt5 >= 55296) {
                int i45 = iCharAt5 & 8191;
                int i46 = 13;
                while (true) {
                    i19 = i44 + 1;
                    cCharAt8 = str.charAt(i44);
                    if (cCharAt8 < 55296) {
                        break;
                    }
                    i45 |= (cCharAt8 & 8191) << i46;
                    i46 += 13;
                    i44 = i19;
                }
                iCharAt5 = i45 | (cCharAt8 << i46);
                i44 = i19;
            }
            int i47 = i44 + 1;
            int iCharAt6 = str.charAt(i44);
            if (iCharAt6 >= 55296) {
                int i48 = iCharAt6 & 8191;
                int i49 = 13;
                while (true) {
                    i18 = i47 + 1;
                    cCharAt7 = str.charAt(i47);
                    if (cCharAt7 < 55296) {
                        break;
                    }
                    i48 |= (cCharAt7 & 8191) << i49;
                    i49 += 13;
                    i47 = i18;
                }
                iCharAt6 = i48 | (cCharAt7 << i49);
                i47 = i18;
            }
            int i50 = i47 + 1;
            int iCharAt7 = str.charAt(i47);
            if (iCharAt7 >= 55296) {
                int i51 = iCharAt7 & 8191;
                int i52 = 13;
                while (true) {
                    i17 = i50 + 1;
                    cCharAt6 = str.charAt(i50);
                    if (cCharAt6 < 55296) {
                        break;
                    }
                    i51 |= (cCharAt6 & 8191) << i52;
                    i52 += 13;
                    i50 = i17;
                }
                iCharAt7 = i51 | (cCharAt6 << i52);
                i50 = i17;
            }
            int i53 = i50 + 1;
            int iCharAt8 = str.charAt(i50);
            if (iCharAt8 >= 55296) {
                int i54 = iCharAt8 & 8191;
                int i55 = 13;
                while (true) {
                    i16 = i53 + 1;
                    cCharAt5 = str.charAt(i53);
                    if (cCharAt5 < 55296) {
                        break;
                    }
                    i54 |= (cCharAt5 & 8191) << i55;
                    i55 += 13;
                    i53 = i16;
                }
                iCharAt8 = i54 | (cCharAt5 << i55);
                i53 = i16;
            }
            int i56 = i53 + 1;
            iCharAt = str.charAt(i53);
            if (iCharAt >= 55296) {
                int i57 = iCharAt & 8191;
                int i58 = 13;
                while (true) {
                    i15 = i56 + 1;
                    cCharAt4 = str.charAt(i56);
                    if (cCharAt4 < 55296) {
                        break;
                    }
                    i57 |= (cCharAt4 & 8191) << i58;
                    i58 += 13;
                    i56 = i15;
                }
                iCharAt = i57 | (cCharAt4 << i58);
                i56 = i15;
            }
            int i59 = i56 + 1;
            iCharAt2 = str.charAt(i56);
            if (iCharAt2 >= 55296) {
                int i60 = iCharAt2 & 8191;
                int i61 = 13;
                while (true) {
                    i14 = i59 + 1;
                    cCharAt3 = str.charAt(i59);
                    if (cCharAt3 < 55296) {
                        break;
                    }
                    i60 |= (cCharAt3 & 8191) << i61;
                    i61 += 13;
                    i59 = i14;
                }
                iCharAt2 = i60 | (cCharAt3 << i61);
                i59 = i14;
            }
            int i62 = i59 + 1;
            int iCharAt9 = str.charAt(i59);
            if (iCharAt9 >= 55296) {
                int i63 = iCharAt9 & 8191;
                int i64 = i62;
                int i65 = 13;
                while (true) {
                    i13 = i64 + 1;
                    cCharAt2 = str.charAt(i64);
                    if (cCharAt2 < 55296) {
                        break;
                    }
                    i63 |= (cCharAt2 & 8191) << i65;
                    i65 += 13;
                    i64 = i13;
                }
                iCharAt9 = i63 | (cCharAt2 << i65);
                i7 = i13;
            } else {
                i7 = i62;
            }
            int i66 = i7 + 1;
            int iCharAt10 = str.charAt(i7);
            if (iCharAt10 >= 55296) {
                int i67 = iCharAt10 & 8191;
                int i68 = i66;
                int i69 = 13;
                while (true) {
                    i12 = i68 + 1;
                    cCharAt = str.charAt(i68);
                    if (cCharAt < 55296) {
                        break;
                    }
                    i67 |= (cCharAt & 8191) << i69;
                    i69 += 13;
                    i68 = i12;
                }
                iCharAt10 = i67 | (cCharAt << i69);
                i66 = i12;
            }
            int[] iArr3 = new int[iCharAt10 + iCharAt2 + iCharAt9];
            i8 = (iCharAt5 * 2) + iCharAt6;
            int i70 = iCharAt7;
            iArr = iArr3;
            i9 = i70;
            i10 = iCharAt8;
            i11 = iCharAt10;
            i37 = iCharAt5;
            i41 = i66;
        }
        Unsafe unsafe = f4288p;
        Object[] objArr = w6.f4315c;
        int i71 = i37;
        Class<?> cls = w6.f4313a.getClass();
        int i72 = iCharAt3;
        int[] iArr4 = new int[iCharAt * 3];
        Object[] objArr2 = new Object[iCharAt * 2];
        int i73 = iCharAt2 + i11;
        int i74 = i11;
        int i75 = i73;
        int i76 = 0;
        int i77 = 0;
        while (i41 < length) {
            int i78 = i41 + 1;
            int iCharAt11 = str.charAt(i41);
            int i79 = length;
            if (iCharAt11 >= 55296) {
                int i80 = iCharAt11 & 8191;
                int i81 = i78;
                int i82 = 13;
                while (true) {
                    i35 = i81 + 1;
                    cCharAt12 = str.charAt(i81);
                    iArr2 = iArr4;
                    if (cCharAt12 < 55296) {
                        break;
                    }
                    i80 |= (cCharAt12 & 8191) << i82;
                    i82 += 13;
                    i81 = i35;
                    iArr4 = iArr2;
                }
                iCharAt11 = i80 | (cCharAt12 << i82);
                i20 = i35;
            } else {
                iArr2 = iArr4;
                i20 = i78;
            }
            int i83 = i20 + 1;
            int iCharAt12 = str.charAt(i20);
            if (iCharAt12 >= 55296) {
                int i84 = iCharAt12 & 8191;
                int i85 = i83;
                int i86 = 13;
                while (true) {
                    i33 = i85 + 1;
                    cCharAt11 = str.charAt(i85);
                    i34 = i84;
                    if (cCharAt11 < 55296) {
                        break;
                    }
                    i84 = i34 | ((cCharAt11 & 8191) << i86);
                    i86 += 13;
                    i85 = i33;
                }
                iCharAt12 = i34 | (cCharAt11 << i86);
                i21 = i33;
            } else {
                i21 = i83;
            }
            int i87 = i9;
            int i88 = iCharAt12 & 255;
            Object[] objArr3 = objArr;
            if ((iCharAt12 & 1024) != 0) {
                iArr[i76] = i77;
                i76++;
            }
            int i89 = iCharAt11;
            if (i88 >= 51) {
                int i90 = i21 + 1;
                int iCharAt13 = str.charAt(i21);
                char c2 = 55296;
                if (iCharAt13 >= 55296) {
                    int i91 = iCharAt13 & 8191;
                    int i92 = 13;
                    while (true) {
                        i32 = i90 + 1;
                        cCharAt10 = str.charAt(i90);
                        if (cCharAt10 < c2) {
                            break;
                        }
                        i91 |= (cCharAt10 & 8191) << i92;
                        i92 += 13;
                        i90 = i32;
                        c2 = 55296;
                    }
                    iCharAt13 = i91 | (cCharAt10 << i92);
                    i90 = i32;
                }
                int i93 = i88 - 51;
                int i94 = iCharAt13;
                if (i93 == 9 || i93 == 17) {
                    i29 = i8 + 1;
                    objArr2[((i77 / 3) * 2) + 1] = objArr3[i8];
                } else {
                    if (i93 == 12 && (i72 & 1) == 1) {
                        i29 = i8 + 1;
                        objArr2[((i77 / 3) * 2) + 1] = objArr3[i8];
                    }
                    i30 = i94 * 2;
                    obj = objArr3[i30];
                    if (obj instanceof Field) {
                        fieldC2 = (Field) obj;
                    } else {
                        fieldC2 = C(cls, (String) obj);
                        objArr3[i30] = fieldC2;
                    }
                    int i95 = i90;
                    int iObjectFieldOffset3 = (int) unsafe.objectFieldOffset(fieldC2);
                    i31 = i30 + 1;
                    obj2 = objArr3[i31];
                    if (obj2 instanceof Field) {
                        fieldC3 = (Field) obj2;
                    } else {
                        fieldC3 = C(cls, (String) obj2);
                        objArr3[i31] = fieldC3;
                    }
                    int i96 = i8;
                    z6 = z6;
                    i26 = i96;
                    i41 = i95;
                    i27 = iObjectFieldOffset3;
                    i22 = i10;
                    iObjectFieldOffset2 = (int) unsafe.objectFieldOffset(fieldC3);
                    i25 = 0;
                }
                i8 = i29;
                i30 = i94 * 2;
                obj = objArr3[i30];
                if (obj instanceof Field) {
                    fieldC2 = (Field) obj;
                } else {
                    fieldC2 = C(cls, (String) obj);
                    objArr3[i30] = fieldC2;
                }
                int i97 = i90;
                int iObjectFieldOffset4 = (int) unsafe.objectFieldOffset(fieldC2);
                i31 = i30 + 1;
                obj2 = objArr3[i31];
                if (obj2 instanceof Field) {
                    fieldC3 = (Field) obj2;
                } else {
                    fieldC3 = C(cls, (String) obj2);
                    objArr3[i31] = fieldC3;
                }
                int i98 = i8;
                z6 = z6;
                i26 = i98;
                i41 = i97;
                i27 = iObjectFieldOffset4;
                i22 = i10;
                iObjectFieldOffset2 = (int) unsafe.objectFieldOffset(fieldC3);
                i25 = 0;
            } else {
                int i99 = i8 + 1;
                Field fieldC4 = C(cls, (String) objArr3[i8]);
                if (i88 == 9 || i88 == 17) {
                    i22 = i10;
                    objArr2[((i77 / 3) * 2) + 1] = fieldC4.getType();
                } else {
                    if (i88 == 27 || i88 == 49) {
                        i22 = i10;
                        i28 = i8 + 2;
                        objArr2[((i77 / 3) * 2) + 1] = objArr3[i99];
                    } else if (i88 == 12 || i88 == 30 || i88 == 44) {
                        i22 = i10;
                        if ((i72 & 1) == 1) {
                            i28 = i8 + 2;
                            objArr2[((i77 / 3) * 2) + 1] = objArr3[i99];
                        }
                        iObjectFieldOffset = (int) unsafe.objectFieldOffset(fieldC4);
                        if ((i72 & 1) == 1 || i88 > 17) {
                            i24 = i21;
                            i25 = 0;
                            iObjectFieldOffset2 = 0;
                        } else {
                            int i100 = i21 + 1;
                            int iCharAt14 = str.charAt(i21);
                            if (iCharAt14 >= 55296) {
                                int i101 = iCharAt14 & 8191;
                                int i102 = 13;
                                while (true) {
                                    i24 = i100 + 1;
                                    cCharAt9 = str.charAt(i100);
                                    if (cCharAt9 < 55296) {
                                        break;
                                    }
                                    i101 |= (cCharAt9 & 8191) << i102;
                                    i102 += 13;
                                    i100 = i24;
                                }
                                iCharAt14 = i101 | (cCharAt9 << i102);
                            } else {
                                i24 = i100;
                            }
                            int i103 = (iCharAt14 / 32) + (i71 * 2);
                            Object obj3 = objArr3[i103];
                            if (obj3 instanceof Field) {
                                fieldC = (Field) obj3;
                            } else {
                                fieldC = C(cls, (String) obj3);
                                objArr3[i103] = fieldC;
                            }
                            iObjectFieldOffset2 = (int) unsafe.objectFieldOffset(fieldC);
                            i25 = iCharAt14 % 32;
                        }
                        if (i88 >= 18 && i88 <= 49) {
                            iArr[i75] = iObjectFieldOffset;
                            i75++;
                        }
                        i26 = i23;
                        i27 = iObjectFieldOffset;
                        i41 = i24;
                    } else {
                        if (i88 == 50) {
                            int i104 = i74 + 1;
                            iArr[i74] = i77;
                            int i105 = (i77 / 3) * 2;
                            int i106 = i8 + 2;
                            objArr2[i105] = objArr3[i99];
                            if ((iCharAt12 & 2048) != 0) {
                                i23 = i8 + 3;
                                objArr2[i105 + 1] = objArr3[i106];
                                i22 = i10;
                                i74 = i104;
                            } else {
                                i23 = i106;
                                i74 = i104;
                                i22 = i10;
                            }
                        } else {
                            i22 = i10;
                        }
                        iObjectFieldOffset = (int) unsafe.objectFieldOffset(fieldC4);
                        if ((i72 & 1) == 1) {
                            i24 = i21;
                            i25 = 0;
                            iObjectFieldOffset2 = 0;
                        } else {
                            i24 = i21;
                            i25 = 0;
                            iObjectFieldOffset2 = 0;
                        }
                        if (i88 >= 18) {
                            iArr[i75] = iObjectFieldOffset;
                            i75++;
                        }
                        i26 = i23;
                        i27 = iObjectFieldOffset;
                        i41 = i24;
                    }
                    i23 = i28;
                    iObjectFieldOffset = (int) unsafe.objectFieldOffset(fieldC4);
                    if ((i72 & 1) == 1) {
                        i24 = i21;
                        i25 = 0;
                        iObjectFieldOffset2 = 0;
                    } else {
                        i24 = i21;
                        i25 = 0;
                        iObjectFieldOffset2 = 0;
                    }
                    if (i88 >= 18) {
                        iArr[i75] = iObjectFieldOffset;
                        i75++;
                    }
                    i26 = i23;
                    i27 = iObjectFieldOffset;
                    i41 = i24;
                }
                i23 = i99;
                iObjectFieldOffset = (int) unsafe.objectFieldOffset(fieldC4);
                if ((i72 & 1) == 1) {
                    i24 = i21;
                    i25 = 0;
                    iObjectFieldOffset2 = 0;
                } else {
                    i24 = i21;
                    i25 = 0;
                    iObjectFieldOffset2 = 0;
                }
                if (i88 >= 18) {
                    iArr[i75] = iObjectFieldOffset;
                    i75++;
                }
                i26 = i23;
                i27 = iObjectFieldOffset;
                i41 = i24;
            }
            int i107 = i77 + 1;
            iArr2[i77] = i89;
            int i108 = i77 + 2;
            String str2 = str;
            iArr2[i107] = ((iCharAt12 & 512) != 0 ? 536870912 : 0) | ((iCharAt12 & 256) != 0 ? 268435456 : 0) | (i88 << 20) | i27;
            i77 += 3;
            iArr2[i108] = (i25 << 20) | iObjectFieldOffset2;
            boolean z7 = z6;
            i8 = i26;
            z6 = z7;
            i9 = i87;
            length = i79;
            objArr = objArr3;
            iArr4 = iArr2;
            i10 = i22;
            str = str2;
        }
        return new N(iArr4, objArr2, i9, i10, w6.f4313a, z6, iArr, i11, i73, p6, d6, g0Var, c0166m, j6);
    }

    public static long x(int i6) {
        return i6 & 1048575;
    }

    public static int y(long j6, Object obj) {
        return ((Integer) o0.f4378d.i(j6, obj)).intValue();
    }

    public static long z(long j6, Object obj) {
        return ((Long) o0.f4378d.i(j6, obj)).longValue();
    }

    public final void A(Object obj, int i6, C0161h c0161h, X x5, C0165l c0165l) throws C0175w {
        int iZ;
        List listC = this.f4300l.c(i6 & 1048575, obj);
        C0160g c0160g = (C0160g) c0161h.f4357e;
        int i7 = c0161h.f4354b;
        if ((i7 & 7) != 2) {
            throw C0176x.b();
        }
        do {
            listC.add(c0161h.D(x5, c0165l));
            if (c0160g.c() || c0161h.f4356d != 0) {
                return;
            } else {
                iZ = c0160g.z();
            }
        } while (iZ == i7);
        c0161h.f4356d = iZ;
    }

    public final void B(Object obj, int i6, C0161h c0161h) {
        if ((536870912 & i6) != 0) {
            o0.o(i6 & 1048575, obj, c0161h.P());
        } else if (this.f4294f) {
            o0.o(i6 & 1048575, obj, c0161h.N());
        } else {
            o0.o(i6 & 1048575, obj, c0161h.i());
        }
    }

    public final void D(int i6, Object obj) {
        if (this.f4295g) {
            return;
        }
        int i7 = this.f4289a[i6 + 2];
        long j6 = i7 & 1048575;
        o0.m(o0.f4378d.g(j6, obj) | (1 << (i7 >>> 20)), j6, obj);
    }

    public final void E(int i6, int i7, Object obj) {
        o0.m(i6, this.f4289a[i7 + 2] & 1048575, obj);
    }

    public final int G(int i6) {
        return this.f4289a[i6 + 1];
    }

    public final void H(Object obj, F f4) throws IOException {
        int i6;
        int i7;
        int i8;
        boolean z6;
        int[] iArr = this.f4289a;
        int length = iArr.length;
        Unsafe unsafe = f4288p;
        int i9 = -1;
        int i10 = 0;
        for (int i11 = 0; i11 < length; i11 = i8 + 3) {
            int iG = G(i11);
            int i12 = iArr[i11];
            int iF = F(iG);
            if (this.f4295g || iF > 17) {
                i6 = 1048575;
                i7 = 0;
            } else {
                int i13 = iArr[i11 + 2];
                i6 = 1048575;
                int i14 = i13 & 1048575;
                if (i14 != i9) {
                    i10 = unsafe.getInt(obj, i14);
                    i9 = i14;
                }
                i7 = 1 << (i13 >>> 20);
            }
            long j6 = iG & i6;
            switch (iF) {
                case 0:
                    i8 = i11;
                    if ((i7 & i10) != 0) {
                        double dE = o0.f4378d.e(j6, obj);
                        C0163j c0163j = (C0163j) f4.f4277a;
                        c0163j.getClass();
                        c0163j.K(Double.doubleToRawLongBits(dE), i12);
                    }
                    break;
                case 1:
                    i8 = i11;
                    if ((i7 & i10) != 0) {
                        float f7 = o0.f4378d.f(j6, obj);
                        C0163j c0163j2 = (C0163j) f4.f4277a;
                        c0163j2.getClass();
                        c0163j2.I(i12, Float.floatToRawIntBits(f7));
                    }
                    break;
                case 2:
                    i8 = i11;
                    if ((i7 & i10) != 0) {
                        ((C0163j) f4.f4277a).U(unsafe.getLong(obj, j6), i12);
                    }
                    break;
                case 3:
                    i8 = i11;
                    if ((i7 & i10) != 0) {
                        ((C0163j) f4.f4277a).U(unsafe.getLong(obj, j6), i12);
                    }
                    break;
                case 4:
                    i8 = i11;
                    if ((i7 & i10) != 0) {
                        ((C0163j) f4.f4277a).M(i12, unsafe.getInt(obj, j6));
                    }
                    break;
                case 5:
                    i8 = i11;
                    if ((i7 & i10) != 0) {
                        ((C0163j) f4.f4277a).K(unsafe.getLong(obj, j6), i12);
                    }
                    break;
                case 6:
                    i8 = i11;
                    if ((i7 & i10) != 0) {
                        ((C0163j) f4.f4277a).I(i12, unsafe.getInt(obj, j6));
                    }
                    break;
                case 7:
                    i8 = i11;
                    if ((i7 & i10) != 0) {
                        ((C0163j) f4.f4277a).F(i12, o0.f4378d.c(j6, obj));
                    }
                    break;
                case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                    i8 = i11;
                    if ((i7 & i10) != 0) {
                        J(i12, unsafe.getObject(obj, j6), f4);
                    }
                    break;
                case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                    i8 = i11;
                    if ((i7 & i10) != 0) {
                        ((C0163j) f4.f4277a).O(i12, (AbstractC0154a) unsafe.getObject(obj, j6), m(i8));
                    }
                    break;
                case 10:
                    i8 = i11;
                    if ((i7 & i10) != 0) {
                        f4.a(i12, (C0159f) unsafe.getObject(obj, j6));
                    }
                    break;
                case 11:
                    i8 = i11;
                    if ((i7 & i10) != 0) {
                        ((C0163j) f4.f4277a).S(i12, unsafe.getInt(obj, j6));
                    }
                    break;
                case 12:
                    i8 = i11;
                    if ((i7 & i10) != 0) {
                        ((C0163j) f4.f4277a).M(i12, unsafe.getInt(obj, j6));
                    }
                    break;
                case 13:
                    i8 = i11;
                    if ((i7 & i10) != 0) {
                        ((C0163j) f4.f4277a).I(i12, unsafe.getInt(obj, j6));
                    }
                    break;
                case 14:
                    i8 = i11;
                    if ((i7 & i10) != 0) {
                        ((C0163j) f4.f4277a).K(unsafe.getLong(obj, j6), i12);
                    }
                    break;
                case 15:
                    i8 = i11;
                    if ((i7 & i10) != 0) {
                        int i15 = unsafe.getInt(obj, j6);
                        ((C0163j) f4.f4277a).S(i12, (i15 >> 31) ^ (i15 << 1));
                    }
                    break;
                case 16:
                    i8 = i11;
                    if ((i7 & i10) != 0) {
                        long j7 = unsafe.getLong(obj, j6);
                        ((C0163j) f4.f4277a).U((j7 >> 63) ^ (j7 << 1), i12);
                    }
                    break;
                case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                    i8 = i11;
                    if ((i7 & i10) != 0) {
                        f4.b(i12, unsafe.getObject(obj, j6), m(i8));
                    }
                    break;
                case 18:
                    i8 = i11;
                    Y.A(iArr[i8], (List) unsafe.getObject(obj, j6), f4, false);
                    break;
                case 19:
                    i8 = i11;
                    Y.E(iArr[i8], (List) unsafe.getObject(obj, j6), f4, false);
                    break;
                case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
                    i8 = i11;
                    Y.H(iArr[i8], (List) unsafe.getObject(obj, j6), f4, false);
                    break;
                case 21:
                    i8 = i11;
                    Y.P(iArr[i8], (List) unsafe.getObject(obj, j6), f4, false);
                    break;
                case 22:
                    i8 = i11;
                    Y.G(iArr[i8], (List) unsafe.getObject(obj, j6), f4, false);
                    break;
                case 23:
                    i8 = i11;
                    Y.D(iArr[i8], (List) unsafe.getObject(obj, j6), f4, false);
                    break;
                case 24:
                    i8 = i11;
                    Y.C(iArr[i8], (List) unsafe.getObject(obj, j6), f4, false);
                    break;
                case 25:
                    i8 = i11;
                    Y.y(iArr[i8], (List) unsafe.getObject(obj, j6), f4, false);
                    break;
                case 26:
                    i8 = i11;
                    Y.N(iArr[i8], (List) unsafe.getObject(obj, j6), f4);
                    break;
                case 27:
                    i8 = i11;
                    Y.I(iArr[i8], (List) unsafe.getObject(obj, j6), f4, m(i8));
                    break;
                case 28:
                    i8 = i11;
                    Y.z(iArr[i8], (List) unsafe.getObject(obj, j6), f4);
                    break;
                case 29:
                    i8 = i11;
                    z6 = false;
                    Y.O(iArr[i8], (List) unsafe.getObject(obj, j6), f4, false);
                    break;
                case 30:
                    i8 = i11;
                    z6 = false;
                    Y.B(iArr[i8], (List) unsafe.getObject(obj, j6), f4, false);
                    break;
                case 31:
                    i8 = i11;
                    z6 = false;
                    Y.J(iArr[i8], (List) unsafe.getObject(obj, j6), f4, false);
                    break;
                case 32:
                    i8 = i11;
                    z6 = false;
                    Y.K(iArr[i8], (List) unsafe.getObject(obj, j6), f4, false);
                    break;
                case 33:
                    i8 = i11;
                    z6 = false;
                    Y.L(iArr[i8], (List) unsafe.getObject(obj, j6), f4, false);
                    break;
                case 34:
                    i8 = i11;
                    z6 = false;
                    Y.M(iArr[i8], (List) unsafe.getObject(obj, j6), f4, false);
                    break;
                case 35:
                    i8 = i11;
                    Y.A(iArr[i8], (List) unsafe.getObject(obj, j6), f4, true);
                    break;
                case 36:
                    i8 = i11;
                    Y.E(iArr[i8], (List) unsafe.getObject(obj, j6), f4, true);
                    break;
                case 37:
                    i8 = i11;
                    Y.H(iArr[i8], (List) unsafe.getObject(obj, j6), f4, true);
                    break;
                case 38:
                    i8 = i11;
                    Y.P(iArr[i8], (List) unsafe.getObject(obj, j6), f4, true);
                    break;
                case 39:
                    i8 = i11;
                    Y.G(iArr[i8], (List) unsafe.getObject(obj, j6), f4, true);
                    break;
                case 40:
                    i8 = i11;
                    Y.D(iArr[i8], (List) unsafe.getObject(obj, j6), f4, true);
                    break;
                case 41:
                    i8 = i11;
                    Y.C(iArr[i8], (List) unsafe.getObject(obj, j6), f4, true);
                    break;
                case 42:
                    i8 = i11;
                    Y.y(iArr[i8], (List) unsafe.getObject(obj, j6), f4, true);
                    break;
                case 43:
                    i8 = i11;
                    Y.O(iArr[i8], (List) unsafe.getObject(obj, j6), f4, true);
                    break;
                case 44:
                    i8 = i11;
                    Y.B(iArr[i8], (List) unsafe.getObject(obj, j6), f4, true);
                    break;
                case 45:
                    i8 = i11;
                    Y.J(iArr[i8], (List) unsafe.getObject(obj, j6), f4, true);
                    break;
                case 46:
                    i8 = i11;
                    Y.K(iArr[i8], (List) unsafe.getObject(obj, j6), f4, true);
                    break;
                case 47:
                    i8 = i11;
                    Y.L(iArr[i8], (List) unsafe.getObject(obj, j6), f4, true);
                    break;
                case 48:
                    i8 = i11;
                    Y.M(iArr[i8], (List) unsafe.getObject(obj, j6), f4, true);
                    break;
                case 49:
                    i8 = i11;
                    Y.F(iArr[i8], (List) unsafe.getObject(obj, j6), f4, m(i8));
                    break;
                case 50:
                    i8 = i11;
                    I(f4, i12, unsafe.getObject(obj, j6), i8);
                    break;
                case 51:
                    i8 = i11;
                    if (q(i12, i8, obj)) {
                        double dDoubleValue = ((Double) o0.f4378d.i(j6, obj)).doubleValue();
                        C0163j c0163j3 = (C0163j) f4.f4277a;
                        c0163j3.getClass();
                        c0163j3.K(Double.doubleToRawLongBits(dDoubleValue), i12);
                    }
                    break;
                case 52:
                    i8 = i11;
                    if (q(i12, i8, obj)) {
                        float fFloatValue = ((Float) o0.f4378d.i(j6, obj)).floatValue();
                        C0163j c0163j4 = (C0163j) f4.f4277a;
                        c0163j4.getClass();
                        c0163j4.I(i12, Float.floatToRawIntBits(fFloatValue));
                    }
                    break;
                case 53:
                    i8 = i11;
                    if (q(i12, i8, obj)) {
                        ((C0163j) f4.f4277a).U(z(j6, obj), i12);
                    }
                    break;
                case 54:
                    i8 = i11;
                    if (q(i12, i8, obj)) {
                        ((C0163j) f4.f4277a).U(z(j6, obj), i12);
                    }
                    break;
                case 55:
                    i8 = i11;
                    if (q(i12, i8, obj)) {
                        ((C0163j) f4.f4277a).M(i12, y(j6, obj));
                    }
                    break;
                case 56:
                    i8 = i11;
                    if (q(i12, i8, obj)) {
                        ((C0163j) f4.f4277a).K(z(j6, obj), i12);
                    }
                    break;
                case 57:
                    i8 = i11;
                    if (q(i12, i8, obj)) {
                        ((C0163j) f4.f4277a).I(i12, y(j6, obj));
                    }
                    break;
                case 58:
                    i8 = i11;
                    if (q(i12, i8, obj)) {
                        ((C0163j) f4.f4277a).F(i12, ((Boolean) o0.f4378d.i(j6, obj)).booleanValue());
                    }
                    break;
                case 59:
                    i8 = i11;
                    if (q(i12, i8, obj)) {
                        J(i12, unsafe.getObject(obj, j6), f4);
                    }
                    break;
                case PipesConfigBase.DEFAULT_STALE_FETCHER_DELAY_SECONDS /* 60 */:
                    i8 = i11;
                    if (q(i12, i8, obj)) {
                        ((C0163j) f4.f4277a).O(i12, (AbstractC0154a) unsafe.getObject(obj, j6), m(i8));
                    }
                    break;
                case 61:
                    i8 = i11;
                    if (q(i12, i8, obj)) {
                        f4.a(i12, (C0159f) unsafe.getObject(obj, j6));
                    }
                    break;
                case 62:
                    i8 = i11;
                    if (q(i12, i8, obj)) {
                        ((C0163j) f4.f4277a).S(i12, y(j6, obj));
                    }
                    break;
                case 63:
                    i8 = i11;
                    if (q(i12, i8, obj)) {
                        ((C0163j) f4.f4277a).M(i12, y(j6, obj));
                    }
                    break;
                case 64:
                    i8 = i11;
                    if (q(i12, i8, obj)) {
                        ((C0163j) f4.f4277a).I(i12, y(j6, obj));
                    }
                    break;
                case 65:
                    i8 = i11;
                    if (q(i12, i8, obj)) {
                        ((C0163j) f4.f4277a).K(z(j6, obj), i12);
                    }
                    break;
                case 66:
                    i8 = i11;
                    if (q(i12, i8, obj)) {
                        int iY = y(j6, obj);
                        ((C0163j) f4.f4277a).S(i12, (iY >> 31) ^ (iY << 1));
                    }
                    break;
                case 67:
                    i8 = i11;
                    if (q(i12, i8, obj)) {
                        long jZ = z(j6, obj);
                        ((C0163j) f4.f4277a).U((jZ >> 63) ^ (jZ << 1), i12);
                    }
                    break;
                case 68:
                    i8 = i11;
                    if (q(i12, i8, obj)) {
                        f4.b(i12, unsafe.getObject(obj, j6), m(i8));
                    }
                    break;
                default:
                    i8 = i11;
                    break;
            }
        }
        this.f4301m.getClass();
        ((AbstractC0172t) obj).unknownFields.d(f4);
    }

    /* JADX WARN: Code duplicated, block: B:43:0x0138  */
    /* JADX WARN: Code duplicated, block: B:48:0x0147  */
    /* JADX WARN: Code duplicated, block: B:49:0x0157  */
    /* JADX WARN: Code duplicated, block: B:50:0x0168  */
    /* JADX WARN: Code duplicated, block: B:51:0x016f  */
    /* JADX WARN: Code duplicated, block: B:53:0x0178  */
    /* JADX WARN: Code duplicated, block: B:54:0x0184  */
    /* JADX WARN: Code duplicated, block: B:55:0x0190  */
    /* JADX WARN: Code duplicated, block: B:57:0x0194  */
    /* JADX WARN: Code duplicated, block: B:58:0x019c  */
    /* JADX WARN: Code duplicated, block: B:60:0x01a6  */
    /* JADX WARN: Code duplicated, block: B:61:0x01b1  */
    /* JADX WARN: Code duplicated, block: B:62:0x01b8  */
    /* JADX WARN: Code duplicated, block: B:64:0x01bc  */
    /* JADX WARN: Code duplicated, block: B:65:0x01c3  */
    /* JADX WARN: Code duplicated, block: B:66:0x01ca  */
    /* JADX WARN: Code duplicated, block: B:67:0x01d2  */
    /* JADX WARN: Code duplicated, block: B:68:0x01d8  */
    /* JADX WARN: Code duplicated, block: B:69:0x01de  */
    /* JADX WARN: Code duplicated, block: B:70:0x01e9  */
    /* JADX WARN: Code duplicated, block: B:71:0x01f4  */
    /* JADX WARN: Code duplicated, block: B:72:0x01ff  */
    /* JADX WARN: Code duplicated, block: B:73:0x0206  */
    /* JADX WARN: Code duplicated, block: B:78:0x0141 A[SYNTHETIC] */
    public final void I(F f4, int i6, Object obj, int i7) throws IOException {
        int iA;
        int iA2;
        int iZ;
        int i8;
        int iY;
        int iA3;
        int iZ2;
        if (obj != null) {
            Object objL = l(i7);
            this.f4302n.getClass();
            G g7 = ((H) objL).f4281a;
            w0 w0Var = g7.f4279b;
            w0 w0Var2 = g7.f4278a;
            C0163j c0163j = (C0163j) f4.f4277a;
            c0163j.getClass();
            for (Map.Entry entry : ((I) obj).entrySet()) {
                c0163j.R(i6, 2);
                Object key = entry.getKey();
                Object value = entry.getValue();
                int i9 = C0168o.f4372c;
                int iY2 = C0163j.y(1);
                t0 t0Var = w0.f4393u;
                if (w0Var2 == t0Var) {
                    iY2 *= 2;
                }
                int iA4 = 8;
                switch (w0Var2.ordinal()) {
                    case 0:
                        ((Double) key).getClass();
                        iA = 8;
                        i8 = iA + iY2;
                        iY = C0163j.y(2);
                        if (w0Var == t0Var) {
                            iY *= 2;
                        }
                        switch (w0Var.ordinal()) {
                            case 0:
                                ((Double) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key2 = entry.getKey();
                                Object value2 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key2);
                                C0168o.b(c0163j, w0Var, 2, value2);
                                break;
                            case 1:
                                ((Float) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key3 = entry.getKey();
                                Object value3 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key3);
                                C0168o.b(c0163j, w0Var, 2, value3);
                                break;
                            case 2:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key4 = entry.getKey();
                                Object value4 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key4);
                                C0168o.b(c0163j, w0Var, 2, value4);
                                break;
                            case 3:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key5 = entry.getKey();
                                Object value5 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key5);
                                C0168o.b(c0163j, w0Var, 2, value5);
                                break;
                            case 4:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key6 = entry.getKey();
                                Object value6 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key6);
                                C0168o.b(c0163j, w0Var, 2, value6);
                                break;
                            case 5:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key7 = entry.getKey();
                                Object value7 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key7);
                                C0168o.b(c0163j, w0Var, 2, value7);
                                break;
                            case 6:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key8 = entry.getKey();
                                Object value8 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key8);
                                C0168o.b(c0163j, w0Var, 2, value8);
                                break;
                            case 7:
                                ((Boolean) value).getClass();
                                iA4 = 1;
                                c0163j.T(iA4 + iY + i8);
                                Object key9 = entry.getKey();
                                Object value9 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key9);
                                C0168o.b(c0163j, w0Var, 2, value9);
                                break;
                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA4 = C0163j.x((String) value);
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key10 = entry.getKey();
                                Object value10 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key10);
                                C0168o.b(c0163j, w0Var, 2, value10);
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                iA4 = ((AbstractC0154a) value).a();
                                c0163j.T(iA4 + iY + i8);
                                Object key11 = entry.getKey();
                                Object value11 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11);
                                C0168o.b(c0163j, w0Var, 2, value11);
                                break;
                            case 10:
                                iA3 = ((AbstractC0154a) value).a();
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                                c0163j.T(iA4 + iY + i8);
                                Object key12 = entry.getKey();
                                Object value12 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key12);
                                C0168o.b(c0163j, w0Var, 2, value12);
                                break;
                            case 11:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA3 = ((byte[]) value).length;
                                    iZ2 = C0163j.z(iA3);
                                    iA4 = iZ2 + iA3;
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key13 = entry.getKey();
                                Object value13 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key13);
                                C0168o.b(c0163j, w0Var, 2, value13);
                                break;
                            case 12:
                                iA4 = C0163j.z(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key14 = entry.getKey();
                                Object value14 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key14);
                                C0168o.b(c0163j, w0Var, 2, value14);
                                break;
                            case 13:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key15 = entry.getKey();
                                Object value15 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key15);
                                C0168o.b(c0163j, w0Var, 2, value15);
                                break;
                            case 14:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key16 = entry.getKey();
                                Object value16 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key16);
                                C0168o.b(c0163j, w0Var, 2, value16);
                                break;
                            case 15:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key17 = entry.getKey();
                                Object value17 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key17);
                                C0168o.b(c0163j, w0Var, 2, value17);
                                break;
                            case 16:
                                int iIntValue = ((Integer) value).intValue();
                                iA4 = C0163j.z((iIntValue >> 31) ^ (iIntValue << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key18 = entry.getKey();
                                Object value18 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key18);
                                C0168o.b(c0163j, w0Var, 2, value18);
                                break;
                            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                long jLongValue = ((Long) value).longValue();
                                iA4 = C0163j.A((jLongValue >> 63) ^ (jLongValue << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key19 = entry.getKey();
                                Object value19 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key19);
                                C0168o.b(c0163j, w0Var, 2, value19);
                                break;
                            default:
                                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                        }
                        break;
                    case 1:
                        ((Float) key).getClass();
                        iA = 4;
                        i8 = iA + iY2;
                        iY = C0163j.y(2);
                        if (w0Var == t0Var) {
                            iY *= 2;
                        }
                        switch (w0Var.ordinal()) {
                            case 0:
                                ((Double) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key110 = entry.getKey();
                                Object value110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key110);
                                C0168o.b(c0163j, w0Var, 2, value110);
                                break;
                            case 1:
                                ((Float) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111 = entry.getKey();
                                Object value111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111);
                                C0168o.b(c0163j, w0Var, 2, value111);
                                break;
                            case 2:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key112 = entry.getKey();
                                Object value112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key112);
                                C0168o.b(c0163j, w0Var, 2, value112);
                                break;
                            case 3:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key113 = entry.getKey();
                                Object value113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key113);
                                C0168o.b(c0163j, w0Var, 2, value113);
                                break;
                            case 4:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key114 = entry.getKey();
                                Object value114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key114);
                                C0168o.b(c0163j, w0Var, 2, value114);
                                break;
                            case 5:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key115 = entry.getKey();
                                Object value115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key115);
                                C0168o.b(c0163j, w0Var, 2, value115);
                                break;
                            case 6:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key116 = entry.getKey();
                                Object value116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key116);
                                C0168o.b(c0163j, w0Var, 2, value116);
                                break;
                            case 7:
                                ((Boolean) value).getClass();
                                iA4 = 1;
                                c0163j.T(iA4 + iY + i8);
                                Object key117 = entry.getKey();
                                Object value117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key117);
                                C0168o.b(c0163j, w0Var, 2, value117);
                                break;
                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA4 = C0163j.x((String) value);
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key118 = entry.getKey();
                                Object value118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key118);
                                C0168o.b(c0163j, w0Var, 2, value118);
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                iA4 = ((AbstractC0154a) value).a();
                                c0163j.T(iA4 + iY + i8);
                                Object key119 = entry.getKey();
                                Object value119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key119);
                                C0168o.b(c0163j, w0Var, 2, value119);
                                break;
                            case 10:
                                iA3 = ((AbstractC0154a) value).a();
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                                c0163j.T(iA4 + iY + i8);
                                Object key1110 = entry.getKey();
                                Object value1110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1110);
                                C0168o.b(c0163j, w0Var, 2, value1110);
                                break;
                            case 11:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA3 = ((byte[]) value).length;
                                    iZ2 = C0163j.z(iA3);
                                    iA4 = iZ2 + iA3;
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key1111 = entry.getKey();
                                Object value1111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111);
                                C0168o.b(c0163j, w0Var, 2, value1111);
                                break;
                            case 12:
                                iA4 = C0163j.z(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1112 = entry.getKey();
                                Object value1112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1112);
                                C0168o.b(c0163j, w0Var, 2, value1112);
                                break;
                            case 13:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1113 = entry.getKey();
                                Object value1113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1113);
                                C0168o.b(c0163j, w0Var, 2, value1113);
                                break;
                            case 14:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key1114 = entry.getKey();
                                Object value1114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1114);
                                C0168o.b(c0163j, w0Var, 2, value1114);
                                break;
                            case 15:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key1115 = entry.getKey();
                                Object value1115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1115);
                                C0168o.b(c0163j, w0Var, 2, value1115);
                                break;
                            case 16:
                                int iIntValue2 = ((Integer) value).intValue();
                                iA4 = C0163j.z((iIntValue2 >> 31) ^ (iIntValue2 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key1116 = entry.getKey();
                                Object value1116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1116);
                                C0168o.b(c0163j, w0Var, 2, value1116);
                                break;
                            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                long jLongValue2 = ((Long) value).longValue();
                                iA4 = C0163j.A((jLongValue2 >> 63) ^ (jLongValue2 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key1117 = entry.getKey();
                                Object value1117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1117);
                                C0168o.b(c0163j, w0Var, 2, value1117);
                                break;
                            default:
                                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                        }
                        break;
                    case 2:
                        iA = C0163j.A(((Long) key).longValue());
                        i8 = iA + iY2;
                        iY = C0163j.y(2);
                        if (w0Var == t0Var) {
                            iY *= 2;
                        }
                        switch (w0Var.ordinal()) {
                            case 0:
                                ((Double) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key1118 = entry.getKey();
                                Object value1118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1118);
                                C0168o.b(c0163j, w0Var, 2, value1118);
                                break;
                            case 1:
                                ((Float) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key1119 = entry.getKey();
                                Object value1119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1119);
                                C0168o.b(c0163j, w0Var, 2, value1119);
                                break;
                            case 2:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11110 = entry.getKey();
                                Object value11110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11110);
                                C0168o.b(c0163j, w0Var, 2, value11110);
                                break;
                            case 3:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111 = entry.getKey();
                                Object value11111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111);
                                C0168o.b(c0163j, w0Var, 2, value11111);
                                break;
                            case 4:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11112 = entry.getKey();
                                Object value11112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11112);
                                C0168o.b(c0163j, w0Var, 2, value11112);
                                break;
                            case 5:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key11113 = entry.getKey();
                                Object value11113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11113);
                                C0168o.b(c0163j, w0Var, 2, value11113);
                                break;
                            case 6:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key11114 = entry.getKey();
                                Object value11114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11114);
                                C0168o.b(c0163j, w0Var, 2, value11114);
                                break;
                            case 7:
                                ((Boolean) value).getClass();
                                iA4 = 1;
                                c0163j.T(iA4 + iY + i8);
                                Object key11115 = entry.getKey();
                                Object value11115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11115);
                                C0168o.b(c0163j, w0Var, 2, value11115);
                                break;
                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA4 = C0163j.x((String) value);
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key11116 = entry.getKey();
                                Object value11116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11116);
                                C0168o.b(c0163j, w0Var, 2, value11116);
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                iA4 = ((AbstractC0154a) value).a();
                                c0163j.T(iA4 + iY + i8);
                                Object key11117 = entry.getKey();
                                Object value11117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11117);
                                C0168o.b(c0163j, w0Var, 2, value11117);
                                break;
                            case 10:
                                iA3 = ((AbstractC0154a) value).a();
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                                c0163j.T(iA4 + iY + i8);
                                Object key11118 = entry.getKey();
                                Object value11118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11118);
                                C0168o.b(c0163j, w0Var, 2, value11118);
                                break;
                            case 11:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA3 = ((byte[]) value).length;
                                    iZ2 = C0163j.z(iA3);
                                    iA4 = iZ2 + iA3;
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key11119 = entry.getKey();
                                Object value11119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11119);
                                C0168o.b(c0163j, w0Var, 2, value11119);
                                break;
                            case 12:
                                iA4 = C0163j.z(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111110 = entry.getKey();
                                Object value111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111110);
                                C0168o.b(c0163j, w0Var, 2, value111110);
                                break;
                            case 13:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111 = entry.getKey();
                                Object value111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111);
                                C0168o.b(c0163j, w0Var, 2, value111111);
                                break;
                            case 14:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111112 = entry.getKey();
                                Object value111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111112);
                                C0168o.b(c0163j, w0Var, 2, value111112);
                                break;
                            case 15:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key111113 = entry.getKey();
                                Object value111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111113);
                                C0168o.b(c0163j, w0Var, 2, value111113);
                                break;
                            case 16:
                                int iIntValue3 = ((Integer) value).intValue();
                                iA4 = C0163j.z((iIntValue3 >> 31) ^ (iIntValue3 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key111114 = entry.getKey();
                                Object value111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111114);
                                C0168o.b(c0163j, w0Var, 2, value111114);
                                break;
                            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                long jLongValue3 = ((Long) value).longValue();
                                iA4 = C0163j.A((jLongValue3 >> 63) ^ (jLongValue3 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key111115 = entry.getKey();
                                Object value111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111115);
                                C0168o.b(c0163j, w0Var, 2, value111115);
                                break;
                            default:
                                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                        }
                        break;
                    case 3:
                        iA = C0163j.A(((Long) key).longValue());
                        i8 = iA + iY2;
                        iY = C0163j.y(2);
                        if (w0Var == t0Var) {
                            iY *= 2;
                        }
                        switch (w0Var.ordinal()) {
                            case 0:
                                ((Double) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key111116 = entry.getKey();
                                Object value111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111116);
                                C0168o.b(c0163j, w0Var, 2, value111116);
                                break;
                            case 1:
                                ((Float) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111117 = entry.getKey();
                                Object value111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111117);
                                C0168o.b(c0163j, w0Var, 2, value111117);
                                break;
                            case 2:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111118 = entry.getKey();
                                Object value111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111118);
                                C0168o.b(c0163j, w0Var, 2, value111118);
                                break;
                            case 3:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111119 = entry.getKey();
                                Object value111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111119);
                                C0168o.b(c0163j, w0Var, 2, value111119);
                                break;
                            case 4:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111110 = entry.getKey();
                                Object value1111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111110);
                                C0168o.b(c0163j, w0Var, 2, value1111110);
                                break;
                            case 5:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111 = entry.getKey();
                                Object value1111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111);
                                C0168o.b(c0163j, w0Var, 2, value1111111);
                                break;
                            case 6:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111112 = entry.getKey();
                                Object value1111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111112);
                                C0168o.b(c0163j, w0Var, 2, value1111112);
                                break;
                            case 7:
                                ((Boolean) value).getClass();
                                iA4 = 1;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111113 = entry.getKey();
                                Object value1111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111113);
                                C0168o.b(c0163j, w0Var, 2, value1111113);
                                break;
                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA4 = C0163j.x((String) value);
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key1111114 = entry.getKey();
                                Object value1111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111114);
                                C0168o.b(c0163j, w0Var, 2, value1111114);
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                iA4 = ((AbstractC0154a) value).a();
                                c0163j.T(iA4 + iY + i8);
                                Object key1111115 = entry.getKey();
                                Object value1111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111115);
                                C0168o.b(c0163j, w0Var, 2, value1111115);
                                break;
                            case 10:
                                iA3 = ((AbstractC0154a) value).a();
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111116 = entry.getKey();
                                Object value1111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111116);
                                C0168o.b(c0163j, w0Var, 2, value1111116);
                                break;
                            case 11:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA3 = ((byte[]) value).length;
                                    iZ2 = C0163j.z(iA3);
                                    iA4 = iZ2 + iA3;
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key1111117 = entry.getKey();
                                Object value1111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111117);
                                C0168o.b(c0163j, w0Var, 2, value1111117);
                                break;
                            case 12:
                                iA4 = C0163j.z(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111118 = entry.getKey();
                                Object value1111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111118);
                                C0168o.b(c0163j, w0Var, 2, value1111118);
                                break;
                            case 13:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111119 = entry.getKey();
                                Object value1111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111119);
                                C0168o.b(c0163j, w0Var, 2, value1111119);
                                break;
                            case 14:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111110 = entry.getKey();
                                Object value11111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111110);
                                C0168o.b(c0163j, w0Var, 2, value11111110);
                                break;
                            case 15:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111 = entry.getKey();
                                Object value11111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111);
                                C0168o.b(c0163j, w0Var, 2, value11111111);
                                break;
                            case 16:
                                int iIntValue4 = ((Integer) value).intValue();
                                iA4 = C0163j.z((iIntValue4 >> 31) ^ (iIntValue4 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key11111112 = entry.getKey();
                                Object value11111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111112);
                                C0168o.b(c0163j, w0Var, 2, value11111112);
                                break;
                            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                long jLongValue4 = ((Long) value).longValue();
                                iA4 = C0163j.A((jLongValue4 >> 63) ^ (jLongValue4 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key11111113 = entry.getKey();
                                Object value11111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111113);
                                C0168o.b(c0163j, w0Var, 2, value11111113);
                                break;
                            default:
                                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                        }
                        break;
                    case 4:
                        iA = C0163j.w(((Integer) key).intValue());
                        i8 = iA + iY2;
                        iY = C0163j.y(2);
                        if (w0Var == t0Var) {
                            iY *= 2;
                        }
                        switch (w0Var.ordinal()) {
                            case 0:
                                ((Double) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111114 = entry.getKey();
                                Object value11111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111114);
                                C0168o.b(c0163j, w0Var, 2, value11111114);
                                break;
                            case 1:
                                ((Float) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111115 = entry.getKey();
                                Object value11111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111115);
                                C0168o.b(c0163j, w0Var, 2, value11111115);
                                break;
                            case 2:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111116 = entry.getKey();
                                Object value11111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111116);
                                C0168o.b(c0163j, w0Var, 2, value11111116);
                                break;
                            case 3:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111117 = entry.getKey();
                                Object value11111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111117);
                                C0168o.b(c0163j, w0Var, 2, value11111117);
                                break;
                            case 4:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111118 = entry.getKey();
                                Object value11111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111118);
                                C0168o.b(c0163j, w0Var, 2, value11111118);
                                break;
                            case 5:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111119 = entry.getKey();
                                Object value11111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111119);
                                C0168o.b(c0163j, w0Var, 2, value11111119);
                                break;
                            case 6:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111110 = entry.getKey();
                                Object value111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111110);
                                C0168o.b(c0163j, w0Var, 2, value111111110);
                                break;
                            case 7:
                                ((Boolean) value).getClass();
                                iA4 = 1;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111 = entry.getKey();
                                Object value111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111);
                                C0168o.b(c0163j, w0Var, 2, value111111111);
                                break;
                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA4 = C0163j.x((String) value);
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key111111112 = entry.getKey();
                                Object value111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111112);
                                C0168o.b(c0163j, w0Var, 2, value111111112);
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                iA4 = ((AbstractC0154a) value).a();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111113 = entry.getKey();
                                Object value111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111113);
                                C0168o.b(c0163j, w0Var, 2, value111111113);
                                break;
                            case 10:
                                iA3 = ((AbstractC0154a) value).a();
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111114 = entry.getKey();
                                Object value111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111114);
                                C0168o.b(c0163j, w0Var, 2, value111111114);
                                break;
                            case 11:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA3 = ((byte[]) value).length;
                                    iZ2 = C0163j.z(iA3);
                                    iA4 = iZ2 + iA3;
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key111111115 = entry.getKey();
                                Object value111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111115);
                                C0168o.b(c0163j, w0Var, 2, value111111115);
                                break;
                            case 12:
                                iA4 = C0163j.z(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111116 = entry.getKey();
                                Object value111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111116);
                                C0168o.b(c0163j, w0Var, 2, value111111116);
                                break;
                            case 13:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111117 = entry.getKey();
                                Object value111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111117);
                                C0168o.b(c0163j, w0Var, 2, value111111117);
                                break;
                            case 14:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111118 = entry.getKey();
                                Object value111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111118);
                                C0168o.b(c0163j, w0Var, 2, value111111118);
                                break;
                            case 15:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111119 = entry.getKey();
                                Object value111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111119);
                                C0168o.b(c0163j, w0Var, 2, value111111119);
                                break;
                            case 16:
                                int iIntValue5 = ((Integer) value).intValue();
                                iA4 = C0163j.z((iIntValue5 >> 31) ^ (iIntValue5 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111110 = entry.getKey();
                                Object value1111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111110);
                                C0168o.b(c0163j, w0Var, 2, value1111111110);
                                break;
                            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                long jLongValue5 = ((Long) value).longValue();
                                iA4 = C0163j.A((jLongValue5 >> 63) ^ (jLongValue5 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111 = entry.getKey();
                                Object value1111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111);
                                C0168o.b(c0163j, w0Var, 2, value1111111111);
                                break;
                            default:
                                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                        }
                        break;
                    case 5:
                        ((Long) key).getClass();
                        iA = 8;
                        i8 = iA + iY2;
                        iY = C0163j.y(2);
                        if (w0Var == t0Var) {
                            iY *= 2;
                        }
                        switch (w0Var.ordinal()) {
                            case 0:
                                ((Double) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111112 = entry.getKey();
                                Object value1111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111112);
                                C0168o.b(c0163j, w0Var, 2, value1111111112);
                                break;
                            case 1:
                                ((Float) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111113 = entry.getKey();
                                Object value1111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111113);
                                C0168o.b(c0163j, w0Var, 2, value1111111113);
                                break;
                            case 2:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111114 = entry.getKey();
                                Object value1111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111114);
                                C0168o.b(c0163j, w0Var, 2, value1111111114);
                                break;
                            case 3:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111115 = entry.getKey();
                                Object value1111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111115);
                                C0168o.b(c0163j, w0Var, 2, value1111111115);
                                break;
                            case 4:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111116 = entry.getKey();
                                Object value1111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111116);
                                C0168o.b(c0163j, w0Var, 2, value1111111116);
                                break;
                            case 5:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111117 = entry.getKey();
                                Object value1111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111117);
                                C0168o.b(c0163j, w0Var, 2, value1111111117);
                                break;
                            case 6:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111118 = entry.getKey();
                                Object value1111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111118);
                                C0168o.b(c0163j, w0Var, 2, value1111111118);
                                break;
                            case 7:
                                ((Boolean) value).getClass();
                                iA4 = 1;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111119 = entry.getKey();
                                Object value1111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111119);
                                C0168o.b(c0163j, w0Var, 2, value1111111119);
                                break;
                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA4 = C0163j.x((String) value);
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111110 = entry.getKey();
                                Object value11111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111110);
                                C0168o.b(c0163j, w0Var, 2, value11111111110);
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                iA4 = ((AbstractC0154a) value).a();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111 = entry.getKey();
                                Object value11111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111);
                                C0168o.b(c0163j, w0Var, 2, value11111111111);
                                break;
                            case 10:
                                iA3 = ((AbstractC0154a) value).a();
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111112 = entry.getKey();
                                Object value11111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111112);
                                C0168o.b(c0163j, w0Var, 2, value11111111112);
                                break;
                            case 11:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA3 = ((byte[]) value).length;
                                    iZ2 = C0163j.z(iA3);
                                    iA4 = iZ2 + iA3;
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111113 = entry.getKey();
                                Object value11111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111113);
                                C0168o.b(c0163j, w0Var, 2, value11111111113);
                                break;
                            case 12:
                                iA4 = C0163j.z(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111114 = entry.getKey();
                                Object value11111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111114);
                                C0168o.b(c0163j, w0Var, 2, value11111111114);
                                break;
                            case 13:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111115 = entry.getKey();
                                Object value11111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111115);
                                C0168o.b(c0163j, w0Var, 2, value11111111115);
                                break;
                            case 14:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111116 = entry.getKey();
                                Object value11111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111116);
                                C0168o.b(c0163j, w0Var, 2, value11111111116);
                                break;
                            case 15:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111117 = entry.getKey();
                                Object value11111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111117);
                                C0168o.b(c0163j, w0Var, 2, value11111111117);
                                break;
                            case 16:
                                int iIntValue6 = ((Integer) value).intValue();
                                iA4 = C0163j.z((iIntValue6 >> 31) ^ (iIntValue6 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111118 = entry.getKey();
                                Object value11111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111118);
                                C0168o.b(c0163j, w0Var, 2, value11111111118);
                                break;
                            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                long jLongValue6 = ((Long) value).longValue();
                                iA4 = C0163j.A((jLongValue6 >> 63) ^ (jLongValue6 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111119 = entry.getKey();
                                Object value11111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111119);
                                C0168o.b(c0163j, w0Var, 2, value11111111119);
                                break;
                            default:
                                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                        }
                        break;
                    case 6:
                        ((Integer) key).getClass();
                        iA = 4;
                        i8 = iA + iY2;
                        iY = C0163j.y(2);
                        if (w0Var == t0Var) {
                            iY *= 2;
                        }
                        switch (w0Var.ordinal()) {
                            case 0:
                                ((Double) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111110 = entry.getKey();
                                Object value111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111110);
                                C0168o.b(c0163j, w0Var, 2, value111111111110);
                                break;
                            case 1:
                                ((Float) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111 = entry.getKey();
                                Object value111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111);
                                C0168o.b(c0163j, w0Var, 2, value111111111111);
                                break;
                            case 2:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111112 = entry.getKey();
                                Object value111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111112);
                                C0168o.b(c0163j, w0Var, 2, value111111111112);
                                break;
                            case 3:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111113 = entry.getKey();
                                Object value111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111113);
                                C0168o.b(c0163j, w0Var, 2, value111111111113);
                                break;
                            case 4:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111114 = entry.getKey();
                                Object value111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111114);
                                C0168o.b(c0163j, w0Var, 2, value111111111114);
                                break;
                            case 5:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111115 = entry.getKey();
                                Object value111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111115);
                                C0168o.b(c0163j, w0Var, 2, value111111111115);
                                break;
                            case 6:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111116 = entry.getKey();
                                Object value111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111116);
                                C0168o.b(c0163j, w0Var, 2, value111111111116);
                                break;
                            case 7:
                                ((Boolean) value).getClass();
                                iA4 = 1;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111117 = entry.getKey();
                                Object value111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111117);
                                C0168o.b(c0163j, w0Var, 2, value111111111117);
                                break;
                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA4 = C0163j.x((String) value);
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111118 = entry.getKey();
                                Object value111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111118);
                                C0168o.b(c0163j, w0Var, 2, value111111111118);
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                iA4 = ((AbstractC0154a) value).a();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111119 = entry.getKey();
                                Object value111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111119);
                                C0168o.b(c0163j, w0Var, 2, value111111111119);
                                break;
                            case 10:
                                iA3 = ((AbstractC0154a) value).a();
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111110 = entry.getKey();
                                Object value1111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111110);
                                C0168o.b(c0163j, w0Var, 2, value1111111111110);
                                break;
                            case 11:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA3 = ((byte[]) value).length;
                                    iZ2 = C0163j.z(iA3);
                                    iA4 = iZ2 + iA3;
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111 = entry.getKey();
                                Object value1111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111);
                                break;
                            case 12:
                                iA4 = C0163j.z(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111112 = entry.getKey();
                                Object value1111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111112);
                                C0168o.b(c0163j, w0Var, 2, value1111111111112);
                                break;
                            case 13:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111113 = entry.getKey();
                                Object value1111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111113);
                                C0168o.b(c0163j, w0Var, 2, value1111111111113);
                                break;
                            case 14:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111114 = entry.getKey();
                                Object value1111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111114);
                                C0168o.b(c0163j, w0Var, 2, value1111111111114);
                                break;
                            case 15:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111115 = entry.getKey();
                                Object value1111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111115);
                                C0168o.b(c0163j, w0Var, 2, value1111111111115);
                                break;
                            case 16:
                                int iIntValue7 = ((Integer) value).intValue();
                                iA4 = C0163j.z((iIntValue7 >> 31) ^ (iIntValue7 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111116 = entry.getKey();
                                Object value1111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111116);
                                C0168o.b(c0163j, w0Var, 2, value1111111111116);
                                break;
                            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                long jLongValue7 = ((Long) value).longValue();
                                iA4 = C0163j.A((jLongValue7 >> 63) ^ (jLongValue7 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111117 = entry.getKey();
                                Object value1111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111117);
                                C0168o.b(c0163j, w0Var, 2, value1111111111117);
                                break;
                            default:
                                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                        }
                        break;
                    case 7:
                        ((Boolean) key).getClass();
                        iA = 1;
                        i8 = iA + iY2;
                        iY = C0163j.y(2);
                        if (w0Var == t0Var) {
                            iY *= 2;
                        }
                        switch (w0Var.ordinal()) {
                            case 0:
                                ((Double) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111118 = entry.getKey();
                                Object value1111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111118);
                                C0168o.b(c0163j, w0Var, 2, value1111111111118);
                                break;
                            case 1:
                                ((Float) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111119 = entry.getKey();
                                Object value1111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111119);
                                C0168o.b(c0163j, w0Var, 2, value1111111111119);
                                break;
                            case 2:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111110 = entry.getKey();
                                Object value11111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111110);
                                C0168o.b(c0163j, w0Var, 2, value11111111111110);
                                break;
                            case 3:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111 = entry.getKey();
                                Object value11111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111);
                                break;
                            case 4:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111112 = entry.getKey();
                                Object value11111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111112);
                                C0168o.b(c0163j, w0Var, 2, value11111111111112);
                                break;
                            case 5:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111113 = entry.getKey();
                                Object value11111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111113);
                                C0168o.b(c0163j, w0Var, 2, value11111111111113);
                                break;
                            case 6:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111114 = entry.getKey();
                                Object value11111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111114);
                                C0168o.b(c0163j, w0Var, 2, value11111111111114);
                                break;
                            case 7:
                                ((Boolean) value).getClass();
                                iA4 = 1;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111115 = entry.getKey();
                                Object value11111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111115);
                                C0168o.b(c0163j, w0Var, 2, value11111111111115);
                                break;
                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA4 = C0163j.x((String) value);
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111116 = entry.getKey();
                                Object value11111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111116);
                                C0168o.b(c0163j, w0Var, 2, value11111111111116);
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                iA4 = ((AbstractC0154a) value).a();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111117 = entry.getKey();
                                Object value11111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111117);
                                C0168o.b(c0163j, w0Var, 2, value11111111111117);
                                break;
                            case 10:
                                iA3 = ((AbstractC0154a) value).a();
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111118 = entry.getKey();
                                Object value11111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111118);
                                C0168o.b(c0163j, w0Var, 2, value11111111111118);
                                break;
                            case 11:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA3 = ((byte[]) value).length;
                                    iZ2 = C0163j.z(iA3);
                                    iA4 = iZ2 + iA3;
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111119 = entry.getKey();
                                Object value11111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111119);
                                C0168o.b(c0163j, w0Var, 2, value11111111111119);
                                break;
                            case 12:
                                iA4 = C0163j.z(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111110 = entry.getKey();
                                Object value111111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111110);
                                C0168o.b(c0163j, w0Var, 2, value111111111111110);
                                break;
                            case 13:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111 = entry.getKey();
                                Object value111111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111);
                                break;
                            case 14:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111112 = entry.getKey();
                                Object value111111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111112);
                                C0168o.b(c0163j, w0Var, 2, value111111111111112);
                                break;
                            case 15:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111113 = entry.getKey();
                                Object value111111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111113);
                                C0168o.b(c0163j, w0Var, 2, value111111111111113);
                                break;
                            case 16:
                                int iIntValue8 = ((Integer) value).intValue();
                                iA4 = C0163j.z((iIntValue8 >> 31) ^ (iIntValue8 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111114 = entry.getKey();
                                Object value111111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111114);
                                C0168o.b(c0163j, w0Var, 2, value111111111111114);
                                break;
                            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                long jLongValue8 = ((Long) value).longValue();
                                iA4 = C0163j.A((jLongValue8 >> 63) ^ (jLongValue8 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111115 = entry.getKey();
                                Object value111111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111115);
                                C0168o.b(c0163j, w0Var, 2, value111111111111115);
                                break;
                            default:
                                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                        }
                        break;
                    case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                        iA = key instanceof C0159f ? C0163j.s((C0159f) key) : C0163j.x((String) key);
                        i8 = iA + iY2;
                        iY = C0163j.y(2);
                        if (w0Var == t0Var) {
                            iY *= 2;
                        }
                        switch (w0Var.ordinal()) {
                            case 0:
                                ((Double) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111116 = entry.getKey();
                                Object value111111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111116);
                                C0168o.b(c0163j, w0Var, 2, value111111111111116);
                                break;
                            case 1:
                                ((Float) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111117 = entry.getKey();
                                Object value111111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111117);
                                C0168o.b(c0163j, w0Var, 2, value111111111111117);
                                break;
                            case 2:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111118 = entry.getKey();
                                Object value111111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111118);
                                C0168o.b(c0163j, w0Var, 2, value111111111111118);
                                break;
                            case 3:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111119 = entry.getKey();
                                Object value111111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111119);
                                C0168o.b(c0163j, w0Var, 2, value111111111111119);
                                break;
                            case 4:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111110 = entry.getKey();
                                Object value1111111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111110);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111110);
                                break;
                            case 5:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111 = entry.getKey();
                                Object value1111111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111);
                                break;
                            case 6:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111112 = entry.getKey();
                                Object value1111111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111112);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111112);
                                break;
                            case 7:
                                ((Boolean) value).getClass();
                                iA4 = 1;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111113 = entry.getKey();
                                Object value1111111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111113);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111113);
                                break;
                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA4 = C0163j.x((String) value);
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111114 = entry.getKey();
                                Object value1111111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111114);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111114);
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                iA4 = ((AbstractC0154a) value).a();
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111115 = entry.getKey();
                                Object value1111111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111115);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111115);
                                break;
                            case 10:
                                iA3 = ((AbstractC0154a) value).a();
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111116 = entry.getKey();
                                Object value1111111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111116);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111116);
                                break;
                            case 11:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA3 = ((byte[]) value).length;
                                    iZ2 = C0163j.z(iA3);
                                    iA4 = iZ2 + iA3;
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111117 = entry.getKey();
                                Object value1111111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111117);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111117);
                                break;
                            case 12:
                                iA4 = C0163j.z(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111118 = entry.getKey();
                                Object value1111111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111118);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111118);
                                break;
                            case 13:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111119 = entry.getKey();
                                Object value1111111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111119);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111119);
                                break;
                            case 14:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111110 = entry.getKey();
                                Object value11111111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111110);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111110);
                                break;
                            case 15:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111 = entry.getKey();
                                Object value11111111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111);
                                break;
                            case 16:
                                int iIntValue9 = ((Integer) value).intValue();
                                iA4 = C0163j.z((iIntValue9 >> 31) ^ (iIntValue9 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111112 = entry.getKey();
                                Object value11111111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111112);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111112);
                                break;
                            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                long jLongValue9 = ((Long) value).longValue();
                                iA4 = C0163j.A((jLongValue9 >> 63) ^ (jLongValue9 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111113 = entry.getKey();
                                Object value11111111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111113);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111113);
                                break;
                            default:
                                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                        }
                        break;
                    case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                        iA = ((AbstractC0154a) key).a();
                        i8 = iA + iY2;
                        iY = C0163j.y(2);
                        if (w0Var == t0Var) {
                            iY *= 2;
                        }
                        switch (w0Var.ordinal()) {
                            case 0:
                                ((Double) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111114 = entry.getKey();
                                Object value11111111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111114);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111114);
                                break;
                            case 1:
                                ((Float) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111115 = entry.getKey();
                                Object value11111111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111115);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111115);
                                break;
                            case 2:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111116 = entry.getKey();
                                Object value11111111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111116);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111116);
                                break;
                            case 3:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111117 = entry.getKey();
                                Object value11111111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111117);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111117);
                                break;
                            case 4:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111118 = entry.getKey();
                                Object value11111111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111118);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111118);
                                break;
                            case 5:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111119 = entry.getKey();
                                Object value11111111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111119);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111119);
                                break;
                            case 6:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111110 = entry.getKey();
                                Object value111111111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111110);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111110);
                                break;
                            case 7:
                                ((Boolean) value).getClass();
                                iA4 = 1;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111 = entry.getKey();
                                Object value111111111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111);
                                break;
                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA4 = C0163j.x((String) value);
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111112 = entry.getKey();
                                Object value111111111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111112);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111112);
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                iA4 = ((AbstractC0154a) value).a();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111113 = entry.getKey();
                                Object value111111111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111113);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111113);
                                break;
                            case 10:
                                iA3 = ((AbstractC0154a) value).a();
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111114 = entry.getKey();
                                Object value111111111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111114);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111114);
                                break;
                            case 11:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA3 = ((byte[]) value).length;
                                    iZ2 = C0163j.z(iA3);
                                    iA4 = iZ2 + iA3;
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111115 = entry.getKey();
                                Object value111111111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111115);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111115);
                                break;
                            case 12:
                                iA4 = C0163j.z(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111116 = entry.getKey();
                                Object value111111111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111116);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111116);
                                break;
                            case 13:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111117 = entry.getKey();
                                Object value111111111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111117);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111117);
                                break;
                            case 14:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111118 = entry.getKey();
                                Object value111111111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111118);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111118);
                                break;
                            case 15:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111119 = entry.getKey();
                                Object value111111111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111119);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111119);
                                break;
                            case 16:
                                int iIntValue10 = ((Integer) value).intValue();
                                iA4 = C0163j.z((iIntValue10 >> 31) ^ (iIntValue10 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111110 = entry.getKey();
                                Object value1111111111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111110);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111110);
                                break;
                            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                long jLongValue10 = ((Long) value).longValue();
                                iA4 = C0163j.A((jLongValue10 >> 63) ^ (jLongValue10 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111 = entry.getKey();
                                Object value1111111111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111);
                                break;
                            default:
                                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                        }
                        break;
                    case 10:
                        iA2 = ((AbstractC0154a) key).a();
                        iZ = C0163j.z(iA2);
                        iA = iA2 + iZ;
                        i8 = iA + iY2;
                        iY = C0163j.y(2);
                        if (w0Var == t0Var) {
                            iY *= 2;
                        }
                        switch (w0Var.ordinal()) {
                            case 0:
                                ((Double) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111112 = entry.getKey();
                                Object value1111111111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111112);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111112);
                                break;
                            case 1:
                                ((Float) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111113 = entry.getKey();
                                Object value1111111111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111113);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111113);
                                break;
                            case 2:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111114 = entry.getKey();
                                Object value1111111111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111114);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111114);
                                break;
                            case 3:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111115 = entry.getKey();
                                Object value1111111111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111115);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111115);
                                break;
                            case 4:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111116 = entry.getKey();
                                Object value1111111111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111116);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111116);
                                break;
                            case 5:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111117 = entry.getKey();
                                Object value1111111111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111117);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111117);
                                break;
                            case 6:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111118 = entry.getKey();
                                Object value1111111111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111118);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111118);
                                break;
                            case 7:
                                ((Boolean) value).getClass();
                                iA4 = 1;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111119 = entry.getKey();
                                Object value1111111111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111119);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111119);
                                break;
                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA4 = C0163j.x((String) value);
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111110 = entry.getKey();
                                Object value11111111111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111110);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111110);
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                iA4 = ((AbstractC0154a) value).a();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111 = entry.getKey();
                                Object value11111111111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111);
                                break;
                            case 10:
                                iA3 = ((AbstractC0154a) value).a();
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111112 = entry.getKey();
                                Object value11111111111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111112);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111112);
                                break;
                            case 11:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA3 = ((byte[]) value).length;
                                    iZ2 = C0163j.z(iA3);
                                    iA4 = iZ2 + iA3;
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111113 = entry.getKey();
                                Object value11111111111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111113);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111113);
                                break;
                            case 12:
                                iA4 = C0163j.z(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111114 = entry.getKey();
                                Object value11111111111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111114);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111114);
                                break;
                            case 13:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111115 = entry.getKey();
                                Object value11111111111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111115);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111115);
                                break;
                            case 14:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111116 = entry.getKey();
                                Object value11111111111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111116);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111116);
                                break;
                            case 15:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111117 = entry.getKey();
                                Object value11111111111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111117);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111117);
                                break;
                            case 16:
                                int iIntValue11 = ((Integer) value).intValue();
                                iA4 = C0163j.z((iIntValue11 >> 31) ^ (iIntValue11 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111118 = entry.getKey();
                                Object value11111111111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111118);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111118);
                                break;
                            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                long jLongValue11 = ((Long) value).longValue();
                                iA4 = C0163j.A((jLongValue11 >> 63) ^ (jLongValue11 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111119 = entry.getKey();
                                Object value11111111111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111119);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111119);
                                break;
                            default:
                                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                        }
                        break;
                    case 11:
                        if (key instanceof C0159f) {
                            iA = C0163j.s((C0159f) key);
                        } else {
                            iA2 = ((byte[]) key).length;
                            iZ = C0163j.z(iA2);
                            iA = iA2 + iZ;
                        }
                        i8 = iA + iY2;
                        iY = C0163j.y(2);
                        if (w0Var == t0Var) {
                            iY *= 2;
                        }
                        switch (w0Var.ordinal()) {
                            case 0:
                                ((Double) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111110 = entry.getKey();
                                Object value111111111111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111110);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111110);
                                break;
                            case 1:
                                ((Float) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111 = entry.getKey();
                                Object value111111111111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111);
                                break;
                            case 2:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111112 = entry.getKey();
                                Object value111111111111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111112);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111112);
                                break;
                            case 3:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111113 = entry.getKey();
                                Object value111111111111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111113);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111113);
                                break;
                            case 4:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111114 = entry.getKey();
                                Object value111111111111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111114);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111114);
                                break;
                            case 5:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111115 = entry.getKey();
                                Object value111111111111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111115);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111115);
                                break;
                            case 6:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111116 = entry.getKey();
                                Object value111111111111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111116);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111116);
                                break;
                            case 7:
                                ((Boolean) value).getClass();
                                iA4 = 1;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111117 = entry.getKey();
                                Object value111111111111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111117);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111117);
                                break;
                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA4 = C0163j.x((String) value);
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111118 = entry.getKey();
                                Object value111111111111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111118);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111118);
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                iA4 = ((AbstractC0154a) value).a();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111119 = entry.getKey();
                                Object value111111111111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111119);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111119);
                                break;
                            case 10:
                                iA3 = ((AbstractC0154a) value).a();
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111110 = entry.getKey();
                                Object value1111111111111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111110);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111110);
                                break;
                            case 11:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA3 = ((byte[]) value).length;
                                    iZ2 = C0163j.z(iA3);
                                    iA4 = iZ2 + iA3;
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111 = entry.getKey();
                                Object value1111111111111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111);
                                break;
                            case 12:
                                iA4 = C0163j.z(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111112 = entry.getKey();
                                Object value1111111111111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111112);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111112);
                                break;
                            case 13:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111113 = entry.getKey();
                                Object value1111111111111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111113);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111113);
                                break;
                            case 14:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111114 = entry.getKey();
                                Object value1111111111111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111114);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111114);
                                break;
                            case 15:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111115 = entry.getKey();
                                Object value1111111111111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111115);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111115);
                                break;
                            case 16:
                                int iIntValue12 = ((Integer) value).intValue();
                                iA4 = C0163j.z((iIntValue12 >> 31) ^ (iIntValue12 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111116 = entry.getKey();
                                Object value1111111111111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111116);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111116);
                                break;
                            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                long jLongValue12 = ((Long) value).longValue();
                                iA4 = C0163j.A((jLongValue12 >> 63) ^ (jLongValue12 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111117 = entry.getKey();
                                Object value1111111111111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111117);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111117);
                                break;
                            default:
                                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                        }
                        break;
                    case 12:
                        iA = C0163j.z(((Integer) key).intValue());
                        i8 = iA + iY2;
                        iY = C0163j.y(2);
                        if (w0Var == t0Var) {
                            iY *= 2;
                        }
                        switch (w0Var.ordinal()) {
                            case 0:
                                ((Double) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111118 = entry.getKey();
                                Object value1111111111111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111118);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111118);
                                break;
                            case 1:
                                ((Float) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111119 = entry.getKey();
                                Object value1111111111111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111119);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111119);
                                break;
                            case 2:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111110 = entry.getKey();
                                Object value11111111111111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111110);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111110);
                                break;
                            case 3:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111 = entry.getKey();
                                Object value11111111111111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111);
                                break;
                            case 4:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111112 = entry.getKey();
                                Object value11111111111111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111112);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111112);
                                break;
                            case 5:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111113 = entry.getKey();
                                Object value11111111111111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111113);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111113);
                                break;
                            case 6:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111114 = entry.getKey();
                                Object value11111111111111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111114);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111114);
                                break;
                            case 7:
                                ((Boolean) value).getClass();
                                iA4 = 1;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111115 = entry.getKey();
                                Object value11111111111111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111115);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111115);
                                break;
                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA4 = C0163j.x((String) value);
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111116 = entry.getKey();
                                Object value11111111111111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111116);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111116);
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                iA4 = ((AbstractC0154a) value).a();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111117 = entry.getKey();
                                Object value11111111111111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111117);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111117);
                                break;
                            case 10:
                                iA3 = ((AbstractC0154a) value).a();
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111118 = entry.getKey();
                                Object value11111111111111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111118);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111118);
                                break;
                            case 11:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA3 = ((byte[]) value).length;
                                    iZ2 = C0163j.z(iA3);
                                    iA4 = iZ2 + iA3;
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111119 = entry.getKey();
                                Object value11111111111111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111119);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111119);
                                break;
                            case 12:
                                iA4 = C0163j.z(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111110 = entry.getKey();
                                Object value111111111111111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111110);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111110);
                                break;
                            case 13:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111 = entry.getKey();
                                Object value111111111111111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111);
                                break;
                            case 14:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111112 = entry.getKey();
                                Object value111111111111111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111112);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111112);
                                break;
                            case 15:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111113 = entry.getKey();
                                Object value111111111111111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111113);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111113);
                                break;
                            case 16:
                                int iIntValue13 = ((Integer) value).intValue();
                                iA4 = C0163j.z((iIntValue13 >> 31) ^ (iIntValue13 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111114 = entry.getKey();
                                Object value111111111111111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111114);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111114);
                                break;
                            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                long jLongValue13 = ((Long) value).longValue();
                                iA4 = C0163j.A((jLongValue13 >> 63) ^ (jLongValue13 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111115 = entry.getKey();
                                Object value111111111111111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111115);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111115);
                                break;
                            default:
                                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                        }
                        break;
                    case 13:
                        iA = C0163j.w(((Integer) key).intValue());
                        i8 = iA + iY2;
                        iY = C0163j.y(2);
                        if (w0Var == t0Var) {
                            iY *= 2;
                        }
                        switch (w0Var.ordinal()) {
                            case 0:
                                ((Double) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111116 = entry.getKey();
                                Object value111111111111111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111116);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111116);
                                break;
                            case 1:
                                ((Float) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111117 = entry.getKey();
                                Object value111111111111111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111117);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111117);
                                break;
                            case 2:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111118 = entry.getKey();
                                Object value111111111111111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111118);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111118);
                                break;
                            case 3:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111119 = entry.getKey();
                                Object value111111111111111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111119);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111119);
                                break;
                            case 4:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111110 = entry.getKey();
                                Object value1111111111111111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111110);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111110);
                                break;
                            case 5:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111 = entry.getKey();
                                Object value1111111111111111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111);
                                break;
                            case 6:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111112 = entry.getKey();
                                Object value1111111111111111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111112);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111112);
                                break;
                            case 7:
                                ((Boolean) value).getClass();
                                iA4 = 1;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111113 = entry.getKey();
                                Object value1111111111111111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111113);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111113);
                                break;
                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA4 = C0163j.x((String) value);
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111114 = entry.getKey();
                                Object value1111111111111111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111114);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111114);
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                iA4 = ((AbstractC0154a) value).a();
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111115 = entry.getKey();
                                Object value1111111111111111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111115);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111115);
                                break;
                            case 10:
                                iA3 = ((AbstractC0154a) value).a();
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111116 = entry.getKey();
                                Object value1111111111111111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111116);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111116);
                                break;
                            case 11:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA3 = ((byte[]) value).length;
                                    iZ2 = C0163j.z(iA3);
                                    iA4 = iZ2 + iA3;
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111117 = entry.getKey();
                                Object value1111111111111111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111117);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111117);
                                break;
                            case 12:
                                iA4 = C0163j.z(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111118 = entry.getKey();
                                Object value1111111111111111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111118);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111118);
                                break;
                            case 13:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111119 = entry.getKey();
                                Object value1111111111111111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111119);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111119);
                                break;
                            case 14:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111110 = entry.getKey();
                                Object value11111111111111111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111110);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111110);
                                break;
                            case 15:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111 = entry.getKey();
                                Object value11111111111111111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111);
                                break;
                            case 16:
                                int iIntValue14 = ((Integer) value).intValue();
                                iA4 = C0163j.z((iIntValue14 >> 31) ^ (iIntValue14 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111112 = entry.getKey();
                                Object value11111111111111111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111112);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111112);
                                break;
                            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                long jLongValue14 = ((Long) value).longValue();
                                iA4 = C0163j.A((jLongValue14 >> 63) ^ (jLongValue14 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111113 = entry.getKey();
                                Object value11111111111111111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111113);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111113);
                                break;
                            default:
                                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                        }
                        break;
                    case 14:
                        ((Integer) key).getClass();
                        iA = 4;
                        i8 = iA + iY2;
                        iY = C0163j.y(2);
                        if (w0Var == t0Var) {
                            iY *= 2;
                        }
                        switch (w0Var.ordinal()) {
                            case 0:
                                ((Double) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111114 = entry.getKey();
                                Object value11111111111111111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111114);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111114);
                                break;
                            case 1:
                                ((Float) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111115 = entry.getKey();
                                Object value11111111111111111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111115);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111115);
                                break;
                            case 2:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111116 = entry.getKey();
                                Object value11111111111111111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111116);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111116);
                                break;
                            case 3:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111117 = entry.getKey();
                                Object value11111111111111111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111117);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111117);
                                break;
                            case 4:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111118 = entry.getKey();
                                Object value11111111111111111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111118);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111118);
                                break;
                            case 5:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111119 = entry.getKey();
                                Object value11111111111111111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111119);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111119);
                                break;
                            case 6:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111110 = entry.getKey();
                                Object value111111111111111111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111110);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111110);
                                break;
                            case 7:
                                ((Boolean) value).getClass();
                                iA4 = 1;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111111 = entry.getKey();
                                Object value111111111111111111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111111);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111111);
                                break;
                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA4 = C0163j.x((String) value);
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111112 = entry.getKey();
                                Object value111111111111111111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111112);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111112);
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                iA4 = ((AbstractC0154a) value).a();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111113 = entry.getKey();
                                Object value111111111111111111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111113);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111113);
                                break;
                            case 10:
                                iA3 = ((AbstractC0154a) value).a();
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111114 = entry.getKey();
                                Object value111111111111111111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111114);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111114);
                                break;
                            case 11:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA3 = ((byte[]) value).length;
                                    iZ2 = C0163j.z(iA3);
                                    iA4 = iZ2 + iA3;
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111115 = entry.getKey();
                                Object value111111111111111111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111115);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111115);
                                break;
                            case 12:
                                iA4 = C0163j.z(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111116 = entry.getKey();
                                Object value111111111111111111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111116);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111116);
                                break;
                            case 13:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111117 = entry.getKey();
                                Object value111111111111111111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111117);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111117);
                                break;
                            case 14:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111118 = entry.getKey();
                                Object value111111111111111111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111118);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111118);
                                break;
                            case 15:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111119 = entry.getKey();
                                Object value111111111111111111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111119);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111119);
                                break;
                            case 16:
                                int iIntValue15 = ((Integer) value).intValue();
                                iA4 = C0163j.z((iIntValue15 >> 31) ^ (iIntValue15 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111110 = entry.getKey();
                                Object value1111111111111111111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111110);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111110);
                                break;
                            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                long jLongValue15 = ((Long) value).longValue();
                                iA4 = C0163j.A((jLongValue15 >> 63) ^ (jLongValue15 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111111 = entry.getKey();
                                Object value1111111111111111111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111111);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111111);
                                break;
                            default:
                                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                        }
                        break;
                    case 15:
                        ((Long) key).getClass();
                        iA = 8;
                        i8 = iA + iY2;
                        iY = C0163j.y(2);
                        if (w0Var == t0Var) {
                            iY *= 2;
                        }
                        switch (w0Var.ordinal()) {
                            case 0:
                                ((Double) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111112 = entry.getKey();
                                Object value1111111111111111111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111112);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111112);
                                break;
                            case 1:
                                ((Float) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111113 = entry.getKey();
                                Object value1111111111111111111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111113);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111113);
                                break;
                            case 2:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111114 = entry.getKey();
                                Object value1111111111111111111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111114);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111114);
                                break;
                            case 3:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111115 = entry.getKey();
                                Object value1111111111111111111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111115);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111115);
                                break;
                            case 4:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111116 = entry.getKey();
                                Object value1111111111111111111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111116);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111116);
                                break;
                            case 5:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111117 = entry.getKey();
                                Object value1111111111111111111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111117);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111117);
                                break;
                            case 6:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111118 = entry.getKey();
                                Object value1111111111111111111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111118);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111118);
                                break;
                            case 7:
                                ((Boolean) value).getClass();
                                iA4 = 1;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111119 = entry.getKey();
                                Object value1111111111111111111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111119);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111119);
                                break;
                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA4 = C0163j.x((String) value);
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111110 = entry.getKey();
                                Object value11111111111111111111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111110);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111110);
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                iA4 = ((AbstractC0154a) value).a();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111111 = entry.getKey();
                                Object value11111111111111111111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111111);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111111);
                                break;
                            case 10:
                                iA3 = ((AbstractC0154a) value).a();
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111112 = entry.getKey();
                                Object value11111111111111111111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111112);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111112);
                                break;
                            case 11:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA3 = ((byte[]) value).length;
                                    iZ2 = C0163j.z(iA3);
                                    iA4 = iZ2 + iA3;
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111113 = entry.getKey();
                                Object value11111111111111111111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111113);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111113);
                                break;
                            case 12:
                                iA4 = C0163j.z(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111114 = entry.getKey();
                                Object value11111111111111111111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111114);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111114);
                                break;
                            case 13:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111115 = entry.getKey();
                                Object value11111111111111111111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111115);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111115);
                                break;
                            case 14:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111116 = entry.getKey();
                                Object value11111111111111111111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111116);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111116);
                                break;
                            case 15:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111117 = entry.getKey();
                                Object value11111111111111111111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111117);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111117);
                                break;
                            case 16:
                                int iIntValue16 = ((Integer) value).intValue();
                                iA4 = C0163j.z((iIntValue16 >> 31) ^ (iIntValue16 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111118 = entry.getKey();
                                Object value11111111111111111111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111118);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111118);
                                break;
                            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                long jLongValue16 = ((Long) value).longValue();
                                iA4 = C0163j.A((jLongValue16 >> 63) ^ (jLongValue16 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111119 = entry.getKey();
                                Object value11111111111111111111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111119);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111119);
                                break;
                            default:
                                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                        }
                        break;
                    case 16:
                        int iIntValue17 = ((Integer) key).intValue();
                        iA = C0163j.z((iIntValue17 >> 31) ^ (iIntValue17 << 1));
                        i8 = iA + iY2;
                        iY = C0163j.y(2);
                        if (w0Var == t0Var) {
                            iY *= 2;
                        }
                        switch (w0Var.ordinal()) {
                            case 0:
                                ((Double) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111111110 = entry.getKey();
                                Object value111111111111111111111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111111110);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111111110);
                                break;
                            case 1:
                                ((Float) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111111111 = entry.getKey();
                                Object value111111111111111111111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111111111);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111111111);
                                break;
                            case 2:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111111112 = entry.getKey();
                                Object value111111111111111111111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111111112);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111111112);
                                break;
                            case 3:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111111113 = entry.getKey();
                                Object value111111111111111111111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111111113);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111111113);
                                break;
                            case 4:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111111114 = entry.getKey();
                                Object value111111111111111111111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111111114);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111111114);
                                break;
                            case 5:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111111115 = entry.getKey();
                                Object value111111111111111111111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111111115);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111111115);
                                break;
                            case 6:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111111116 = entry.getKey();
                                Object value111111111111111111111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111111116);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111111116);
                                break;
                            case 7:
                                ((Boolean) value).getClass();
                                iA4 = 1;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111111117 = entry.getKey();
                                Object value111111111111111111111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111111117);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111111117);
                                break;
                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA4 = C0163j.x((String) value);
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111111118 = entry.getKey();
                                Object value111111111111111111111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111111118);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111111118);
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                iA4 = ((AbstractC0154a) value).a();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111111119 = entry.getKey();
                                Object value111111111111111111111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111111119);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111111119);
                                break;
                            case 10:
                                iA3 = ((AbstractC0154a) value).a();
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111111110 = entry.getKey();
                                Object value1111111111111111111111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111111110);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111111110);
                                break;
                            case 11:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA3 = ((byte[]) value).length;
                                    iZ2 = C0163j.z(iA3);
                                    iA4 = iZ2 + iA3;
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111111111 = entry.getKey();
                                Object value1111111111111111111111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111111111);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111111111);
                                break;
                            case 12:
                                iA4 = C0163j.z(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111111112 = entry.getKey();
                                Object value1111111111111111111111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111111112);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111111112);
                                break;
                            case 13:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111111113 = entry.getKey();
                                Object value1111111111111111111111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111111113);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111111113);
                                break;
                            case 14:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111111114 = entry.getKey();
                                Object value1111111111111111111111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111111114);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111111114);
                                break;
                            case 15:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111111115 = entry.getKey();
                                Object value1111111111111111111111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111111115);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111111115);
                                break;
                            case 16:
                                int iIntValue18 = ((Integer) value).intValue();
                                iA4 = C0163j.z((iIntValue18 >> 31) ^ (iIntValue18 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111111116 = entry.getKey();
                                Object value1111111111111111111111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111111116);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111111116);
                                break;
                            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                long jLongValue17 = ((Long) value).longValue();
                                iA4 = C0163j.A((jLongValue17 >> 63) ^ (jLongValue17 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111111117 = entry.getKey();
                                Object value1111111111111111111111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111111117);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111111117);
                                break;
                            default:
                                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                        }
                        break;
                    case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                        long jLongValue18 = ((Long) key).longValue();
                        iA = C0163j.A((jLongValue18 << 1) ^ (jLongValue18 >> 63));
                        i8 = iA + iY2;
                        iY = C0163j.y(2);
                        if (w0Var == t0Var) {
                            iY *= 2;
                        }
                        switch (w0Var.ordinal()) {
                            case 0:
                                ((Double) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111111118 = entry.getKey();
                                Object value1111111111111111111111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111111118);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111111118);
                                break;
                            case 1:
                                ((Float) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key1111111111111111111111111111119 = entry.getKey();
                                Object value1111111111111111111111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key1111111111111111111111111111119);
                                C0168o.b(c0163j, w0Var, 2, value1111111111111111111111111111119);
                                break;
                            case 2:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111111110 = entry.getKey();
                                Object value11111111111111111111111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111111110);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111111110);
                                break;
                            case 3:
                                iA4 = C0163j.A(((Long) value).longValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111111111 = entry.getKey();
                                Object value11111111111111111111111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111111111);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111111111);
                                break;
                            case 4:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111111112 = entry.getKey();
                                Object value11111111111111111111111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111111112);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111111112);
                                break;
                            case 5:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111111113 = entry.getKey();
                                Object value11111111111111111111111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111111113);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111111113);
                                break;
                            case 6:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111111114 = entry.getKey();
                                Object value11111111111111111111111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111111114);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111111114);
                                break;
                            case 7:
                                ((Boolean) value).getClass();
                                iA4 = 1;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111111115 = entry.getKey();
                                Object value11111111111111111111111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111111115);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111111115);
                                break;
                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA4 = C0163j.x((String) value);
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111111116 = entry.getKey();
                                Object value11111111111111111111111111111116 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111111116);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111111116);
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                iA4 = ((AbstractC0154a) value).a();
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111111117 = entry.getKey();
                                Object value11111111111111111111111111111117 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111111117);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111111117);
                                break;
                            case 10:
                                iA3 = ((AbstractC0154a) value).a();
                                iZ2 = C0163j.z(iA3);
                                iA4 = iZ2 + iA3;
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111111118 = entry.getKey();
                                Object value11111111111111111111111111111118 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111111118);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111111118);
                                break;
                            case 11:
                                if (value instanceof C0159f) {
                                    iA4 = C0163j.s((C0159f) value);
                                } else {
                                    iA3 = ((byte[]) value).length;
                                    iZ2 = C0163j.z(iA3);
                                    iA4 = iZ2 + iA3;
                                }
                                c0163j.T(iA4 + iY + i8);
                                Object key11111111111111111111111111111119 = entry.getKey();
                                Object value11111111111111111111111111111119 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key11111111111111111111111111111119);
                                C0168o.b(c0163j, w0Var, 2, value11111111111111111111111111111119);
                                break;
                            case 12:
                                iA4 = C0163j.z(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111111111110 = entry.getKey();
                                Object value111111111111111111111111111111110 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111111111110);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111111111110);
                                break;
                            case 13:
                                iA4 = C0163j.w(((Integer) value).intValue());
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111111111111 = entry.getKey();
                                Object value111111111111111111111111111111111 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111111111111);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111111111111);
                                break;
                            case 14:
                                ((Integer) value).getClass();
                                iA4 = 4;
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111111111112 = entry.getKey();
                                Object value111111111111111111111111111111112 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111111111112);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111111111112);
                                break;
                            case 15:
                                ((Long) value).getClass();
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111111111113 = entry.getKey();
                                Object value111111111111111111111111111111113 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111111111113);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111111111113);
                                break;
                            case 16:
                                int iIntValue19 = ((Integer) value).intValue();
                                iA4 = C0163j.z((iIntValue19 >> 31) ^ (iIntValue19 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111111111114 = entry.getKey();
                                Object value111111111111111111111111111111114 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111111111114);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111111111114);
                                break;
                            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                long jLongValue19 = ((Long) value).longValue();
                                iA4 = C0163j.A((jLongValue19 >> 63) ^ (jLongValue19 << 1));
                                c0163j.T(iA4 + iY + i8);
                                Object key111111111111111111111111111111115 = entry.getKey();
                                Object value111111111111111111111111111111115 = entry.getValue();
                                C0168o.b(c0163j, w0Var2, 1, key111111111111111111111111111111115);
                                C0168o.b(c0163j, w0Var, 2, value111111111111111111111111111111115);
                                break;
                            default:
                                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                        }
                        break;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            }
        }
    }

    @Override // androidx.datastore.preferences.protobuf.X
    public final void a(Object obj) {
        int[] iArr;
        int i6;
        int i7 = this.f4297i;
        while (true) {
            iArr = this.f4296h;
            i6 = this.f4298j;
            if (i7 >= i6) {
                break;
            }
            long jG = G(iArr[i7]) & 1048575;
            Object objI = o0.f4378d.i(jG, obj);
            if (objI != null) {
                this.f4302n.getClass();
                ((I) objI).r = false;
                o0.o(jG, obj, objI);
            }
            i7++;
        }
        int length = iArr.length;
        while (i6 < length) {
            this.f4300l.a(iArr[i6], obj);
            i6++;
        }
        this.f4301m.getClass();
        ((AbstractC0172t) obj).unknownFields.f4342e = false;
    }

    /* JADX WARN: Code duplicated, block: B:21:0x0049  */
    /* JADX WARN: Code duplicated, block: B:67:0x0103  */
    /* JADX WARN: Code duplicated, block: B:68:0x0108  */
    /* JADX WARN: Code duplicated, block: B:71:0x010c  */
    /* JADX WARN: Code duplicated, block: B:73:0x010f  */
    /* JADX WARN: Code duplicated, block: B:83:0x0122 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:88:0x0123 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:89:0x0123 A[SYNTHETIC] */
    @Override // androidx.datastore.preferences.protobuf.X
    public final boolean b(Object obj) {
        int i6;
        int iF;
        int i7 = -1;
        int i8 = 0;
        int i9 = 0;
        while (true) {
            boolean zP = true;
            if (i8 >= this.f4297i) {
                return true;
            }
            int i10 = this.f4296h[i8];
            int[] iArr = this.f4289a;
            int i11 = iArr[i10];
            int iG = G(i10);
            boolean z6 = this.f4295g;
            if (z6) {
                i6 = 0;
            } else {
                int i12 = iArr[i10 + 2];
                int i13 = i12 & 1048575;
                i6 = 1 << (i12 >>> 20);
                if (i13 != i7) {
                    i9 = f4288p.getInt(obj, i13);
                    i7 = i13;
                }
            }
            if ((268435456 & iG) == 0) {
                iF = F(iG);
                if (iF != 9 || iF == 17) {
                    if (z6) {
                        zP = p(i10, obj);
                    } else if ((i6 & i9) == 0) {
                        zP = false;
                    }
                    if (zP) {
                        continue;
                    } else if (!m(i10).b(o0.f4378d.i(iG & 1048575, obj))) {
                    }
                    i8++;
                } else {
                    if (iF != 27) {
                        if (iF == 60 || iF == 68) {
                            if (!q(i11, i10, obj)) {
                                continue;
                            } else if (!m(i10).b(o0.f4378d.i(iG & 1048575, obj))) {
                            }
                            i8++;
                        } else if (iF != 49) {
                            if (iF != 50) {
                                continue;
                            } else {
                                Object objI = o0.f4378d.i(iG & 1048575, obj);
                                this.f4302n.getClass();
                                I i14 = (I) objI;
                                if (!i14.isEmpty() && ((H) l(i10)).f4281a.f4279b.r == x0.MESSAGE) {
                                    X xA = null;
                                    for (Object obj2 : i14.values()) {
                                        if (xA == null) {
                                            xA = U.f4308c.a(obj2.getClass());
                                        }
                                        if (!xA.b(obj2)) {
                                        }
                                    }
                                }
                            }
                            i8++;
                        }
                    }
                    List list = (List) o0.f4378d.i(iG & 1048575, obj);
                    if (list.isEmpty()) {
                        continue;
                    } else {
                        X xM = m(i10);
                        for (int i15 = 0; i15 < list.size(); i15++) {
                            if (xM.b(list.get(i15))) {
                            }
                        }
                    }
                    i8++;
                }
            } else {
                if (z6 ? p(i10, obj) : (i9 & i6) != 0) {
                    iF = F(iG);
                    if (iF != 9) {
                    }
                    if (z6) {
                        zP = p(i10, obj);
                    } else if ((i6 & i9) == 0) {
                        zP = false;
                    }
                    if (zP) {
                        continue;
                    } else if (!m(i10).b(o0.f4378d.i(iG & 1048575, obj))) {
                    }
                    i8++;
                }
            }
            return false;
        }
    }

    @Override // androidx.datastore.preferences.protobuf.X
    public final void c(Object obj, F f4) throws IOException {
        f4.getClass();
        C0163j c0163j = (C0163j) f4.f4277a;
        if (!this.f4295g) {
            H(obj, f4);
            return;
        }
        int[] iArr = this.f4289a;
        int length = iArr.length;
        for (int i6 = 0; i6 < length; i6 += 3) {
            int iG = G(i6);
            int i7 = iArr[i6];
            switch (F(iG)) {
                case 0:
                    if (p(i6, obj)) {
                        double dE = o0.f4378d.e(iG & 1048575, obj);
                        c0163j.getClass();
                        c0163j.K(Double.doubleToRawLongBits(dE), i7);
                    }
                    break;
                case 1:
                    if (p(i6, obj)) {
                        float f7 = o0.f4378d.f(iG & 1048575, obj);
                        c0163j.getClass();
                        c0163j.I(i7, Float.floatToRawIntBits(f7));
                    }
                    break;
                case 2:
                    if (p(i6, obj)) {
                        c0163j.U(o0.f4378d.h(iG & 1048575, obj), i7);
                    }
                    break;
                case 3:
                    if (p(i6, obj)) {
                        c0163j.U(o0.f4378d.h(iG & 1048575, obj), i7);
                    }
                    break;
                case 4:
                    if (p(i6, obj)) {
                        c0163j.M(i7, o0.f4378d.g(iG & 1048575, obj));
                    }
                    break;
                case 5:
                    if (p(i6, obj)) {
                        c0163j.K(o0.f4378d.h(iG & 1048575, obj), i7);
                    }
                    break;
                case 6:
                    if (p(i6, obj)) {
                        c0163j.I(i7, o0.f4378d.g(iG & 1048575, obj));
                    }
                    break;
                case 7:
                    if (p(i6, obj)) {
                        c0163j.F(i7, o0.f4378d.c(iG & 1048575, obj));
                    }
                    break;
                case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                    if (p(i6, obj)) {
                        J(i7, o0.f4378d.i(iG & 1048575, obj), f4);
                    }
                    break;
                case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                    if (p(i6, obj)) {
                        c0163j.O(i7, (AbstractC0154a) o0.f4378d.i(iG & 1048575, obj), m(i6));
                    }
                    break;
                case 10:
                    if (p(i6, obj)) {
                        f4.a(i7, (C0159f) o0.f4378d.i(iG & 1048575, obj));
                    }
                    break;
                case 11:
                    if (p(i6, obj)) {
                        c0163j.S(i7, o0.f4378d.g(iG & 1048575, obj));
                    }
                    break;
                case 12:
                    if (p(i6, obj)) {
                        c0163j.M(i7, o0.f4378d.g(iG & 1048575, obj));
                    }
                    break;
                case 13:
                    if (p(i6, obj)) {
                        c0163j.I(i7, o0.f4378d.g(iG & 1048575, obj));
                    }
                    break;
                case 14:
                    if (p(i6, obj)) {
                        c0163j.K(o0.f4378d.h(iG & 1048575, obj), i7);
                    }
                    break;
                case 15:
                    if (p(i6, obj)) {
                        int iG2 = o0.f4378d.g(iG & 1048575, obj);
                        c0163j.S(i7, (iG2 >> 31) ^ (iG2 << 1));
                    }
                    break;
                case 16:
                    if (p(i6, obj)) {
                        long jH = o0.f4378d.h(iG & 1048575, obj);
                        c0163j.U((jH >> 63) ^ (jH << 1), i7);
                    }
                    break;
                case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                    if (p(i6, obj)) {
                        f4.b(i7, o0.f4378d.i(iG & 1048575, obj), m(i6));
                    }
                    break;
                case 18:
                    Y.A(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, false);
                    break;
                case 19:
                    Y.E(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, false);
                    break;
                case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
                    Y.H(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, false);
                    break;
                case 21:
                    Y.P(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, false);
                    break;
                case 22:
                    Y.G(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, false);
                    break;
                case 23:
                    Y.D(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, false);
                    break;
                case 24:
                    Y.C(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, false);
                    break;
                case 25:
                    Y.y(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, false);
                    break;
                case 26:
                    Y.N(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4);
                    break;
                case 27:
                    Y.I(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, m(i6));
                    break;
                case 28:
                    Y.z(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4);
                    break;
                case 29:
                    Y.O(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, false);
                    break;
                case 30:
                    Y.B(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, false);
                    break;
                case 31:
                    Y.J(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, false);
                    break;
                case 32:
                    Y.K(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, false);
                    break;
                case 33:
                    Y.L(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, false);
                    break;
                case 34:
                    Y.M(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, false);
                    break;
                case 35:
                    Y.A(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, true);
                    break;
                case 36:
                    Y.E(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, true);
                    break;
                case 37:
                    Y.H(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, true);
                    break;
                case 38:
                    Y.P(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, true);
                    break;
                case 39:
                    Y.G(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, true);
                    break;
                case 40:
                    Y.D(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, true);
                    break;
                case 41:
                    Y.C(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, true);
                    break;
                case 42:
                    Y.y(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, true);
                    break;
                case 43:
                    Y.O(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, true);
                    break;
                case 44:
                    Y.B(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, true);
                    break;
                case 45:
                    Y.J(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, true);
                    break;
                case 46:
                    Y.K(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, true);
                    break;
                case 47:
                    Y.L(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, true);
                    break;
                case 48:
                    Y.M(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, true);
                    break;
                case 49:
                    Y.F(iArr[i6], (List) o0.f4378d.i(iG & 1048575, obj), f4, m(i6));
                    break;
                case 50:
                    I(f4, i7, o0.f4378d.i(iG & 1048575, obj), i6);
                    break;
                case 51:
                    if (q(i7, i6, obj)) {
                        double dDoubleValue = ((Double) o0.f4378d.i(iG & 1048575, obj)).doubleValue();
                        c0163j.getClass();
                        c0163j.K(Double.doubleToRawLongBits(dDoubleValue), i7);
                    }
                    break;
                case 52:
                    if (q(i7, i6, obj)) {
                        float fFloatValue = ((Float) o0.f4378d.i(iG & 1048575, obj)).floatValue();
                        c0163j.getClass();
                        c0163j.I(i7, Float.floatToRawIntBits(fFloatValue));
                    }
                    break;
                case 53:
                    if (q(i7, i6, obj)) {
                        c0163j.U(z(iG & 1048575, obj), i7);
                    }
                    break;
                case 54:
                    if (q(i7, i6, obj)) {
                        c0163j.U(z(iG & 1048575, obj), i7);
                    }
                    break;
                case 55:
                    if (q(i7, i6, obj)) {
                        c0163j.M(i7, y(iG & 1048575, obj));
                    }
                    break;
                case 56:
                    if (q(i7, i6, obj)) {
                        c0163j.K(z(iG & 1048575, obj), i7);
                    }
                    break;
                case 57:
                    if (q(i7, i6, obj)) {
                        c0163j.I(i7, y(iG & 1048575, obj));
                    }
                    break;
                case 58:
                    if (q(i7, i6, obj)) {
                        c0163j.F(i7, ((Boolean) o0.f4378d.i(iG & 1048575, obj)).booleanValue());
                    }
                    break;
                case 59:
                    if (q(i7, i6, obj)) {
                        J(i7, o0.f4378d.i(iG & 1048575, obj), f4);
                    }
                    break;
                case PipesConfigBase.DEFAULT_STALE_FETCHER_DELAY_SECONDS /* 60 */:
                    if (q(i7, i6, obj)) {
                        c0163j.O(i7, (AbstractC0154a) o0.f4378d.i(iG & 1048575, obj), m(i6));
                    }
                    break;
                case 61:
                    if (q(i7, i6, obj)) {
                        f4.a(i7, (C0159f) o0.f4378d.i(iG & 1048575, obj));
                    }
                    break;
                case 62:
                    if (q(i7, i6, obj)) {
                        c0163j.S(i7, y(iG & 1048575, obj));
                    }
                    break;
                case 63:
                    if (q(i7, i6, obj)) {
                        c0163j.M(i7, y(iG & 1048575, obj));
                    }
                    break;
                case 64:
                    if (q(i7, i6, obj)) {
                        c0163j.I(i7, y(iG & 1048575, obj));
                    }
                    break;
                case 65:
                    if (q(i7, i6, obj)) {
                        c0163j.K(z(iG & 1048575, obj), i7);
                    }
                    break;
                case 66:
                    if (q(i7, i6, obj)) {
                        int iY = y(iG & 1048575, obj);
                        c0163j.S(i7, (iY >> 31) ^ (iY << 1));
                    }
                    break;
                case 67:
                    if (q(i7, i6, obj)) {
                        long jZ = z(iG & 1048575, obj);
                        c0163j.U((jZ >> 63) ^ (jZ << 1), i7);
                    }
                    break;
                case 68:
                    if (q(i7, i6, obj)) {
                        f4.b(i7, o0.f4378d.i(iG & 1048575, obj), m(i6));
                    }
                    break;
            }
        }
        this.f4301m.getClass();
        ((AbstractC0172t) obj).unknownFields.d(f4);
    }

    /* JADX WARN: Code duplicated, block: B:42:0x00e1 A[PHI: r3
  0x00e1: PHI (r3v32 int) = (r3v10 int), (r3v33 int) binds: [B:83:0x0216, B:41:0x00df] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // androidx.datastore.preferences.protobuf.X
    public final int d(AbstractC0172t abstractC0172t) {
        int i6;
        int iB;
        int i7;
        int[] iArr = this.f4289a;
        int length = iArr.length;
        int i8 = 0;
        for (int i9 = 0; i9 < length; i9 += 3) {
            int iG = G(i9);
            int i10 = iArr[i9];
            long j6 = 1048575 & iG;
            int i11 = 1237;
            int iHashCode = 37;
            switch (F(iG)) {
                case 0:
                    i6 = i8 * 53;
                    iB = AbstractC0174v.b(Double.doubleToLongBits(o0.f4378d.e(j6, abstractC0172t)));
                    i8 = iB + i6;
                    break;
                case 1:
                    i6 = i8 * 53;
                    iB = Float.floatToIntBits(o0.f4378d.f(j6, abstractC0172t));
                    i8 = iB + i6;
                    break;
                case 2:
                    i6 = i8 * 53;
                    iB = AbstractC0174v.b(o0.f4378d.h(j6, abstractC0172t));
                    i8 = iB + i6;
                    break;
                case 3:
                    i6 = i8 * 53;
                    iB = AbstractC0174v.b(o0.f4378d.h(j6, abstractC0172t));
                    i8 = iB + i6;
                    break;
                case 4:
                    i6 = i8 * 53;
                    iB = o0.f4378d.g(j6, abstractC0172t);
                    i8 = iB + i6;
                    break;
                case 5:
                    i6 = i8 * 53;
                    iB = AbstractC0174v.b(o0.f4378d.h(j6, abstractC0172t));
                    i8 = iB + i6;
                    break;
                case 6:
                    i6 = i8 * 53;
                    iB = o0.f4378d.g(j6, abstractC0172t);
                    i8 = iB + i6;
                    break;
                case 7:
                    i7 = i8 * 53;
                    boolean zC = o0.f4378d.c(j6, abstractC0172t);
                    Charset charset = AbstractC0174v.f4391a;
                    if (zC) {
                        i11 = 1231;
                    }
                    i8 = i11 + i7;
                    break;
                case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                    i6 = i8 * 53;
                    iB = ((String) o0.f4378d.i(j6, abstractC0172t)).hashCode();
                    i8 = iB + i6;
                    break;
                case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                    Object objI = o0.f4378d.i(j6, abstractC0172t);
                    if (objI != null) {
                        iHashCode = objI.hashCode();
                    }
                    i8 = (i8 * 53) + iHashCode;
                    break;
                case 10:
                    i6 = i8 * 53;
                    iB = o0.f4378d.i(j6, abstractC0172t).hashCode();
                    i8 = iB + i6;
                    break;
                case 11:
                    i6 = i8 * 53;
                    iB = o0.f4378d.g(j6, abstractC0172t);
                    i8 = iB + i6;
                    break;
                case 12:
                    i6 = i8 * 53;
                    iB = o0.f4378d.g(j6, abstractC0172t);
                    i8 = iB + i6;
                    break;
                case 13:
                    i6 = i8 * 53;
                    iB = o0.f4378d.g(j6, abstractC0172t);
                    i8 = iB + i6;
                    break;
                case 14:
                    i6 = i8 * 53;
                    iB = AbstractC0174v.b(o0.f4378d.h(j6, abstractC0172t));
                    i8 = iB + i6;
                    break;
                case 15:
                    i6 = i8 * 53;
                    iB = o0.f4378d.g(j6, abstractC0172t);
                    i8 = iB + i6;
                    break;
                case 16:
                    i6 = i8 * 53;
                    iB = AbstractC0174v.b(o0.f4378d.h(j6, abstractC0172t));
                    i8 = iB + i6;
                    break;
                case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                    Object objI2 = o0.f4378d.i(j6, abstractC0172t);
                    if (objI2 != null) {
                        iHashCode = objI2.hashCode();
                    }
                    i8 = (i8 * 53) + iHashCode;
                    break;
                case 18:
                case 19:
                case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
                case 21:
                case 22:
                case 23:
                case 24:
                case 25:
                case 26:
                case 27:
                case 28:
                case 29:
                case 30:
                case 31:
                case 32:
                case 33:
                case 34:
                case 35:
                case 36:
                case 37:
                case 38:
                case 39:
                case 40:
                case 41:
                case 42:
                case 43:
                case 44:
                case 45:
                case 46:
                case 47:
                case 48:
                case 49:
                    i6 = i8 * 53;
                    iB = o0.f4378d.i(j6, abstractC0172t).hashCode();
                    i8 = iB + i6;
                    break;
                case 50:
                    i6 = i8 * 53;
                    iB = o0.f4378d.i(j6, abstractC0172t).hashCode();
                    i8 = iB + i6;
                    break;
                case 51:
                    if (q(i10, i9, abstractC0172t)) {
                        i6 = i8 * 53;
                        iB = AbstractC0174v.b(Double.doubleToLongBits(((Double) o0.f4378d.i(j6, abstractC0172t)).doubleValue()));
                        i8 = iB + i6;
                    }
                    break;
                case 52:
                    if (q(i10, i9, abstractC0172t)) {
                        i6 = i8 * 53;
                        iB = Float.floatToIntBits(((Float) o0.f4378d.i(j6, abstractC0172t)).floatValue());
                        i8 = iB + i6;
                    }
                    break;
                case 53:
                    if (q(i10, i9, abstractC0172t)) {
                        i6 = i8 * 53;
                        iB = AbstractC0174v.b(z(j6, abstractC0172t));
                        i8 = iB + i6;
                    }
                    break;
                case 54:
                    if (q(i10, i9, abstractC0172t)) {
                        i6 = i8 * 53;
                        iB = AbstractC0174v.b(z(j6, abstractC0172t));
                        i8 = iB + i6;
                    }
                    break;
                case 55:
                    if (q(i10, i9, abstractC0172t)) {
                        i6 = i8 * 53;
                        iB = y(j6, abstractC0172t);
                        i8 = iB + i6;
                    }
                    break;
                case 56:
                    if (q(i10, i9, abstractC0172t)) {
                        i6 = i8 * 53;
                        iB = AbstractC0174v.b(z(j6, abstractC0172t));
                        i8 = iB + i6;
                    }
                    break;
                case 57:
                    if (q(i10, i9, abstractC0172t)) {
                        i6 = i8 * 53;
                        iB = y(j6, abstractC0172t);
                        i8 = iB + i6;
                    }
                    break;
                case 58:
                    if (q(i10, i9, abstractC0172t)) {
                        i7 = i8 * 53;
                        boolean zBooleanValue = ((Boolean) o0.f4378d.i(j6, abstractC0172t)).booleanValue();
                        Charset charset2 = AbstractC0174v.f4391a;
                        if (zBooleanValue) {
                            i11 = 1231;
                        }
                        i8 = i11 + i7;
                    }
                    break;
                case 59:
                    if (q(i10, i9, abstractC0172t)) {
                        i6 = i8 * 53;
                        iB = ((String) o0.f4378d.i(j6, abstractC0172t)).hashCode();
                        i8 = iB + i6;
                    }
                    break;
                case PipesConfigBase.DEFAULT_STALE_FETCHER_DELAY_SECONDS /* 60 */:
                    if (q(i10, i9, abstractC0172t)) {
                        i6 = i8 * 53;
                        iB = o0.f4378d.i(j6, abstractC0172t).hashCode();
                        i8 = iB + i6;
                    }
                    break;
                case 61:
                    if (q(i10, i9, abstractC0172t)) {
                        i6 = i8 * 53;
                        iB = o0.f4378d.i(j6, abstractC0172t).hashCode();
                        i8 = iB + i6;
                    }
                    break;
                case 62:
                    if (q(i10, i9, abstractC0172t)) {
                        i6 = i8 * 53;
                        iB = y(j6, abstractC0172t);
                        i8 = iB + i6;
                    }
                    break;
                case 63:
                    if (q(i10, i9, abstractC0172t)) {
                        i6 = i8 * 53;
                        iB = y(j6, abstractC0172t);
                        i8 = iB + i6;
                    }
                    break;
                case 64:
                    if (q(i10, i9, abstractC0172t)) {
                        i6 = i8 * 53;
                        iB = y(j6, abstractC0172t);
                        i8 = iB + i6;
                    }
                    break;
                case 65:
                    if (q(i10, i9, abstractC0172t)) {
                        i6 = i8 * 53;
                        iB = AbstractC0174v.b(z(j6, abstractC0172t));
                        i8 = iB + i6;
                    }
                    break;
                case 66:
                    if (q(i10, i9, abstractC0172t)) {
                        i6 = i8 * 53;
                        iB = y(j6, abstractC0172t);
                        i8 = iB + i6;
                    }
                    break;
                case 67:
                    if (q(i10, i9, abstractC0172t)) {
                        i6 = i8 * 53;
                        iB = AbstractC0174v.b(z(j6, abstractC0172t));
                        i8 = iB + i6;
                    }
                    break;
                case 68:
                    if (q(i10, i9, abstractC0172t)) {
                        i6 = i8 * 53;
                        iB = o0.f4378d.i(j6, abstractC0172t).hashCode();
                        i8 = iB + i6;
                    }
                    break;
            }
        }
        this.f4301m.getClass();
        return abstractC0172t.unknownFields.hashCode() + (i8 * 53);
    }

    @Override // androidx.datastore.preferences.protobuf.X
    public final int e(AbstractC0154a abstractC0154a) {
        return this.f4295g ? o(abstractC0154a) : n(abstractC0154a);
    }

    /* JADX WARN: Code duplicated, block: B:13:0x003d  */
    @Override // androidx.datastore.preferences.protobuf.X
    public final boolean f(AbstractC0172t abstractC0172t, AbstractC0172t abstractC0172t2) {
        int[] iArr = this.f4289a;
        int length = iArr.length;
        int i6 = 0;
        while (true) {
            boolean zX = true;
            if (i6 < length) {
                int iG = G(i6);
                long j6 = iG & 1048575;
                switch (F(iG)) {
                    case 0:
                        if (!i(abstractC0172t, abstractC0172t2, i6)) {
                            zX = false;
                        } else {
                            n0 n0Var = o0.f4378d;
                            if (Double.doubleToLongBits(n0Var.e(j6, abstractC0172t)) != Double.doubleToLongBits(n0Var.e(j6, abstractC0172t2))) {
                                zX = false;
                            }
                        }
                        break;
                    case 1:
                        if (!i(abstractC0172t, abstractC0172t2, i6)) {
                            zX = false;
                        } else {
                            n0 n0Var2 = o0.f4378d;
                            if (Float.floatToIntBits(n0Var2.f(j6, abstractC0172t)) != Float.floatToIntBits(n0Var2.f(j6, abstractC0172t2))) {
                                zX = false;
                            }
                        }
                        break;
                    case 2:
                        if (!i(abstractC0172t, abstractC0172t2, i6)) {
                            zX = false;
                        } else {
                            n0 n0Var3 = o0.f4378d;
                            if (n0Var3.h(j6, abstractC0172t) != n0Var3.h(j6, abstractC0172t2)) {
                                zX = false;
                            }
                        }
                        break;
                    case 3:
                        if (!i(abstractC0172t, abstractC0172t2, i6)) {
                            zX = false;
                        } else {
                            n0 n0Var4 = o0.f4378d;
                            if (n0Var4.h(j6, abstractC0172t) != n0Var4.h(j6, abstractC0172t2)) {
                                zX = false;
                            }
                        }
                        break;
                    case 4:
                        if (!i(abstractC0172t, abstractC0172t2, i6)) {
                            zX = false;
                        } else {
                            n0 n0Var5 = o0.f4378d;
                            if (n0Var5.g(j6, abstractC0172t) != n0Var5.g(j6, abstractC0172t2)) {
                                zX = false;
                            }
                        }
                        break;
                    case 5:
                        if (!i(abstractC0172t, abstractC0172t2, i6)) {
                            zX = false;
                        } else {
                            n0 n0Var6 = o0.f4378d;
                            if (n0Var6.h(j6, abstractC0172t) != n0Var6.h(j6, abstractC0172t2)) {
                                zX = false;
                            }
                        }
                        break;
                    case 6:
                        if (!i(abstractC0172t, abstractC0172t2, i6)) {
                            zX = false;
                        } else {
                            n0 n0Var7 = o0.f4378d;
                            if (n0Var7.g(j6, abstractC0172t) != n0Var7.g(j6, abstractC0172t2)) {
                                zX = false;
                            }
                        }
                        break;
                    case 7:
                        if (!i(abstractC0172t, abstractC0172t2, i6)) {
                            zX = false;
                        } else {
                            n0 n0Var8 = o0.f4378d;
                            if (n0Var8.c(j6, abstractC0172t) != n0Var8.c(j6, abstractC0172t2)) {
                                zX = false;
                            }
                        }
                        break;
                    case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                        if (!i(abstractC0172t, abstractC0172t2, i6)) {
                            zX = false;
                        } else {
                            n0 n0Var9 = o0.f4378d;
                            if (!Y.x(n0Var9.i(j6, abstractC0172t), n0Var9.i(j6, abstractC0172t2))) {
                                zX = false;
                            }
                        }
                        break;
                    case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                        if (!i(abstractC0172t, abstractC0172t2, i6)) {
                            zX = false;
                        } else {
                            n0 n0Var10 = o0.f4378d;
                            if (!Y.x(n0Var10.i(j6, abstractC0172t), n0Var10.i(j6, abstractC0172t2))) {
                                zX = false;
                            }
                        }
                        break;
                    case 10:
                        if (!i(abstractC0172t, abstractC0172t2, i6)) {
                            zX = false;
                        } else {
                            n0 n0Var11 = o0.f4378d;
                            if (!Y.x(n0Var11.i(j6, abstractC0172t), n0Var11.i(j6, abstractC0172t2))) {
                                zX = false;
                            }
                        }
                        break;
                    case 11:
                        if (!i(abstractC0172t, abstractC0172t2, i6)) {
                            zX = false;
                        } else {
                            n0 n0Var12 = o0.f4378d;
                            if (n0Var12.g(j6, abstractC0172t) != n0Var12.g(j6, abstractC0172t2)) {
                                zX = false;
                            }
                        }
                        break;
                    case 12:
                        if (!i(abstractC0172t, abstractC0172t2, i6)) {
                            zX = false;
                        } else {
                            n0 n0Var13 = o0.f4378d;
                            if (n0Var13.g(j6, abstractC0172t) != n0Var13.g(j6, abstractC0172t2)) {
                                zX = false;
                            }
                        }
                        break;
                    case 13:
                        if (!i(abstractC0172t, abstractC0172t2, i6)) {
                            zX = false;
                        } else {
                            n0 n0Var14 = o0.f4378d;
                            if (n0Var14.g(j6, abstractC0172t) != n0Var14.g(j6, abstractC0172t2)) {
                                zX = false;
                            }
                        }
                        break;
                    case 14:
                        if (!i(abstractC0172t, abstractC0172t2, i6)) {
                            zX = false;
                        } else {
                            n0 n0Var15 = o0.f4378d;
                            if (n0Var15.h(j6, abstractC0172t) != n0Var15.h(j6, abstractC0172t2)) {
                                zX = false;
                            }
                        }
                        break;
                    case 15:
                        if (!i(abstractC0172t, abstractC0172t2, i6)) {
                            zX = false;
                        } else {
                            n0 n0Var16 = o0.f4378d;
                            if (n0Var16.g(j6, abstractC0172t) != n0Var16.g(j6, abstractC0172t2)) {
                                zX = false;
                            }
                        }
                        break;
                    case 16:
                        if (!i(abstractC0172t, abstractC0172t2, i6)) {
                            zX = false;
                        } else {
                            n0 n0Var17 = o0.f4378d;
                            if (n0Var17.h(j6, abstractC0172t) != n0Var17.h(j6, abstractC0172t2)) {
                                zX = false;
                            }
                        }
                        break;
                    case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                        if (!i(abstractC0172t, abstractC0172t2, i6)) {
                            zX = false;
                        } else {
                            n0 n0Var18 = o0.f4378d;
                            if (!Y.x(n0Var18.i(j6, abstractC0172t), n0Var18.i(j6, abstractC0172t2))) {
                                zX = false;
                            }
                        }
                        break;
                    case 18:
                    case 19:
                    case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
                    case 21:
                    case 22:
                    case 23:
                    case 24:
                    case 25:
                    case 26:
                    case 27:
                    case 28:
                    case 29:
                    case 30:
                    case 31:
                    case 32:
                    case 33:
                    case 34:
                    case 35:
                    case 36:
                    case 37:
                    case 38:
                    case 39:
                    case 40:
                    case 41:
                    case 42:
                    case 43:
                    case 44:
                    case 45:
                    case 46:
                    case 47:
                    case 48:
                    case 49:
                        n0 n0Var19 = o0.f4378d;
                        zX = Y.x(n0Var19.i(j6, abstractC0172t), n0Var19.i(j6, abstractC0172t2));
                        break;
                    case 50:
                        n0 n0Var20 = o0.f4378d;
                        zX = Y.x(n0Var20.i(j6, abstractC0172t), n0Var20.i(j6, abstractC0172t2));
                        break;
                    case 51:
                    case 52:
                    case 53:
                    case 54:
                    case 55:
                    case 56:
                    case 57:
                    case 58:
                    case 59:
                    case PipesConfigBase.DEFAULT_STALE_FETCHER_DELAY_SECONDS /* 60 */:
                    case 61:
                    case 62:
                    case 63:
                    case 64:
                    case 65:
                    case 66:
                    case 67:
                    case 68:
                        long j7 = iArr[i6 + 2] & 1048575;
                        n0 n0Var21 = o0.f4378d;
                        if (n0Var21.g(j7, abstractC0172t) != n0Var21.g(j7, abstractC0172t2) || !Y.x(n0Var21.i(j6, abstractC0172t), n0Var21.i(j6, abstractC0172t2))) {
                            zX = false;
                        }
                        break;
                }
                if (zX) {
                    i6 += 3;
                }
            } else {
                this.f4301m.getClass();
                if (abstractC0172t.unknownFields.equals(abstractC0172t2.unknownFields)) {
                    return true;
                }
            }
        }
        return false;
    }

    /* JADX WARN: Code duplicated, block: B:167:0x0608 A[Catch: all -> 0x039e, TryCatch #11 {all -> 0x039e, blocks: (B:165:0x0603, B:167:0x0608, B:169:0x060f, B:171:0x0616, B:116:0x0388, B:117:0x0391, B:120:0x03a1, B:121:0x03b2, B:122:0x03c3, B:123:0x03d4, B:124:0x03e5, B:125:0x03f6, B:126:0x0407, B:127:0x0418, B:128:0x0429, B:130:0x0434, B:131:0x0453, B:132:0x0467, B:133:0x047c, B:134:0x0491, B:135:0x04a6, B:136:0x04bb, B:137:0x04d3, B:138:0x04e8, B:139:0x04fd, B:141:0x0508, B:142:0x0527, B:143:0x053b, B:144:0x0548, B:145:0x055f, B:146:0x0574, B:147:0x0589, B:148:0x059e, B:149:0x05b3, B:150:0x05c8, B:151:0x05de, B:157:0x05f4), top: B:202:0x0603 }] */
    /* JADX WARN: Code duplicated, block: B:169:0x060f A[Catch: all -> 0x039e, TryCatch #11 {all -> 0x039e, blocks: (B:165:0x0603, B:167:0x0608, B:169:0x060f, B:171:0x0616, B:116:0x0388, B:117:0x0391, B:120:0x03a1, B:121:0x03b2, B:122:0x03c3, B:123:0x03d4, B:124:0x03e5, B:125:0x03f6, B:126:0x0407, B:127:0x0418, B:128:0x0429, B:130:0x0434, B:131:0x0453, B:132:0x0467, B:133:0x047c, B:134:0x0491, B:135:0x04a6, B:136:0x04bb, B:137:0x04d3, B:138:0x04e8, B:139:0x04fd, B:141:0x0508, B:142:0x0527, B:143:0x053b, B:144:0x0548, B:145:0x055f, B:146:0x0574, B:147:0x0589, B:148:0x059e, B:149:0x05b3, B:150:0x05c8, B:151:0x05de, B:157:0x05f4), top: B:202:0x0603 }] */
    /* JADX WARN: Code duplicated, block: B:174:0x061e A[LOOP:3: B:173:0x061c->B:174:0x061e, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:176:0x0628  */
    /* JADX WARN: Code duplicated, block: B:182:0x0639 A[LOOP:4: B:181:0x0637->B:182:0x0639, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:184:0x0643  */
    /* JADX WARN: Code duplicated, block: B:213:0x061c A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:231:? A[RETURN, SYNTHETIC] */
    @Override // androidx.datastore.preferences.protobuf.X
    public final void g(Object obj, C0161h c0161h, C0165l c0165l) throws Throwable {
        N n6;
        int i6;
        C0161h c0161h2;
        AbstractC0172t abstractC0172t;
        f0 f0VarB;
        N n7 = this;
        Object obj2 = obj;
        C0161h c0161h3 = c0161h;
        C0165l c0165l2 = c0165l;
        c0165l2.getClass();
        g0 g0Var = n7.f4301m;
        int[] iArr = n7.f4296h;
        int i7 = n7.f4298j;
        int i8 = n7.f4297i;
        f0 f0VarB2 = null;
        while (true) {
            try {
                int iC = c0161h3.c();
                if (iC < n7.f4291c || iC > n7.f4292d) {
                    i6 = -1;
                } else {
                    int[] iArr2 = n7.f4289a;
                    int length = (iArr2.length / 3) - 1;
                    int i9 = 0;
                    while (true) {
                        if (i9 > length) {
                            i6 = -1;
                        } else {
                            int i10 = (length + i9) >>> 1;
                            int i11 = i10 * 3;
                            int i12 = iArr2[i11];
                            if (iC == i12) {
                                i6 = i11;
                            } else if (iC < i12) {
                                length = i10 - 1;
                            } else {
                                i9 = i10 + 1;
                            }
                        }
                    }
                }
                f0 f0Var = f0.f4337f;
                if (i6 >= 0) {
                    int iG = n7.G(i6);
                    try {
                        int iF = F(iG);
                        D d6 = n7.f4300l;
                        switch (iF) {
                            case 0:
                                int i13 = i6;
                                c0161h2 = c0161h3;
                                n6 = n7;
                                try {
                                    try {
                                        o0.f4378d.m(obj, x(iG), c0161h2.l());
                                        obj2 = obj;
                                        n6.D(i13, obj2);
                                    } catch (C0175w unused) {
                                        obj2 = obj;
                                        try {
                                            g0Var.getClass();
                                            if (f0VarB2 == null) {
                                                abstractC0172t = (AbstractC0172t) obj2;
                                                f0VarB = abstractC0172t.unknownFields;
                                                if (f0VarB == f0Var) {
                                                    f0VarB = f0.b();
                                                    abstractC0172t.unknownFields = f0VarB;
                                                }
                                                f0VarB2 = f0VarB;
                                            }
                                            if (!g0.a(f0VarB2, c0161h2)) {
                                                while (i8 < i7) {
                                                    n6.j(obj2, f0VarB2, iArr[i8]);
                                                    i8++;
                                                }
                                                if (f0VarB2 != null) {
                                                    ((AbstractC0172t) obj2).unknownFields = f0VarB2;
                                                    return;
                                                }
                                                return;
                                            }
                                        } catch (Throwable th) {
                                            th = th;
                                            while (i8 < i7) {
                                                n6.j(obj2, f0VarB2, iArr[i8]);
                                                i8++;
                                            }
                                            if (f0VarB2 != null) {
                                                g0Var.getClass();
                                                ((AbstractC0172t) obj2).unknownFields = f0VarB2;
                                            }
                                            throw th;
                                        }
                                    } catch (Throwable th2) {
                                        th = th2;
                                        obj2 = obj;
                                        while (i8 < i7) {
                                            n6.j(obj2, f0VarB2, iArr[i8]);
                                            i8++;
                                        }
                                        if (f0VarB2 != null) {
                                            g0Var.getClass();
                                            ((AbstractC0172t) obj2).unknownFields = f0VarB2;
                                        }
                                        throw th;
                                    }
                                } catch (C0175w unused2) {
                                    obj2 = obj;
                                } catch (Throwable th3) {
                                    th = th3;
                                    obj2 = obj;
                                }
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 1:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                o0.f4378d.n(obj2, x(iG), c0161h2.u());
                                n6.D(i6, obj2);
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 2:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                o0.n(obj2, x(iG), c0161h2.B());
                                n6.D(i6, obj2);
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 3:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                o0.n(obj2, x(iG), c0161h2.S());
                                n6.D(i6, obj2);
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 4:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                o0.m(c0161h2.z(), x(iG), obj2);
                                n6.D(i6, obj2);
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 5:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                o0.n(obj2, x(iG), c0161h2.s());
                                n6.D(i6, obj2);
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 6:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                o0.m(c0161h2.q(), x(iG), obj2);
                                n6.D(i6, obj2);
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 7:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                o0.f4378d.k(obj2, x(iG), c0161h2.g());
                                n6.D(i6, obj2);
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                n6.B(obj2, iG, c0161h2);
                                n6.D(i6, obj2);
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                                int i14 = i6;
                                c0161h2 = c0161h3;
                                C0165l c0165l3 = c0165l2;
                                n6 = n7;
                                if (n6.p(i14, obj2)) {
                                    o0.o(x(iG), obj2, AbstractC0174v.c(o0.f4378d.i(x(iG), obj2), c0161h2.E(n6.m(i14), c0165l3)));
                                } else {
                                    o0.o(x(iG), obj2, c0161h2.E(n6.m(i14), c0165l3));
                                    n6.D(i14, obj2);
                                }
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 10:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                o0.o(x(iG), obj2, c0161h2.i());
                                n6.D(i6, obj2);
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 11:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                o0.m(c0161h2.Q(), x(iG), obj2);
                                n6.D(i6, obj2);
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 12:
                                int i15 = i6;
                                c0161h2 = c0161h3;
                                n6 = n7;
                                int iN = c0161h2.n();
                                n6.k(i15);
                                o0.m(iN, x(iG), obj2);
                                n6.D(i15, obj2);
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 13:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                o0.m(c0161h2.F(), x(iG), obj2);
                                n6.D(i6, obj2);
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 14:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                o0.n(obj2, x(iG), c0161h2.H());
                                n6.D(i6, obj2);
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 15:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                o0.m(c0161h2.J(), x(iG), obj2);
                                n6.D(i6, obj2);
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 16:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                o0.n(obj2, x(iG), c0161h2.L());
                                n6.D(i6, obj2);
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                                int i16 = i6;
                                c0161h2 = c0161h3;
                                C0165l c0165l4 = c0165l2;
                                n6 = n7;
                                if (n6.p(i16, obj2)) {
                                    o0.o(x(iG), obj2, AbstractC0174v.c(o0.f4378d.i(x(iG), obj2), c0161h2.x(n6.m(i16), c0165l4)));
                                } else {
                                    o0.o(x(iG), obj2, c0161h2.x(n6.m(i16), c0165l4));
                                    n6.D(i16, obj2);
                                }
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 18:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                c0161h2.m(d6.c(x(iG), obj2));
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 19:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                c0161h2.v(d6.c(x(iG), obj2));
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                c0161h2.C(d6.c(x(iG), obj2));
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 21:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                c0161h2.T(d6.c(x(iG), obj2));
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 22:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                c0161h2.A(d6.c(x(iG), obj2));
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 23:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                c0161h2.t(d6.c(x(iG), obj2));
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 24:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                c0161h2.r(d6.c(x(iG), obj2));
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 25:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                c0161h2.h(d6.c(x(iG), obj2));
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 26:
                                c0161h2 = c0161h3;
                                n6 = n7;
                                if ((536870912 & iG) != 0) {
                                    try {
                                        c0161h2.O(d6.c(iG & 1048575, obj2), true);
                                    } catch (C0175w unused3) {
                                        g0Var.getClass();
                                        if (f0VarB2 == null) {
                                            abstractC0172t = (AbstractC0172t) obj2;
                                            f0VarB = abstractC0172t.unknownFields;
                                            if (f0VarB == f0Var) {
                                                f0VarB = f0.b();
                                                abstractC0172t.unknownFields = f0VarB;
                                            }
                                            f0VarB2 = f0VarB;
                                        }
                                        if (!g0.a(f0VarB2, c0161h2)) {
                                            while (i8 < i7) {
                                                n6.j(obj2, f0VarB2, iArr[i8]);
                                                i8++;
                                            }
                                            if (f0VarB2 != null) {
                                                ((AbstractC0172t) obj2).unknownFields = f0VarB2;
                                                return;
                                            }
                                            return;
                                        }
                                    }
                                } else {
                                    c0161h2.O(d6.c(iG & 1048575, obj2), false);
                                }
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 27:
                                try {
                                    try {
                                        n7.A(obj2, iG, c0161h3, n7.m(i6), c0165l);
                                        n6 = n7;
                                        c0161h2 = c0161h3;
                                    } catch (C0175w unused4) {
                                        n6 = n7;
                                        c0161h2 = c0161h3;
                                        g0Var.getClass();
                                        if (f0VarB2 == null) {
                                            abstractC0172t = (AbstractC0172t) obj2;
                                            f0VarB = abstractC0172t.unknownFields;
                                            if (f0VarB == f0Var) {
                                                f0VarB = f0.b();
                                                abstractC0172t.unknownFields = f0VarB;
                                            }
                                            f0VarB2 = f0VarB;
                                        }
                                        if (!g0.a(f0VarB2, c0161h2)) {
                                            while (i8 < i7) {
                                                n6.j(obj2, f0VarB2, iArr[i8]);
                                                i8++;
                                            }
                                            if (f0VarB2 != null) {
                                                ((AbstractC0172t) obj2).unknownFields = f0VarB2;
                                                return;
                                            }
                                            return;
                                        }
                                    }
                                } catch (C0175w unused5) {
                                    n6 = n7;
                                    c0161h2 = c0161h3;
                                    g0Var.getClass();
                                    if (f0VarB2 == null) {
                                        abstractC0172t = (AbstractC0172t) obj2;
                                        f0VarB = abstractC0172t.unknownFields;
                                        if (f0VarB == f0Var) {
                                            f0VarB = f0.b();
                                            abstractC0172t.unknownFields = f0VarB;
                                        }
                                        f0VarB2 = f0VarB;
                                    }
                                    if (!g0.a(f0VarB2, c0161h2)) {
                                        while (i8 < i7) {
                                            n6.j(obj2, f0VarB2, iArr[i8]);
                                            i8++;
                                        }
                                        if (f0VarB2 != null) {
                                            ((AbstractC0172t) obj2).unknownFields = f0VarB2;
                                            return;
                                        }
                                        return;
                                    }
                                    c0165l2 = c0165l;
                                    n7 = n6;
                                    c0161h3 = c0161h2;
                                    break;
                                }
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 28:
                                c0161h3.k(d6.c(x(iG), obj2));
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 29:
                                c0161h3.R(d6.c(x(iG), obj2));
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 30:
                                c0161h3.o(d6.c(x(iG), obj2));
                                n7.k(i6);
                                Class cls = Y.f4317a;
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 31:
                                c0161h3.G(d6.c(x(iG), obj2));
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 32:
                                c0161h3.I(d6.c(x(iG), obj2));
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 33:
                                c0161h3.K(d6.c(x(iG), obj2));
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 34:
                                c0161h3.M(d6.c(x(iG), obj2));
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 35:
                                c0161h3.m(d6.c(x(iG), obj2));
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 36:
                                c0161h3.v(d6.c(x(iG), obj2));
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 37:
                                c0161h3.C(d6.c(x(iG), obj2));
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 38:
                                c0161h3.T(d6.c(x(iG), obj2));
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 39:
                                c0161h3.A(d6.c(x(iG), obj2));
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 40:
                                c0161h3.t(d6.c(x(iG), obj2));
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 41:
                                c0161h3.r(d6.c(iG & 1048575, obj2));
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 42:
                                c0161h3.h(d6.c(iG & 1048575, obj2));
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 43:
                                c0161h3.R(d6.c(iG & 1048575, obj2));
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 44:
                                c0161h3.o(d6.c(iG & 1048575, obj2));
                                n7.k(i6);
                                Class cls2 = Y.f4317a;
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 45:
                                c0161h3.G(d6.c(iG & 1048575, obj2));
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 46:
                                c0161h3.I(d6.c(iG & 1048575, obj2));
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 47:
                                c0161h3.K(d6.c(iG & 1048575, obj2));
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 48:
                                c0161h3.M(d6.c(iG & 1048575, obj2));
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 49:
                                c0161h3.y(d6.c(iG & 1048575, obj2), n7.m(i6), c0165l2);
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 50:
                                try {
                                    try {
                                        n7.s(obj2, i6, n7.l(i6), c0165l2, c0161h);
                                        c0161h3 = c0161h;
                                        n6 = n7;
                                        c0161h2 = c0161h3;
                                    } catch (C0175w unused6) {
                                        n6 = n7;
                                        c0161h2 = c0161h;
                                        g0Var.getClass();
                                        if (f0VarB2 == null) {
                                            abstractC0172t = (AbstractC0172t) obj2;
                                            f0VarB = abstractC0172t.unknownFields;
                                            if (f0VarB == f0Var) {
                                                f0VarB = f0.b();
                                                abstractC0172t.unknownFields = f0VarB;
                                            }
                                            f0VarB2 = f0VarB;
                                        }
                                        if (!g0.a(f0VarB2, c0161h2)) {
                                            while (i8 < i7) {
                                                n6.j(obj2, f0VarB2, iArr[i8]);
                                                i8++;
                                            }
                                            if (f0VarB2 != null) {
                                                ((AbstractC0172t) obj2).unknownFields = f0VarB2;
                                                return;
                                            }
                                            return;
                                        }
                                    }
                                } catch (C0175w unused7) {
                                    c0161h2 = c0161h;
                                    n6 = n7;
                                }
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 51:
                                o0.o(iG & 1048575, obj2, Double.valueOf(c0161h3.l()));
                                n7.E(iC, i6, obj2);
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 52:
                                o0.o(iG & 1048575, obj2, Float.valueOf(c0161h3.u()));
                                n7.E(iC, i6, obj2);
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 53:
                                o0.o(iG & 1048575, obj2, Long.valueOf(c0161h3.B()));
                                n7.E(iC, i6, obj2);
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 54:
                                o0.o(iG & 1048575, obj2, Long.valueOf(c0161h3.S()));
                                n7.E(iC, i6, obj2);
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 55:
                                o0.o(iG & 1048575, obj2, Integer.valueOf(c0161h3.z()));
                                n7.E(iC, i6, obj2);
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 56:
                                o0.o(iG & 1048575, obj2, Long.valueOf(c0161h3.s()));
                                n7.E(iC, i6, obj2);
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 57:
                                o0.o(iG & 1048575, obj2, Integer.valueOf(c0161h3.q()));
                                n7.E(iC, i6, obj2);
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 58:
                                o0.o(iG & 1048575, obj2, Boolean.valueOf(c0161h3.g()));
                                n7.E(iC, i6, obj2);
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 59:
                                n7.B(obj2, iG, c0161h3);
                                n7.E(iC, i6, obj2);
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case PipesConfigBase.DEFAULT_STALE_FETCHER_DELAY_SECONDS /* 60 */:
                                if (n7.q(iC, i6, obj2)) {
                                    long j6 = iG & 1048575;
                                    o0.o(j6, obj2, AbstractC0174v.c(o0.f4378d.i(j6, obj2), c0161h3.E(n7.m(i6), c0165l2)));
                                } else {
                                    o0.o(iG & 1048575, obj2, c0161h3.E(n7.m(i6), c0165l2));
                                    n7.D(i6, obj2);
                                }
                                n7.E(iC, i6, obj2);
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 61:
                                o0.o(iG & 1048575, obj2, c0161h3.i());
                                n7.E(iC, i6, obj2);
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 62:
                                o0.o(iG & 1048575, obj2, Integer.valueOf(c0161h3.Q()));
                                n7.E(iC, i6, obj2);
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 63:
                                int iN2 = c0161h3.n();
                                n7.k(i6);
                                o0.o(iG & 1048575, obj2, Integer.valueOf(iN2));
                                n7.E(iC, i6, obj2);
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 64:
                                o0.o(iG & 1048575, obj2, Integer.valueOf(c0161h3.F()));
                                n7.E(iC, i6, obj2);
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 65:
                                o0.o(iG & 1048575, obj2, Long.valueOf(c0161h3.H()));
                                n7.E(iC, i6, obj2);
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 66:
                                o0.o(iG & 1048575, obj2, Integer.valueOf(c0161h3.J()));
                                n7.E(iC, i6, obj2);
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 67:
                                o0.o(iG & 1048575, obj2, Long.valueOf(c0161h3.L()));
                                n7.E(iC, i6, obj2);
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            case 68:
                                o0.o(iG & 1048575, obj2, c0161h3.x(n7.m(i6), c0165l2));
                                n7.E(iC, i6, obj2);
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                            default:
                                if (f0VarB2 == null) {
                                    g0Var.getClass();
                                    f0VarB2 = f0.b();
                                }
                                g0Var.getClass();
                                if (!g0.a(f0VarB2, c0161h3)) {
                                    while (i8 < i7) {
                                        n7.j(obj2, f0VarB2, iArr[i8]);
                                        i8++;
                                    }
                                }
                                n6 = n7;
                                c0161h2 = c0161h3;
                                c0165l2 = c0165l;
                                n7 = n6;
                                c0161h3 = c0161h2;
                                break;
                        }
                    } catch (C0175w unused8) {
                    }
                } else if (iC == Integer.MAX_VALUE) {
                    while (i8 < i7) {
                        n7.j(obj2, f0VarB2, iArr[i8]);
                        i8++;
                    }
                    if (f0VarB2 != null) {
                        g0Var.getClass();
                    }
                } else {
                    g0Var.getClass();
                    if (f0VarB2 == null) {
                        AbstractC0172t abstractC0172t2 = (AbstractC0172t) obj2;
                        f0 f0VarB3 = abstractC0172t2.unknownFields;
                        if (f0VarB3 == f0Var) {
                            f0VarB3 = f0.b();
                            abstractC0172t2.unknownFields = f0VarB3;
                        }
                        f0VarB2 = f0VarB3;
                    }
                    if (!g0.a(f0VarB2, c0161h3)) {
                        while (i8 < i7) {
                            n7.j(obj2, f0VarB2, iArr[i8]);
                            i8++;
                        }
                        if (f0VarB2 != null) {
                        }
                    }
                }
            } catch (Throwable th4) {
                th = th4;
                n6 = n7;
            }
        }
        ((AbstractC0172t) obj2).unknownFields = f0VarB2;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:9:0x001f  */
    @Override // androidx.datastore.preferences.protobuf.X
    public final void h(AbstractC0172t abstractC0172t, AbstractC0172t abstractC0172t2) {
        AbstractC0172t abstractC0172t3;
        abstractC0172t2.getClass();
        int i6 = 0;
        while (true) {
            int[] iArr = this.f4289a;
            if (i6 >= iArr.length) {
                AbstractC0172t abstractC0172t4 = abstractC0172t;
                if (this.f4295g) {
                    return;
                }
                Y.w(this.f4301m, abstractC0172t4, abstractC0172t2);
                return;
            }
            int iG = G(i6);
            long j6 = 1048575 & iG;
            int i7 = iArr[i6];
            switch (F(iG)) {
                case 0:
                    if (!p(i6, abstractC0172t2)) {
                        abstractC0172t3 = abstractC0172t;
                    } else {
                        n0 n0Var = o0.f4378d;
                        abstractC0172t3 = abstractC0172t;
                        n0Var.m(abstractC0172t3, j6, n0Var.e(j6, abstractC0172t2));
                        D(i6, abstractC0172t3);
                    }
                    break;
                case 1:
                    if (p(i6, abstractC0172t2)) {
                        n0 n0Var2 = o0.f4378d;
                        n0Var2.n(abstractC0172t, j6, n0Var2.f(j6, abstractC0172t2));
                        D(i6, abstractC0172t);
                    }
                    abstractC0172t3 = abstractC0172t;
                    break;
                case 2:
                    if (p(i6, abstractC0172t2)) {
                        o0.n(abstractC0172t, j6, o0.f4378d.h(j6, abstractC0172t2));
                        D(i6, abstractC0172t);
                    }
                    abstractC0172t3 = abstractC0172t;
                    break;
                case 3:
                    if (p(i6, abstractC0172t2)) {
                        o0.n(abstractC0172t, j6, o0.f4378d.h(j6, abstractC0172t2));
                        D(i6, abstractC0172t);
                    }
                    abstractC0172t3 = abstractC0172t;
                    break;
                case 4:
                    if (p(i6, abstractC0172t2)) {
                        o0.m(o0.f4378d.g(j6, abstractC0172t2), j6, abstractC0172t);
                        D(i6, abstractC0172t);
                    }
                    abstractC0172t3 = abstractC0172t;
                    break;
                case 5:
                    if (p(i6, abstractC0172t2)) {
                        o0.n(abstractC0172t, j6, o0.f4378d.h(j6, abstractC0172t2));
                        D(i6, abstractC0172t);
                    }
                    abstractC0172t3 = abstractC0172t;
                    break;
                case 6:
                    if (p(i6, abstractC0172t2)) {
                        o0.m(o0.f4378d.g(j6, abstractC0172t2), j6, abstractC0172t);
                        D(i6, abstractC0172t);
                    }
                    abstractC0172t3 = abstractC0172t;
                    break;
                case 7:
                    if (p(i6, abstractC0172t2)) {
                        n0 n0Var3 = o0.f4378d;
                        n0Var3.k(abstractC0172t, j6, n0Var3.c(j6, abstractC0172t2));
                        D(i6, abstractC0172t);
                    }
                    abstractC0172t3 = abstractC0172t;
                    break;
                case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                    if (p(i6, abstractC0172t2)) {
                        o0.o(j6, abstractC0172t, o0.f4378d.i(j6, abstractC0172t2));
                        D(i6, abstractC0172t);
                    }
                    abstractC0172t3 = abstractC0172t;
                    break;
                case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                    t(abstractC0172t, abstractC0172t2, i6);
                    abstractC0172t3 = abstractC0172t;
                    break;
                case 10:
                    if (p(i6, abstractC0172t2)) {
                        o0.o(j6, abstractC0172t, o0.f4378d.i(j6, abstractC0172t2));
                        D(i6, abstractC0172t);
                    }
                    abstractC0172t3 = abstractC0172t;
                    break;
                case 11:
                    if (p(i6, abstractC0172t2)) {
                        o0.m(o0.f4378d.g(j6, abstractC0172t2), j6, abstractC0172t);
                        D(i6, abstractC0172t);
                    }
                    abstractC0172t3 = abstractC0172t;
                    break;
                case 12:
                    if (p(i6, abstractC0172t2)) {
                        o0.m(o0.f4378d.g(j6, abstractC0172t2), j6, abstractC0172t);
                        D(i6, abstractC0172t);
                    }
                    abstractC0172t3 = abstractC0172t;
                    break;
                case 13:
                    if (p(i6, abstractC0172t2)) {
                        o0.m(o0.f4378d.g(j6, abstractC0172t2), j6, abstractC0172t);
                        D(i6, abstractC0172t);
                    }
                    abstractC0172t3 = abstractC0172t;
                    break;
                case 14:
                    if (p(i6, abstractC0172t2)) {
                        o0.n(abstractC0172t, j6, o0.f4378d.h(j6, abstractC0172t2));
                        D(i6, abstractC0172t);
                    }
                    abstractC0172t3 = abstractC0172t;
                    break;
                case 15:
                    if (p(i6, abstractC0172t2)) {
                        o0.m(o0.f4378d.g(j6, abstractC0172t2), j6, abstractC0172t);
                        D(i6, abstractC0172t);
                    }
                    abstractC0172t3 = abstractC0172t;
                    break;
                case 16:
                    if (p(i6, abstractC0172t2)) {
                        o0.n(abstractC0172t, j6, o0.f4378d.h(j6, abstractC0172t2));
                        D(i6, abstractC0172t);
                    }
                    abstractC0172t3 = abstractC0172t;
                    break;
                case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                    t(abstractC0172t, abstractC0172t2, i6);
                    abstractC0172t3 = abstractC0172t;
                    break;
                case 18:
                case 19:
                case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
                case 21:
                case 22:
                case 23:
                case 24:
                case 25:
                case 26:
                case 27:
                case 28:
                case 29:
                case 30:
                case 31:
                case 32:
                case 33:
                case 34:
                case 35:
                case 36:
                case 37:
                case 38:
                case 39:
                case 40:
                case 41:
                case 42:
                case 43:
                case 44:
                case 45:
                case 46:
                case 47:
                case 48:
                case 49:
                    this.f4300l.b(j6, abstractC0172t, abstractC0172t2);
                    abstractC0172t3 = abstractC0172t;
                    break;
                case 50:
                    Class cls = Y.f4317a;
                    n0 n0Var4 = o0.f4378d;
                    Object objI = n0Var4.i(j6, abstractC0172t);
                    Object objI2 = n0Var4.i(j6, abstractC0172t2);
                    this.f4302n.getClass();
                    o0.o(j6, abstractC0172t, J.b(objI, objI2));
                    abstractC0172t3 = abstractC0172t;
                    break;
                case 51:
                case 52:
                case 53:
                case 54:
                case 55:
                case 56:
                case 57:
                case 58:
                case 59:
                    if (q(i7, i6, abstractC0172t2)) {
                        o0.o(j6, abstractC0172t, o0.f4378d.i(j6, abstractC0172t2));
                        E(i7, i6, abstractC0172t);
                    }
                    abstractC0172t3 = abstractC0172t;
                    break;
                case PipesConfigBase.DEFAULT_STALE_FETCHER_DELAY_SECONDS /* 60 */:
                    u(abstractC0172t, abstractC0172t2, i6);
                    abstractC0172t3 = abstractC0172t;
                    break;
                case 61:
                case 62:
                case 63:
                case 64:
                case 65:
                case 66:
                case 67:
                    if (q(i7, i6, abstractC0172t2)) {
                        o0.o(j6, abstractC0172t, o0.f4378d.i(j6, abstractC0172t2));
                        E(i7, i6, abstractC0172t);
                    }
                    abstractC0172t3 = abstractC0172t;
                    break;
                case 68:
                    u(abstractC0172t, abstractC0172t2, i6);
                    abstractC0172t3 = abstractC0172t;
                    break;
                default:
                    abstractC0172t3 = abstractC0172t;
                    break;
            }
            i6 += 3;
            abstractC0172t = abstractC0172t3;
        }
    }

    public final boolean i(AbstractC0172t abstractC0172t, Object obj, int i6) {
        return p(i6, abstractC0172t) == p(i6, obj);
    }

    public final void j(Object obj, Object obj2, int i6) {
        int i7 = this.f4289a[i6];
        if (o0.f4378d.i(G(i6) & 1048575, obj) == null) {
            return;
        }
        k(i6);
    }

    public final void k(int i6) {
        if (this.f4290b[((i6 / 3) * 2) + 1] != null) {
            throw new ClassCastException();
        }
    }

    public final Object l(int i6) {
        return this.f4290b[(i6 / 3) * 2];
    }

    public final X m(int i6) {
        int i7 = (i6 / 3) * 2;
        Object[] objArr = this.f4290b;
        X x5 = (X) objArr[i7];
        if (x5 != null) {
            return x5;
        }
        X xA = U.f4308c.a((Class) objArr[i7 + 1]);
        objArr[i7] = xA;
        return xA;
    }

    public final int n(Object obj) {
        int i6;
        int iY;
        int iA;
        int iY2;
        int iW;
        int iU;
        int iY3;
        int iX;
        int iR;
        int iY4;
        int iV;
        Unsafe unsafe = f4288p;
        int i7 = -1;
        int i8 = 0;
        int i9 = 0;
        int i10 = 0;
        while (true) {
            int[] iArr = this.f4289a;
            if (i8 >= iArr.length) {
                this.f4301m.getClass();
                return ((AbstractC0172t) obj).unknownFields.a() + i9;
            }
            int iG = G(i8);
            int i11 = iArr[i8];
            int iF = F(iG);
            if (iF <= 17) {
                int i12 = iArr[i8 + 2];
                int i13 = i12 & 1048575;
                i6 = 1 << (i12 >>> 20);
                if (i13 != i7) {
                    i10 = unsafe.getInt(obj, i13);
                    i7 = i13;
                }
            } else {
                i6 = 0;
            }
            long j6 = iG & 1048575;
            switch (iF) {
                case 0:
                    if ((i6 & i10) != 0) {
                        i9 = A3.a.i(i11, 8, i9);
                    }
                    break;
                case 1:
                    if ((i10 & i6) != 0) {
                        i9 = A3.a.i(i11, 4, i9);
                    }
                    break;
                case 2:
                    if ((i10 & i6) != 0) {
                        long j7 = unsafe.getLong(obj, j6);
                        iY = C0163j.y(i11);
                        iA = C0163j.A(j7);
                        iY4 = iA + iY;
                        i9 += iY4;
                    }
                    break;
                case 3:
                    if ((i10 & i6) != 0) {
                        long j8 = unsafe.getLong(obj, j6);
                        iY = C0163j.y(i11);
                        iA = C0163j.A(j8);
                        iY4 = iA + iY;
                        i9 += iY4;
                    }
                    break;
                case 4:
                    if ((i10 & i6) != 0) {
                        int i14 = unsafe.getInt(obj, j6);
                        iY2 = C0163j.y(i11);
                        iW = C0163j.w(i14);
                        iU = iW + iY2;
                        i9 += iU;
                    }
                    break;
                case 5:
                    if ((i10 & i6) != 0) {
                        iU = C0163j.u(i11);
                        i9 += iU;
                    }
                    break;
                case 6:
                    if ((i10 & i6) != 0) {
                        iU = C0163j.t(i11);
                        i9 += iU;
                    }
                    break;
                case 7:
                    if ((i10 & i6) != 0) {
                        i9 = A3.a.i(i11, 1, i9);
                    }
                    break;
                case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                    if ((i10 & i6) != 0) {
                        Object object = unsafe.getObject(obj, j6);
                        if (object instanceof C0159f) {
                            iR = C0163j.r(i11, (C0159f) object);
                        } else {
                            iY3 = C0163j.y(i11);
                            iX = C0163j.x((String) object);
                            iR = iX + iY3;
                        }
                        i9 = iR + i9;
                    }
                    break;
                case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                    if ((i10 & i6) != 0) {
                        Object object2 = unsafe.getObject(obj, j6);
                        X xM = m(i8);
                        Class cls = Y.f4317a;
                        int iY5 = C0163j.y(i11);
                        int iB = ((AbstractC0154a) object2).b(xM);
                        i9 = A3.a.j(iB, iB, iY5, i9);
                    }
                    break;
                case 10:
                    if ((i10 & i6) != 0) {
                        iU = C0163j.r(i11, (C0159f) unsafe.getObject(obj, j6));
                        i9 += iU;
                    }
                    break;
                case 11:
                    if ((i10 & i6) != 0) {
                        int i15 = unsafe.getInt(obj, j6);
                        iY2 = C0163j.y(i11);
                        iW = C0163j.z(i15);
                        iU = iW + iY2;
                        i9 += iU;
                    }
                    break;
                case 12:
                    if ((i10 & i6) != 0) {
                        int i16 = unsafe.getInt(obj, j6);
                        iY2 = C0163j.y(i11);
                        iW = C0163j.w(i16);
                        iU = iW + iY2;
                        i9 += iU;
                    }
                    break;
                case 13:
                    if ((i10 & i6) != 0) {
                        i9 = A3.a.i(i11, 4, i9);
                    }
                    break;
                case 14:
                    if ((i6 & i10) != 0) {
                        i9 = A3.a.i(i11, 8, i9);
                    }
                    break;
                case 15:
                    if ((i10 & i6) != 0) {
                        int i17 = unsafe.getInt(obj, j6);
                        iY2 = C0163j.y(i11);
                        iW = C0163j.z((i17 >> 31) ^ (i17 << 1));
                        iU = iW + iY2;
                        i9 += iU;
                    }
                    break;
                case 16:
                    if ((i10 & i6) != 0) {
                        long j9 = unsafe.getLong(obj, j6);
                        iY = C0163j.y(i11);
                        iA = C0163j.A((j9 >> 63) ^ (j9 << 1));
                        iY4 = iA + iY;
                        i9 += iY4;
                    }
                    break;
                case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                    if ((i10 & i6) != 0) {
                        iU = C0163j.v(i11, (AbstractC0154a) unsafe.getObject(obj, j6), m(i8));
                        i9 += iU;
                    }
                    break;
                case 18:
                    iU = Y.f(i11, (List) unsafe.getObject(obj, j6));
                    i9 += iU;
                    break;
                case 19:
                    iU = Y.d(i11, (List) unsafe.getObject(obj, j6));
                    i9 += iU;
                    break;
                case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
                    iU = Y.j(i11, (List) unsafe.getObject(obj, j6));
                    i9 += iU;
                    break;
                case 21:
                    iU = Y.t(i11, (List) unsafe.getObject(obj, j6));
                    i9 += iU;
                    break;
                case 22:
                    iU = Y.h(i11, (List) unsafe.getObject(obj, j6));
                    i9 += iU;
                    break;
                case 23:
                    iU = Y.f(i11, (List) unsafe.getObject(obj, j6));
                    i9 += iU;
                    break;
                case 24:
                    iU = Y.d(i11, (List) unsafe.getObject(obj, j6));
                    i9 += iU;
                    break;
                case 25:
                    List list = (List) unsafe.getObject(obj, j6);
                    Class cls2 = Y.f4317a;
                    int size = list.size();
                    iY4 = size == 0 ? 0 : (C0163j.y(i11) + 1) * size;
                    i9 += iY4;
                    break;
                case 26:
                    iU = Y.q(i11, (List) unsafe.getObject(obj, j6));
                    i9 += iU;
                    break;
                case 27:
                    iU = Y.l(i11, (List) unsafe.getObject(obj, j6), m(i8));
                    i9 += iU;
                    break;
                case 28:
                    iU = Y.a(i11, (List) unsafe.getObject(obj, j6));
                    i9 += iU;
                    break;
                case 29:
                    iU = Y.r(i11, (List) unsafe.getObject(obj, j6));
                    i9 += iU;
                    break;
                case 30:
                    iU = Y.b(i11, (List) unsafe.getObject(obj, j6));
                    i9 += iU;
                    break;
                case 31:
                    iU = Y.d(i11, (List) unsafe.getObject(obj, j6));
                    i9 += iU;
                    break;
                case 32:
                    iU = Y.f(i11, (List) unsafe.getObject(obj, j6));
                    i9 += iU;
                    break;
                case 33:
                    iU = Y.m(i11, (List) unsafe.getObject(obj, j6));
                    i9 += iU;
                    break;
                case 34:
                    iU = Y.o(i11, (List) unsafe.getObject(obj, j6));
                    i9 += iU;
                    break;
                case 35:
                    int iG2 = Y.g((List) unsafe.getObject(obj, j6));
                    if (iG2 > 0) {
                        i9 = A3.a.j(iG2, C0163j.y(i11), iG2, i9);
                    }
                    break;
                case 36:
                    int iE = Y.e((List) unsafe.getObject(obj, j6));
                    if (iE > 0) {
                        i9 = A3.a.j(iE, C0163j.y(i11), iE, i9);
                    }
                    break;
                case 37:
                    int iK = Y.k((List) unsafe.getObject(obj, j6));
                    if (iK > 0) {
                        i9 = A3.a.j(iK, C0163j.y(i11), iK, i9);
                    }
                    break;
                case 38:
                    int iU2 = Y.u((List) unsafe.getObject(obj, j6));
                    if (iU2 > 0) {
                        i9 = A3.a.j(iU2, C0163j.y(i11), iU2, i9);
                    }
                    break;
                case 39:
                    int i18 = Y.i((List) unsafe.getObject(obj, j6));
                    if (i18 > 0) {
                        i9 = A3.a.j(i18, C0163j.y(i11), i18, i9);
                    }
                    break;
                case 40:
                    int iG3 = Y.g((List) unsafe.getObject(obj, j6));
                    if (iG3 > 0) {
                        i9 = A3.a.j(iG3, C0163j.y(i11), iG3, i9);
                    }
                    break;
                case 41:
                    int iE2 = Y.e((List) unsafe.getObject(obj, j6));
                    if (iE2 > 0) {
                        i9 = A3.a.j(iE2, C0163j.y(i11), iE2, i9);
                    }
                    break;
                case 42:
                    List list2 = (List) unsafe.getObject(obj, j6);
                    Class cls3 = Y.f4317a;
                    int size2 = list2.size();
                    if (size2 > 0) {
                        i9 = A3.a.j(size2, C0163j.y(i11), size2, i9);
                    }
                    break;
                case 43:
                    int iS = Y.s((List) unsafe.getObject(obj, j6));
                    if (iS > 0) {
                        i9 = A3.a.j(iS, C0163j.y(i11), iS, i9);
                    }
                    break;
                case 44:
                    int iC = Y.c((List) unsafe.getObject(obj, j6));
                    if (iC > 0) {
                        i9 = A3.a.j(iC, C0163j.y(i11), iC, i9);
                    }
                    break;
                case 45:
                    int iE3 = Y.e((List) unsafe.getObject(obj, j6));
                    if (iE3 > 0) {
                        i9 = A3.a.j(iE3, C0163j.y(i11), iE3, i9);
                    }
                    break;
                case 46:
                    int iG4 = Y.g((List) unsafe.getObject(obj, j6));
                    if (iG4 > 0) {
                        i9 = A3.a.j(iG4, C0163j.y(i11), iG4, i9);
                    }
                    break;
                case 47:
                    int iN = Y.n((List) unsafe.getObject(obj, j6));
                    if (iN > 0) {
                        i9 = A3.a.j(iN, C0163j.y(i11), iN, i9);
                    }
                    break;
                case 48:
                    int iP = Y.p((List) unsafe.getObject(obj, j6));
                    if (iP > 0) {
                        i9 = A3.a.j(iP, C0163j.y(i11), iP, i9);
                    }
                    break;
                case 49:
                    List list3 = (List) unsafe.getObject(obj, j6);
                    X xM2 = m(i8);
                    Class cls4 = Y.f4317a;
                    int size3 = list3.size();
                    if (size3 == 0) {
                        iV = 0;
                    } else {
                        iV = 0;
                        for (int i19 = 0; i19 < size3; i19++) {
                            iV += C0163j.v(i11, (AbstractC0154a) list3.get(i19), xM2);
                        }
                    }
                    i9 += iV;
                    break;
                case 50:
                    Object object3 = unsafe.getObject(obj, j6);
                    Object objL = l(i8);
                    this.f4302n.getClass();
                    iU = J.a(object3, objL, i11);
                    i9 += iU;
                    break;
                case 51:
                    if (q(i11, i8, obj)) {
                        i9 = A3.a.i(i11, 8, i9);
                    }
                    break;
                case 52:
                    if (q(i11, i8, obj)) {
                        i9 = A3.a.i(i11, 4, i9);
                    }
                    break;
                case 53:
                    if (q(i11, i8, obj)) {
                        long jZ = z(j6, obj);
                        iY = C0163j.y(i11);
                        iA = C0163j.A(jZ);
                        iY4 = iA + iY;
                        i9 += iY4;
                    }
                    break;
                case 54:
                    if (q(i11, i8, obj)) {
                        long jZ2 = z(j6, obj);
                        iY = C0163j.y(i11);
                        iA = C0163j.A(jZ2);
                        iY4 = iA + iY;
                        i9 += iY4;
                    }
                    break;
                case 55:
                    if (q(i11, i8, obj)) {
                        int iY6 = y(j6, obj);
                        iY2 = C0163j.y(i11);
                        iW = C0163j.w(iY6);
                        iU = iW + iY2;
                        i9 += iU;
                    }
                    break;
                case 56:
                    if (q(i11, i8, obj)) {
                        iU = C0163j.u(i11);
                        i9 += iU;
                    }
                    break;
                case 57:
                    if (q(i11, i8, obj)) {
                        iU = C0163j.t(i11);
                        i9 += iU;
                    }
                    break;
                case 58:
                    if (q(i11, i8, obj)) {
                        i9 = A3.a.i(i11, 1, i9);
                    }
                    break;
                case 59:
                    if (q(i11, i8, obj)) {
                        Object object4 = unsafe.getObject(obj, j6);
                        if (object4 instanceof C0159f) {
                            iR = C0163j.r(i11, (C0159f) object4);
                        } else {
                            iY3 = C0163j.y(i11);
                            iX = C0163j.x((String) object4);
                            iR = iX + iY3;
                        }
                        i9 = iR + i9;
                    }
                    break;
                case PipesConfigBase.DEFAULT_STALE_FETCHER_DELAY_SECONDS /* 60 */:
                    if (q(i11, i8, obj)) {
                        Object object5 = unsafe.getObject(obj, j6);
                        X xM3 = m(i8);
                        Class cls5 = Y.f4317a;
                        int iY7 = C0163j.y(i11);
                        int iB2 = ((AbstractC0154a) object5).b(xM3);
                        i9 = A3.a.j(iB2, iB2, iY7, i9);
                    }
                    break;
                case 61:
                    if (q(i11, i8, obj)) {
                        iU = C0163j.r(i11, (C0159f) unsafe.getObject(obj, j6));
                        i9 += iU;
                    }
                    break;
                case 62:
                    if (q(i11, i8, obj)) {
                        int iY8 = y(j6, obj);
                        iY2 = C0163j.y(i11);
                        iW = C0163j.z(iY8);
                        iU = iW + iY2;
                        i9 += iU;
                    }
                    break;
                case 63:
                    if (q(i11, i8, obj)) {
                        int iY9 = y(j6, obj);
                        iY2 = C0163j.y(i11);
                        iW = C0163j.w(iY9);
                        iU = iW + iY2;
                        i9 += iU;
                    }
                    break;
                case 64:
                    if (q(i11, i8, obj)) {
                        i9 = A3.a.i(i11, 4, i9);
                    }
                    break;
                case 65:
                    if (q(i11, i8, obj)) {
                        i9 = A3.a.i(i11, 8, i9);
                    }
                    break;
                case 66:
                    if (q(i11, i8, obj)) {
                        int iY10 = y(j6, obj);
                        iY2 = C0163j.y(i11);
                        iW = C0163j.z((iY10 >> 31) ^ (iY10 << 1));
                        iU = iW + iY2;
                        i9 += iU;
                    }
                    break;
                case 67:
                    if (q(i11, i8, obj)) {
                        long jZ3 = z(j6, obj);
                        iY = C0163j.y(i11);
                        iA = C0163j.A((jZ3 >> 63) ^ (jZ3 << 1));
                        iY4 = iA + iY;
                        i9 += iY4;
                    }
                    break;
                case 68:
                    if (q(i11, i8, obj)) {
                        iU = C0163j.v(i11, (AbstractC0154a) unsafe.getObject(obj, j6), m(i8));
                        i9 += iU;
                    }
                    break;
            }
            i8 += 3;
        }
    }

    @Override // androidx.datastore.preferences.protobuf.X
    public final Object newInstance() {
        this.f4299k.getClass();
        return ((AbstractC0172t) this.f4293e).d(4);
    }

    public final int o(Object obj) {
        int iY;
        int iA;
        int iY2;
        int iW;
        int iU;
        int iY3;
        int iX;
        int iR;
        int iY4;
        int iA2;
        int iV;
        Unsafe unsafe = f4288p;
        int i6 = 0;
        int i7 = 0;
        while (true) {
            int[] iArr = this.f4289a;
            if (i6 >= iArr.length) {
                this.f4301m.getClass();
                return ((AbstractC0172t) obj).unknownFields.a() + i7;
            }
            int iG = G(i6);
            int iF = F(iG);
            int i8 = iArr[i6];
            long j6 = iG & 1048575;
            if (iF >= EnumC0169p.f4383s.r && iF <= EnumC0169p.t.r) {
                int i9 = iArr[i6 + 2];
            }
            switch (iF) {
                case 0:
                    if (p(i6, obj)) {
                        i7 = A3.a.i(i8, 8, i7);
                    }
                    break;
                case 1:
                    if (p(i6, obj)) {
                        i7 = A3.a.i(i8, 4, i7);
                    }
                    break;
                case 2:
                    if (p(i6, obj)) {
                        long jH = o0.f4378d.h(j6, obj);
                        iY = C0163j.y(i8);
                        iA = C0163j.A(jH);
                        iU = iA + iY;
                        i7 += iU;
                    }
                    break;
                case 3:
                    if (p(i6, obj)) {
                        long jH2 = o0.f4378d.h(j6, obj);
                        iY = C0163j.y(i8);
                        iA = C0163j.A(jH2);
                        iU = iA + iY;
                        i7 += iU;
                    }
                    break;
                case 4:
                    if (p(i6, obj)) {
                        int iG2 = o0.f4378d.g(j6, obj);
                        iY2 = C0163j.y(i8);
                        iW = C0163j.w(iG2);
                        iU = iW + iY2;
                        i7 += iU;
                    }
                    break;
                case 5:
                    if (p(i6, obj)) {
                        iU = C0163j.u(i8);
                        i7 += iU;
                    }
                    break;
                case 6:
                    if (p(i6, obj)) {
                        iU = C0163j.t(i8);
                        i7 += iU;
                    }
                    break;
                case 7:
                    if (p(i6, obj)) {
                        i7 = A3.a.i(i8, 1, i7);
                    }
                    break;
                case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                    if (p(i6, obj)) {
                        Object objI = o0.f4378d.i(j6, obj);
                        if (objI instanceof C0159f) {
                            iR = C0163j.r(i8, (C0159f) objI);
                        } else {
                            iY3 = C0163j.y(i8);
                            iX = C0163j.x((String) objI);
                            iR = iX + iY3;
                        }
                        i7 = iR + i7;
                    }
                    break;
                case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                    if (p(i6, obj)) {
                        Object objI2 = o0.f4378d.i(j6, obj);
                        X xM = m(i6);
                        Class cls = Y.f4317a;
                        int iY5 = C0163j.y(i8);
                        int iB = ((AbstractC0154a) objI2).b(xM);
                        i7 = A3.a.j(iB, iB, iY5, i7);
                    }
                    break;
                case 10:
                    if (p(i6, obj)) {
                        iU = C0163j.r(i8, (C0159f) o0.f4378d.i(j6, obj));
                        i7 += iU;
                    }
                    break;
                case 11:
                    if (p(i6, obj)) {
                        int iG3 = o0.f4378d.g(j6, obj);
                        iY2 = C0163j.y(i8);
                        iW = C0163j.z(iG3);
                        iU = iW + iY2;
                        i7 += iU;
                    }
                    break;
                case 12:
                    if (p(i6, obj)) {
                        int iG4 = o0.f4378d.g(j6, obj);
                        iY2 = C0163j.y(i8);
                        iW = C0163j.w(iG4);
                        iU = iW + iY2;
                        i7 += iU;
                    }
                    break;
                case 13:
                    if (p(i6, obj)) {
                        i7 = A3.a.i(i8, 4, i7);
                    }
                    break;
                case 14:
                    if (p(i6, obj)) {
                        i7 = A3.a.i(i8, 8, i7);
                    }
                    break;
                case 15:
                    if (p(i6, obj)) {
                        int iG5 = o0.f4378d.g(j6, obj);
                        iY2 = C0163j.y(i8);
                        iW = C0163j.z((iG5 >> 31) ^ (iG5 << 1));
                        iU = iW + iY2;
                        i7 += iU;
                    }
                    break;
                case 16:
                    if (p(i6, obj)) {
                        long jH3 = o0.f4378d.h(j6, obj);
                        iY4 = C0163j.y(i8);
                        iA2 = C0163j.A((jH3 >> 63) ^ (jH3 << 1));
                        iU = iA2 + iY4;
                        i7 += iU;
                    }
                    break;
                case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                    if (p(i6, obj)) {
                        iU = C0163j.v(i8, (AbstractC0154a) o0.f4378d.i(j6, obj), m(i6));
                        i7 += iU;
                    }
                    break;
                case 18:
                    iU = Y.f(i8, r(j6, obj));
                    i7 += iU;
                    break;
                case 19:
                    iU = Y.d(i8, r(j6, obj));
                    i7 += iU;
                    break;
                case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
                    iU = Y.j(i8, r(j6, obj));
                    i7 += iU;
                    break;
                case 21:
                    iU = Y.t(i8, r(j6, obj));
                    i7 += iU;
                    break;
                case 22:
                    iU = Y.h(i8, r(j6, obj));
                    i7 += iU;
                    break;
                case 23:
                    iU = Y.f(i8, r(j6, obj));
                    i7 += iU;
                    break;
                case 24:
                    iU = Y.d(i8, r(j6, obj));
                    i7 += iU;
                    break;
                case 25:
                    List listR = r(j6, obj);
                    Class cls2 = Y.f4317a;
                    int size = listR.size();
                    i7 += size == 0 ? 0 : (C0163j.y(i8) + 1) * size;
                    break;
                case 26:
                    iU = Y.q(i8, r(j6, obj));
                    i7 += iU;
                    break;
                case 27:
                    iU = Y.l(i8, r(j6, obj), m(i6));
                    i7 += iU;
                    break;
                case 28:
                    iU = Y.a(i8, r(j6, obj));
                    i7 += iU;
                    break;
                case 29:
                    iU = Y.r(i8, r(j6, obj));
                    i7 += iU;
                    break;
                case 30:
                    iU = Y.b(i8, r(j6, obj));
                    i7 += iU;
                    break;
                case 31:
                    iU = Y.d(i8, r(j6, obj));
                    i7 += iU;
                    break;
                case 32:
                    iU = Y.f(i8, r(j6, obj));
                    i7 += iU;
                    break;
                case 33:
                    iU = Y.m(i8, r(j6, obj));
                    i7 += iU;
                    break;
                case 34:
                    iU = Y.o(i8, r(j6, obj));
                    i7 += iU;
                    break;
                case 35:
                    int iG6 = Y.g((List) unsafe.getObject(obj, j6));
                    if (iG6 > 0) {
                        i7 = A3.a.j(iG6, C0163j.y(i8), iG6, i7);
                    }
                    break;
                case 36:
                    int iE = Y.e((List) unsafe.getObject(obj, j6));
                    if (iE > 0) {
                        i7 = A3.a.j(iE, C0163j.y(i8), iE, i7);
                    }
                    break;
                case 37:
                    int iK = Y.k((List) unsafe.getObject(obj, j6));
                    if (iK > 0) {
                        i7 = A3.a.j(iK, C0163j.y(i8), iK, i7);
                    }
                    break;
                case 38:
                    int iU2 = Y.u((List) unsafe.getObject(obj, j6));
                    if (iU2 > 0) {
                        i7 = A3.a.j(iU2, C0163j.y(i8), iU2, i7);
                    }
                    break;
                case 39:
                    int i10 = Y.i((List) unsafe.getObject(obj, j6));
                    if (i10 > 0) {
                        i7 = A3.a.j(i10, C0163j.y(i8), i10, i7);
                    }
                    break;
                case 40:
                    int iG7 = Y.g((List) unsafe.getObject(obj, j6));
                    if (iG7 > 0) {
                        i7 = A3.a.j(iG7, C0163j.y(i8), iG7, i7);
                    }
                    break;
                case 41:
                    int iE2 = Y.e((List) unsafe.getObject(obj, j6));
                    if (iE2 > 0) {
                        i7 = A3.a.j(iE2, C0163j.y(i8), iE2, i7);
                    }
                    break;
                case 42:
                    List list = (List) unsafe.getObject(obj, j6);
                    Class cls3 = Y.f4317a;
                    int size2 = list.size();
                    if (size2 > 0) {
                        i7 = A3.a.j(size2, C0163j.y(i8), size2, i7);
                    }
                    break;
                case 43:
                    int iS = Y.s((List) unsafe.getObject(obj, j6));
                    if (iS > 0) {
                        i7 = A3.a.j(iS, C0163j.y(i8), iS, i7);
                    }
                    break;
                case 44:
                    int iC = Y.c((List) unsafe.getObject(obj, j6));
                    if (iC > 0) {
                        i7 = A3.a.j(iC, C0163j.y(i8), iC, i7);
                    }
                    break;
                case 45:
                    int iE3 = Y.e((List) unsafe.getObject(obj, j6));
                    if (iE3 > 0) {
                        i7 = A3.a.j(iE3, C0163j.y(i8), iE3, i7);
                    }
                    break;
                case 46:
                    int iG8 = Y.g((List) unsafe.getObject(obj, j6));
                    if (iG8 > 0) {
                        i7 = A3.a.j(iG8, C0163j.y(i8), iG8, i7);
                    }
                    break;
                case 47:
                    int iN = Y.n((List) unsafe.getObject(obj, j6));
                    if (iN > 0) {
                        i7 = A3.a.j(iN, C0163j.y(i8), iN, i7);
                    }
                    break;
                case 48:
                    int iP = Y.p((List) unsafe.getObject(obj, j6));
                    if (iP > 0) {
                        i7 = A3.a.j(iP, C0163j.y(i8), iP, i7);
                    }
                    break;
                case 49:
                    List listR2 = r(j6, obj);
                    X xM2 = m(i6);
                    Class cls4 = Y.f4317a;
                    int size3 = listR2.size();
                    if (size3 == 0) {
                        iV = 0;
                    } else {
                        iV = 0;
                        for (int i11 = 0; i11 < size3; i11++) {
                            iV += C0163j.v(i8, (AbstractC0154a) listR2.get(i11), xM2);
                        }
                    }
                    i7 += iV;
                    break;
                case 50:
                    Object objI3 = o0.f4378d.i(j6, obj);
                    Object objL = l(i6);
                    this.f4302n.getClass();
                    iU = J.a(objI3, objL, i8);
                    i7 += iU;
                    break;
                case 51:
                    if (q(i8, i6, obj)) {
                        i7 = A3.a.i(i8, 8, i7);
                    }
                    break;
                case 52:
                    if (q(i8, i6, obj)) {
                        i7 = A3.a.i(i8, 4, i7);
                    }
                    break;
                case 53:
                    if (q(i8, i6, obj)) {
                        long jZ = z(j6, obj);
                        iY = C0163j.y(i8);
                        iA = C0163j.A(jZ);
                        iU = iA + iY;
                        i7 += iU;
                    }
                    break;
                case 54:
                    if (q(i8, i6, obj)) {
                        long jZ2 = z(j6, obj);
                        iY = C0163j.y(i8);
                        iA = C0163j.A(jZ2);
                        iU = iA + iY;
                        i7 += iU;
                    }
                    break;
                case 55:
                    if (q(i8, i6, obj)) {
                        int iY6 = y(j6, obj);
                        iY2 = C0163j.y(i8);
                        iW = C0163j.w(iY6);
                        iU = iW + iY2;
                        i7 += iU;
                    }
                    break;
                case 56:
                    if (q(i8, i6, obj)) {
                        iU = C0163j.u(i8);
                        i7 += iU;
                    }
                    break;
                case 57:
                    if (q(i8, i6, obj)) {
                        iU = C0163j.t(i8);
                        i7 += iU;
                    }
                    break;
                case 58:
                    if (q(i8, i6, obj)) {
                        i7 = A3.a.i(i8, 1, i7);
                    }
                    break;
                case 59:
                    if (q(i8, i6, obj)) {
                        Object objI4 = o0.f4378d.i(j6, obj);
                        if (objI4 instanceof C0159f) {
                            iR = C0163j.r(i8, (C0159f) objI4);
                        } else {
                            iY3 = C0163j.y(i8);
                            iX = C0163j.x((String) objI4);
                            iR = iX + iY3;
                        }
                        i7 = iR + i7;
                    }
                    break;
                case PipesConfigBase.DEFAULT_STALE_FETCHER_DELAY_SECONDS /* 60 */:
                    if (q(i8, i6, obj)) {
                        Object objI5 = o0.f4378d.i(j6, obj);
                        X xM3 = m(i6);
                        Class cls5 = Y.f4317a;
                        int iY7 = C0163j.y(i8);
                        int iB2 = ((AbstractC0154a) objI5).b(xM3);
                        i7 = A3.a.j(iB2, iB2, iY7, i7);
                    }
                    break;
                case 61:
                    if (q(i8, i6, obj)) {
                        iU = C0163j.r(i8, (C0159f) o0.f4378d.i(j6, obj));
                        i7 += iU;
                    }
                    break;
                case 62:
                    if (q(i8, i6, obj)) {
                        int iY8 = y(j6, obj);
                        iY2 = C0163j.y(i8);
                        iW = C0163j.z(iY8);
                        iU = iW + iY2;
                        i7 += iU;
                    }
                    break;
                case 63:
                    if (q(i8, i6, obj)) {
                        int iY9 = y(j6, obj);
                        iY2 = C0163j.y(i8);
                        iW = C0163j.w(iY9);
                        iU = iW + iY2;
                        i7 += iU;
                    }
                    break;
                case 64:
                    if (q(i8, i6, obj)) {
                        i7 = A3.a.i(i8, 4, i7);
                    }
                    break;
                case 65:
                    if (q(i8, i6, obj)) {
                        i7 = A3.a.i(i8, 8, i7);
                    }
                    break;
                case 66:
                    if (q(i8, i6, obj)) {
                        int iY10 = y(j6, obj);
                        iY2 = C0163j.y(i8);
                        iW = C0163j.z((iY10 >> 31) ^ (iY10 << 1));
                        iU = iW + iY2;
                        i7 += iU;
                    }
                    break;
                case 67:
                    if (q(i8, i6, obj)) {
                        long jZ3 = z(j6, obj);
                        iY4 = C0163j.y(i8);
                        iA2 = C0163j.A((jZ3 >> 63) ^ (jZ3 << 1));
                        iU = iA2 + iY4;
                        i7 += iU;
                    }
                    break;
                case 68:
                    if (q(i8, i6, obj)) {
                        iU = C0163j.v(i8, (AbstractC0154a) o0.f4378d.i(j6, obj), m(i6));
                        i7 += iU;
                    }
                    break;
            }
            i6 += 3;
        }
    }

    public final boolean p(int i6, Object obj) {
        if (this.f4295g) {
            int iG = G(i6);
            long j6 = iG & 1048575;
            switch (F(iG)) {
                case 0:
                    if (o0.f4378d.e(j6, obj) == 0.0d) {
                        return false;
                    }
                    break;
                case 1:
                    if (o0.f4378d.f(j6, obj) == 0.0f) {
                        return false;
                    }
                    break;
                case 2:
                    if (o0.f4378d.h(j6, obj) == 0) {
                        return false;
                    }
                    break;
                case 3:
                    if (o0.f4378d.h(j6, obj) == 0) {
                        return false;
                    }
                    break;
                case 4:
                    if (o0.f4378d.g(j6, obj) == 0) {
                        return false;
                    }
                    break;
                case 5:
                    if (o0.f4378d.h(j6, obj) == 0) {
                        return false;
                    }
                    break;
                case 6:
                    if (o0.f4378d.g(j6, obj) == 0) {
                        return false;
                    }
                    break;
                case 7:
                    return o0.f4378d.c(j6, obj);
                case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                    Object objI = o0.f4378d.i(j6, obj);
                    if (objI instanceof String) {
                        return !((String) objI).isEmpty();
                    }
                    if (objI instanceof C0159f) {
                        return !C0159f.t.equals(objI);
                    }
                    throw new IllegalArgumentException();
                case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                    if (o0.f4378d.i(j6, obj) == null) {
                        return false;
                    }
                    break;
                case 10:
                    return !C0159f.t.equals(o0.f4378d.i(j6, obj));
                case 11:
                    if (o0.f4378d.g(j6, obj) == 0) {
                        return false;
                    }
                    break;
                case 12:
                    if (o0.f4378d.g(j6, obj) == 0) {
                        return false;
                    }
                    break;
                case 13:
                    if (o0.f4378d.g(j6, obj) == 0) {
                        return false;
                    }
                    break;
                case 14:
                    if (o0.f4378d.h(j6, obj) == 0) {
                        return false;
                    }
                    break;
                case 15:
                    if (o0.f4378d.g(j6, obj) == 0) {
                        return false;
                    }
                    break;
                case 16:
                    if (o0.f4378d.h(j6, obj) == 0) {
                        return false;
                    }
                    break;
                case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                    if (o0.f4378d.i(j6, obj) == null) {
                        return false;
                    }
                    break;
                default:
                    throw new IllegalArgumentException();
            }
        } else {
            int i7 = this.f4289a[i6 + 2];
            if ((o0.f4378d.g(i7 & 1048575, obj) & (1 << (i7 >>> 20))) == 0) {
                return false;
            }
        }
        return true;
    }

    public final boolean q(int i6, int i7, Object obj) {
        return o0.f4378d.g((long) (this.f4289a[i7 + 2] & 1048575), obj) == i6;
    }

    public final void s(Object obj, int i6, Object obj2, C0165l c0165l, C0161h c0161h) throws C0175w {
        long jG = G(i6) & 1048575;
        Object objI = o0.f4378d.i(jG, obj);
        J j6 = this.f4302n;
        if (objI == null) {
            j6.getClass();
            objI = I.f4283s.c();
            o0.o(jG, obj, objI);
        } else {
            j6.getClass();
            if (!((I) objI).r) {
                I iC = I.f4283s.c();
                J.b(iC, objI);
                o0.o(jG, obj, iC);
                objI = iC;
            }
        }
        j6.getClass();
        I i7 = (I) objI;
        G g7 = ((H) obj2).f4281a;
        c0161h.Y(2);
        C0160g c0160g = (C0160g) c0161h.f4357e;
        int iE = c0160g.e(c0160g.A());
        Object obj3 = g7.f4280c;
        Object objP = StringUtils.EMPTY;
        Object objP2 = obj3;
        while (true) {
            try {
                int iC2 = c0161h.c();
                if (iC2 == Integer.MAX_VALUE || c0160g.c()) {
                    break;
                }
                if (iC2 == 1) {
                    objP = c0161h.p(g7.f4278a, null, null);
                } else if (iC2 != 2) {
                    try {
                        if (!c0161h.Z()) {
                            throw new C0176x("Unable to parse map entry.");
                        }
                    } catch (C0175w unused) {
                        if (!c0161h.Z()) {
                            throw new C0176x("Unable to parse map entry.");
                        }
                    }
                } else {
                    objP2 = c0161h.p(g7.f4279b, obj3.getClass(), c0165l);
                }
            } catch (Throwable th) {
                c0160g.d(iE);
                throw th;
            }
        }
        i7.put(objP, objP2);
        c0160g.d(iE);
    }

    public final void t(Object obj, Object obj2, int i6) {
        long jG = G(i6) & 1048575;
        if (p(i6, obj2)) {
            n0 n0Var = o0.f4378d;
            Object objI = n0Var.i(jG, obj);
            Object objI2 = n0Var.i(jG, obj2);
            if (objI != null && objI2 != null) {
                o0.o(jG, obj, AbstractC0174v.c(objI, objI2));
                D(i6, obj);
            } else if (objI2 != null) {
                o0.o(jG, obj, objI2);
                D(i6, obj);
            }
        }
    }

    public final void u(Object obj, Object obj2, int i6) {
        int iG = G(i6);
        int i7 = this.f4289a[i6];
        long j6 = iG & 1048575;
        if (q(i7, i6, obj2)) {
            n0 n0Var = o0.f4378d;
            Object objI = n0Var.i(j6, obj);
            Object objI2 = n0Var.i(j6, obj2);
            if (objI != null && objI2 != null) {
                o0.o(j6, obj, AbstractC0174v.c(objI, objI2));
                E(i7, i6, obj);
            } else if (objI2 != null) {
                o0.o(j6, obj, objI2);
                E(i7, i6, obj);
            }
        }
    }
}
