package androidx.datastore.preferences.protobuf;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0170q implements L {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final C0170q f4387b = new C0170q(0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f4388a;

    public /* synthetic */ C0170q(int i6) {
        this.f4388a = i6;
    }

    @Override // androidx.datastore.preferences.protobuf.L
    public final W a(Class cls) {
        switch (this.f4388a) {
            case 0:
                if (!AbstractC0172t.class.isAssignableFrom(cls)) {
                    throw new IllegalArgumentException("Unsupported message type: ".concat(cls.getName()));
                }
                try {
                    return (W) AbstractC0172t.e(cls.asSubclass(AbstractC0172t.class)).d(3);
                } catch (Exception e6) {
                    throw new RuntimeException("Unable to get message info for ".concat(cls.getName()), e6);
                }
            default:
                throw new IllegalStateException("This should never be called.");
        }
    }

    @Override // androidx.datastore.preferences.protobuf.L
    public final boolean b(Class cls) {
        switch (this.f4388a) {
            case 0:
                return AbstractC0172t.class.isAssignableFrom(cls);
            default:
                return false;
        }
    }
}
