package androidx.datastore.preferences.protobuf;

import java.util.List;
import java.util.RandomAccess;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.u, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0173u extends List, RandomAccess {
    InterfaceC0173u a(int i6);
}
