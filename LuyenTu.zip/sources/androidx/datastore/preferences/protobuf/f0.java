package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class f0 {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final f0 f4337f = new f0(0, new int[0], new Object[0], false);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f4338a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int[] f4339b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object[] f4340c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f4341d = -1;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f4342e;

    public f0(int i6, int[] iArr, Object[] objArr, boolean z6) {
        this.f4338a = i6;
        this.f4339b = iArr;
        this.f4340c = objArr;
        this.f4342e = z6;
    }

    public static f0 b() {
        return new f0(0, new int[8], new Object[8], true);
    }

    public final int a() {
        int iY;
        int iA;
        int iU;
        int i6 = this.f4341d;
        if (i6 != -1) {
            return i6;
        }
        int i7 = 0;
        for (int i8 = 0; i8 < this.f4338a; i8++) {
            int i9 = this.f4339b[i8];
            int i10 = i9 >>> 3;
            int i11 = i9 & 7;
            if (i11 != 0) {
                if (i11 == 1) {
                    ((Long) this.f4340c[i8]).getClass();
                    iU = C0163j.u(i10);
                } else if (i11 == 2) {
                    iU = C0163j.r(i10, (C0159f) this.f4340c[i8]);
                } else if (i11 == 3) {
                    iY = C0163j.y(i10) * 2;
                    iA = ((f0) this.f4340c[i8]).a();
                } else {
                    if (i11 != 5) {
                        throw new IllegalStateException(C0176x.b());
                    }
                    ((Integer) this.f4340c[i8]).getClass();
                    iU = C0163j.t(i10);
                }
                i7 = iU + i7;
            } else {
                long jLongValue = ((Long) this.f4340c[i8]).longValue();
                iY = C0163j.y(i10);
                iA = C0163j.A(jLongValue);
            }
            i7 = iA + iY + i7;
        }
        this.f4341d = i7;
        return i7;
    }

    public final void c(int i6, Object obj) {
        if (!this.f4342e) {
            throw new UnsupportedOperationException();
        }
        int i7 = this.f4338a;
        int[] iArr = this.f4339b;
        if (i7 == iArr.length) {
            int i8 = i7 + (i7 < 4 ? 8 : i7 >> 1);
            this.f4339b = Arrays.copyOf(iArr, i8);
            this.f4340c = Arrays.copyOf(this.f4340c, i8);
        }
        int[] iArr2 = this.f4339b;
        int i9 = this.f4338a;
        iArr2[i9] = i6;
        this.f4340c[i9] = obj;
        this.f4338a = i9 + 1;
    }

    public final void d(F f4) throws IOException {
        if (this.f4338a == 0) {
            return;
        }
        f4.getClass();
        C0163j c0163j = (C0163j) f4.f4277a;
        for (int i6 = 0; i6 < this.f4338a; i6++) {
            int i7 = this.f4339b[i6];
            Object obj = this.f4340c[i6];
            int i8 = i7 >>> 3;
            int i9 = i7 & 7;
            if (i9 == 0) {
                c0163j.U(((Long) obj).longValue(), i8);
            } else if (i9 == 1) {
                c0163j.K(((Long) obj).longValue(), i8);
            } else if (i9 == 2) {
                f4.a(i8, (C0159f) obj);
            } else if (i9 == 3) {
                c0163j.R(i8, 3);
                ((f0) obj).d(f4);
                c0163j.R(i8, 4);
            } else {
                if (i9 != 5) {
                    throw new RuntimeException(C0176x.b());
                }
                c0163j.I(i8, ((Integer) obj).intValue());
            }
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof f0)) {
            return false;
        }
        f0 f0Var = (f0) obj;
        int i6 = this.f4338a;
        if (i6 == f0Var.f4338a) {
            int[] iArr = this.f4339b;
            int[] iArr2 = f0Var.f4339b;
            for (int i7 = 0; i7 < i6; i7++) {
                if (iArr[i7] == iArr2[i7]) {
                }
            }
            Object[] objArr = this.f4340c;
            Object[] objArr2 = f0Var.f4340c;
            int i8 = this.f4338a;
            for (int i9 = 0; i9 < i8; i9++) {
                if (objArr[i9].equals(objArr2[i9])) {
                }
            }
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i6 = this.f4338a;
        int i7 = (527 + i6) * 31;
        int[] iArr = this.f4339b;
        int iHashCode = 17;
        int i8 = 17;
        for (int i9 = 0; i9 < i6; i9++) {
            i8 = (i8 * 31) + iArr[i9];
        }
        int i10 = (i7 + i8) * 31;
        Object[] objArr = this.f4340c;
        int i11 = this.f4338a;
        for (int i12 = 0; i12 < i11; i12++) {
            iHashCode = (iHashCode * 31) + objArr[i12].hashCode();
        }
        return i10 + iHashCode;
    }
}
