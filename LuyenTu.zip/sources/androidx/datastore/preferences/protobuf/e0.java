package androidx.datastore.preferences.protobuf;

import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class e0 extends AbstractSet {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ Map f4334s;

    public /* synthetic */ e0(Map map, int i6) {
        this.r = i6;
        this.f4334s = map;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public boolean add(Object obj) {
        switch (this.r) {
            case 0:
                Map.Entry entry = (Map.Entry) obj;
                if (contains(entry)) {
                    return false;
                }
                ((Z) this.f4334s).g((Comparable) entry.getKey(), entry.getValue());
                return true;
            default:
                return super.add(obj);
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public void clear() {
        switch (this.r) {
            case 0:
                ((Z) this.f4334s).clear();
                break;
            default:
                super.clear();
                break;
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public boolean contains(Object obj) {
        switch (this.r) {
            case 0:
                Map.Entry entry = (Map.Entry) obj;
                Object obj2 = ((Z) this.f4334s).get(entry.getKey());
                Object value = entry.getValue();
                return obj2 == value || (obj2 != null && obj2.equals(value));
            default:
                return super.contains(obj);
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.Set
    public Iterator iterator() {
        switch (this.r) {
            case 0:
                return new d0((Z) this.f4334s);
            default:
                return new p093p.c((p093p.e) this.f4334s);
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public boolean remove(Object obj) {
        switch (this.r) {
            case 0:
                Map.Entry entry = (Map.Entry) obj;
                if (!contains(entry)) {
                    return false;
                }
                ((Z) this.f4334s).remove(entry.getKey());
                return true;
            default:
                return super.remove(obj);
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public final int size() {
        switch (this.r) {
            case 0:
                return ((Z) this.f4334s).size();
            default:
                return ((p093p.e) this.f4334s).t;
        }
    }
}
