package androidx.datastore.preferences.protobuf;

import java.util.ListIterator;

/* JADX INFO: loaded from: classes.dex */
public final class h0 implements ListIterator {
    public ListIterator r;

    @Override // java.util.ListIterator
    public final void add(Object obj) {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.ListIterator, java.util.Iterator
    public final boolean hasNext() {
        return this.r.hasNext();
    }

    @Override // java.util.ListIterator
    public final boolean hasPrevious() {
        return this.r.hasPrevious();
    }

    @Override // java.util.ListIterator, java.util.Iterator
    public final Object next() {
        return (String) this.r.next();
    }

    @Override // java.util.ListIterator
    public final int nextIndex() {
        return this.r.nextIndex();
    }

    @Override // java.util.ListIterator
    public final Object previous() {
        return (String) this.r.previous();
    }

    @Override // java.util.ListIterator
    public final int previousIndex() {
        return this.r.previousIndex();
    }

    @Override // java.util.ListIterator, java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.ListIterator
    public final void set(Object obj) {
        throw new UnsupportedOperationException();
    }
}
