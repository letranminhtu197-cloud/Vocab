package androidx.datastore.preferences.protobuf;

import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

/* JADX INFO: loaded from: classes.dex */
public final class Z extends AbstractMap {

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final /* synthetic */ int f4321x = 0;
    public final int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public List f4322s = Collections.EMPTY_LIST;
    public Map t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f4323u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public volatile e0 f4324v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public Map f4325w;

    public Z(int i6) {
        this.r = i6;
        Map map = Collections.EMPTY_MAP;
        this.t = map;
        this.f4325w = map;
    }

    /* JADX WARN: Code duplicated, block: B:13:0x0024  */
    /* JADX WARN: Code duplicated, block: B:17:0x003e  */
    /* JADX WARN: Code duplicated, block: B:21:0x003c A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:22:0x0042 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:23:0x0038 A[SYNTHETIC] */
    public final int a(Comparable comparable) {
        int i6;
        int i7;
        int i8;
        int iCompareTo;
        int size = this.f4322s.size();
        int i9 = size - 1;
        if (i9 < 0) {
            i6 = 0;
            while (i6 <= i9) {
                i8 = (i6 + i9) / 2;
                iCompareTo = comparable.compareTo(((c0) this.f4322s.get(i8)).r);
                if (iCompareTo < 0) {
                    i9 = i8 - 1;
                } else {
                    if (iCompareTo > 0) {
                        return i8;
                    }
                    i6 = i8 + 1;
                }
            }
            i7 = i6 + 1;
        } else {
            int iCompareTo2 = comparable.compareTo(((c0) this.f4322s.get(i9)).r);
            if (iCompareTo2 > 0) {
                i7 = size + 1;
            } else {
                if (iCompareTo2 == 0) {
                    return i9;
                }
                i6 = 0;
                while (i6 <= i9) {
                    i8 = (i6 + i9) / 2;
                    iCompareTo = comparable.compareTo(((c0) this.f4322s.get(i8)).r);
                    if (iCompareTo < 0) {
                        i9 = i8 - 1;
                    } else {
                        if (iCompareTo > 0) {
                            return i8;
                        }
                        i6 = i8 + 1;
                    }
                }
                i7 = i6 + 1;
            }
        }
        return -i7;
    }

    public final void c() {
        if (this.f4323u) {
            throw new UnsupportedOperationException();
        }
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final void clear() {
        c();
        if (!this.f4322s.isEmpty()) {
            this.f4322s.clear();
        }
        if (this.t.isEmpty()) {
            return;
        }
        this.t.clear();
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final boolean containsKey(Object obj) {
        Comparable comparable = (Comparable) obj;
        return a(comparable) >= 0 || this.t.containsKey(comparable);
    }

    public final Map.Entry d(int i6) {
        return (Map.Entry) this.f4322s.get(i6);
    }

    public final Iterable e() {
        return this.t.isEmpty() ? M.f4287b : this.t.entrySet();
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Set entrySet() {
        if (this.f4324v == null) {
            this.f4324v = new e0(this, 0);
        }
        return this.f4324v;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Z)) {
            return super.equals(obj);
        }
        Z z6 = (Z) obj;
        int size = size();
        if (size == z6.size()) {
            int size2 = this.f4322s.size();
            if (size2 != z6.f4322s.size()) {
                return ((AbstractSet) entrySet()).equals(z6.entrySet());
            }
            for (int i6 = 0; i6 < size2; i6++) {
                if (d(i6).equals(z6.d(i6))) {
                }
            }
            if (size2 != size) {
                return this.t.equals(z6.t);
            }
            return true;
        }
        return false;
    }

    public final SortedMap f() {
        c();
        if (this.t.isEmpty() && !(this.t instanceof TreeMap)) {
            TreeMap treeMap = new TreeMap();
            this.t = treeMap;
            this.f4325w = treeMap.descendingMap();
        }
        return (SortedMap) this.t;
    }

    public final Object g(Comparable comparable, Object obj) {
        c();
        int iA = a(comparable);
        if (iA >= 0) {
            return ((c0) this.f4322s.get(iA)).setValue(obj);
        }
        c();
        boolean zIsEmpty = this.f4322s.isEmpty();
        int i6 = this.r;
        if (zIsEmpty && !(this.f4322s instanceof ArrayList)) {
            this.f4322s = new ArrayList(i6);
        }
        int i7 = -(iA + 1);
        if (i7 >= i6) {
            return f().put(comparable, obj);
        }
        if (this.f4322s.size() == i6) {
            c0 c0Var = (c0) this.f4322s.remove(i6 - 1);
            f().put(c0Var.r, c0Var.f4328s);
        }
        this.f4322s.add(i7, new c0(this, comparable, obj));
        return null;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Object get(Object obj) {
        Comparable comparable = (Comparable) obj;
        int iA = a(comparable);
        return iA >= 0 ? ((c0) this.f4322s.get(iA)).f4328s : this.t.get(comparable);
    }

    public final Object h(int i6) {
        c();
        Object obj = ((c0) this.f4322s.remove(i6)).f4328s;
        if (!this.t.isEmpty()) {
            Iterator it = f().entrySet().iterator();
            List list = this.f4322s;
            Map.Entry entry = (Map.Entry) it.next();
            list.add(new c0(this, (Comparable) entry.getKey(), entry.getValue()));
            it.remove();
        }
        return obj;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final int hashCode() {
        int size = this.f4322s.size();
        int iHashCode = 0;
        for (int i6 = 0; i6 < size; i6++) {
            iHashCode += ((c0) this.f4322s.get(i6)).hashCode();
        }
        return this.t.size() > 0 ? this.t.hashCode() + iHashCode : iHashCode;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final /* synthetic */ Object put(Object obj, Object obj2) {
        if (obj == null) {
            return g(null, obj2);
        }
        throw new ClassCastException();
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Object remove(Object obj) {
        c();
        Comparable comparable = (Comparable) obj;
        int iA = a(comparable);
        if (iA >= 0) {
            return h(iA);
        }
        if (this.t.isEmpty()) {
            return null;
        }
        return this.t.remove(comparable);
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final int size() {
        return this.t.size() + this.f4322s.size();
    }
}
