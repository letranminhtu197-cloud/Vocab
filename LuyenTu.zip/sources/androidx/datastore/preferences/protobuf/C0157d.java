package androidx.datastore.preferences.protobuf;

import com.google.android.gms.internal.play_billing.C0241o0;
import com.google.crypto.tink.shaded.protobuf.C0269g;
import java.util.Iterator;
import java.util.NoSuchElementException;

/* JADX INFO: renamed from: androidx.datastore.preferences.protobuf.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0157d implements Iterator {
    public final /* synthetic */ int r = 0;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f4329s = 0;
    public final int t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ Object f4330u;

    public C0157d(C0241o0 c0241o0) {
        this.f4330u = c0241o0;
        this.t = c0241o0.g();
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        switch (this.r) {
            case 0:
                return this.f4329s < this.t;
            case 1:
                return this.f4329s < this.t;
            case 2:
                return this.f4329s < this.t;
            default:
                return this.f4329s < this.t;
        }
    }

    @Override // java.util.Iterator
    public final Object next() {
        switch (this.r) {
            case 0:
                int i6 = this.f4329s;
                if (i6 >= this.t) {
                    throw new NoSuchElementException();
                }
                this.f4329s = i6 + 1;
                return Byte.valueOf(((C0159f) this.f4330u).f4336s[i6]);
            case 1:
                int i7 = this.f4329s;
                if (i7 >= this.t) {
                    throw new NoSuchElementException();
                }
                this.f4329s = i7 + 1;
                return Byte.valueOf(((C0241o0) this.f4330u).c(i7));
            case 2:
                int i8 = this.f4329s;
                if (i8 >= this.t) {
                    throw new NoSuchElementException();
                }
                this.f4329s = i8 + 1;
                return Byte.valueOf(((C0269g) this.f4330u).l(i8));
            default:
                int i9 = this.f4329s;
                if (i9 >= this.t) {
                    throw new NoSuchElementException();
                }
                this.f4329s = i9 + 1;
                return Byte.valueOf(((p045h3.K) this.f4330u).c(i9));
        }
    }

    @Override // java.util.Iterator
    public final void remove() {
        switch (this.r) {
            case 0:
                throw new UnsupportedOperationException();
            case 1:
                throw new UnsupportedOperationException();
            case 2:
                throw new UnsupportedOperationException();
            default:
                throw new UnsupportedOperationException();
        }
    }

    public C0157d(p045h3.K k3) {
        this.f4330u = k3;
        this.t = k3.h();
    }

    public C0157d(C0159f c0159f) {
        this.f4330u = c0159f;
        this.t = c0159f.size();
    }

    public C0157d(C0269g c0269g) {
        this.f4330u = c0269g;
        this.t = c0269g.size();
    }
}
