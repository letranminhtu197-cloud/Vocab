package androidx.datastore.preferences.protobuf;

/* JADX INFO: loaded from: classes.dex */
public final class q0 extends IllegalArgumentException {
    public q0(int i6, int i7) {
        super(A3.a.k(i6, i7, "Unpaired surrogate at index ", " of "));
    }
}
