package androidx.media3.exoplayer.dash;

import A0.n;
import K0.d;
import K2.i;
import M4.m;
import Z3.e;
import p128v0.g;

/* JADX INFO: loaded from: classes.dex */
public final class DashMediaSource$Factory {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final n f4488a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final g f4489b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final i f4490c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final e f4491d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final m f4492e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final long f4493f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final long f4494g;

    public DashMediaSource$Factory(g gVar) {
        d dVar = K0.e.f1997A;
        n nVar = new n();
        nVar.t = dVar;
        nVar.f96s = gVar;
        nVar.r = 1;
        this.f4488a = nVar;
        this.f4489b = gVar;
        this.f4490c = new i(3);
        this.f4492e = new m(1);
        this.f4493f = 30000L;
        this.f4494g = 5000000L;
        this.f4491d = new e(19);
        ((d) nVar.t).f1996s = true;
    }
}
