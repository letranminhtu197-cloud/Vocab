package androidx.media3.exoplayer.smoothstreaming;

import p128v0.g;

/* JADX INFO: loaded from: classes.dex */
public final class SsMediaSource$Factory {
    public SsMediaSource$Factory(g gVar) {
    }
}
