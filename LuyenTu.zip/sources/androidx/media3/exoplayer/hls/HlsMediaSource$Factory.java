package androidx.media3.exoplayer.hls;

import D0.c;
import D0.k;
import M4.i;
import M4.m;
import Z3.e;
import p128v0.g;

/* JADX INFO: loaded from: classes.dex */
public final class HlsMediaSource$Factory {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final i f4495a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c f4496b;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final e f4499e;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final m f4501g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final boolean f4502h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f4503i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final long f4504j;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final K2.i f4500f = new K2.i(3);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final e f4497c = new e(12);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final A0.c f4498d = E0.c.f909F;

    public HlsMediaSource$Factory(g gVar) {
        this.f4495a = new i(gVar, 2);
        c cVar = k.f658a;
        this.f4496b = cVar;
        this.f4501g = new m(1);
        this.f4499e = new e(19);
        this.f4503i = 1;
        this.f4504j = -9223372036854775807L;
        this.f4502h = true;
        cVar.f628c = true;
    }
}
