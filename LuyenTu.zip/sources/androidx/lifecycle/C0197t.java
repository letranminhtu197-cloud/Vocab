package androidx.lifecycle;

/* JADX INFO: renamed from: androidx.lifecycle.t, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0197t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public EnumC0191m f4463a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public InterfaceC0195q f4464b;

    public final void a(InterfaceC0196s interfaceC0196s, EnumC0190l enumC0190l) {
        EnumC0191m enumC0191mA = enumC0190l.a();
        EnumC0191m enumC0191m = this.f4463a;
        A5.h.e(enumC0191m, "state1");
        if (enumC0191mA.compareTo(enumC0191m) < 0) {
            enumC0191m = enumC0191mA;
        }
        this.f4463a = enumC0191m;
        this.f4464b.f(interfaceC0196s, enumC0190l);
        this.f4463a = enumC0191mA;
    }
}
