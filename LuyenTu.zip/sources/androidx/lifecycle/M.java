package androidx.lifecycle;

import java.util.Iterator;
import java.util.Map;
import p045h3.C0331c;

/* JADX INFO: loaded from: classes.dex */
public abstract class M implements T {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final M4.m f4436a = new M4.m(21);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final M4.m f4437b = new M4.m(22);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final M4.m f4438c = new M4.m(20);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final M4.m f4439d = new M4.m(23);

    public static final void c(S s6, J1.e eVar, AbstractC0192n abstractC0192n) {
        AutoCloseable autoCloseable;
        A5.h.e(eVar, "registry");
        A5.h.e(abstractC0192n, "lifecycle");
        p069l0.a aVar = s6.f4446a;
        if (aVar != null) {
            synchronized (aVar.f7509a) {
                autoCloseable = (AutoCloseable) aVar.f7510b.get("androidx.lifecycle.savedstate.vm.tag");
            }
        } else {
            autoCloseable = null;
        }
    }

    public static final void d(J1.f fVar) {
        J1.d dVar;
        String str;
        EnumC0191m enumC0191m = fVar.i().f4467c;
        if (enumC0191m != EnumC0191m.f4458s && enumC0191m != EnumC0191m.t) {
            throw new IllegalArgumentException("Failed requirement.");
        }
        Iterator it = ((p082n.f) fVar.d().f1890d).iterator();
        do {
            p082n.b bVar = (p082n.b) it;
            if (!bVar.hasNext()) {
                dVar = null;
                break;
            }
            Map.Entry entry = (Map.Entry) bVar.next();
            A5.h.d(entry, "components");
            str = (String) entry.getKey();
            dVar = (J1.d) entry.getValue();
        } while (!A5.h.a(str, "androidx.lifecycle.internal.SavedStateHandlesProvider"));
        if (dVar == null) {
            N n6 = new N(fVar.d(), (V) fVar);
            fVar.d().c("androidx.lifecycle.internal.SavedStateHandlesProvider", n6);
            fVar.i().a(new J1.b(n6, 2));
        }
    }

    public static final O e(V v6) {
        L l6 = new L();
        U uH = v6.h();
        D3.e eVarA = v6 instanceof InterfaceC0186h ? ((InterfaceC0186h) v6).a() : p063k0.a.f7237b;
        A5.h.e(uH, "store");
        A5.h.e(eVarA, "defaultCreationExtras");
        return (O) new C0331c(uH, l6, eVarA).u(A5.o.a(O.class), "androidx.lifecycle.internal.SavedStateHandlesVM");
    }
}
