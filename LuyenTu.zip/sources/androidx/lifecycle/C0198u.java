package androidx.lifecycle;

import android.os.Looper;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: renamed from: androidx.lifecycle.u, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0198u extends AbstractC0192n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f4465a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public p082n.a f4466b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public EnumC0191m f4467c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final WeakReference f4468d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f4469e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f4470f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f4471g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final ArrayList f4472h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final N5.x f4473i;

    public C0198u(InterfaceC0196s interfaceC0196s) {
        new AtomicReference(null);
        this.f4465a = true;
        this.f4466b = new p082n.a();
        EnumC0191m enumC0191m = EnumC0191m.f4458s;
        this.f4467c = enumC0191m;
        this.f4472h = new ArrayList();
        this.f4468d = new WeakReference(interfaceC0196s);
        this.f4473i = N5.y.a(enumC0191m);
    }

    @Override // androidx.lifecycle.AbstractC0192n
    public final void a(r rVar) {
        InterfaceC0195q c0183e;
        Object obj;
        InterfaceC0196s interfaceC0196s;
        EnumC0190l enumC0190l;
        A5.h.e(rVar, "observer");
        d("addObserver");
        EnumC0191m enumC0191m = this.f4467c;
        EnumC0191m enumC0191m2 = EnumC0191m.r;
        if (enumC0191m != enumC0191m2) {
            enumC0191m2 = EnumC0191m.f4458s;
        }
        C0197t c0197t = new C0197t();
        HashMap map = w.f4474a;
        boolean z6 = rVar instanceof InterfaceC0195q;
        boolean z7 = rVar instanceof DefaultLifecycleObserver;
        int i6 = 1;
        if (z6 && z7) {
            c0183e = new C0183e((DefaultLifecycleObserver) rVar, (InterfaceC0195q) rVar);
        } else if (z7) {
            c0183e = new C0183e((DefaultLifecycleObserver) rVar, (InterfaceC0195q) null);
        } else if (z6) {
            c0183e = (InterfaceC0195q) rVar;
        } else {
            Class<?> cls = rVar.getClass();
            if (w.b(cls) == 2) {
                Object obj2 = w.f4475b.get(cls);
                A5.h.b(obj2);
                List list = (List) obj2;
                if (list.size() == 1) {
                    w.a((Constructor) list.get(0), rVar);
                    throw null;
                }
                int size = list.size();
                InterfaceC0185g[] interfaceC0185gArr = new InterfaceC0185g[size];
                if (size > 0) {
                    w.a((Constructor) list.get(0), rVar);
                    throw null;
                }
                c0183e = new J1.b(interfaceC0185gArr, i6);
            } else {
                c0183e = new C0183e(rVar);
            }
        }
        c0197t.f4464b = c0183e;
        c0197t.f4463a = enumC0191m2;
        p082n.a aVar = this.f4466b;
        p082n.c cVarB = aVar.b(rVar);
        if (cVarB != null) {
            obj = cVarB.f7922s;
        } else {
            HashMap map2 = aVar.f7920v;
            p082n.c cVar = new p082n.c(rVar, c0197t);
            aVar.f7926u++;
            p082n.c cVar2 = aVar.f7925s;
            if (cVar2 == null) {
                aVar.r = cVar;
                aVar.f7925s = cVar;
            } else {
                cVar2.t = cVar;
                cVar.f7923u = cVar2;
                aVar.f7925s = cVar;
            }
            map2.put(rVar, cVar);
            obj = null;
        }
        if (((C0197t) obj) == null && (interfaceC0196s = (InterfaceC0196s) this.f4468d.get()) != null) {
            boolean z8 = this.f4469e != 0 || this.f4470f;
            EnumC0191m enumC0191mC = c(rVar);
            this.f4469e++;
            while (c0197t.f4463a.compareTo(enumC0191mC) < 0 && this.f4466b.f7920v.containsKey(rVar)) {
                EnumC0191m enumC0191m3 = c0197t.f4463a;
                ArrayList arrayList = this.f4472h;
                arrayList.add(enumC0191m3);
                C0188j c0188j = EnumC0190l.Companion;
                EnumC0191m enumC0191m4 = c0197t.f4463a;
                c0188j.getClass();
                A5.h.e(enumC0191m4, "state");
                int iOrdinal = enumC0191m4.ordinal();
                if (iOrdinal == 1) {
                    enumC0190l = EnumC0190l.ON_CREATE;
                } else if (iOrdinal != 2) {
                    enumC0190l = iOrdinal != 3 ? null : EnumC0190l.ON_RESUME;
                } else {
                    enumC0190l = EnumC0190l.ON_START;
                }
                if (enumC0190l == null) {
                    throw new IllegalStateException("no event up from " + c0197t.f4463a);
                }
                c0197t.a(interfaceC0196s, enumC0190l);
                arrayList.remove(arrayList.size() - 1);
                enumC0191mC = c(rVar);
            }
            if (!z8) {
                h();
            }
            this.f4469e--;
        }
    }

    @Override // androidx.lifecycle.AbstractC0192n
    public final void b(r rVar) {
        A5.h.e(rVar, "observer");
        d("removeObserver");
        this.f4466b.c(rVar);
    }

    public final EnumC0191m c(r rVar) {
        C0197t c0197t;
        HashMap map = this.f4466b.f7920v;
        p082n.c cVar = map.containsKey(rVar) ? ((p082n.c) map.get(rVar)).f7923u : null;
        EnumC0191m enumC0191m = (cVar == null || (c0197t = (C0197t) cVar.f7922s) == null) ? null : c0197t.f4463a;
        ArrayList arrayList = this.f4472h;
        EnumC0191m enumC0191m2 = arrayList.isEmpty() ? null : (EnumC0191m) arrayList.get(arrayList.size() - 1);
        EnumC0191m enumC0191m3 = this.f4467c;
        A5.h.e(enumC0191m3, "state1");
        if (enumC0191m == null || enumC0191m.compareTo(enumC0191m3) >= 0) {
            enumC0191m = enumC0191m3;
        }
        return (enumC0191m2 == null || enumC0191m2.compareTo(enumC0191m) >= 0) ? enumC0191m : enumC0191m2;
    }

    public final void d(String str) {
        if (this.f4465a) {
            p075m.a.a0().f7750f.getClass();
            if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
                throw new IllegalStateException(com.google.crypto.tink.shaded.protobuf.T.j("Method ", str, " must be called on the main thread").toString());
            }
        }
    }

    public final void e(EnumC0190l enumC0190l) {
        A5.h.e(enumC0190l, "event");
        d("handleLifecycleEvent");
        f(enumC0190l.a());
    }

    public final void f(EnumC0191m enumC0191m) {
        EnumC0191m enumC0191m2 = this.f4467c;
        if (enumC0191m2 == enumC0191m) {
            return;
        }
        EnumC0191m enumC0191m3 = EnumC0191m.f4458s;
        EnumC0191m enumC0191m4 = EnumC0191m.r;
        if (enumC0191m2 == enumC0191m3 && enumC0191m == enumC0191m4) {
            throw new IllegalStateException(("State must be at least CREATED to move to " + enumC0191m + ", but was " + this.f4467c + " in component " + this.f4468d.get()).toString());
        }
        this.f4467c = enumC0191m;
        if (this.f4470f || this.f4469e != 0) {
            this.f4471g = true;
            return;
        }
        this.f4470f = true;
        h();
        this.f4470f = false;
        if (this.f4467c == enumC0191m4) {
            this.f4466b = new p082n.a();
        }
    }

    public final void g() {
        d("setCurrentState");
        f(EnumC0191m.t);
    }

    public final void h() {
        EnumC0190l enumC0190l;
        EnumC0190l enumC0190l2;
        InterfaceC0196s interfaceC0196s = (InterfaceC0196s) this.f4468d.get();
        if (interfaceC0196s == null) {
            throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is already garbage collected. It is too late to change lifecycle state.");
        }
        while (true) {
            p082n.a aVar = this.f4466b;
            if (aVar.f7926u != 0) {
                p082n.c cVar = aVar.r;
                A5.h.b(cVar);
                EnumC0191m enumC0191m = ((C0197t) cVar.f7922s).f4463a;
                p082n.c cVar2 = this.f4466b.f7925s;
                A5.h.b(cVar2);
                EnumC0191m enumC0191m2 = ((C0197t) cVar2.f7922s).f4463a;
                if (enumC0191m == enumC0191m2 && this.f4467c == enumC0191m2) {
                    break;
                }
                this.f4471g = false;
                EnumC0191m enumC0191m3 = this.f4467c;
                p082n.c cVar3 = this.f4466b.r;
                A5.h.b(cVar3);
                if (enumC0191m3.compareTo(((C0197t) cVar3.f7922s).f4463a) < 0) {
                    p082n.a aVar2 = this.f4466b;
                    p082n.b bVar = new p082n.b(aVar2.f7925s, aVar2.r, 1);
                    aVar2.t.put(bVar, Boolean.FALSE);
                    while (bVar.hasNext() && !this.f4471g) {
                        Map.Entry entry = (Map.Entry) bVar.next();
                        A5.h.d(entry, "next()");
                        r rVar = (r) entry.getKey();
                        C0197t c0197t = (C0197t) entry.getValue();
                        while (c0197t.f4463a.compareTo(this.f4467c) > 0 && !this.f4471g && this.f4466b.f7920v.containsKey(rVar)) {
                            C0188j c0188j = EnumC0190l.Companion;
                            EnumC0191m enumC0191m4 = c0197t.f4463a;
                            c0188j.getClass();
                            A5.h.e(enumC0191m4, "state");
                            int iOrdinal = enumC0191m4.ordinal();
                            if (iOrdinal == 2) {
                                enumC0190l2 = EnumC0190l.ON_DESTROY;
                            } else if (iOrdinal != 3) {
                                enumC0190l2 = iOrdinal != 4 ? null : EnumC0190l.ON_PAUSE;
                            } else {
                                enumC0190l2 = EnumC0190l.ON_STOP;
                            }
                            if (enumC0190l2 == null) {
                                throw new IllegalStateException("no event down from " + c0197t.f4463a);
                            }
                            this.f4472h.add(enumC0190l2.a());
                            c0197t.a(interfaceC0196s, enumC0190l2);
                            ArrayList arrayList = this.f4472h;
                            arrayList.remove(arrayList.size() - 1);
                        }
                    }
                }
                p082n.c cVar4 = this.f4466b.f7925s;
                if (!this.f4471g && cVar4 != null && this.f4467c.compareTo(((C0197t) cVar4.f7922s).f4463a) > 0) {
                    p082n.a aVar3 = this.f4466b;
                    aVar3.getClass();
                    p082n.d dVar = new p082n.d(aVar3);
                    aVar3.t.put(dVar, Boolean.FALSE);
                    while (dVar.hasNext() && !this.f4471g) {
                        Map.Entry entry2 = (Map.Entry) dVar.next();
                        r rVar2 = (r) entry2.getKey();
                        C0197t c0197t2 = (C0197t) entry2.getValue();
                        while (c0197t2.f4463a.compareTo(this.f4467c) < 0 && !this.f4471g && this.f4466b.f7920v.containsKey(rVar2)) {
                            this.f4472h.add(c0197t2.f4463a);
                            C0188j c0188j2 = EnumC0190l.Companion;
                            EnumC0191m enumC0191m5 = c0197t2.f4463a;
                            c0188j2.getClass();
                            A5.h.e(enumC0191m5, "state");
                            int iOrdinal2 = enumC0191m5.ordinal();
                            if (iOrdinal2 == 1) {
                                enumC0190l = EnumC0190l.ON_CREATE;
                            } else if (iOrdinal2 != 2) {
                                enumC0190l = iOrdinal2 != 3 ? null : EnumC0190l.ON_RESUME;
                            } else {
                                enumC0190l = EnumC0190l.ON_START;
                            }
                            if (enumC0190l == null) {
                                throw new IllegalStateException("no event up from " + c0197t2.f4463a);
                            }
                            c0197t2.a(interfaceC0196s, enumC0190l);
                            ArrayList arrayList2 = this.f4472h;
                            arrayList2.remove(arrayList2.size() - 1);
                        }
                    }
                }
            } else {
                break;
            }
        }
        this.f4471g = false;
        this.f4473i.f(this.f4467c);
    }
}
