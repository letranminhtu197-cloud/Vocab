package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface B {
    void F(Object obj);
}
