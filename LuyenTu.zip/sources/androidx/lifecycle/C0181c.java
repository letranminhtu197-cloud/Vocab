package androidx.lifecycle;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: renamed from: androidx.lifecycle.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0181c {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final C0181c f4452c = new C0181c();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashMap f4453a = new HashMap();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final HashMap f4454b = new HashMap();

    public static void b(HashMap map, C0180b c0180b, EnumC0190l enumC0190l, Class cls) {
        EnumC0190l enumC0190l2 = (EnumC0190l) map.get(c0180b);
        if (enumC0190l2 == null || enumC0190l == enumC0190l2) {
            if (enumC0190l2 == null) {
                map.put(c0180b, enumC0190l);
                return;
            }
            return;
        }
        throw new IllegalArgumentException("Method " + c0180b.f4451b.getName() + " in " + cls.getName() + " already declared with different @OnLifecycleEvent value: previous value " + enumC0190l2 + ", new value " + enumC0190l);
    }

    public final C0179a a(Class cls, Method[] methodArr) {
        int i6;
        Class superclass = cls.getSuperclass();
        HashMap map = new HashMap();
        HashMap map2 = this.f4453a;
        if (superclass != null) {
            C0179a c0179aA = (C0179a) map2.get(superclass);
            if (c0179aA == null) {
                c0179aA = a(superclass, null);
            }
            map.putAll(c0179aA.f4449b);
        }
        for (Class<?> cls2 : cls.getInterfaces()) {
            C0179a c0179aA2 = (C0179a) map2.get(cls2);
            if (c0179aA2 == null) {
                c0179aA2 = a(cls2, null);
            }
            for (Map.Entry entry : c0179aA2.f4449b.entrySet()) {
                b(map, (C0180b) entry.getKey(), (EnumC0190l) entry.getValue(), cls);
            }
        }
        if (methodArr == null) {
            try {
                methodArr = cls.getDeclaredMethods();
            } catch (NoClassDefFoundError e6) {
                throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", e6);
            }
        }
        boolean z6 = false;
        for (Method method : methodArr) {
            C c2 = (C) method.getAnnotation(C.class);
            if (c2 != null) {
                Class<?>[] parameterTypes = method.getParameterTypes();
                if (parameterTypes.length <= 0) {
                    i6 = 0;
                } else {
                    if (!InterfaceC0196s.class.isAssignableFrom(parameterTypes[0])) {
                        throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner");
                    }
                    i6 = 1;
                }
                EnumC0190l enumC0190lValue = c2.value();
                if (parameterTypes.length > 1) {
                    if (!EnumC0190l.class.isAssignableFrom(parameterTypes[1])) {
                        throw new IllegalArgumentException("invalid parameter type. second arg must be an event");
                    }
                    if (enumC0190lValue != EnumC0190l.ON_ANY) {
                        throw new IllegalArgumentException("Second arg is supported only for ON_ANY value");
                    }
                    i6 = 2;
                }
                if (parameterTypes.length > 2) {
                    throw new IllegalArgumentException("cannot have more than 2 params");
                }
                b(map, new C0180b(i6, method), enumC0190lValue, cls);
                z6 = true;
            }
        }
        C0179a c0179a = new C0179a(map);
        map2.put(cls, c0179a);
        this.f4454b.put(cls, Boolean.valueOf(z6));
        return c0179a;
    }
}
