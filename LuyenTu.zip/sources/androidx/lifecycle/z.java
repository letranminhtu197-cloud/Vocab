package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public abstract class z {
    public final B r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f4478s;
    public int t = -1;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ A f4479u;

    public z(A a5, B b6) {
        this.f4479u = a5;
        this.r = b6;
    }

    public final void b(boolean z6) {
        if (z6 == this.f4478s) {
            return;
        }
        this.f4478s = z6;
        int i6 = z6 ? 1 : -1;
        A a5 = this.f4479u;
        int i7 = a5.f4421c;
        a5.f4421c = i6 + i7;
        if (!a5.f4422d) {
            a5.f4422d = true;
            while (true) {
                try {
                    int i8 = a5.f4421c;
                    if (i7 == i8) {
                        break;
                    }
                    boolean z7 = i7 == 0 && i8 > 0;
                    boolean z8 = i7 > 0 && i8 == 0;
                    if (z7) {
                        a5.f();
                    } else if (z8) {
                        a5.g();
                    }
                    i7 = i8;
                } catch (Throwable th) {
                    a5.f4422d = false;
                    throw th;
                }
            }
            a5.f4422d = false;
        }
        if (this.f4478s) {
            a5.c(this);
        }
    }

    public void c() {
    }

    public boolean g(InterfaceC0196s interfaceC0196s) {
        return false;
    }

    public abstract boolean h();
}
