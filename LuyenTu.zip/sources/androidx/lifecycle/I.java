package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;

/* JADX INFO: loaded from: classes.dex */
public class I extends Fragment {

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final /* synthetic */ int f4435s = 0;
    public p066k4.c r;

    public static final class a implements Application.ActivityLifecycleCallbacks {
        public static final H Companion = new H();

        public static final void registerIn(Activity activity) {
            Companion.getClass();
            A5.h.e(activity, "activity");
            activity.registerActivityLifecycleCallbacks(new a());
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityCreated(Activity activity, Bundle bundle) {
            A5.h.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityDestroyed(Activity activity) {
            A5.h.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPaused(Activity activity) {
            A5.h.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostCreated(Activity activity, Bundle bundle) {
            A5.h.e(activity, "activity");
            int i6 = I.f4435s;
            G.a(activity, EnumC0190l.ON_CREATE);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostResumed(Activity activity) {
            A5.h.e(activity, "activity");
            int i6 = I.f4435s;
            G.a(activity, EnumC0190l.ON_RESUME);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostStarted(Activity activity) {
            A5.h.e(activity, "activity");
            int i6 = I.f4435s;
            G.a(activity, EnumC0190l.ON_START);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPreDestroyed(Activity activity) {
            A5.h.e(activity, "activity");
            int i6 = I.f4435s;
            G.a(activity, EnumC0190l.ON_DESTROY);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPrePaused(Activity activity) {
            A5.h.e(activity, "activity");
            int i6 = I.f4435s;
            G.a(activity, EnumC0190l.ON_PAUSE);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPreStopped(Activity activity) {
            A5.h.e(activity, "activity");
            int i6 = I.f4435s;
            G.a(activity, EnumC0190l.ON_STOP);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityResumed(Activity activity) {
            A5.h.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
            A5.h.e(activity, "activity");
            A5.h.e(bundle, "bundle");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStarted(Activity activity) {
            A5.h.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStopped(Activity activity) {
            A5.h.e(activity, "activity");
        }
    }

    public final void a(EnumC0190l enumC0190l) {
        if (Build.VERSION.SDK_INT < 29) {
            Activity activity = getActivity();
            A5.h.d(activity, "activity");
            G.a(activity, enumC0190l);
        }
    }

    @Override // android.app.Fragment
    public final void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        a(EnumC0190l.ON_CREATE);
    }

    @Override // android.app.Fragment
    public final void onDestroy() {
        super.onDestroy();
        a(EnumC0190l.ON_DESTROY);
        this.r = null;
    }

    @Override // android.app.Fragment
    public final void onPause() {
        super.onPause();
        a(EnumC0190l.ON_PAUSE);
    }

    @Override // android.app.Fragment
    public final void onResume() {
        super.onResume();
        p066k4.c cVar = this.r;
        if (cVar != null) {
            ((F) cVar.f7289s).a();
        }
        a(EnumC0190l.ON_RESUME);
    }

    @Override // android.app.Fragment
    public final void onStart() {
        super.onStart();
        p066k4.c cVar = this.r;
        if (cVar != null) {
            F f4 = (F) cVar.f7289s;
            int i6 = f4.r + 1;
            f4.r = i6;
            if (i6 == 1 && f4.f4431u) {
                f4.f4433w.e(EnumC0190l.ON_START);
                f4.f4431u = false;
            }
        }
        a(EnumC0190l.ON_START);
    }

    @Override // android.app.Fragment
    public final void onStop() {
        super.onStop();
        a(EnumC0190l.ON_STOP);
    }
}
