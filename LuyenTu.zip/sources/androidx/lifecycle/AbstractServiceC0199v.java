package androidx.lifecycle;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

/* JADX INFO: renamed from: androidx.lifecycle.v, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractServiceC0199v extends Service implements InterfaceC0196s {
    public final A4.d r = new A4.d(this);

    @Override // androidx.lifecycle.InterfaceC0196s
    public final C0198u i() {
        return (C0198u) this.r.f176s;
    }

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        A5.h.e(intent, "intent");
        this.r.P(EnumC0190l.ON_START);
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        this.r.P(EnumC0190l.ON_CREATE);
        super.onCreate();
    }

    @Override // android.app.Service
    public void onDestroy() {
        EnumC0190l enumC0190l = EnumC0190l.ON_STOP;
        A4.d dVar = this.r;
        dVar.P(enumC0190l);
        dVar.P(EnumC0190l.ON_DESTROY);
        super.onDestroy();
    }

    @Override // android.app.Service
    public final void onStart(Intent intent, int i6) {
        this.r.P(EnumC0190l.ON_START);
        super.onStart(intent, i6);
    }
}
