package androidx.lifecycle;

import java.io.Closeable;

/* JADX INFO: loaded from: classes.dex */
public abstract class K implements InterfaceC0195q, Closeable {
    public abstract void t(J1.e eVar, AbstractC0192n abstractC0192n);
}
