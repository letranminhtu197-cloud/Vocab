package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class L implements T {
    @Override // androidx.lifecycle.T
    public final S b(Class cls, p063k0.b bVar) {
        return new O();
    }
}
