package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface T {
    default S a(Class cls) {
        throw new UnsupportedOperationException("`Factory.create(String, CreationExtras)` is not implemented. You may need to override the method and provide a custom implementation. Note that using `Factory.create(String)` is not supported and considered an error.");
    }

    default S b(Class cls, p063k0.b bVar) {
        return a(cls);
    }
}
