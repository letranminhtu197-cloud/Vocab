package androidx.lifecycle;

/* JADX INFO: renamed from: androidx.lifecycle.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0192n {
    public abstract void a(r rVar);

    public abstract void b(r rVar);
}
