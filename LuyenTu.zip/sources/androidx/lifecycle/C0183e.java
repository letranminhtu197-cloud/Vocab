package androidx.lifecycle;

import java.util.HashMap;
import java.util.List;

/* JADX INFO: renamed from: androidx.lifecycle.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0183e implements InterfaceC0195q {
    public final /* synthetic */ int r = 1;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final Object f4456s;
    public final Object t;

    public C0183e(DefaultLifecycleObserver defaultLifecycleObserver, InterfaceC0195q interfaceC0195q) {
        A5.h.e(defaultLifecycleObserver, "defaultLifecycleObserver");
        this.f4456s = defaultLifecycleObserver;
        this.t = interfaceC0195q;
    }

    @Override // androidx.lifecycle.InterfaceC0195q
    public final void f(InterfaceC0196s interfaceC0196s, EnumC0190l enumC0190l) {
        switch (this.r) {
            case 0:
                DefaultLifecycleObserver defaultLifecycleObserver = (DefaultLifecycleObserver) this.f4456s;
                switch (AbstractC0182d.f4455a[enumC0190l.ordinal()]) {
                    case 1:
                        defaultLifecycleObserver.e(interfaceC0196s);
                        break;
                    case 2:
                        defaultLifecycleObserver.o(interfaceC0196s);
                        break;
                    case 3:
                        defaultLifecycleObserver.a(interfaceC0196s);
                        break;
                    case 4:
                        defaultLifecycleObserver.j(interfaceC0196s);
                        break;
                    case 5:
                        defaultLifecycleObserver.q(interfaceC0196s);
                        break;
                    case 6:
                        defaultLifecycleObserver.d(interfaceC0196s);
                        break;
                    case 7:
                        throw new IllegalArgumentException("ON_ANY must not been send by anybody");
                }
                InterfaceC0195q interfaceC0195q = (InterfaceC0195q) this.t;
                if (interfaceC0195q != null) {
                    interfaceC0195q.f(interfaceC0196s, enumC0190l);
                    return;
                }
                return;
            case 1:
                if (enumC0190l == EnumC0190l.ON_START) {
                    ((AbstractC0192n) this.f4456s).b(this);
                    ((J1.e) this.t).d();
                    return;
                }
                return;
            default:
                HashMap map = ((C0179a) this.t).f4448a;
                List list = (List) map.get(enumC0190l);
                Object obj = this.f4456s;
                C0179a.a(list, interfaceC0196s, enumC0190l, obj);
                C0179a.a((List) map.get(EnumC0190l.ON_ANY), interfaceC0196s, enumC0190l, obj);
                return;
        }
    }

    public C0183e(r rVar) {
        this.f4456s = rVar;
        C0181c c0181c = C0181c.f4452c;
        Class<?> cls = rVar.getClass();
        C0179a c0179a = (C0179a) c0181c.f4453a.get(cls);
        this.t = c0179a == null ? c0181c.a(cls, null) : c0179a;
    }

    public C0183e(J1.e eVar, AbstractC0192n abstractC0192n) {
        this.f4456s = abstractC0192n;
        this.t = eVar;
    }
}
