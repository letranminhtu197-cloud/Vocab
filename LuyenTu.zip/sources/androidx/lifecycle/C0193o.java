package androidx.lifecycle;

import android.app.Activity;
import android.os.Bundle;

/* JADX INFO: renamed from: androidx.lifecycle.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0193o extends AbstractC0184f {
    @Override // androidx.lifecycle.AbstractC0184f, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
        A5.h.e(activity, "activity");
        int i6 = I.f4435s;
        G.b(activity);
    }
}
