package androidx.lifecycle;

/* JADX INFO: renamed from: androidx.lifecycle.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0195q extends r {
    void f(InterfaceC0196s interfaceC0196s, EnumC0190l enumC0190l);
}
