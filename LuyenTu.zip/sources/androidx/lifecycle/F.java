package androidx.lifecycle;

import android.os.Handler;

/* JADX INFO: loaded from: classes.dex */
public final class F implements InterfaceC0196s {

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public static final F f4429z = new F();
    public int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f4430s;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public Handler f4432v;
    public boolean t = true;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f4431u = true;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final C0198u f4433w = new C0198u(this);

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final B4.f f4434x = new B4.f(this, 12);
    public final p066k4.c y = new p066k4.c(this, 20);

    public final void a() {
        int i6 = this.f4430s + 1;
        this.f4430s = i6;
        if (i6 == 1) {
            if (this.t) {
                this.f4433w.e(EnumC0190l.ON_RESUME);
                this.t = false;
            } else {
                Handler handler = this.f4432v;
                A5.h.b(handler);
                handler.removeCallbacks(this.f4434x);
            }
        }
    }

    @Override // androidx.lifecycle.InterfaceC0196s
    public final C0198u i() {
        return this.f4433w;
    }
}
