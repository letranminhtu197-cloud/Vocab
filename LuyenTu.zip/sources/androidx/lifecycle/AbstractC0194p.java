package androidx.lifecycle;

import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: renamed from: androidx.lifecycle.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0194p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final AtomicBoolean f4462a = new AtomicBoolean(false);
}
