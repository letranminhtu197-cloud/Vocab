package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class Q implements Runnable {
    public final C0198u r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final EnumC0190l f4445s;
    public boolean t;

    public Q(C0198u c0198u, EnumC0190l enumC0190l) {
        A5.h.e(c0198u, "registry");
        A5.h.e(enumC0190l, "event");
        this.r = c0198u;
        this.f4445s = enumC0190l;
    }

    @Override // java.lang.Runnable
    public final void run() {
        if (this.t) {
            return;
        }
        this.r.e(this.f4445s);
        this.t = true;
    }
}
