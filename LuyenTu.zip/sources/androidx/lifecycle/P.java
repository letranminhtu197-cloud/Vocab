package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public abstract class P implements T {
}
