package androidx.lifecycle;

import android.os.Looper;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class A {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final Object f4416k = new Object();

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static A f4417l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static A f4418m;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f4419a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final p082n.f f4420b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f4421c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f4422d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public volatile Object f4423e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public volatile Object f4424f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f4425g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f4426h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f4427i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final E.b f4428j;

    public A(int i6) {
        p018d2.C c2 = p018d2.l.f5279d;
        this.f4419a = new Object();
        this.f4420b = new p082n.f();
        this.f4421c = 0;
        this.f4424f = f4416k;
        this.f4428j = new E.b(this, 9);
        this.f4423e = c2;
        this.f4425g = 0;
    }

    public static void a(String str) {
        p075m.a.a0().f7750f.getClass();
        if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
            throw new IllegalStateException(com.google.crypto.tink.shaded.protobuf.T.j("Cannot invoke ", str, " on a background thread"));
        }
    }

    public final void b(z zVar) {
        if (zVar.f4478s) {
            if (!zVar.h()) {
                zVar.b(false);
                return;
            }
            int i6 = zVar.t;
            int i7 = this.f4425g;
            if (i6 >= i7) {
                return;
            }
            zVar.t = i7;
            zVar.r.F(this.f4423e);
        }
    }

    public final void c(z zVar) {
        if (this.f4426h) {
            this.f4427i = true;
            return;
        }
        this.f4426h = true;
        do {
            this.f4427i = false;
            if (zVar != null) {
                b(zVar);
                zVar = null;
            } else {
                p082n.f fVar = this.f4420b;
                fVar.getClass();
                p082n.d dVar = new p082n.d(fVar);
                fVar.t.put(dVar, Boolean.FALSE);
                while (dVar.hasNext()) {
                    b((z) ((Map.Entry) dVar.next()).getValue());
                    if (this.f4427i) {
                        break;
                    }
                }
            }
        } while (this.f4427i);
        this.f4426h = false;
    }

    public final void d(InterfaceC0196s interfaceC0196s, B b6) {
        Object obj;
        a("observe");
        if (interfaceC0196s.i().f4467c == EnumC0191m.r) {
            return;
        }
        y yVar = new y(this, interfaceC0196s, b6);
        p082n.f fVar = this.f4420b;
        p082n.c cVarB = fVar.b(b6);
        if (cVarB != null) {
            obj = cVarB.f7922s;
        } else {
            p082n.c cVar = new p082n.c(b6, yVar);
            fVar.f7926u++;
            p082n.c cVar2 = fVar.f7925s;
            if (cVar2 == null) {
                fVar.r = cVar;
                fVar.f7925s = cVar;
            } else {
                cVar2.t = cVar;
                cVar.f7923u = cVar2;
                fVar.f7925s = cVar;
            }
            obj = null;
        }
        z zVar = (z) obj;
        if (zVar != null && !zVar.g(interfaceC0196s)) {
            throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
        }
        if (zVar != null) {
            return;
        }
        interfaceC0196s.i().a(yVar);
    }

    public final void e(B b6) {
        Object obj;
        a("observeForever");
        x xVar = new x(this, b6);
        p082n.f fVar = this.f4420b;
        p082n.c cVarB = fVar.b(b6);
        if (cVarB != null) {
            obj = cVarB.f7922s;
        } else {
            p082n.c cVar = new p082n.c(b6, xVar);
            fVar.f7926u++;
            p082n.c cVar2 = fVar.f7925s;
            if (cVar2 == null) {
                fVar.r = cVar;
                fVar.f7925s = cVar;
            } else {
                cVar2.t = cVar;
                cVar.f7923u = cVar2;
                fVar.f7925s = cVar;
            }
            obj = null;
        }
        z zVar = (z) obj;
        if (zVar instanceof y) {
            throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
        }
        if (zVar != null) {
            return;
        }
        xVar.b(true);
    }

    public void h(Object obj) {
        boolean z6;
        synchronized (this.f4419a) {
            z6 = this.f4424f == f4416k;
            this.f4424f = obj;
        }
        if (z6) {
            p075m.a aVarA0 = p075m.a.a0();
            E.b bVar = this.f4428j;
            p075m.c cVar = aVarA0.f7750f;
            if (cVar.f7754h == null) {
                synchronized (cVar.f7752f) {
                    try {
                        if (cVar.f7754h == null) {
                            cVar.f7754h = p075m.c.a0(Looper.getMainLooper());
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
            }
            cVar.f7754h.post(bVar);
        }
    }

    public void i(B b6) {
        a("removeObserver");
        z zVar = (z) this.f4420b.c(b6);
        if (zVar == null) {
            return;
        }
        zVar.c();
        zVar.b(false);
    }

    public void j(Object obj) {
        a("setValue");
        this.f4425g++;
        this.f4423e = obj;
        c(null);
    }

    public A() {
        this.f4419a = new Object();
        this.f4420b = new p082n.f();
        this.f4421c = 0;
        Object obj = f4416k;
        this.f4424f = obj;
        this.f4428j = new E.b(this, 9);
        this.f4423e = obj;
        this.f4425g = -1;
    }

    public void f() {
    }

    public void g() {
    }
}
