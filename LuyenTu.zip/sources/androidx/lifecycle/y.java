package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class y extends z implements InterfaceC0195q {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final InterfaceC0196s f4476v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ A f4477w;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public y(A a5, InterfaceC0196s interfaceC0196s, B b6) {
        super(a5, b6);
        this.f4477w = a5;
        this.f4476v = interfaceC0196s;
    }

    @Override // androidx.lifecycle.z
    public final void c() {
        this.f4476v.i().b(this);
    }

    @Override // androidx.lifecycle.InterfaceC0195q
    public final void f(InterfaceC0196s interfaceC0196s, EnumC0190l enumC0190l) {
        InterfaceC0196s interfaceC0196s2 = this.f4476v;
        EnumC0191m enumC0191m = interfaceC0196s2.i().f4467c;
        if (enumC0191m == EnumC0191m.r) {
            this.f4477w.i(this.r);
            return;
        }
        EnumC0191m enumC0191m2 = null;
        while (enumC0191m2 != enumC0191m) {
            b(h());
            enumC0191m2 = enumC0191m;
            enumC0191m = interfaceC0196s2.i().f4467c;
        }
    }

    @Override // androidx.lifecycle.z
    public final boolean g(InterfaceC0196s interfaceC0196s) {
        return this.f4476v == interfaceC0196s;
    }

    @Override // androidx.lifecycle.z
    public final boolean h() {
        return this.f4476v.i().f4467c.compareTo(EnumC0191m.f4459u) >= 0;
    }
}
