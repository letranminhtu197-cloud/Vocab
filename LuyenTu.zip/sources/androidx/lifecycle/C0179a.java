package androidx.lifecycle;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: renamed from: androidx.lifecycle.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0179a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashMap f4448a = new HashMap();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final HashMap f4449b;

    public C0179a(HashMap map) {
        this.f4449b = map;
        for (Map.Entry entry : map.entrySet()) {
            EnumC0190l enumC0190l = (EnumC0190l) entry.getValue();
            List arrayList = (List) this.f4448a.get(enumC0190l);
            if (arrayList == null) {
                arrayList = new ArrayList();
                this.f4448a.put(enumC0190l, arrayList);
            }
            arrayList.add((C0180b) entry.getKey());
        }
    }

    public static void a(List list, InterfaceC0196s interfaceC0196s, EnumC0190l enumC0190l, Object obj) {
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                C0180b c0180b = (C0180b) list.get(size);
                Method method = c0180b.f4451b;
                try {
                    int i6 = c0180b.f4450a;
                    if (i6 == 0) {
                        method.invoke(obj, null);
                    } else if (i6 == 1) {
                        method.invoke(obj, interfaceC0196s);
                    } else if (i6 == 2) {
                        method.invoke(obj, interfaceC0196s, enumC0190l);
                    }
                } catch (IllegalAccessException e6) {
                    throw new RuntimeException(e6);
                } catch (InvocationTargetException e7) {
                    throw new RuntimeException("Failed to call observer method", e7.getCause());
                }
            }
        }
    }
}
