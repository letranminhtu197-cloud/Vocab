package androidx.lifecycle;

import android.app.Activity;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

/* JADX INFO: loaded from: classes.dex */
public final class E extends AbstractC0184f {
    final /* synthetic */ F this$0;

    public static final class a extends AbstractC0184f {
        final /* synthetic */ F this$0;

        public a(F f4) {
            this.this$0 = f4;
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostResumed(Activity activity) {
            A5.h.e(activity, "activity");
            this.this$0.a();
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostStarted(Activity activity) {
            A5.h.e(activity, "activity");
            F f4 = this.this$0;
            int i6 = f4.r + 1;
            f4.r = i6;
            if (i6 == 1 && f4.f4431u) {
                f4.f4433w.e(EnumC0190l.ON_START);
                f4.f4431u = false;
            }
        }
    }

    public E(F f4) {
        this.this$0 = f4;
    }

    @Override // androidx.lifecycle.AbstractC0184f, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
        A5.h.e(activity, "activity");
        if (Build.VERSION.SDK_INT < 29) {
            int i6 = I.f4435s;
            Fragment fragmentFindFragmentByTag = activity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag");
            A5.h.c(fragmentFindFragmentByTag, "null cannot be cast to non-null type androidx.lifecycle.ReportFragment");
            ((I) fragmentFindFragmentByTag).r = this.this$0.y;
        }
    }

    @Override // androidx.lifecycle.AbstractC0184f, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPaused(Activity activity) {
        A5.h.e(activity, "activity");
        F f4 = this.this$0;
        int i6 = f4.f4430s - 1;
        f4.f4430s = i6;
        if (i6 == 0) {
            Handler handler = f4.f4432v;
            A5.h.b(handler);
            handler.postDelayed(f4.f4434x, 700L);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPreCreated(Activity activity, Bundle bundle) {
        A5.h.e(activity, "activity");
        D.a(activity, new a(this.this$0));
    }

    @Override // androidx.lifecycle.AbstractC0184f, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStopped(Activity activity) {
        A5.h.e(activity, "activity");
        F f4 = this.this$0;
        int i6 = f4.r - 1;
        f4.r = i6;
        if (i6 == 0 && f4.t) {
            f4.f4433w.e(EnumC0190l.ON_STOP);
            f4.f4431u = true;
        }
    }
}
