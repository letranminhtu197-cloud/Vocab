package androidx.lifecycle;

import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public abstract class S {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p069l0.a f4446a = new p069l0.a();

    public final void a() {
        p069l0.a aVar = this.f4446a;
        if (aVar != null && !aVar.f7512d) {
            aVar.f7512d = true;
            synchronized (aVar.f7509a) {
                try {
                    Iterator it = aVar.f7510b.values().iterator();
                    while (it.hasNext()) {
                        p069l0.a.a((AutoCloseable) it.next());
                    }
                    Iterator it2 = aVar.f7511c.iterator();
                    while (it2.hasNext()) {
                        p069l0.a.a((AutoCloseable) it2.next());
                    }
                    aVar.f7511c.clear();
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        b();
    }

    public void b() {
    }
}
