package androidx.lifecycle;

import android.os.Bundle;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class N implements J1.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final J1.e f4440a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f4441b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Bundle f4442c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final p074l5.j f4443d;

    public N(J1.e eVar, V v6) {
        A5.h.e(eVar, "savedStateRegistry");
        this.f4440a = eVar;
        this.f4443d = new p074l5.j(new T1.a(v6, 3));
    }

    @Override // J1.d
    public final Bundle a() {
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.f4442c;
        if (bundle2 != null) {
            bundle.putAll(bundle2);
        }
        Iterator it = ((O) this.f4443d.getValue()).f4444b.entrySet().iterator();
        if (!it.hasNext()) {
            this.f4441b = false;
            return bundle;
        }
        Map.Entry entry = (Map.Entry) it.next();
        ((J) entry.getValue()).getClass();
        throw null;
    }
}
