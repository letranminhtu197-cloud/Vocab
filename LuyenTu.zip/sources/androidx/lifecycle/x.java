package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class x extends z {
    @Override // androidx.lifecycle.z
    public final boolean h() {
        return true;
    }
}
