package androidx.lifecycle;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: androidx.lifecycle.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC0191m {
    public static final EnumC0191m r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final EnumC0191m f4458s;
    public static final EnumC0191m t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final EnumC0191m f4459u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final EnumC0191m f4460v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final /* synthetic */ EnumC0191m[] f4461w;

    static {
        EnumC0191m enumC0191m = new EnumC0191m("DESTROYED", 0);
        r = enumC0191m;
        EnumC0191m enumC0191m2 = new EnumC0191m("INITIALIZED", 1);
        f4458s = enumC0191m2;
        EnumC0191m enumC0191m3 = new EnumC0191m("CREATED", 2);
        t = enumC0191m3;
        EnumC0191m enumC0191m4 = new EnumC0191m("STARTED", 3);
        f4459u = enumC0191m4;
        EnumC0191m enumC0191m5 = new EnumC0191m("RESUMED", 4);
        f4460v = enumC0191m5;
        f4461w = new EnumC0191m[]{enumC0191m, enumC0191m2, enumC0191m3, enumC0191m4, enumC0191m5};
    }

    public static EnumC0191m valueOf(String str) {
        return (EnumC0191m) Enum.valueOf(EnumC0191m.class, str);
    }

    public static EnumC0191m[] values() {
        return (EnumC0191m[]) f4461w.clone();
    }
}
