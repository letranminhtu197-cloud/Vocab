package androidx.lifecycle;

import java.lang.reflect.Method;

/* JADX INFO: renamed from: androidx.lifecycle.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0180b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f4450a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Method f4451b;

    public C0180b(int i6, Method method) {
        this.f4450a = i6;
        this.f4451b = method;
        method.setAccessible(true);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0180b)) {
            return false;
        }
        C0180b c0180b = (C0180b) obj;
        return this.f4450a == c0180b.f4450a && this.f4451b.getName().equals(c0180b.f4451b.getName());
    }

    public final int hashCode() {
        return this.f4451b.getName().hashCode() + (this.f4450a * 31);
    }
}
