package androidx.lifecycle;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class ProcessLifecycleInitializer implements P1.b {
    @Override // P1.b
    public final List a() {
        return p081m5.m.r;
    }

    @Override // P1.b
    public final Object b(Context context) {
        A5.h.e(context, "context");
        P1.a aVarC = P1.a.c(context);
        A5.h.d(aVarC, "getInstance(context)");
        if (!aVarC.f2983b.contains(ProcessLifecycleInitializer.class)) {
            throw new IllegalStateException("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml");
        }
        if (!AbstractC0194p.f4462a.getAndSet(true)) {
            Context applicationContext = context.getApplicationContext();
            A5.h.c(applicationContext, "null cannot be cast to non-null type android.app.Application");
            ((Application) applicationContext).registerActivityLifecycleCallbacks(new C0193o());
        }
        F f4 = F.f4429z;
        f4.getClass();
        f4.f4432v = new Handler();
        f4.f4433w.e(EnumC0190l.ON_CREATE);
        Context applicationContext2 = context.getApplicationContext();
        A5.h.c(applicationContext2, "null cannot be cast to non-null type android.app.Application");
        ((Application) applicationContext2).registerActivityLifecycleCallbacks(new E(f4));
        return f4;
    }
}
