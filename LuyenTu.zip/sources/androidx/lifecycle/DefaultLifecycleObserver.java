package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface DefaultLifecycleObserver extends r {
    default void a(InterfaceC0196s interfaceC0196s) {
    }

    default void d(InterfaceC0196s interfaceC0196s) {
    }

    default void e(InterfaceC0196s interfaceC0196s) {
    }

    default void j(InterfaceC0196s interfaceC0196s) {
    }

    default void o(InterfaceC0196s interfaceC0196s) {
    }

    default void q(InterfaceC0196s interfaceC0196s) {
    }
}
