package androidx.lifecycle;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: androidx.lifecycle.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC0190l {
    private static final /* synthetic */ EnumC0190l[] $VALUES;
    public static final C0188j Companion;
    public static final EnumC0190l ON_ANY;
    public static final EnumC0190l ON_CREATE;
    public static final EnumC0190l ON_DESTROY;
    public static final EnumC0190l ON_PAUSE;
    public static final EnumC0190l ON_RESUME;
    public static final EnumC0190l ON_START;
    public static final EnumC0190l ON_STOP;

    static {
        EnumC0190l enumC0190l = new EnumC0190l("ON_CREATE", 0);
        ON_CREATE = enumC0190l;
        EnumC0190l enumC0190l2 = new EnumC0190l("ON_START", 1);
        ON_START = enumC0190l2;
        EnumC0190l enumC0190l3 = new EnumC0190l("ON_RESUME", 2);
        ON_RESUME = enumC0190l3;
        EnumC0190l enumC0190l4 = new EnumC0190l("ON_PAUSE", 3);
        ON_PAUSE = enumC0190l4;
        EnumC0190l enumC0190l5 = new EnumC0190l("ON_STOP", 4);
        ON_STOP = enumC0190l5;
        EnumC0190l enumC0190l6 = new EnumC0190l("ON_DESTROY", 5);
        ON_DESTROY = enumC0190l6;
        EnumC0190l enumC0190l7 = new EnumC0190l("ON_ANY", 6);
        ON_ANY = enumC0190l7;
        $VALUES = new EnumC0190l[]{enumC0190l, enumC0190l2, enumC0190l3, enumC0190l4, enumC0190l5, enumC0190l6, enumC0190l7};
        Companion = new C0188j();
    }

    public static EnumC0190l valueOf(String str) {
        return (EnumC0190l) Enum.valueOf(EnumC0190l.class, str);
    }

    public static EnumC0190l[] values() {
        return (EnumC0190l[]) $VALUES.clone();
    }

    public final EnumC0191m a() {
        switch (AbstractC0189k.f4457a[ordinal()]) {
            case 1:
            case 2:
                return EnumC0191m.t;
            case 3:
            case 4:
                return EnumC0191m.f4459u;
            case 5:
                return EnumC0191m.f4460v;
            case 6:
                return EnumC0191m.r;
            default:
                throw new IllegalArgumentException(this + " has no target state");
        }
    }
}
