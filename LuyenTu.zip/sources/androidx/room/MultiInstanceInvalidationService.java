package androidx.room;

import A5.h;
import C1.BinderC0009j;
import C1.RemoteCallbackListC0010k;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import java.util.LinkedHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class MultiInstanceInvalidationService extends Service {
    public int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final LinkedHashMap f4505s = new LinkedHashMap();
    public final RemoteCallbackListC0010k t = new RemoteCallbackListC0010k(this);

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final BinderC0009j f4506u = new BinderC0009j(this);

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        h.e(intent, "intent");
        return this.f4506u;
    }
}
