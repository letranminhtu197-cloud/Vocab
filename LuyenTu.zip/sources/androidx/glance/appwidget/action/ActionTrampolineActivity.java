package androidx.glance.appwidget.action;

import android.app.Activity;
import android.os.Bundle;
import p056j0.e;

/* JADX INFO: loaded from: classes.dex */
public final class ActionTrampolineActivity extends Activity {
    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        e.a(this, getIntent());
        finish();
    }
}
