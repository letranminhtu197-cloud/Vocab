package androidx.glance.appwidget.action;

import K5.AbstractC0120y;
import K5.G;
import P5.d;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import p025e2.v;
import p049i0.a;
import p056j0.b;

/* JADX INFO: loaded from: classes.dex */
public final class ActionCallbackBroadcastReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        b bVar = new b(intent, context, null);
        d dVarB = AbstractC0120y.b(v.E(AbstractC0120y.d(), G.f2085a));
        AbstractC0120y.p(dVarB, null, null, new a(bVar, dVarB, goAsync(), null), 3);
    }
}
