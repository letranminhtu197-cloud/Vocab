package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.FrameLayout;
import p068l.InterfaceC0412z;

/* JADX INFO: loaded from: classes.dex */
public class ContentFrameLayout extends FrameLayout {
    public TypedValue r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public TypedValue f4144s;
    public TypedValue t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public TypedValue f4145u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public TypedValue f4146v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public TypedValue f4147w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final Rect f4148x;

    public ContentFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        this.f4148x = new Rect();
    }

    public TypedValue getFixedHeightMajor() {
        if (this.f4146v == null) {
            this.f4146v = new TypedValue();
        }
        return this.f4146v;
    }

    public TypedValue getFixedHeightMinor() {
        if (this.f4147w == null) {
            this.f4147w = new TypedValue();
        }
        return this.f4147w;
    }

    public TypedValue getFixedWidthMajor() {
        if (this.t == null) {
            this.t = new TypedValue();
        }
        return this.t;
    }

    public TypedValue getFixedWidthMinor() {
        if (this.f4145u == null) {
            this.f4145u = new TypedValue();
        }
        return this.f4145u;
    }

    public TypedValue getMinWidthMajor() {
        if (this.r == null) {
            this.r = new TypedValue();
        }
        return this.r;
    }

    public TypedValue getMinWidthMinor() {
        if (this.f4144s == null) {
            this.f4144s = new TypedValue();
        }
        return this.f4144s;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
    }

    /* JADX WARN: Code duplicated, block: B:21:0x004e  */
    /* JADX WARN: Code duplicated, block: B:22:0x0062  */
    /* JADX WARN: Code duplicated, block: B:37:0x008a  */
    /* JADX WARN: Code duplicated, block: B:38:0x009d  */
    /* JADX WARN: Code duplicated, block: B:55:0x00d1  */
    /* JADX WARN: Code duplicated, block: B:57:0x00d9  */
    /* JADX WARN: Code duplicated, block: B:58:0x00de  */
    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i6, int i7) {
        int iMakeMeasureSpec;
        boolean z6;
        int iMakeMeasureSpec2;
        int i8;
        int i9;
        float fraction;
        int i10;
        int i11;
        float fraction2;
        int i12;
        int i13;
        float fraction3;
        DisplayMetrics displayMetrics = getContext().getResources().getDisplayMetrics();
        boolean z7 = true;
        boolean z8 = displayMetrics.widthPixels < displayMetrics.heightPixels;
        int mode = View.MeasureSpec.getMode(i6);
        int mode2 = View.MeasureSpec.getMode(i7);
        Rect rect = this.f4148x;
        if (mode != Integer.MIN_VALUE) {
            iMakeMeasureSpec = i6;
            z6 = false;
        } else {
            TypedValue typedValue = z8 ? this.f4145u : this.t;
            if (typedValue == null || (i12 = typedValue.type) == 0) {
                iMakeMeasureSpec = i6;
                z6 = false;
            } else {
                if (i12 == 5) {
                    fraction3 = typedValue.getDimension(displayMetrics);
                } else {
                    if (i12 == 6) {
                        int i14 = displayMetrics.widthPixels;
                        fraction3 = typedValue.getFraction(i14, i14);
                    } else {
                        i13 = 0;
                    }
                    if (i13 > 0) {
                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(Math.min(i13 - (rect.left + rect.right), View.MeasureSpec.getSize(i6)), 1073741824);
                        z6 = true;
                    } else {
                        iMakeMeasureSpec = i6;
                        z6 = false;
                    }
                }
                i13 = (int) fraction3;
                if (i13 > 0) {
                    iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(Math.min(i13 - (rect.left + rect.right), View.MeasureSpec.getSize(i6)), 1073741824);
                    z6 = true;
                } else {
                    iMakeMeasureSpec = i6;
                    z6 = false;
                }
            }
        }
        if (mode2 != Integer.MIN_VALUE) {
            iMakeMeasureSpec2 = i7;
        } else {
            TypedValue typedValue2 = z8 ? this.f4146v : this.f4147w;
            if (typedValue2 == null || (i10 = typedValue2.type) == 0) {
                iMakeMeasureSpec2 = i7;
            } else {
                if (i10 == 5) {
                    fraction2 = typedValue2.getDimension(displayMetrics);
                } else {
                    if (i10 == 6) {
                        int i15 = displayMetrics.heightPixels;
                        fraction2 = typedValue2.getFraction(i15, i15);
                    } else {
                        i11 = 0;
                    }
                    if (i11 > 0) {
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(Math.min(i11 - (rect.top + rect.bottom), View.MeasureSpec.getSize(i7)), 1073741824);
                    } else {
                        iMakeMeasureSpec2 = i7;
                    }
                }
                i11 = (int) fraction2;
                if (i11 > 0) {
                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(Math.min(i11 - (rect.top + rect.bottom), View.MeasureSpec.getSize(i7)), 1073741824);
                } else {
                    iMakeMeasureSpec2 = i7;
                }
            }
        }
        super.onMeasure(iMakeMeasureSpec, iMakeMeasureSpec2);
        int measuredWidth = getMeasuredWidth();
        int iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(measuredWidth, 1073741824);
        if (z6 || mode != Integer.MIN_VALUE) {
            z7 = false;
        } else {
            TypedValue typedValue3 = z8 ? this.f4144s : this.r;
            if (typedValue3 == null || (i8 = typedValue3.type) == 0) {
                z7 = false;
            } else {
                if (i8 == 5) {
                    fraction = typedValue3.getDimension(displayMetrics);
                } else {
                    if (i8 == 6) {
                        int i16 = displayMetrics.widthPixels;
                        fraction = typedValue3.getFraction(i16, i16);
                    } else {
                        i9 = 0;
                    }
                    if (i9 > 0) {
                        i9 -= rect.left + rect.right;
                    }
                    if (measuredWidth < i9) {
                        iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(i9, 1073741824);
                    } else {
                        z7 = false;
                    }
                }
                i9 = (int) fraction;
                if (i9 > 0) {
                    i9 -= rect.left + rect.right;
                }
                if (measuredWidth < i9) {
                    iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(i9, 1073741824);
                } else {
                    z7 = false;
                }
            }
        }
        if (z7) {
            super.onMeasure(iMakeMeasureSpec3, iMakeMeasureSpec2);
        }
    }

    public void setAttachListener(InterfaceC0412z interfaceC0412z) {
    }
}
