package androidx.appcompat.widget;

import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class b implements View.OnKeyListener {
    public final /* synthetic */ SearchView r;

    public b(SearchView searchView) {
        this.r = searchView;
    }

    @Override // android.view.View.OnKeyListener
    public final boolean onKey(View view, int i6, KeyEvent keyEvent) {
        SearchView searchView = this.r;
        SearchView.SearchAutoComplete searchAutoComplete = searchView.f4150G;
        if (searchView.f4183s0 != null) {
            if (!searchAutoComplete.isPopupShowing() || searchAutoComplete.getListSelection() == -1) {
                if (TextUtils.getTrimmedLength(searchAutoComplete.getText()) != 0 && keyEvent.hasNoModifiers() && keyEvent.getAction() == 1 && i6 == 66) {
                    view.cancelLongPress();
                    searchView.getContext().startActivity(searchView.h("android.intent.action.SEARCH", null, null, searchAutoComplete.getText().toString()));
                    return true;
                }
            } else if (searchView.f4183s0 != null && searchView.f4173i0 != null && keyEvent.getAction() == 0 && keyEvent.hasNoModifiers()) {
                if (i6 == 66 || i6 == 84 || i6 == 61) {
                    searchView.l(searchAutoComplete.getListSelection());
                    return true;
                }
                if (i6 == 21 || i6 == 22) {
                    searchAutoComplete.setSelection(i6 == 21 ? 0 : searchAutoComplete.length());
                    searchAutoComplete.setListSelection(0);
                    searchAutoComplete.clearListSelection();
                    searchAutoComplete.a();
                    return true;
                }
                if (i6 == 19) {
                    searchAutoComplete.getListSelection();
                    return false;
                }
            }
        }
        return false;
    }
}
