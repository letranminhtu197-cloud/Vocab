package androidx.appcompat.widget;

import H.AbstractC0046z;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import com.luyentu.mobile.R;
import java.lang.reflect.Field;
import p068l.C0388a;
import p068l.U;

/* JADX INFO: loaded from: classes.dex */
public class ActionBarContainer extends FrameLayout {
    public boolean r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public View f4099s;
    public View t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public Drawable f4100u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public Drawable f4101v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public Drawable f4102w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final boolean f4103x;
    public boolean y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final int f4104z;

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        C0388a c0388a = new C0388a(this);
        Field field = AbstractC0046z.f1508a;
        setBackground(c0388a);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p041h.a.f5945a);
        boolean z6 = false;
        this.f4100u = typedArrayObtainStyledAttributes.getDrawable(0);
        this.f4101v = typedArrayObtainStyledAttributes.getDrawable(2);
        this.f4104z = typedArrayObtainStyledAttributes.getDimensionPixelSize(13, -1);
        if (getId() == R.id.split_action_bar) {
            this.f4103x = true;
            this.f4102w = typedArrayObtainStyledAttributes.getDrawable(1);
        }
        typedArrayObtainStyledAttributes.recycle();
        if (!this.f4103x ? !(this.f4100u != null || this.f4101v != null) : this.f4102w == null) {
            z6 = true;
        }
        setWillNotDraw(z6);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f4100u;
        if (drawable != null && drawable.isStateful()) {
            this.f4100u.setState(getDrawableState());
        }
        Drawable drawable2 = this.f4101v;
        if (drawable2 != null && drawable2.isStateful()) {
            this.f4101v.setState(getDrawableState());
        }
        Drawable drawable3 = this.f4102w;
        if (drawable3 == null || !drawable3.isStateful()) {
            return;
        }
        this.f4102w.setState(getDrawableState());
    }

    public View getTabContainer() {
        return null;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f4100u;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f4101v;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.f4102w;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        this.f4099s = findViewById(R.id.action_bar);
        this.t = findViewById(R.id.action_context_bar);
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.r || super.onInterceptTouchEvent(motionEvent);
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z6, int i6, int i7, int i8, int i9) {
        super.onLayout(z6, i6, i7, i8, i9);
        boolean z7 = true;
        if (this.f4103x) {
            Drawable drawable = this.f4102w;
            if (drawable != null) {
                drawable.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            } else {
                z7 = false;
            }
        } else {
            if (this.f4100u == null) {
                z7 = false;
            } else if (this.f4099s.getVisibility() == 0) {
                this.f4100u.setBounds(this.f4099s.getLeft(), this.f4099s.getTop(), this.f4099s.getRight(), this.f4099s.getBottom());
            } else {
                View view = this.t;
                if (view == null || view.getVisibility() != 0) {
                    this.f4100u.setBounds(0, 0, 0, 0);
                } else {
                    this.f4100u.setBounds(this.t.getLeft(), this.t.getTop(), this.t.getRight(), this.t.getBottom());
                }
            }
            this.y = false;
        }
        if (z7) {
            invalidate();
        }
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i6, int i7) {
        int i8;
        if (this.f4099s == null && View.MeasureSpec.getMode(i7) == Integer.MIN_VALUE && (i8 = this.f4104z) >= 0) {
            i7 = View.MeasureSpec.makeMeasureSpec(Math.min(i8, View.MeasureSpec.getSize(i7)), Integer.MIN_VALUE);
        }
        super.onMeasure(i6, i7);
        if (this.f4099s == null) {
            return;
        }
        View.MeasureSpec.getMode(i7);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.f4100u;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.f4100u);
        }
        this.f4100u = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.f4099s;
            if (view != null) {
                this.f4100u.setBounds(view.getLeft(), this.f4099s.getTop(), this.f4099s.getRight(), this.f4099s.getBottom());
            }
        }
        boolean z6 = false;
        if (!this.f4103x ? !(this.f4100u != null || this.f4101v != null) : this.f4102w == null) {
            z6 = true;
        }
        setWillNotDraw(z6);
        invalidate();
        invalidateOutline();
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f4102w;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.f4102w);
        }
        this.f4102w = drawable;
        boolean z6 = this.f4103x;
        boolean z7 = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (z6 && (drawable2 = this.f4102w) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!z6 ? !(this.f4100u != null || this.f4101v != null) : this.f4102w == null) {
            z7 = true;
        }
        setWillNotDraw(z7);
        invalidate();
        invalidateOutline();
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2 = this.f4101v;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.f4101v);
        }
        this.f4101v = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.y && this.f4101v != null) {
                throw null;
            }
        }
        boolean z6 = false;
        if (!this.f4103x ? !(this.f4100u != null || this.f4101v != null) : this.f4102w == null) {
            z6 = true;
        }
        setWillNotDraw(z6);
        invalidate();
        invalidateOutline();
    }

    public void setTransitioning(boolean z6) {
        this.r = z6;
        setDescendantFocusability(z6 ? 393216 : 262144);
    }

    @Override // android.view.View
    public void setVisibility(int i6) {
        super.setVisibility(i6);
        boolean z6 = i6 == 0;
        Drawable drawable = this.f4100u;
        if (drawable != null) {
            drawable.setVisible(z6, false);
        }
        Drawable drawable2 = this.f4101v;
        if (drawable2 != null) {
            drawable2.setVisible(z6, false);
        }
        Drawable drawable3 = this.f4102w;
        if (drawable3 != null) {
            drawable3.setVisible(z6, false);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    @Override // android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        Drawable drawable2 = this.f4100u;
        boolean z6 = this.f4103x;
        if (drawable == drawable2 && !z6) {
            return true;
        }
        if (drawable == this.f4101v && this.y) {
            return true;
        }
        return (drawable == this.f4102w && z6) || super.verifyDrawable(drawable);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i6) {
        if (i6 != 0) {
            return super.startActionModeForChild(view, callback, i6);
        }
        return null;
    }

    public void setTabContainer(U u6) {
    }
}
