package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.lang.ref.WeakReference;
import p068l.x0;

/* JADX INFO: loaded from: classes.dex */
public final class ViewStubCompat extends View {
    public int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f4223s;
    public WeakReference t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public LayoutInflater f4224u;

    public ViewStubCompat(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        this.r = 0;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p041h.a.f5963v, 0, 0);
        this.f4223s = typedArrayObtainStyledAttributes.getResourceId(2, -1);
        this.r = typedArrayObtainStyledAttributes.getResourceId(1, 0);
        setId(typedArrayObtainStyledAttributes.getResourceId(0, -1));
        typedArrayObtainStyledAttributes.recycle();
        setVisibility(8);
        setWillNotDraw(true);
    }

    @Override // android.view.View
    public final void dispatchDraw(Canvas canvas) {
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
    }

    public int getInflatedId() {
        return this.f4223s;
    }

    public LayoutInflater getLayoutInflater() {
        return this.f4224u;
    }

    public int getLayoutResource() {
        return this.r;
    }

    @Override // android.view.View
    public final void onMeasure(int i6, int i7) {
        setMeasuredDimension(0, 0);
    }

    public void setInflatedId(int i6) {
        this.f4223s = i6;
    }

    public void setLayoutInflater(LayoutInflater layoutInflater) {
        this.f4224u = layoutInflater;
    }

    public void setLayoutResource(int i6) {
        this.r = i6;
    }

    @Override // android.view.View
    public void setVisibility(int i6) {
        WeakReference weakReference = this.t;
        if (weakReference != null) {
            View view = (View) weakReference.get();
            if (view == null) {
                throw new IllegalStateException("setVisibility called on un-referenced view");
            }
            view.setVisibility(i6);
            return;
        }
        super.setVisibility(i6);
        if (i6 == 0 || i6 == 4) {
            ViewParent parent = getParent();
            if (!(parent instanceof ViewGroup)) {
                throw new IllegalStateException("ViewStub must have a non-null ViewGroup viewParent");
            }
            if (this.r == 0) {
                throw new IllegalArgumentException("ViewStub must have a valid layoutResource");
            }
            ViewGroup viewGroup = (ViewGroup) parent;
            LayoutInflater layoutInflaterFrom = this.f4224u;
            if (layoutInflaterFrom == null) {
                layoutInflaterFrom = LayoutInflater.from(getContext());
            }
            View viewInflate = layoutInflaterFrom.inflate(this.r, viewGroup, false);
            int i7 = this.f4223s;
            if (i7 != -1) {
                viewInflate.setId(i7);
            }
            int iIndexOfChild = viewGroup.indexOfChild(this);
            viewGroup.removeViewInLayout(this);
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            if (layoutParams != null) {
                viewGroup.addView(viewInflate, iIndexOfChild, layoutParams);
            } else {
                viewGroup.addView(viewInflate, iIndexOfChild);
            }
            this.t = new WeakReference(viewInflate);
        }
    }

    public void setOnInflateListener(x0 x0Var) {
    }
}
