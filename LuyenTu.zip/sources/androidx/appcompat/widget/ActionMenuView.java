package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.appcompat.view.menu.ActionMenuItemView;
import p033f5.f;
import p062k.h;
import p062k.i;
import p062k.j;
import p068l.C0393f;
import p068l.C0395h;
import p068l.C0396i;
import p068l.C0398k;
import p068l.G;
import p068l.H;
import p068l.InterfaceC0397j;
import p068l.InterfaceC0399l;
import p068l.y0;

/* JADX INFO: loaded from: classes.dex */
public class ActionMenuView extends H implements h {

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public i f4134G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public Context f4135H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public int f4136I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public C0396i f4137J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public boolean f4138K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public int f4139L;

    /* JADX INFO: renamed from: M, reason: collision with root package name */
    public final int f4140M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public final int f4141N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public InterfaceC0399l f4142O;

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        setBaselineAligned(false);
        float f4 = context.getResources().getDisplayMetrics().density;
        this.f4140M = (int) (56.0f * f4);
        this.f4141N = (int) (f4 * 4.0f);
        this.f4135H = context;
        this.f4136I = 0;
    }

    public static C0398k h() {
        C0398k c0398k = new C0398k(-2);
        c0398k.f7425c = false;
        c0398k.f7303b = 16;
        return c0398k;
    }

    public static C0398k i(ViewGroup.LayoutParams layoutParams) {
        C0398k c0398k;
        if (layoutParams == null) {
            return h();
        }
        if (layoutParams instanceof C0398k) {
            C0398k c0398k2 = (C0398k) layoutParams;
            c0398k = new C0398k(c0398k2);
            c0398k.f7425c = c0398k2.f7425c;
        } else {
            c0398k = new C0398k(layoutParams);
        }
        if (c0398k.f7303b <= 0) {
            c0398k.f7303b = 16;
        }
        return c0398k;
    }

    @Override // p062k.h
    public final boolean a(j jVar) {
        return this.f4134G.p(jVar, null, 0);
    }

    @Override // p068l.H, android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0398k;
    }

    @Override // p068l.H
    /* JADX INFO: renamed from: d */
    public final /* bridge */ /* synthetic */ G generateDefaultLayoutParams() {
        return h();
    }

    @Override // android.view.View
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    @Override // p068l.H
    /* JADX INFO: renamed from: e */
    public final G generateLayoutParams(AttributeSet attributeSet) {
        return new C0398k(getContext(), attributeSet);
    }

    @Override // p068l.H
    /* JADX INFO: renamed from: f */
    public final /* bridge */ /* synthetic */ G generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return i(layoutParams);
    }

    @Override // p068l.H, android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return h();
    }

    @Override // p068l.H, android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return i(layoutParams);
    }

    public Menu getMenu() {
        if (this.f4134G == null) {
            Context context = getContext();
            i iVar = new i(context);
            this.f4134G = iVar;
            iVar.f7171e = new io.flutter.plugin.editing.j(this);
            C0396i c0396i = new C0396i(context);
            this.f4137J = c0396i;
            c0396i.f7385B = true;
            c0396i.C = true;
            c0396i.f7398v = new f(20);
            this.f4134G.b(c0396i, this.f4135H);
            C0396i c0396i2 = this.f4137J;
            c0396i2.f7400x = this;
            this.f4134G = c0396i2.t;
        }
        return this.f4134G;
    }

    public Drawable getOverflowIcon() {
        getMenu();
        C0396i c0396i = this.f4137J;
        C0395h c0395h = c0396i.y;
        if (c0395h != null) {
            return c0395h.getDrawable();
        }
        if (c0396i.f7384A) {
            return c0396i.f7401z;
        }
        return null;
    }

    public int getPopupTheme() {
        return this.f4136I;
    }

    public int getWindowAnimations() {
        return 0;
    }

    public final boolean j(int i6) {
        boolean zB = false;
        if (i6 == 0) {
            return false;
        }
        KeyEvent.Callback childAt = getChildAt(i6 - 1);
        KeyEvent.Callback childAt2 = getChildAt(i6);
        if (i6 < getChildCount() && (childAt instanceof InterfaceC0397j)) {
            zB = ((InterfaceC0397j) childAt).b();
        }
        return (i6 <= 0 || !(childAt2 instanceof InterfaceC0397j)) ? zB : ((InterfaceC0397j) childAt2).c() | zB;
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        C0396i c0396i = this.f4137J;
        if (c0396i != null) {
            c0396i.f();
            C0393f c0393f = this.f4137J.f7391I;
            if (c0393f == null || !c0393f.b()) {
                return;
            }
            this.f4137J.g();
            this.f4137J.k();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C0396i c0396i = this.f4137J;
        if (c0396i != null) {
            c0396i.g();
            C0393f c0393f = c0396i.f7392J;
            if (c0393f == null || !c0393f.b()) {
                return;
            }
            c0393f.f7216i.dismiss();
        }
    }

    @Override // p068l.H, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z6, int i6, int i7, int i8, int i9) {
        int width;
        int paddingLeft;
        if (!this.f4138K) {
            super.onLayout(z6, i6, i7, i8, i9);
            return;
        }
        int childCount = getChildCount();
        int i10 = (i9 - i7) / 2;
        int dividerWidth = getDividerWidth();
        int i11 = i8 - i6;
        int paddingRight = (i11 - getPaddingRight()) - getPaddingLeft();
        boolean zA = y0.a(this);
        int i12 = 0;
        int i13 = 0;
        for (int i14 = 0; i14 < childCount; i14++) {
            View childAt = getChildAt(i14);
            if (childAt.getVisibility() != 8) {
                C0398k c0398k = (C0398k) childAt.getLayoutParams();
                if (c0398k.f7425c) {
                    int measuredWidth = childAt.getMeasuredWidth();
                    if (j(i14)) {
                        measuredWidth += dividerWidth;
                    }
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (zA) {
                        paddingLeft = getPaddingLeft() + ((ViewGroup.MarginLayoutParams) c0398k).leftMargin;
                        width = paddingLeft + measuredWidth;
                    } else {
                        width = (getWidth() - getPaddingRight()) - ((ViewGroup.MarginLayoutParams) c0398k).rightMargin;
                        paddingLeft = width - measuredWidth;
                    }
                    int i15 = i10 - (measuredHeight / 2);
                    childAt.layout(paddingLeft, i15, width, measuredHeight + i15);
                    paddingRight -= measuredWidth;
                    i12 = 1;
                } else {
                    paddingRight -= (childAt.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) c0398k).leftMargin) + ((ViewGroup.MarginLayoutParams) c0398k).rightMargin;
                    j(i14);
                    i13++;
                }
            }
        }
        if (childCount == 1 && i12 == 0) {
            View childAt2 = getChildAt(0);
            int measuredWidth2 = childAt2.getMeasuredWidth();
            int measuredHeight2 = childAt2.getMeasuredHeight();
            int i16 = (i11 / 2) - (measuredWidth2 / 2);
            int i17 = i10 - (measuredHeight2 / 2);
            childAt2.layout(i16, i17, measuredWidth2 + i16, measuredHeight2 + i17);
            return;
        }
        int i18 = i13 - (i12 ^ 1);
        int iMax = Math.max(0, i18 > 0 ? paddingRight / i18 : 0);
        if (zA) {
            int width2 = getWidth() - getPaddingRight();
            for (int i19 = 0; i19 < childCount; i19++) {
                View childAt3 = getChildAt(i19);
                C0398k c0398k2 = (C0398k) childAt3.getLayoutParams();
                if (childAt3.getVisibility() != 8 && !c0398k2.f7425c) {
                    int i20 = width2 - ((ViewGroup.MarginLayoutParams) c0398k2).rightMargin;
                    int measuredWidth3 = childAt3.getMeasuredWidth();
                    int measuredHeight3 = childAt3.getMeasuredHeight();
                    int i21 = i10 - (measuredHeight3 / 2);
                    childAt3.layout(i20 - measuredWidth3, i21, i20, measuredHeight3 + i21);
                    width2 = i20 - ((measuredWidth3 + ((ViewGroup.MarginLayoutParams) c0398k2).leftMargin) + iMax);
                }
            }
            return;
        }
        int paddingLeft2 = getPaddingLeft();
        for (int i22 = 0; i22 < childCount; i22++) {
            View childAt4 = getChildAt(i22);
            C0398k c0398k3 = (C0398k) childAt4.getLayoutParams();
            if (childAt4.getVisibility() != 8 && !c0398k3.f7425c) {
                int i23 = paddingLeft2 + ((ViewGroup.MarginLayoutParams) c0398k3).leftMargin;
                int measuredWidth4 = childAt4.getMeasuredWidth();
                int measuredHeight4 = childAt4.getMeasuredHeight();
                int i24 = i10 - (measuredHeight4 / 2);
                childAt4.layout(i23, i24, i23 + measuredWidth4, measuredHeight4 + i24);
                paddingLeft2 = measuredWidth4 + ((ViewGroup.MarginLayoutParams) c0398k3).rightMargin + iMax + i23;
            }
        }
    }

    /* JADX WARN: Type inference failed for: r11v15 */
    /* JADX WARN: Type inference failed for: r11v16, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r11v18 */
    /* JADX WARN: Type inference failed for: r11v41 */
    @Override // p068l.H, android.view.View
    public final void onMeasure(int i6, int i7) {
        int i8;
        int i9;
        ?? r11;
        int i10;
        int i11;
        i iVar;
        boolean z6 = this.f4138K;
        boolean z7 = View.MeasureSpec.getMode(i6) == 1073741824;
        this.f4138K = z7;
        if (z6 != z7) {
            this.f4139L = 0;
        }
        int size = View.MeasureSpec.getSize(i6);
        if (this.f4138K && (iVar = this.f4134G) != null && size != this.f4139L) {
            this.f4139L = size;
            iVar.o(true);
        }
        int childCount = getChildCount();
        if (!this.f4138K || childCount <= 0) {
            for (int i12 = 0; i12 < childCount; i12++) {
                C0398k c0398k = (C0398k) getChildAt(i12).getLayoutParams();
                ((ViewGroup.MarginLayoutParams) c0398k).rightMargin = 0;
                ((ViewGroup.MarginLayoutParams) c0398k).leftMargin = 0;
            }
            super.onMeasure(i6, i7);
            return;
        }
        int mode = View.MeasureSpec.getMode(i7);
        int size2 = View.MeasureSpec.getSize(i6);
        int size3 = View.MeasureSpec.getSize(i7);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i7, paddingBottom, -2);
        int i13 = size2 - paddingRight;
        int i14 = this.f4140M;
        int i15 = i13 / i14;
        int i16 = i13 % i14;
        if (i15 == 0) {
            setMeasuredDimension(i13, 0);
            return;
        }
        int i17 = (i16 / i15) + i14;
        int childCount2 = getChildCount();
        int iMax = 0;
        int i18 = 0;
        int iMax2 = 0;
        int i19 = 0;
        boolean z8 = false;
        int i20 = 0;
        long j6 = 0;
        while (true) {
            i8 = this.f4141N;
            if (i19 >= childCount2) {
                break;
            }
            View childAt = getChildAt(i19);
            int i21 = size3;
            int i22 = paddingBottom;
            if (childAt.getVisibility() == 8) {
                i10 = i17;
            } else {
                boolean z9 = childAt instanceof ActionMenuItemView;
                i18++;
                if (z9) {
                    childAt.setPadding(i8, 0, i8, 0);
                }
                C0398k c0398k2 = (C0398k) childAt.getLayoutParams();
                c0398k2.f7430h = false;
                c0398k2.f7427e = 0;
                c0398k2.f7426d = 0;
                c0398k2.f7428f = false;
                ((ViewGroup.MarginLayoutParams) c0398k2).leftMargin = 0;
                ((ViewGroup.MarginLayoutParams) c0398k2).rightMargin = 0;
                c0398k2.f7429g = z9 && !TextUtils.isEmpty(((ActionMenuItemView) childAt).getText());
                int i23 = c0398k2.f7425c ? 1 : i15;
                C0398k c0398k3 = (C0398k) childAt.getLayoutParams();
                int i24 = i15;
                i10 = i17;
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(childMeasureSpec) - i22, View.MeasureSpec.getMode(childMeasureSpec));
                ActionMenuItemView actionMenuItemView = z9 ? (ActionMenuItemView) childAt : null;
                boolean z10 = (actionMenuItemView == null || TextUtils.isEmpty(actionMenuItemView.getText())) ? false : true;
                boolean z11 = z10;
                if (i23 <= 0 || (z10 && i23 < 2)) {
                    i11 = 0;
                } else {
                    childAt.measure(View.MeasureSpec.makeMeasureSpec(i10 * i23, Integer.MIN_VALUE), iMakeMeasureSpec);
                    int measuredWidth = childAt.getMeasuredWidth();
                    i11 = measuredWidth / i10;
                    if (measuredWidth % i10 != 0) {
                        i11++;
                    }
                    if (z11 && i11 < 2) {
                        i11 = 2;
                    }
                }
                c0398k3.f7428f = !c0398k3.f7425c && z11;
                c0398k3.f7426d = i11;
                childAt.measure(View.MeasureSpec.makeMeasureSpec(i11 * i10, 1073741824), iMakeMeasureSpec);
                iMax2 = Math.max(iMax2, i11);
                if (c0398k2.f7428f) {
                    i20++;
                }
                if (c0398k2.f7425c) {
                    z8 = true;
                }
                i15 = i24 - i11;
                iMax = Math.max(iMax, childAt.getMeasuredHeight());
                if (i11 == 1) {
                    j6 |= (long) (1 << i19);
                }
            }
            i19++;
            size3 = i21;
            paddingBottom = i22;
            i17 = i10;
        }
        int i25 = size3;
        int i26 = i15;
        int i27 = i17;
        boolean z12 = z8 && i18 == 2;
        int i28 = i26;
        boolean z13 = false;
        while (true) {
            if (i20 <= 0 || i28 <= 0) {
                i9 = iMax;
                break;
            }
            int i29 = Integer.MAX_VALUE;
            long j7 = 0;
            int i30 = 0;
            int i31 = 0;
            while (i31 < childCount2) {
                int i32 = iMax;
                C0398k c0398k4 = (C0398k) getChildAt(i31).getLayoutParams();
                boolean z14 = z12;
                if (c0398k4.f7428f) {
                    int i33 = c0398k4.f7426d;
                    if (i33 < i29) {
                        j7 = 1 << i31;
                        i29 = i33;
                        i30 = 1;
                    } else if (i33 == i29) {
                        j7 |= 1 << i31;
                        i30++;
                    }
                }
                i31++;
                z12 = z14;
                iMax = i32;
            }
            i9 = iMax;
            boolean z15 = z12;
            j6 |= j7;
            if (i30 > i28) {
                break;
            }
            int i34 = i29 + 1;
            int i35 = 0;
            while (i35 < childCount2) {
                View childAt2 = getChildAt(i35);
                C0398k c0398k5 = (C0398k) childAt2.getLayoutParams();
                boolean z16 = z8;
                long j8 = 1 << i35;
                if ((j7 & j8) != 0) {
                    if (z15 && c0398k5.f7429g) {
                        r11 = 1;
                        r11 = 1;
                        if (i28 == 1) {
                            childAt2.setPadding(i8 + i27, 0, i8, 0);
                        }
                    } else {
                        r11 = 1;
                    }
                    c0398k5.f7426d += r11;
                    c0398k5.f7430h = r11;
                    i28--;
                } else if (c0398k5.f7426d == i34) {
                    j6 |= j8;
                }
                i35++;
                z8 = z16;
            }
            z12 = z15;
            iMax = i9;
            z13 = true;
        }
        boolean z17 = !z8 && i18 == 1;
        if (i28 > 0 && j6 != 0 && (i28 < i18 - 1 || z17 || iMax2 > 1)) {
            float fBitCount = Long.bitCount(j6);
            if (!z17) {
                if ((j6 & 1) != 0 && !((C0398k) getChildAt(0).getLayoutParams()).f7429g) {
                    fBitCount -= 0.5f;
                }
                int i36 = childCount2 - 1;
                if ((j6 & ((long) (1 << i36))) != 0 && !((C0398k) getChildAt(i36).getLayoutParams()).f7429g) {
                    fBitCount -= 0.5f;
                }
            }
            int i37 = fBitCount > 0.0f ? (int) ((i28 * i27) / fBitCount) : 0;
            boolean z18 = z13;
            for (int i38 = 0; i38 < childCount2; i38++) {
                if ((j6 & ((long) (1 << i38))) != 0) {
                    View childAt3 = getChildAt(i38);
                    C0398k c0398k6 = (C0398k) childAt3.getLayoutParams();
                    if (childAt3 instanceof ActionMenuItemView) {
                        c0398k6.f7427e = i37;
                        c0398k6.f7430h = true;
                        if (i38 == 0 && !c0398k6.f7429g) {
                            ((ViewGroup.MarginLayoutParams) c0398k6).leftMargin = (-i37) / 2;
                        }
                        z18 = true;
                    } else if (c0398k6.f7425c) {
                        c0398k6.f7427e = i37;
                        c0398k6.f7430h = true;
                        ((ViewGroup.MarginLayoutParams) c0398k6).rightMargin = (-i37) / 2;
                        z18 = true;
                    } else {
                        if (i38 != 0) {
                            ((ViewGroup.MarginLayoutParams) c0398k6).leftMargin = i37 / 2;
                        }
                        if (i38 != childCount2 - 1) {
                            ((ViewGroup.MarginLayoutParams) c0398k6).rightMargin = i37 / 2;
                        }
                    }
                }
            }
            z13 = z18;
        }
        if (z13) {
            for (int i39 = 0; i39 < childCount2; i39++) {
                View childAt4 = getChildAt(i39);
                C0398k c0398k7 = (C0398k) childAt4.getLayoutParams();
                if (c0398k7.f7430h) {
                    childAt4.measure(View.MeasureSpec.makeMeasureSpec((c0398k7.f7426d * i27) + c0398k7.f7427e, 1073741824), childMeasureSpec);
                }
            }
        }
        setMeasuredDimension(i13, mode != 1073741824 ? i9 : i25);
    }

    public void setExpandedActionViewsExclusive(boolean z6) {
        this.f4137J.f7389G = z6;
    }

    public void setOnMenuItemClickListener(InterfaceC0399l interfaceC0399l) {
        this.f4142O = interfaceC0399l;
    }

    public void setOverflowIcon(Drawable drawable) {
        getMenu();
        C0396i c0396i = this.f4137J;
        C0395h c0395h = c0396i.y;
        if (c0395h != null) {
            c0395h.setImageDrawable(drawable);
        } else {
            c0396i.f7384A = true;
            c0396i.f7401z = drawable;
        }
    }

    public void setOverflowReserved(boolean z6) {
    }

    public void setPopupTheme(int i6) {
        if (this.f4136I != i6) {
            this.f4136I = i6;
            if (i6 == 0) {
                this.f4135H = getContext();
            } else {
                this.f4135H = new ContextThemeWrapper(getContext(), i6);
            }
        }
    }

    public void setPresenter(C0396i c0396i) {
        this.f4137J = c0396i;
        c0396i.f7400x = this;
        this.f4134G = c0396i.t;
    }

    @Override // p068l.H, android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0398k(getContext(), attributeSet);
    }
}
