package androidx.appcompat.widget;

import H.AbstractC0046z;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.luyentu.mobile.R;
import java.lang.reflect.Field;
import java.util.ArrayList;
import p045h3.C0331c;
import p055j.d;
import p062k.i;
import p062k.j;
import p068l.A;
import p068l.C0393f;
import p068l.C0396i;
import p068l.C0403p;
import p068l.C0404q;
import p068l.C0407u;
import p068l.T;
import p068l.m0;
import p068l.n0;
import p068l.o0;
import p068l.p0;
import p068l.q0;
import p068l.r0;
import p068l.s0;
import p068l.y0;

/* JADX INFO: loaded from: classes.dex */
public class Toolbar extends ViewGroup {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public Context f4192A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public int f4193B;
    public int C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public int f4194D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public final int f4195E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public final int f4196F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public int f4197G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public int f4198H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public int f4199I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public int f4200J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public T f4201K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public int f4202L;

    /* JADX INFO: renamed from: M, reason: collision with root package name */
    public int f4203M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public final int f4204N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public CharSequence f4205O;

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public CharSequence f4206P;

    /* JADX INFO: renamed from: Q, reason: collision with root package name */
    public ColorStateList f4207Q;

    /* JADX INFO: renamed from: R, reason: collision with root package name */
    public ColorStateList f4208R;

    /* JADX INFO: renamed from: S, reason: collision with root package name */
    public boolean f4209S;

    /* JADX INFO: renamed from: T, reason: collision with root package name */
    public boolean f4210T;

    /* JADX INFO: renamed from: U, reason: collision with root package name */
    public final ArrayList f4211U;

    /* JADX INFO: renamed from: V, reason: collision with root package name */
    public final ArrayList f4212V;
    public final int[] W;
    public final m0 a0;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public s0 f4213b0;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public o0 f4214c0;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public boolean f4215d0;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public final E.b f4216e0;
    public ActionMenuView r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public C0407u f4217s;
    public C0407u t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public C0403p f4218u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public C0404q f4219v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final Drawable f4220w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final CharSequence f4221x;
    public C0403p y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public View f4222z;

    public Toolbar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.toolbarStyle);
        this.f4204N = 8388627;
        this.f4211U = new ArrayList();
        this.f4212V = new ArrayList();
        this.W = new int[2];
        this.a0 = new m0(this);
        this.f4216e0 = new E.b(this, 16);
        Context context2 = getContext();
        int[] iArr = p041h.a.t;
        C0331c c0331cW = C0331c.w(context2, attributeSet, iArr, R.attr.toolbarStyle);
        AbstractC0046z.b(this, context, iArr, attributeSet, (TypedArray) c0331cW.f6060u, R.attr.toolbarStyle);
        TypedArray typedArray = (TypedArray) c0331cW.f6060u;
        this.C = typedArray.getResourceId(28, 0);
        this.f4194D = typedArray.getResourceId(19, 0);
        this.f4204N = typedArray.getInteger(0, 8388627);
        this.f4195E = typedArray.getInteger(2, 48);
        int dimensionPixelOffset = typedArray.getDimensionPixelOffset(22, 0);
        dimensionPixelOffset = typedArray.hasValue(27) ? typedArray.getDimensionPixelOffset(27, dimensionPixelOffset) : dimensionPixelOffset;
        this.f4200J = dimensionPixelOffset;
        this.f4199I = dimensionPixelOffset;
        this.f4198H = dimensionPixelOffset;
        this.f4197G = dimensionPixelOffset;
        int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(25, -1);
        if (dimensionPixelOffset2 >= 0) {
            this.f4197G = dimensionPixelOffset2;
        }
        int dimensionPixelOffset3 = typedArray.getDimensionPixelOffset(24, -1);
        if (dimensionPixelOffset3 >= 0) {
            this.f4198H = dimensionPixelOffset3;
        }
        int dimensionPixelOffset4 = typedArray.getDimensionPixelOffset(26, -1);
        if (dimensionPixelOffset4 >= 0) {
            this.f4199I = dimensionPixelOffset4;
        }
        int dimensionPixelOffset5 = typedArray.getDimensionPixelOffset(23, -1);
        if (dimensionPixelOffset5 >= 0) {
            this.f4200J = dimensionPixelOffset5;
        }
        this.f4196F = typedArray.getDimensionPixelSize(13, -1);
        int dimensionPixelOffset6 = typedArray.getDimensionPixelOffset(9, Integer.MIN_VALUE);
        int dimensionPixelOffset7 = typedArray.getDimensionPixelOffset(5, Integer.MIN_VALUE);
        int dimensionPixelSize = typedArray.getDimensionPixelSize(7, 0);
        int dimensionPixelSize2 = typedArray.getDimensionPixelSize(8, 0);
        d();
        T t = this.f4201K;
        t.f7359h = false;
        if (dimensionPixelSize != Integer.MIN_VALUE) {
            t.f7356e = dimensionPixelSize;
            t.f7352a = dimensionPixelSize;
        }
        if (dimensionPixelSize2 != Integer.MIN_VALUE) {
            t.f7357f = dimensionPixelSize2;
            t.f7353b = dimensionPixelSize2;
        }
        if (dimensionPixelOffset6 != Integer.MIN_VALUE || dimensionPixelOffset7 != Integer.MIN_VALUE) {
            t.a(dimensionPixelOffset6, dimensionPixelOffset7);
        }
        this.f4202L = typedArray.getDimensionPixelOffset(10, Integer.MIN_VALUE);
        this.f4203M = typedArray.getDimensionPixelOffset(6, Integer.MIN_VALUE);
        this.f4220w = c0331cW.p(4);
        this.f4221x = typedArray.getText(3);
        CharSequence text = typedArray.getText(21);
        if (!TextUtils.isEmpty(text)) {
            setTitle(text);
        }
        CharSequence text2 = typedArray.getText(18);
        if (!TextUtils.isEmpty(text2)) {
            setSubtitle(text2);
        }
        this.f4192A = getContext();
        setPopupTheme(typedArray.getResourceId(17, 0));
        Drawable drawableP = c0331cW.p(16);
        if (drawableP != null) {
            setNavigationIcon(drawableP);
        }
        CharSequence text3 = typedArray.getText(15);
        if (!TextUtils.isEmpty(text3)) {
            setNavigationContentDescription(text3);
        }
        Drawable drawableP2 = c0331cW.p(11);
        if (drawableP2 != null) {
            setLogo(drawableP2);
        }
        CharSequence text4 = typedArray.getText(12);
        if (!TextUtils.isEmpty(text4)) {
            setLogoDescription(text4);
        }
        if (typedArray.hasValue(29)) {
            setTitleTextColor(c0331cW.o(29));
        }
        if (typedArray.hasValue(20)) {
            setSubtitleTextColor(c0331cW.o(20));
        }
        if (typedArray.hasValue(14)) {
            getMenuInflater().inflate(typedArray.getResourceId(14, 0), getMenu());
        }
        c0331cW.z();
    }

    public static p0 g() {
        p0 p0Var = new p0(-2, -2);
        p0Var.f7446b = 0;
        p0Var.f7445a = 8388627;
        return p0Var;
    }

    private MenuInflater getMenuInflater() {
        return new d(getContext());
    }

    public static p0 h(ViewGroup.LayoutParams layoutParams) {
        boolean z6 = layoutParams instanceof p0;
        if (z6) {
            p0 p0Var = (p0) layoutParams;
            p0 p0Var2 = new p0(p0Var);
            p0Var2.f7446b = 0;
            p0Var2.f7446b = p0Var.f7446b;
            return p0Var2;
        }
        if (z6) {
            p0 p0Var3 = new p0((p0) layoutParams);
            p0Var3.f7446b = 0;
            return p0Var3;
        }
        if (!(layoutParams instanceof ViewGroup.MarginLayoutParams)) {
            p0 p0Var4 = new p0(layoutParams);
            p0Var4.f7446b = 0;
            return p0Var4;
        }
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
        p0 p0Var5 = new p0(marginLayoutParams);
        p0Var5.f7446b = 0;
        ((ViewGroup.MarginLayoutParams) p0Var5).leftMargin = marginLayoutParams.leftMargin;
        ((ViewGroup.MarginLayoutParams) p0Var5).topMargin = marginLayoutParams.topMargin;
        ((ViewGroup.MarginLayoutParams) p0Var5).rightMargin = marginLayoutParams.rightMargin;
        ((ViewGroup.MarginLayoutParams) p0Var5).bottomMargin = marginLayoutParams.bottomMargin;
        return p0Var5;
    }

    public static int j(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginEnd() + marginLayoutParams.getMarginStart();
    }

    public static int k(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    public final void a(int i6, ArrayList arrayList) {
        Field field = AbstractC0046z.f1508a;
        boolean z6 = getLayoutDirection() == 1;
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i6, getLayoutDirection());
        arrayList.clear();
        if (!z6) {
            for (int i7 = 0; i7 < childCount; i7++) {
                View childAt = getChildAt(i7);
                p0 p0Var = (p0) childAt.getLayoutParams();
                if (p0Var.f7446b == 0 && q(childAt)) {
                    int i8 = p0Var.f7445a;
                    Field field2 = AbstractC0046z.f1508a;
                    int layoutDirection = getLayoutDirection();
                    int absoluteGravity2 = Gravity.getAbsoluteGravity(i8, layoutDirection) & 7;
                    if (absoluteGravity2 != 1 && absoluteGravity2 != 3 && absoluteGravity2 != 5) {
                        absoluteGravity2 = layoutDirection == 1 ? 5 : 3;
                    }
                    if (absoluteGravity2 == absoluteGravity) {
                        arrayList.add(childAt);
                    }
                }
            }
            return;
        }
        for (int i9 = childCount - 1; i9 >= 0; i9--) {
            View childAt2 = getChildAt(i9);
            p0 p0Var2 = (p0) childAt2.getLayoutParams();
            if (p0Var2.f7446b == 0 && q(childAt2)) {
                int i10 = p0Var2.f7445a;
                Field field3 = AbstractC0046z.f1508a;
                int layoutDirection2 = getLayoutDirection();
                int absoluteGravity3 = Gravity.getAbsoluteGravity(i10, layoutDirection2) & 7;
                if (absoluteGravity3 != 1 && absoluteGravity3 != 3 && absoluteGravity3 != 5) {
                    absoluteGravity3 = layoutDirection2 == 1 ? 5 : 3;
                }
                if (absoluteGravity3 == absoluteGravity) {
                    arrayList.add(childAt2);
                }
            }
        }
    }

    public final void b(View view, boolean z6) {
        p0 p0VarH;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            p0VarH = g();
        } else {
            p0VarH = !checkLayoutParams(layoutParams) ? h(layoutParams) : (p0) layoutParams;
        }
        p0VarH.f7446b = 1;
        if (!z6 || this.f4222z == null) {
            addView(view, p0VarH);
        } else {
            view.setLayoutParams(p0VarH);
            this.f4212V.add(view);
        }
    }

    public final void c() {
        if (this.y == null) {
            C0403p c0403p = new C0403p(getContext());
            this.y = c0403p;
            c0403p.setImageDrawable(this.f4220w);
            this.y.setContentDescription(this.f4221x);
            p0 p0VarG = g();
            p0VarG.f7445a = (this.f4195E & 112) | 8388611;
            p0VarG.f7446b = 2;
            this.y.setLayoutParams(p0VarG);
            this.y.setOnClickListener(new n0(this));
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof p0);
    }

    public final void d() {
        if (this.f4201K == null) {
            T t = new T();
            t.f7352a = 0;
            t.f7353b = 0;
            t.f7354c = Integer.MIN_VALUE;
            t.f7355d = Integer.MIN_VALUE;
            t.f7356e = 0;
            t.f7357f = 0;
            t.f7358g = false;
            t.f7359h = false;
            this.f4201K = t;
        }
    }

    public final void e() {
        if (this.r == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext(), null);
            this.r = actionMenuView;
            actionMenuView.setPopupTheme(this.f4193B);
            this.r.setOnMenuItemClickListener(this.a0);
            this.r.getClass();
            p0 p0VarG = g();
            p0VarG.f7445a = (this.f4195E & 112) | 8388613;
            this.r.setLayoutParams(p0VarG);
            b(this.r, false);
        }
        ActionMenuView actionMenuView2 = this.r;
        if (actionMenuView2.f4134G == null) {
            i iVar = (i) actionMenuView2.getMenu();
            if (this.f4214c0 == null) {
                this.f4214c0 = new o0(this);
            }
            this.r.setExpandedActionViewsExclusive(true);
            iVar.b(this.f4214c0, this.f4192A);
        }
    }

    public final void f() {
        if (this.f4218u == null) {
            this.f4218u = new C0403p(getContext());
            p0 p0VarG = g();
            p0VarG.f7445a = (this.f4195E & 112) | 8388611;
            this.f4218u.setLayoutParams(p0VarG);
        }
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return g();
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return h(layoutParams);
    }

    public CharSequence getCollapseContentDescription() {
        C0403p c0403p = this.y;
        if (c0403p != null) {
            return c0403p.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        C0403p c0403p = this.y;
        if (c0403p != null) {
            return c0403p.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        T t = this.f4201K;
        if (t != null) {
            return t.f7358g ? t.f7352a : t.f7353b;
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i6 = this.f4203M;
        return i6 != Integer.MIN_VALUE ? i6 : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        T t = this.f4201K;
        if (t != null) {
            return t.f7352a;
        }
        return 0;
    }

    public int getContentInsetRight() {
        T t = this.f4201K;
        if (t != null) {
            return t.f7353b;
        }
        return 0;
    }

    public int getContentInsetStart() {
        T t = this.f4201K;
        if (t != null) {
            return t.f7358g ? t.f7353b : t.f7352a;
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i6 = this.f4202L;
        return i6 != Integer.MIN_VALUE ? i6 : getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        i iVar;
        ActionMenuView actionMenuView = this.r;
        return (actionMenuView == null || (iVar = actionMenuView.f4134G) == null || !iVar.hasVisibleItems()) ? getContentInsetEnd() : Math.max(getContentInsetEnd(), Math.max(this.f4203M, 0));
    }

    public int getCurrentContentInsetLeft() {
        Field field = AbstractC0046z.f1508a;
        return getLayoutDirection() == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        Field field = AbstractC0046z.f1508a;
        return getLayoutDirection() == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.f4202L, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        C0404q c0404q = this.f4219v;
        if (c0404q != null) {
            return c0404q.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        C0404q c0404q = this.f4219v;
        if (c0404q != null) {
            return c0404q.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        e();
        return this.r.getMenu();
    }

    public CharSequence getNavigationContentDescription() {
        C0403p c0403p = this.f4218u;
        if (c0403p != null) {
            return c0403p.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        C0403p c0403p = this.f4218u;
        if (c0403p != null) {
            return c0403p.getDrawable();
        }
        return null;
    }

    public C0396i getOuterActionMenuPresenter() {
        return null;
    }

    public Drawable getOverflowIcon() {
        e();
        return this.r.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.f4192A;
    }

    public int getPopupTheme() {
        return this.f4193B;
    }

    public CharSequence getSubtitle() {
        return this.f4206P;
    }

    public final TextView getSubtitleTextView() {
        return this.t;
    }

    public CharSequence getTitle() {
        return this.f4205O;
    }

    public int getTitleMarginBottom() {
        return this.f4200J;
    }

    public int getTitleMarginEnd() {
        return this.f4198H;
    }

    public int getTitleMarginStart() {
        return this.f4197G;
    }

    public int getTitleMarginTop() {
        return this.f4199I;
    }

    public final TextView getTitleTextView() {
        return this.f4217s;
    }

    public A getWrapper() {
        Drawable drawable;
        if (this.f4213b0 == null) {
            s0 s0Var = new s0();
            s0Var.f7464l = 0;
            s0Var.f7453a = this;
            s0Var.f7460h = getTitle();
            s0Var.f7461i = getSubtitle();
            s0Var.f7459g = s0Var.f7460h != null;
            s0Var.f7458f = getNavigationIcon();
            C0331c c0331cW = C0331c.w(getContext(), null, p041h.a.f5945a, R.attr.actionBarStyle);
            TypedArray typedArray = (TypedArray) c0331cW.f6060u;
            s0Var.f7465m = c0331cW.p(15);
            CharSequence text = typedArray.getText(27);
            if (!TextUtils.isEmpty(text)) {
                s0Var.f7459g = true;
                s0Var.f7460h = text;
                if ((s0Var.f7454b & 8) != 0) {
                    s0Var.f7453a.setTitle(text);
                }
            }
            CharSequence text2 = typedArray.getText(25);
            if (!TextUtils.isEmpty(text2)) {
                s0Var.f7461i = text2;
                if ((s0Var.f7454b & 8) != 0) {
                    setSubtitle(text2);
                }
            }
            Drawable drawableP = c0331cW.p(20);
            if (drawableP != null) {
                s0Var.f7457e = drawableP;
                s0Var.c();
            }
            Drawable drawableP2 = c0331cW.p(17);
            if (drawableP2 != null) {
                s0Var.f7456d = drawableP2;
                s0Var.c();
            }
            if (s0Var.f7458f == null && (drawable = s0Var.f7465m) != null) {
                s0Var.f7458f = drawable;
                Toolbar toolbar = s0Var.f7453a;
                if ((s0Var.f7454b & 4) != 0) {
                    toolbar.setNavigationIcon(drawable);
                } else {
                    toolbar.setNavigationIcon((Drawable) null);
                }
            }
            s0Var.a(typedArray.getInt(10, 0));
            int resourceId = typedArray.getResourceId(9, 0);
            if (resourceId != 0) {
                View viewInflate = LayoutInflater.from(getContext()).inflate(resourceId, (ViewGroup) this, false);
                View view = s0Var.f7455c;
                if (view != null && (s0Var.f7454b & 16) != 0) {
                    removeView(view);
                }
                s0Var.f7455c = viewInflate;
                if (viewInflate != null && (s0Var.f7454b & 16) != 0) {
                    addView(viewInflate);
                }
                s0Var.a(s0Var.f7454b | 16);
            }
            int layoutDimension = typedArray.getLayoutDimension(13, 0);
            if (layoutDimension > 0) {
                ViewGroup.LayoutParams layoutParams = getLayoutParams();
                layoutParams.height = layoutDimension;
                setLayoutParams(layoutParams);
            }
            int dimensionPixelOffset = typedArray.getDimensionPixelOffset(7, -1);
            int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(3, -1);
            if (dimensionPixelOffset >= 0 || dimensionPixelOffset2 >= 0) {
                int iMax = Math.max(dimensionPixelOffset, 0);
                int iMax2 = Math.max(dimensionPixelOffset2, 0);
                d();
                this.f4201K.a(iMax, iMax2);
            }
            int resourceId2 = typedArray.getResourceId(28, 0);
            if (resourceId2 != 0) {
                Context context = getContext();
                this.C = resourceId2;
                C0407u c0407u = this.f4217s;
                if (c0407u != null) {
                    c0407u.setTextAppearance(context, resourceId2);
                }
            }
            int resourceId3 = typedArray.getResourceId(26, 0);
            if (resourceId3 != 0) {
                Context context2 = getContext();
                this.f4194D = resourceId3;
                C0407u c0407u2 = this.t;
                if (c0407u2 != null) {
                    c0407u2.setTextAppearance(context2, resourceId3);
                }
            }
            int resourceId4 = typedArray.getResourceId(22, 0);
            if (resourceId4 != 0) {
                setPopupTheme(resourceId4);
            }
            c0331cW.z();
            if (R.string.abc_action_bar_up_description != s0Var.f7464l) {
                s0Var.f7464l = R.string.abc_action_bar_up_description;
                if (TextUtils.isEmpty(getNavigationContentDescription())) {
                    int i6 = s0Var.f7464l;
                    s0Var.f7462j = i6 != 0 ? getContext().getString(i6) : null;
                    s0Var.b();
                }
            }
            s0Var.f7462j = getNavigationContentDescription();
            setNavigationOnClickListener(new n0(s0Var));
            this.f4213b0 = s0Var;
        }
        return this.f4213b0;
    }

    public final int i(View view, int i6) {
        p0 p0Var = (p0) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i7 = i6 > 0 ? (measuredHeight - i6) / 2 : 0;
        int i8 = p0Var.f7445a & 112;
        if (i8 != 16 && i8 != 48 && i8 != 80) {
            i8 = this.f4204N & 112;
        }
        if (i8 == 48) {
            return getPaddingTop() - i7;
        }
        if (i8 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) p0Var).bottomMargin) - i7;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int iMax = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i9 = ((ViewGroup.MarginLayoutParams) p0Var).topMargin;
        if (iMax < i9) {
            iMax = i9;
        } else {
            int i10 = (((height - paddingBottom) - measuredHeight) - iMax) - paddingTop;
            int i11 = ((ViewGroup.MarginLayoutParams) p0Var).bottomMargin;
            if (i10 < i11) {
                iMax = Math.max(0, iMax - (i11 - i10));
            }
        }
        return paddingTop + iMax;
    }

    public final boolean l(View view) {
        return view.getParent() == this || this.f4212V.contains(view);
    }

    public final int m(View view, int i6, int i7, int[] iArr) {
        p0 p0Var = (p0) view.getLayoutParams();
        int i8 = ((ViewGroup.MarginLayoutParams) p0Var).leftMargin - iArr[0];
        int iMax = Math.max(0, i8) + i6;
        iArr[0] = Math.max(0, -i8);
        int i9 = i(view, i7);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax, i9, iMax + measuredWidth, view.getMeasuredHeight() + i9);
        return measuredWidth + ((ViewGroup.MarginLayoutParams) p0Var).rightMargin + iMax;
    }

    public final int n(View view, int i6, int i7, int[] iArr) {
        p0 p0Var = (p0) view.getLayoutParams();
        int i8 = ((ViewGroup.MarginLayoutParams) p0Var).rightMargin - iArr[1];
        int iMax = i6 - Math.max(0, i8);
        iArr[1] = Math.max(0, -i8);
        int i9 = i(view, i7);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax - measuredWidth, i9, iMax, view.getMeasuredHeight() + i9);
        return iMax - (measuredWidth + ((ViewGroup.MarginLayoutParams) p0Var).leftMargin);
    }

    public final int o(View view, int i6, int i7, int i8, int i9, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i10 = marginLayoutParams.leftMargin - iArr[0];
        int i11 = marginLayoutParams.rightMargin - iArr[1];
        int iMax = Math.max(0, i11) + Math.max(0, i10);
        iArr[0] = Math.max(0, -i10);
        iArr[1] = Math.max(0, -i11);
        view.measure(ViewGroup.getChildMeasureSpec(i6, getPaddingRight() + getPaddingLeft() + iMax + i7, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i8, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i9, marginLayoutParams.height));
        return view.getMeasuredWidth() + iMax;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f4216e0);
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f4210T = false;
        }
        if (!this.f4210T) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.f4210T = true;
            }
        }
        if (actionMasked != 10 && actionMasked != 3) {
            return true;
        }
        this.f4210T = false;
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:100:0x027d  */
    /* JADX WARN: Code duplicated, block: B:103:0x028f A[LOOP:0: B:102:0x028d->B:103:0x028f, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:106:0x02a7 A[LOOP:1: B:105:0x02a5->B:106:0x02a7, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:109:0x02c7 A[LOOP:2: B:108:0x02c5->B:109:0x02c7, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:113:0x030d A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:114:0x030f  */
    /* JADX WARN: Code duplicated, block: B:115:0x0313  */
    /* JADX WARN: Code duplicated, block: B:118:0x031a A[LOOP:3: B:117:0x0318->B:118:0x031a, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:19:0x0062 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:20:0x0064  */
    /* JADX WARN: Code duplicated, block: B:21:0x006b  */
    /* JADX WARN: Code duplicated, block: B:24:0x0079 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:25:0x007b  */
    /* JADX WARN: Code duplicated, block: B:26:0x0082  */
    /* JADX WARN: Code duplicated, block: B:29:0x00b6 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:30:0x00b8  */
    /* JADX WARN: Code duplicated, block: B:31:0x00bf  */
    /* JADX WARN: Code duplicated, block: B:34:0x00cd A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:35:0x00cf  */
    /* JADX WARN: Code duplicated, block: B:36:0x00d6  */
    /* JADX WARN: Code duplicated, block: B:39:0x00ea  */
    /* JADX WARN: Code duplicated, block: B:40:0x0101  */
    /* JADX WARN: Code duplicated, block: B:42:0x0106  */
    /* JADX WARN: Code duplicated, block: B:43:0x011f  */
    /* JADX WARN: Code duplicated, block: B:46:0x0125 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:47:0x0127  */
    /* JADX WARN: Code duplicated, block: B:48:0x012a  */
    /* JADX WARN: Code duplicated, block: B:50:0x012e  */
    /* JADX WARN: Code duplicated, block: B:51:0x0131  */
    /* JADX WARN: Code duplicated, block: B:54:0x0143  */
    /* JADX WARN: Code duplicated, block: B:56:0x014b A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:63:0x0164  */
    /* JADX WARN: Code duplicated, block: B:65:0x0168  */
    /* JADX WARN: Code duplicated, block: B:67:0x0179  */
    /* JADX WARN: Code duplicated, block: B:68:0x017b  */
    /* JADX WARN: Code duplicated, block: B:70:0x0187  */
    /* JADX WARN: Code duplicated, block: B:72:0x0193  */
    /* JADX WARN: Code duplicated, block: B:73:0x019d  */
    /* JADX WARN: Code duplicated, block: B:75:0x01aa A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:76:0x01ac  */
    /* JADX WARN: Code duplicated, block: B:77:0x01af  */
    /* JADX WARN: Code duplicated, block: B:80:0x01c2  */
    /* JADX WARN: Code duplicated, block: B:81:0x01e6  */
    /* JADX WARN: Code duplicated, block: B:83:0x01e9  */
    /* JADX WARN: Code duplicated, block: B:84:0x020d  */
    /* JADX WARN: Code duplicated, block: B:86:0x0210  */
    /* JADX WARN: Code duplicated, block: B:88:0x0218 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:89:0x021a  */
    /* JADX WARN: Code duplicated, block: B:91:0x021e  */
    /* JADX WARN: Code duplicated, block: B:94:0x0232  */
    /* JADX WARN: Code duplicated, block: B:95:0x0255  */
    /* JADX WARN: Code duplicated, block: B:97:0x0258  */
    /* JADX WARN: Code duplicated, block: B:98:0x027a  */
    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z6, int i6, int i7, int i8, int i9) {
        int iM;
        int iN;
        int iMax;
        int iMin;
        boolean zQ;
        boolean zQ2;
        int measuredHeight;
        C0407u c0407u;
        C0407u c0407u2;
        p0 p0Var;
        p0 p0Var2;
        int i10;
        boolean z7;
        int i11;
        int i12;
        int paddingTop;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        int iMax2;
        int i19;
        int i20;
        int i21;
        int i22;
        ArrayList arrayList;
        int size;
        int iM2;
        int i23;
        int size2;
        int i24;
        int i25;
        int size3;
        int i26;
        int i27;
        int measuredWidth;
        int i28;
        int i29;
        int i30;
        int size4;
        Field field = AbstractC0046z.f1508a;
        boolean z8 = getLayoutDirection() == 1;
        int width = getWidth();
        int height = getHeight();
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int paddingTop2 = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int i31 = width - paddingRight;
        int[] iArr = this.W;
        iArr[1] = 0;
        iArr[0] = 0;
        int minimumHeight = getMinimumHeight();
        int iMin2 = minimumHeight >= 0 ? Math.min(minimumHeight, i9 - i7) : 0;
        if (q(this.f4218u)) {
            if (z8) {
                iN = n(this.f4218u, i31, iMin2, iArr);
                iM = paddingLeft;
            } else {
                iM = m(this.f4218u, paddingLeft, iMin2, iArr);
            }
            if (q(this.y)) {
                if (z8) {
                    iN = n(this.y, iN, iMin2, iArr);
                } else {
                    iM = m(this.y, iM, iMin2, iArr);
                }
            }
            if (q(this.r)) {
                if (z8) {
                    iM = m(this.r, iM, iMin2, iArr);
                } else {
                    iN = n(this.r, iN, iMin2, iArr);
                }
            }
            int currentContentInsetLeft = getCurrentContentInsetLeft();
            int currentContentInsetRight = getCurrentContentInsetRight();
            iArr[0] = Math.max(0, currentContentInsetLeft - iM);
            iArr[1] = Math.max(0, currentContentInsetRight - (i31 - iN));
            iMax = Math.max(iM, currentContentInsetLeft);
            iMin = Math.min(iN, i31 - currentContentInsetRight);
            if (q(this.f4222z)) {
                if (z8) {
                    iMin = n(this.f4222z, iMin, iMin2, iArr);
                } else {
                    iMax = m(this.f4222z, iMax, iMin2, iArr);
                }
            }
            if (q(this.f4219v)) {
                if (z8) {
                    iMin = n(this.f4219v, iMin, iMin2, iArr);
                } else {
                    iMax = m(this.f4219v, iMax, iMin2, iArr);
                }
            }
            zQ = q(this.f4217s);
            zQ2 = q(this.t);
            if (zQ) {
                p0 p0Var3 = (p0) this.f4217s.getLayoutParams();
                measuredHeight = this.f4217s.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) p0Var3).topMargin + ((ViewGroup.MarginLayoutParams) p0Var3).bottomMargin;
            } else {
                measuredHeight = 0;
            }
            if (zQ2) {
                p0 p0Var4 = (p0) this.t.getLayoutParams();
                measuredHeight = this.t.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) p0Var4).topMargin + ((ViewGroup.MarginLayoutParams) p0Var4).bottomMargin + measuredHeight;
            }
            if (zQ || zQ2) {
                if (zQ) {
                    c0407u = this.f4217s;
                } else {
                    c0407u = this.t;
                }
                if (zQ2) {
                    c0407u2 = this.t;
                } else {
                    c0407u2 = this.f4217s;
                }
                p0Var = (p0) c0407u.getLayoutParams();
                p0Var2 = (p0) c0407u2.getLayoutParams();
                i10 = measuredHeight;
                z7 = (!zQ && this.f4217s.getMeasuredWidth() > 0) || (zQ2 && this.t.getMeasuredWidth() > 0);
                i11 = this.f4204N & 112;
                i12 = iMax;
                if (i11 == 48) {
                    paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) p0Var).topMargin + this.f4199I;
                } else if (i11 != 80) {
                    iMax2 = (((height - paddingTop2) - paddingBottom) - i10) / 2;
                    i19 = ((ViewGroup.MarginLayoutParams) p0Var).topMargin + this.f4199I;
                    if (iMax2 < i19) {
                        iMax2 = i19;
                    } else {
                        i20 = (((height - paddingBottom) - i10) - iMax2) - paddingTop2;
                        i21 = ((ViewGroup.MarginLayoutParams) p0Var).bottomMargin;
                        i22 = this.f4200J;
                        if (i20 < i21 + i22) {
                            iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) p0Var2).bottomMargin + i22) - i20));
                        }
                    }
                    paddingTop = paddingTop2 + iMax2;
                } else {
                    paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) p0Var2).bottomMargin) - this.f4200J) - i10;
                }
                if (z8) {
                    if (z7) {
                        i16 = this.f4197G;
                    } else {
                        i16 = 0;
                    }
                    int i32 = i16 - iArr[1];
                    iMin -= Math.max(0, i32);
                    iArr[1] = Math.max(0, -i32);
                    if (zQ) {
                        p0 p0Var5 = (p0) this.f4217s.getLayoutParams();
                        int measuredWidth2 = iMin - this.f4217s.getMeasuredWidth();
                        int measuredHeight2 = this.f4217s.getMeasuredHeight() + paddingTop;
                        this.f4217s.layout(measuredWidth2, paddingTop, iMin, measuredHeight2);
                        i17 = measuredWidth2 - this.f4198H;
                        paddingTop = measuredHeight2 + ((ViewGroup.MarginLayoutParams) p0Var5).bottomMargin;
                    } else {
                        i17 = iMin;
                    }
                    if (zQ2) {
                        int i33 = paddingTop + ((ViewGroup.MarginLayoutParams) ((p0) this.t.getLayoutParams())).topMargin;
                        this.t.layout(iMin - this.t.getMeasuredWidth(), i33, iMin, this.t.getMeasuredHeight() + i33);
                        i18 = iMin - this.f4198H;
                    } else {
                        i18 = iMin;
                    }
                    if (z7) {
                        iMin = Math.min(i17, i18);
                    }
                    iMax = i12;
                } else {
                    if (z7) {
                        i13 = this.f4197G;
                    } else {
                        i13 = 0;
                    }
                    int i34 = i13 - iArr[0];
                    iMax = Math.max(0, i34) + i12;
                    iArr[0] = Math.max(0, -i34);
                    if (zQ) {
                        p0 p0Var6 = (p0) this.f4217s.getLayoutParams();
                        int measuredWidth3 = this.f4217s.getMeasuredWidth() + iMax;
                        int measuredHeight3 = this.f4217s.getMeasuredHeight() + paddingTop;
                        this.f4217s.layout(iMax, paddingTop, measuredWidth3, measuredHeight3);
                        i14 = measuredWidth3 + this.f4198H;
                        paddingTop = measuredHeight3 + ((ViewGroup.MarginLayoutParams) p0Var6).bottomMargin;
                    } else {
                        i14 = iMax;
                    }
                    if (zQ2) {
                        int i35 = paddingTop + ((ViewGroup.MarginLayoutParams) ((p0) this.t.getLayoutParams())).topMargin;
                        int measuredWidth4 = this.t.getMeasuredWidth() + iMax;
                        this.t.layout(iMax, i35, measuredWidth4, this.t.getMeasuredHeight() + i35);
                        i15 = measuredWidth4 + this.f4198H;
                    } else {
                        i15 = iMax;
                    }
                    if (z7) {
                        iMax = Math.max(i14, i15);
                    }
                }
            }
            arrayList = this.f4211U;
            a(3, arrayList);
            size = arrayList.size();
            iM2 = iMax;
            for (i23 = 0; i23 < size; i23++) {
                iM2 = m((View) arrayList.get(i23), iM2, iMin2, iArr);
            }
            a(5, arrayList);
            size2 = arrayList.size();
            for (i24 = 0; i24 < size2; i24++) {
                iMin = n((View) arrayList.get(i24), iMin, iMin2, iArr);
            }
            a(1, arrayList);
            int i36 = iArr[0];
            i25 = iArr[1];
            size3 = arrayList.size();
            i26 = i36;
            i27 = 0;
            measuredWidth = 0;
            while (i27 < size3) {
                View view = (View) arrayList.get(i27);
                p0 p0Var7 = (p0) view.getLayoutParams();
                int i37 = i25;
                int i38 = ((ViewGroup.MarginLayoutParams) p0Var7).leftMargin - i26;
                int i39 = ((ViewGroup.MarginLayoutParams) p0Var7).rightMargin - i37;
                int iMax3 = Math.max(0, i38);
                int iMax4 = Math.max(0, i39);
                int iMax5 = Math.max(0, -i38);
                int iMax6 = Math.max(0, -i39);
                measuredWidth += view.getMeasuredWidth() + iMax3 + iMax4;
                i27++;
                i26 = iMax5;
                i25 = iMax6;
            }
            i29 = ((((width - paddingLeft) - paddingRight) / 2) + paddingLeft) - (measuredWidth / 2);
            i30 = measuredWidth + i29;
            if (i29 >= iM2) {
                if (i30 > iMin) {
                    iM2 = i29 - (i30 - iMin);
                } else {
                    iM2 = i29;
                }
            }
            size4 = arrayList.size();
            for (i28 = 0; i28 < size4; i28++) {
                iM2 = m((View) arrayList.get(i28), iM2, iMin2, iArr);
            }
            arrayList.clear();
        }
        iM = paddingLeft;
        iN = i31;
        if (q(this.y)) {
            if (z8) {
                iN = n(this.y, iN, iMin2, iArr);
            } else {
                iM = m(this.y, iM, iMin2, iArr);
            }
        }
        if (q(this.r)) {
            if (z8) {
                iM = m(this.r, iM, iMin2, iArr);
            } else {
                iN = n(this.r, iN, iMin2, iArr);
            }
        }
        int currentContentInsetLeft2 = getCurrentContentInsetLeft();
        int currentContentInsetRight2 = getCurrentContentInsetRight();
        iArr[0] = Math.max(0, currentContentInsetLeft2 - iM);
        iArr[1] = Math.max(0, currentContentInsetRight2 - (i31 - iN));
        iMax = Math.max(iM, currentContentInsetLeft2);
        iMin = Math.min(iN, i31 - currentContentInsetRight2);
        if (q(this.f4222z)) {
            if (z8) {
                iMin = n(this.f4222z, iMin, iMin2, iArr);
            } else {
                iMax = m(this.f4222z, iMax, iMin2, iArr);
            }
        }
        if (q(this.f4219v)) {
            if (z8) {
                iMin = n(this.f4219v, iMin, iMin2, iArr);
            } else {
                iMax = m(this.f4219v, iMax, iMin2, iArr);
            }
        }
        zQ = q(this.f4217s);
        zQ2 = q(this.t);
        if (zQ) {
            p0 p0Var8 = (p0) this.f4217s.getLayoutParams();
            measuredHeight = this.f4217s.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) p0Var8).topMargin + ((ViewGroup.MarginLayoutParams) p0Var8).bottomMargin;
        } else {
            measuredHeight = 0;
        }
        if (zQ2) {
            p0 p0Var9 = (p0) this.t.getLayoutParams();
            measuredHeight = this.t.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) p0Var9).topMargin + ((ViewGroup.MarginLayoutParams) p0Var9).bottomMargin + measuredHeight;
        }
        if (zQ) {
            if (zQ) {
                c0407u = this.f4217s;
            } else {
                c0407u = this.t;
            }
            if (zQ2) {
                c0407u2 = this.t;
            } else {
                c0407u2 = this.f4217s;
            }
            p0Var = (p0) c0407u.getLayoutParams();
            p0Var2 = (p0) c0407u2.getLayoutParams();
            i10 = measuredHeight;
            if (zQ) {
            }
            i11 = this.f4204N & 112;
            i12 = iMax;
            if (i11 == 48) {
                paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) p0Var).topMargin + this.f4199I;
            } else if (i11 != 80) {
                iMax2 = (((height - paddingTop2) - paddingBottom) - i10) / 2;
                i19 = ((ViewGroup.MarginLayoutParams) p0Var).topMargin + this.f4199I;
                if (iMax2 < i19) {
                    iMax2 = i19;
                } else {
                    i20 = (((height - paddingBottom) - i10) - iMax2) - paddingTop2;
                    i21 = ((ViewGroup.MarginLayoutParams) p0Var).bottomMargin;
                    i22 = this.f4200J;
                    if (i20 < i21 + i22) {
                        iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) p0Var2).bottomMargin + i22) - i20));
                    }
                }
                paddingTop = paddingTop2 + iMax2;
            } else {
                paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) p0Var2).bottomMargin) - this.f4200J) - i10;
            }
            if (z8) {
                if (z7) {
                    i16 = this.f4197G;
                } else {
                    i16 = 0;
                }
                int i310 = i16 - iArr[1];
                iMin -= Math.max(0, i310);
                iArr[1] = Math.max(0, -i310);
                if (zQ) {
                    p0 p0Var10 = (p0) this.f4217s.getLayoutParams();
                    int measuredWidth5 = iMin - this.f4217s.getMeasuredWidth();
                    int measuredHeight4 = this.f4217s.getMeasuredHeight() + paddingTop;
                    this.f4217s.layout(measuredWidth5, paddingTop, iMin, measuredHeight4);
                    i17 = measuredWidth5 - this.f4198H;
                    paddingTop = measuredHeight4 + ((ViewGroup.MarginLayoutParams) p0Var10).bottomMargin;
                } else {
                    i17 = iMin;
                }
                if (zQ2) {
                    int i311 = paddingTop + ((ViewGroup.MarginLayoutParams) ((p0) this.t.getLayoutParams())).topMargin;
                    this.t.layout(iMin - this.t.getMeasuredWidth(), i311, iMin, this.t.getMeasuredHeight() + i311);
                    i18 = iMin - this.f4198H;
                } else {
                    i18 = iMin;
                }
                if (z7) {
                    iMin = Math.min(i17, i18);
                }
                iMax = i12;
            } else {
                if (z7) {
                    i13 = this.f4197G;
                } else {
                    i13 = 0;
                }
                int i312 = i13 - iArr[0];
                iMax = Math.max(0, i312) + i12;
                iArr[0] = Math.max(0, -i312);
                if (zQ) {
                    p0 p0Var11 = (p0) this.f4217s.getLayoutParams();
                    int measuredWidth6 = this.f4217s.getMeasuredWidth() + iMax;
                    int measuredHeight5 = this.f4217s.getMeasuredHeight() + paddingTop;
                    this.f4217s.layout(iMax, paddingTop, measuredWidth6, measuredHeight5);
                    i14 = measuredWidth6 + this.f4198H;
                    paddingTop = measuredHeight5 + ((ViewGroup.MarginLayoutParams) p0Var11).bottomMargin;
                } else {
                    i14 = iMax;
                }
                if (zQ2) {
                    int i313 = paddingTop + ((ViewGroup.MarginLayoutParams) ((p0) this.t.getLayoutParams())).topMargin;
                    int measuredWidth7 = this.t.getMeasuredWidth() + iMax;
                    this.t.layout(iMax, i313, measuredWidth7, this.t.getMeasuredHeight() + i313);
                    i15 = measuredWidth7 + this.f4198H;
                } else {
                    i15 = iMax;
                }
                if (z7) {
                    iMax = Math.max(i14, i15);
                }
            }
        } else {
            if (zQ) {
                c0407u = this.f4217s;
            } else {
                c0407u = this.t;
            }
            if (zQ2) {
                c0407u2 = this.t;
            } else {
                c0407u2 = this.f4217s;
            }
            p0Var = (p0) c0407u.getLayoutParams();
            p0Var2 = (p0) c0407u2.getLayoutParams();
            i10 = measuredHeight;
            if (zQ) {
            }
            i11 = this.f4204N & 112;
            i12 = iMax;
            if (i11 == 48) {
                paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) p0Var).topMargin + this.f4199I;
            } else if (i11 != 80) {
                iMax2 = (((height - paddingTop2) - paddingBottom) - i10) / 2;
                i19 = ((ViewGroup.MarginLayoutParams) p0Var).topMargin + this.f4199I;
                if (iMax2 < i19) {
                    iMax2 = i19;
                } else {
                    i20 = (((height - paddingBottom) - i10) - iMax2) - paddingTop2;
                    i21 = ((ViewGroup.MarginLayoutParams) p0Var).bottomMargin;
                    i22 = this.f4200J;
                    if (i20 < i21 + i22) {
                        iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) p0Var2).bottomMargin + i22) - i20));
                    }
                }
                paddingTop = paddingTop2 + iMax2;
            } else {
                paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) p0Var2).bottomMargin) - this.f4200J) - i10;
            }
            if (z8) {
                if (z7) {
                    i16 = this.f4197G;
                } else {
                    i16 = 0;
                }
                int i314 = i16 - iArr[1];
                iMin -= Math.max(0, i314);
                iArr[1] = Math.max(0, -i314);
                if (zQ) {
                    p0 p0Var12 = (p0) this.f4217s.getLayoutParams();
                    int measuredWidth8 = iMin - this.f4217s.getMeasuredWidth();
                    int measuredHeight6 = this.f4217s.getMeasuredHeight() + paddingTop;
                    this.f4217s.layout(measuredWidth8, paddingTop, iMin, measuredHeight6);
                    i17 = measuredWidth8 - this.f4198H;
                    paddingTop = measuredHeight6 + ((ViewGroup.MarginLayoutParams) p0Var12).bottomMargin;
                } else {
                    i17 = iMin;
                }
                if (zQ2) {
                    int i315 = paddingTop + ((ViewGroup.MarginLayoutParams) ((p0) this.t.getLayoutParams())).topMargin;
                    this.t.layout(iMin - this.t.getMeasuredWidth(), i315, iMin, this.t.getMeasuredHeight() + i315);
                    i18 = iMin - this.f4198H;
                } else {
                    i18 = iMin;
                }
                if (z7) {
                    iMin = Math.min(i17, i18);
                }
                iMax = i12;
            } else {
                if (z7) {
                    i13 = this.f4197G;
                } else {
                    i13 = 0;
                }
                int i316 = i13 - iArr[0];
                iMax = Math.max(0, i316) + i12;
                iArr[0] = Math.max(0, -i316);
                if (zQ) {
                    p0 p0Var13 = (p0) this.f4217s.getLayoutParams();
                    int measuredWidth9 = this.f4217s.getMeasuredWidth() + iMax;
                    int measuredHeight7 = this.f4217s.getMeasuredHeight() + paddingTop;
                    this.f4217s.layout(iMax, paddingTop, measuredWidth9, measuredHeight7);
                    i14 = measuredWidth9 + this.f4198H;
                    paddingTop = measuredHeight7 + ((ViewGroup.MarginLayoutParams) p0Var13).bottomMargin;
                } else {
                    i14 = iMax;
                }
                if (zQ2) {
                    int i317 = paddingTop + ((ViewGroup.MarginLayoutParams) ((p0) this.t.getLayoutParams())).topMargin;
                    int measuredWidth10 = this.t.getMeasuredWidth() + iMax;
                    this.t.layout(iMax, i317, measuredWidth10, this.t.getMeasuredHeight() + i317);
                    i15 = measuredWidth10 + this.f4198H;
                } else {
                    i15 = iMax;
                }
                if (z7) {
                    iMax = Math.max(i14, i15);
                }
            }
        }
        arrayList = this.f4211U;
        a(3, arrayList);
        size = arrayList.size();
        iM2 = iMax;
        while (i23 < size) {
            iM2 = m((View) arrayList.get(i23), iM2, iMin2, iArr);
        }
        a(5, arrayList);
        size2 = arrayList.size();
        while (i24 < size2) {
            iMin = n((View) arrayList.get(i24), iMin, iMin2, iArr);
        }
        a(1, arrayList);
        int i318 = iArr[0];
        i25 = iArr[1];
        size3 = arrayList.size();
        i26 = i318;
        i27 = 0;
        measuredWidth = 0;
        while (i27 < size3) {
            View view2 = (View) arrayList.get(i27);
            p0 p0Var14 = (p0) view2.getLayoutParams();
            int i319 = i25;
            int i320 = ((ViewGroup.MarginLayoutParams) p0Var14).leftMargin - i26;
            int i321 = ((ViewGroup.MarginLayoutParams) p0Var14).rightMargin - i319;
            int iMax7 = Math.max(0, i320);
            int iMax8 = Math.max(0, i321);
            int iMax9 = Math.max(0, -i320);
            int iMax10 = Math.max(0, -i321);
            measuredWidth += view2.getMeasuredWidth() + iMax7 + iMax8;
            i27++;
            i26 = iMax9;
            i25 = iMax10;
        }
        i29 = ((((width - paddingLeft) - paddingRight) / 2) + paddingLeft) - (measuredWidth / 2);
        i30 = measuredWidth + i29;
        if (i29 >= iM2) {
            if (i30 > iMin) {
                iM2 = i29 - (i30 - iMin);
            } else {
                iM2 = i29;
            }
        }
        size4 = arrayList.size();
        while (i28 < size4) {
            iM2 = m((View) arrayList.get(i28), iM2, iMin2, iArr);
        }
        arrayList.clear();
    }

    @Override // android.view.View
    public final void onMeasure(int i6, int i7) {
        int iJ;
        int iMax;
        int iCombineMeasuredStates;
        int iJ2;
        int iK;
        int iCombineMeasuredStates2;
        int iMax2;
        boolean zA = y0.a(this);
        int i8 = !zA ? 1 : 0;
        int i9 = 0;
        if (q(this.f4218u)) {
            p(this.f4218u, i6, 0, i7, this.f4196F);
            iJ = j(this.f4218u) + this.f4218u.getMeasuredWidth();
            iMax = Math.max(0, k(this.f4218u) + this.f4218u.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(0, this.f4218u.getMeasuredState());
        } else {
            iJ = 0;
            iMax = 0;
            iCombineMeasuredStates = 0;
        }
        if (q(this.y)) {
            p(this.y, i6, 0, i7, this.f4196F);
            iJ = j(this.y) + this.y.getMeasuredWidth();
            iMax = Math.max(iMax, k(this.y) + this.y.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.y.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int iMax3 = Math.max(currentContentInsetStart, iJ);
        int iMax4 = Math.max(0, currentContentInsetStart - iJ);
        int[] iArr = this.W;
        iArr[zA ? 1 : 0] = iMax4;
        if (q(this.r)) {
            p(this.r, i6, iMax3, i7, this.f4196F);
            iJ2 = j(this.r) + this.r.getMeasuredWidth();
            iMax = Math.max(iMax, k(this.r) + this.r.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.r.getMeasuredState());
        } else {
            iJ2 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int iMax5 = iMax3 + Math.max(currentContentInsetEnd, iJ2);
        iArr[i8] = Math.max(0, currentContentInsetEnd - iJ2);
        if (q(this.f4222z)) {
            iMax5 += o(this.f4222z, i6, iMax5, i7, 0, iArr);
            iMax = Math.max(iMax, k(this.f4222z) + this.f4222z.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f4222z.getMeasuredState());
        }
        if (q(this.f4219v)) {
            iMax5 += o(this.f4219v, i6, iMax5, i7, 0, iArr);
            iMax = Math.max(iMax, k(this.f4219v) + this.f4219v.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f4219v.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (((p0) childAt.getLayoutParams()).f7446b == 0 && q(childAt)) {
                iMax5 += o(childAt, i6, iMax5, i7, 0, iArr);
                int iMax6 = Math.max(iMax, k(childAt) + childAt.getMeasuredHeight());
                iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, childAt.getMeasuredState());
                iMax = iMax6;
            } else {
                iMax5 = iMax5;
            }
        }
        int i11 = iMax5;
        int i12 = this.f4199I + this.f4200J;
        int i13 = this.f4197G + this.f4198H;
        if (q(this.f4217s)) {
            o(this.f4217s, i6, i11 + i13, i7, i12, iArr);
            int iJ3 = j(this.f4217s) + this.f4217s.getMeasuredWidth();
            iK = k(this.f4217s) + this.f4217s.getMeasuredHeight();
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.f4217s.getMeasuredState());
            iMax2 = iJ3;
        } else {
            iK = 0;
            iCombineMeasuredStates2 = iCombineMeasuredStates;
            iMax2 = 0;
        }
        if (q(this.t)) {
            iMax2 = Math.max(iMax2, o(this.t, i6, i11 + i13, i7, i12 + iK, iArr));
            iK += k(this.t) + this.t.getMeasuredHeight();
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates2, this.t.getMeasuredState());
        }
        int iMax7 = Math.max(iMax, iK);
        int paddingRight = getPaddingRight() + getPaddingLeft() + i11 + iMax2;
        int paddingBottom = getPaddingBottom() + getPaddingTop() + iMax7;
        int iResolveSizeAndState = View.resolveSizeAndState(Math.max(paddingRight, getSuggestedMinimumWidth()), i6, (-16777216) & iCombineMeasuredStates2);
        int iResolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i7, iCombineMeasuredStates2 << 16);
        if (!this.f4215d0) {
            i9 = iResolveSizeAndState2;
            break;
        }
        int childCount2 = getChildCount();
        for (int i14 = 0; i14 < childCount2; i14++) {
            View childAt2 = getChildAt(i14);
            if (q(childAt2) && childAt2.getMeasuredWidth() > 0 && childAt2.getMeasuredHeight() > 0) {
                i9 = iResolveSizeAndState2;
                break;
            }
        }
        setMeasuredDimension(iResolveSizeAndState, i9);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem menuItemFindItem;
        if (!(parcelable instanceof r0)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        r0 r0Var = (r0) parcelable;
        super.onRestoreInstanceState(r0Var.r);
        ActionMenuView actionMenuView = this.r;
        i iVar = actionMenuView != null ? actionMenuView.f4134G : null;
        int i6 = r0Var.t;
        if (i6 != 0 && this.f4214c0 != null && iVar != null && (menuItemFindItem = iVar.findItem(i6)) != null) {
            menuItemFindItem.expandActionView();
        }
        if (r0Var.f7448u) {
            E.b bVar = this.f4216e0;
            removeCallbacks(bVar);
            post(bVar);
        }
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i6) {
        super.onRtlPropertiesChanged(i6);
        d();
        T t = this.f4201K;
        boolean z6 = i6 == 1;
        if (z6 == t.f7358g) {
            return;
        }
        t.f7358g = z6;
        if (!t.f7359h) {
            t.f7352a = t.f7356e;
            t.f7353b = t.f7357f;
            return;
        }
        if (z6) {
            int i7 = t.f7355d;
            if (i7 == Integer.MIN_VALUE) {
                i7 = t.f7356e;
            }
            t.f7352a = i7;
            int i8 = t.f7354c;
            if (i8 == Integer.MIN_VALUE) {
                i8 = t.f7357f;
            }
            t.f7353b = i8;
            return;
        }
        int i9 = t.f7354c;
        if (i9 == Integer.MIN_VALUE) {
            i9 = t.f7356e;
        }
        t.f7352a = i9;
        int i10 = t.f7355d;
        if (i10 == Integer.MIN_VALUE) {
            i10 = t.f7357f;
        }
        t.f7353b = i10;
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        C0396i c0396i;
        C0393f c0393f;
        j jVar;
        r0 r0Var = new r0(super.onSaveInstanceState());
        o0 o0Var = this.f4214c0;
        if (o0Var != null && (jVar = o0Var.f7443s) != null) {
            r0Var.t = jVar.f7186a;
        }
        ActionMenuView actionMenuView = this.r;
        r0Var.f7448u = (actionMenuView == null || (c0396i = actionMenuView.f4137J) == null || (c0393f = c0396i.f7391I) == null || !c0393f.b()) ? false : true;
        return r0Var;
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f4209S = false;
        }
        if (!this.f4209S) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.f4209S = true;
            }
        }
        if (actionMasked != 1 && actionMasked != 3) {
            return true;
        }
        this.f4209S = false;
        return true;
    }

    public final void p(View view, int i6, int i7, int i8, int i9) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i6, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i7, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i8, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i9 >= 0) {
            if (mode != 0) {
                i9 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i9);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i9, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public final boolean q(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    public void setCollapseContentDescription(int i6) {
        setCollapseContentDescription(i6 != 0 ? getContext().getText(i6) : null);
    }

    public void setCollapseIcon(int i6) {
        setCollapseIcon(p048i.a.a(getContext(), i6));
    }

    public void setCollapsible(boolean z6) {
        this.f4215d0 = z6;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i6) {
        if (i6 < 0) {
            i6 = Integer.MIN_VALUE;
        }
        if (i6 != this.f4203M) {
            this.f4203M = i6;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i6) {
        if (i6 < 0) {
            i6 = Integer.MIN_VALUE;
        }
        if (i6 != this.f4202L) {
            this.f4202L = i6;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i6) {
        setLogo(p048i.a.a(getContext(), i6));
    }

    public void setLogoDescription(int i6) {
        setLogoDescription(getContext().getText(i6));
    }

    public void setNavigationContentDescription(int i6) {
        setNavigationContentDescription(i6 != 0 ? getContext().getText(i6) : null);
    }

    public void setNavigationIcon(int i6) {
        setNavigationIcon(p048i.a.a(getContext(), i6));
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        f();
        this.f4218u.setOnClickListener(onClickListener);
    }

    public void setOverflowIcon(Drawable drawable) {
        e();
        this.r.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i6) {
        if (this.f4193B != i6) {
            this.f4193B = i6;
            if (i6 == 0) {
                this.f4192A = getContext();
            } else {
                this.f4192A = new ContextThemeWrapper(getContext(), i6);
            }
        }
    }

    public void setSubtitle(int i6) {
        setSubtitle(getContext().getText(i6));
    }

    public void setSubtitleTextColor(int i6) {
        setSubtitleTextColor(ColorStateList.valueOf(i6));
    }

    public void setTitle(int i6) {
        setTitle(getContext().getText(i6));
    }

    public void setTitleMarginBottom(int i6) {
        this.f4200J = i6;
        requestLayout();
    }

    public void setTitleMarginEnd(int i6) {
        this.f4198H = i6;
        requestLayout();
    }

    public void setTitleMarginStart(int i6) {
        this.f4197G = i6;
        requestLayout();
    }

    public void setTitleMarginTop(int i6) {
        this.f4199I = i6;
        requestLayout();
    }

    public void setTitleTextColor(int i6) {
        setTitleTextColor(ColorStateList.valueOf(i6));
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        p0 p0Var = new p0(context, attributeSet);
        p0Var.f7445a = 0;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p041h.a.f5946b);
        p0Var.f7445a = typedArrayObtainStyledAttributes.getInt(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        p0Var.f7446b = 0;
        return p0Var;
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            c();
        }
        C0403p c0403p = this.y;
        if (c0403p != null) {
            c0403p.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            c();
            this.y.setImageDrawable(drawable);
        } else {
            C0403p c0403p = this.y;
            if (c0403p != null) {
                c0403p.setImageDrawable(this.f4220w);
            }
        }
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            if (this.f4219v == null) {
                this.f4219v = new C0404q(getContext(), 0);
            }
            if (!l(this.f4219v)) {
                b(this.f4219v, true);
            }
        } else {
            C0404q c0404q = this.f4219v;
            if (c0404q != null && l(c0404q)) {
                removeView(this.f4219v);
                this.f4212V.remove(this.f4219v);
            }
        }
        C0404q c0404q2 = this.f4219v;
        if (c0404q2 != null) {
            c0404q2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && this.f4219v == null) {
            this.f4219v = new C0404q(getContext(), 0);
        }
        C0404q c0404q = this.f4219v;
        if (c0404q != null) {
            c0404q.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            f();
        }
        C0403p c0403p = this.f4218u;
        if (c0403p != null) {
            c0403p.setContentDescription(charSequence);
        }
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            f();
            if (!l(this.f4218u)) {
                b(this.f4218u, true);
            }
        } else {
            C0403p c0403p = this.f4218u;
            if (c0403p != null && l(c0403p)) {
                removeView(this.f4218u);
                this.f4212V.remove(this.f4218u);
            }
        }
        C0403p c0403p2 = this.f4218u;
        if (c0403p2 != null) {
            c0403p2.setImageDrawable(drawable);
        }
    }

    public void setSubtitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            C0407u c0407u = this.t;
            if (c0407u != null && l(c0407u)) {
                removeView(this.t);
                this.f4212V.remove(this.t);
            }
        } else {
            if (this.t == null) {
                Context context = getContext();
                C0407u c0407u2 = new C0407u(context, null);
                this.t = c0407u2;
                c0407u2.setSingleLine();
                this.t.setEllipsize(TextUtils.TruncateAt.END);
                int i6 = this.f4194D;
                if (i6 != 0) {
                    this.t.setTextAppearance(context, i6);
                }
                ColorStateList colorStateList = this.f4208R;
                if (colorStateList != null) {
                    this.t.setTextColor(colorStateList);
                }
            }
            if (!l(this.t)) {
                b(this.t, true);
            }
        }
        C0407u c0407u3 = this.t;
        if (c0407u3 != null) {
            c0407u3.setText(charSequence);
        }
        this.f4206P = charSequence;
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.f4208R = colorStateList;
        C0407u c0407u = this.t;
        if (c0407u != null) {
            c0407u.setTextColor(colorStateList);
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            C0407u c0407u = this.f4217s;
            if (c0407u != null && l(c0407u)) {
                removeView(this.f4217s);
                this.f4212V.remove(this.f4217s);
            }
        } else {
            if (this.f4217s == null) {
                Context context = getContext();
                C0407u c0407u2 = new C0407u(context, null);
                this.f4217s = c0407u2;
                c0407u2.setSingleLine();
                this.f4217s.setEllipsize(TextUtils.TruncateAt.END);
                int i6 = this.C;
                if (i6 != 0) {
                    this.f4217s.setTextAppearance(context, i6);
                }
                ColorStateList colorStateList = this.f4207Q;
                if (colorStateList != null) {
                    this.f4217s.setTextColor(colorStateList);
                }
            }
            if (!l(this.f4217s)) {
                b(this.f4217s, true);
            }
        }
        C0407u c0407u3 = this.f4217s;
        if (c0407u3 != null) {
            c0407u3.setText(charSequence);
        }
        this.f4205O = charSequence;
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.f4207Q = colorStateList;
        C0407u c0407u = this.f4217s;
        if (c0407u != null) {
            c0407u.setTextColor(colorStateList);
        }
    }

    public void setOnMenuItemClickListener(q0 q0Var) {
    }
}
