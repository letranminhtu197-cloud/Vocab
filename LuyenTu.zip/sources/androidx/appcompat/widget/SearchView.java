package androidx.appcompat.widget;

import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import com.luyentu.mobile.R;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import org.apache.tika.utils.StringUtils;
import p045h3.C0331c;
import p068l.AbstractC0400m;
import p068l.H;
import p068l.I;
import p068l.V;
import p068l.W;
import p068l.X;
import p068l.Y;
import p068l.Z;
import p068l.a0;
import p068l.b0;
import p068l.c0;
import p068l.d0;
import p068l.e0;
import p068l.f0;
import p068l.g0;
import p068l.i0;

/* JADX INFO: loaded from: classes.dex */
public class SearchView extends H implements p055j.a {

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public static final e0 f4149x0;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public final SearchAutoComplete f4150G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public final View f4151H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public final View f4152I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public final View f4153J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public final ImageView f4154K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public final ImageView f4155L;

    /* JADX INFO: renamed from: M, reason: collision with root package name */
    public final ImageView f4156M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public final ImageView f4157N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public final View f4158O;

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public g0 f4159P;

    /* JADX INFO: renamed from: Q, reason: collision with root package name */
    public final Rect f4160Q;

    /* JADX INFO: renamed from: R, reason: collision with root package name */
    public final Rect f4161R;

    /* JADX INFO: renamed from: S, reason: collision with root package name */
    public final int[] f4162S;

    /* JADX INFO: renamed from: T, reason: collision with root package name */
    public final int[] f4163T;

    /* JADX INFO: renamed from: U, reason: collision with root package name */
    public final ImageView f4164U;

    /* JADX INFO: renamed from: V, reason: collision with root package name */
    public final Drawable f4165V;
    public final int W;
    public final int a0;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public final Intent f4166b0;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public final Intent f4167c0;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public final CharSequence f4168d0;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public View.OnFocusChangeListener f4169e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public View.OnClickListener f4170f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public boolean f4171g0;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    public boolean f4172h0;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    public X.b f4173i0;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    public boolean f4174j0;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    public CharSequence f4175k0;

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    public boolean f4176l0;

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    public boolean f4177m0;

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    public int f4178n0;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    public boolean f4179o0;

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    public CharSequence f4180p0;

    /* JADX INFO: renamed from: q0, reason: collision with root package name */
    public boolean f4181q0;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public int f4182r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public SearchableInfo f4183s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public Bundle f4184t0;

    /* JADX INFO: renamed from: u0, reason: collision with root package name */
    public final W f4185u0;

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    public final W f4186v0;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public final WeakHashMap f4187w0;

    public static class SearchAutoComplete extends AbstractC0400m {

        /* JADX INFO: renamed from: u, reason: collision with root package name */
        public int f4188u;

        /* JADX INFO: renamed from: v, reason: collision with root package name */
        public SearchView f4189v;

        /* JADX INFO: renamed from: w, reason: collision with root package name */
        public boolean f4190w;

        /* JADX INFO: renamed from: x, reason: collision with root package name */
        public final c f4191x;

        public SearchAutoComplete(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f4191x = new c(this);
            this.f4188u = getThreshold();
        }

        private int getSearchViewTextMinWidthDp() {
            Configuration configuration = getResources().getConfiguration();
            int i6 = configuration.screenWidthDp;
            int i7 = configuration.screenHeightDp;
            if (i6 >= 960 && i7 >= 720 && configuration.orientation == 2) {
                return 256;
            }
            if (i6 < 600) {
                return (i6 < 640 || i7 < 480) ? 160 : 192;
            }
            return 192;
        }

        public final void a() {
            if (Build.VERSION.SDK_INT >= 29) {
                setInputMethodMode(1);
                if (enoughToFilter()) {
                    showDropDown();
                    return;
                }
                return;
            }
            e0 e0Var = SearchView.f4149x0;
            e0Var.getClass();
            e0.a();
            Method method = e0Var.f7369c;
            if (method != null) {
                try {
                    method.invoke(this, Boolean.TRUE);
                } catch (Exception unused) {
                }
            }
        }

        @Override // android.widget.AutoCompleteTextView
        public final boolean enoughToFilter() {
            return this.f4188u <= 0 || super.enoughToFilter();
        }

        @Override // p068l.AbstractC0400m, android.widget.TextView, android.view.View
        public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
            InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
            if (this.f4190w) {
                c cVar = this.f4191x;
                removeCallbacks(cVar);
                post(cVar);
            }
            return inputConnectionOnCreateInputConnection;
        }

        @Override // android.view.View
        public final void onFinishInflate() {
            super.onFinishInflate();
            setMinWidth((int) TypedValue.applyDimension(1, getSearchViewTextMinWidthDp(), getResources().getDisplayMetrics()));
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public final void onFocusChanged(boolean z6, int i6, Rect rect) {
            super.onFocusChanged(z6, i6, rect);
            SearchView searchView = this.f4189v;
            searchView.u(searchView.f4172h0);
            searchView.post(searchView.f4185u0);
            if (searchView.f4150G.hasFocus()) {
                searchView.j();
            }
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public final boolean onKeyPreIme(int i6, KeyEvent keyEvent) {
            if (i6 == 4) {
                if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                    KeyEvent.DispatcherState keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState != null) {
                        keyDispatcherState.startTracking(keyEvent, this);
                    }
                    return true;
                }
                if (keyEvent.getAction() == 1) {
                    KeyEvent.DispatcherState keyDispatcherState2 = getKeyDispatcherState();
                    if (keyDispatcherState2 != null) {
                        keyDispatcherState2.handleUpEvent(keyEvent);
                    }
                    if (keyEvent.isTracking() && !keyEvent.isCanceled()) {
                        this.f4189v.clearFocus();
                        setImeVisibility(false);
                        return true;
                    }
                }
            }
            return super.onKeyPreIme(i6, keyEvent);
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public final void onWindowFocusChanged(boolean z6) {
            super.onWindowFocusChanged(z6);
            if (z6 && this.f4189v.hasFocus() && getVisibility() == 0) {
                this.f4190w = true;
                Context context = getContext();
                e0 e0Var = SearchView.f4149x0;
                if (context.getResources().getConfiguration().orientation == 2) {
                    a();
                }
            }
        }

        @Override // android.widget.AutoCompleteTextView
        public final void performCompletion() {
        }

        @Override // android.widget.AutoCompleteTextView
        public final void replaceText(CharSequence charSequence) {
        }

        public void setImeVisibility(boolean z6) {
            InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
            c cVar = this.f4191x;
            if (!z6) {
                this.f4190w = false;
                removeCallbacks(cVar);
                inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
            } else {
                if (!inputMethodManager.isActive(this)) {
                    this.f4190w = true;
                    return;
                }
                this.f4190w = false;
                removeCallbacks(cVar);
                inputMethodManager.showSoftInput(this, 0);
            }
        }

        public void setSearchView(SearchView searchView) {
            this.f4189v = searchView;
        }

        @Override // android.widget.AutoCompleteTextView
        public void setThreshold(int i6) {
            super.setThreshold(i6);
            this.f4188u = i6;
        }
    }

    static {
        e0 e0Var = null;
        if (Build.VERSION.SDK_INT < 29) {
            e0 e0Var2 = new e0();
            e0Var2.f7367a = null;
            e0Var2.f7368b = null;
            e0Var2.f7369c = null;
            e0.a();
            try {
                Method declaredMethod = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", null);
                e0Var2.f7367a = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            try {
                Method declaredMethod2 = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", null);
                e0Var2.f7368b = declaredMethod2;
                declaredMethod2.setAccessible(true);
            } catch (NoSuchMethodException unused2) {
            }
            try {
                Method method = AutoCompleteTextView.class.getMethod("ensureImeVisible", Boolean.TYPE);
                e0Var2.f7369c = method;
                method.setAccessible(true);
            } catch (NoSuchMethodException unused3) {
            }
            e0Var = e0Var2;
        }
        f4149x0 = e0Var;
    }

    public SearchView(Context context) {
        this(context, null);
    }

    private int getPreferredHeight() {
        return getContext().getResources().getDimensionPixelSize(R.dimen.abc_search_view_preferred_height);
    }

    private int getPreferredWidth() {
        return getContext().getResources().getDimensionPixelSize(R.dimen.abc_search_view_preferred_width);
    }

    private void setQuery(CharSequence charSequence) {
        SearchAutoComplete searchAutoComplete = this.f4150G;
        searchAutoComplete.setText(charSequence);
        searchAutoComplete.setSelection(TextUtils.isEmpty(charSequence) ? 0 : charSequence.length());
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void clearFocus() {
        this.f4177m0 = true;
        super.clearFocus();
        SearchAutoComplete searchAutoComplete = this.f4150G;
        searchAutoComplete.clearFocus();
        searchAutoComplete.setImeVisibility(false);
        this.f4177m0 = false;
    }

    public int getImeOptions() {
        return this.f4150G.getImeOptions();
    }

    public int getInputType() {
        return this.f4150G.getInputType();
    }

    public int getMaxWidth() {
        return this.f4178n0;
    }

    public CharSequence getQuery() {
        return this.f4150G.getText();
    }

    public CharSequence getQueryHint() {
        CharSequence charSequence = this.f4175k0;
        if (charSequence != null) {
            return charSequence;
        }
        SearchableInfo searchableInfo = this.f4183s0;
        return (searchableInfo == null || searchableInfo.getHintId() == 0) ? this.f4168d0 : getContext().getText(this.f4183s0.getHintId());
    }

    public int getSuggestionCommitIconResId() {
        return this.a0;
    }

    public int getSuggestionRowLayout() {
        return this.W;
    }

    public X.b getSuggestionsAdapter() {
        return this.f4173i0;
    }

    public final Intent h(String str, Uri uri, String str2, String str3) {
        Intent intent = new Intent(str);
        intent.addFlags(268435456);
        if (uri != null) {
            intent.setData(uri);
        }
        intent.putExtra("user_query", this.f4180p0);
        if (str3 != null) {
            intent.putExtra("query", str3);
        }
        if (str2 != null) {
            intent.putExtra("intent_extra_data_key", str2);
        }
        Bundle bundle = this.f4184t0;
        if (bundle != null) {
            intent.putExtra("app_data", bundle);
        }
        intent.setComponent(this.f4183s0.getSearchActivity());
        return intent;
    }

    public final Intent i(Intent intent, SearchableInfo searchableInfo) {
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        Intent intent2 = new Intent("android.intent.action.SEARCH");
        intent2.setComponent(searchActivity);
        PendingIntent activity = PendingIntent.getActivity(getContext(), 0, intent2, 1073741824);
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.f4184t0;
        if (bundle2 != null) {
            bundle.putParcelable("app_data", bundle2);
        }
        Intent intent3 = new Intent(intent);
        Resources resources = getResources();
        String string = searchableInfo.getVoiceLanguageModeId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageModeId()) : "free_form";
        String string2 = searchableInfo.getVoicePromptTextId() != 0 ? resources.getString(searchableInfo.getVoicePromptTextId()) : null;
        String string3 = searchableInfo.getVoiceLanguageId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageId()) : null;
        int voiceMaxResults = searchableInfo.getVoiceMaxResults() != 0 ? searchableInfo.getVoiceMaxResults() : 1;
        intent3.putExtra("android.speech.extra.LANGUAGE_MODEL", string);
        intent3.putExtra("android.speech.extra.PROMPT", string2);
        intent3.putExtra("android.speech.extra.LANGUAGE", string3);
        intent3.putExtra("android.speech.extra.MAX_RESULTS", voiceMaxResults);
        intent3.putExtra("calling_package", searchActivity != null ? searchActivity.flattenToShortString() : null);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", activity);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle);
        return intent3;
    }

    public final void j() {
        int i6 = Build.VERSION.SDK_INT;
        SearchAutoComplete searchAutoComplete = this.f4150G;
        if (i6 >= 29) {
            searchAutoComplete.refreshAutoCompleteResults();
            return;
        }
        e0 e0Var = f4149x0;
        e0Var.getClass();
        e0.a();
        Method method = e0Var.f7367a;
        if (method != null) {
            try {
                method.invoke(searchAutoComplete, null);
            } catch (Exception unused) {
            }
        }
        e0.a();
        Method method2 = e0Var.f7368b;
        if (method2 != null) {
            try {
                method2.invoke(searchAutoComplete, null);
            } catch (Exception unused2) {
            }
        }
    }

    public final void k() {
        SearchAutoComplete searchAutoComplete = this.f4150G;
        if (!TextUtils.isEmpty(searchAutoComplete.getText())) {
            searchAutoComplete.setText(StringUtils.EMPTY);
            searchAutoComplete.requestFocus();
            searchAutoComplete.setImeVisibility(true);
        } else if (this.f4171g0) {
            clearFocus();
            u(true);
        }
    }

    public final void l(int i6) {
        int position;
        String strH;
        Cursor cursor = this.f4173i0.t;
        if (cursor != null && cursor.moveToPosition(i6)) {
            Intent intentH = null;
            try {
                int i7 = i0.f7402P;
                String strH2 = i0.h(cursor, cursor.getColumnIndex("suggest_intent_action"));
                if (strH2 == null) {
                    strH2 = this.f4183s0.getSuggestIntentAction();
                }
                if (strH2 == null) {
                    strH2 = "android.intent.action.SEARCH";
                }
                String strH3 = i0.h(cursor, cursor.getColumnIndex("suggest_intent_data"));
                if (strH3 == null) {
                    strH3 = this.f4183s0.getSuggestIntentData();
                }
                if (strH3 != null && (strH = i0.h(cursor, cursor.getColumnIndex("suggest_intent_data_id"))) != null) {
                    strH3 = strH3 + "/" + Uri.encode(strH);
                }
                intentH = h(strH2, strH3 == null ? null : Uri.parse(strH3), i0.h(cursor, cursor.getColumnIndex("suggest_intent_extra_data")), i0.h(cursor, cursor.getColumnIndex("suggest_intent_query")));
            } catch (RuntimeException e6) {
                try {
                    position = cursor.getPosition();
                } catch (RuntimeException unused) {
                    position = -1;
                }
                Log.w("SearchView", "Search suggestions cursor at row " + position + " returned exception.", e6);
            }
            if (intentH != null) {
                try {
                    getContext().startActivity(intentH);
                } catch (RuntimeException e7) {
                    Log.e("SearchView", "Failed launch activity: " + intentH, e7);
                }
            }
        }
        SearchAutoComplete searchAutoComplete = this.f4150G;
        searchAutoComplete.setImeVisibility(false);
        searchAutoComplete.dismissDropDown();
    }

    public final void m(int i6) {
        Editable text = this.f4150G.getText();
        Cursor cursor = this.f4173i0.t;
        if (cursor == null) {
            return;
        }
        if (!cursor.moveToPosition(i6)) {
            setQuery(text);
            return;
        }
        String strC = this.f4173i0.c(cursor);
        if (strC != null) {
            setQuery(strC);
        } else {
            setQuery(text);
        }
    }

    public final void n(CharSequence charSequence) {
        setQuery(charSequence);
    }

    public final void o() {
        SearchAutoComplete searchAutoComplete = this.f4150G;
        Editable text = searchAutoComplete.getText();
        if (text == null || TextUtils.getTrimmedLength(text) <= 0) {
            return;
        }
        if (this.f4183s0 != null) {
            getContext().startActivity(h("android.intent.action.SEARCH", null, null, text.toString()));
        }
        searchAutoComplete.setImeVisibility(false);
        searchAutoComplete.dismissDropDown();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        removeCallbacks(this.f4185u0);
        post(this.f4186v0);
        super.onDetachedFromWindow();
    }

    @Override // p068l.H, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z6, int i6, int i7, int i8, int i9) {
        super.onLayout(z6, i6, i7, i8, i9);
        if (z6) {
            SearchAutoComplete searchAutoComplete = this.f4150G;
            int[] iArr = this.f4162S;
            searchAutoComplete.getLocationInWindow(iArr);
            int[] iArr2 = this.f4163T;
            getLocationInWindow(iArr2);
            int i10 = iArr[1] - iArr2[1];
            int i11 = iArr[0] - iArr2[0];
            int width = searchAutoComplete.getWidth() + i11;
            int height = searchAutoComplete.getHeight() + i10;
            Rect rect = this.f4160Q;
            rect.set(i11, i10, width, height);
            int i12 = rect.left;
            int i13 = rect.right;
            int i14 = i9 - i7;
            Rect rect2 = this.f4161R;
            rect2.set(i12, 0, i13, i14);
            g0 g0Var = this.f4159P;
            if (g0Var == null) {
                g0 g0Var2 = new g0(rect2, rect, searchAutoComplete);
                this.f4159P = g0Var2;
                setTouchDelegate(g0Var2);
            } else {
                g0Var.f7374b.set(rect2);
                Rect rect3 = g0Var.f7376d;
                rect3.set(rect2);
                int i15 = -g0Var.f7377e;
                rect3.inset(i15, i15);
                g0Var.f7375c.set(rect);
            }
        }
    }

    @Override // p068l.H, android.view.View
    public final void onMeasure(int i6, int i7) {
        int i8;
        if (this.f4172h0) {
            super.onMeasure(i6, i7);
            return;
        }
        int mode = View.MeasureSpec.getMode(i6);
        int size = View.MeasureSpec.getSize(i6);
        if (mode == Integer.MIN_VALUE) {
            int i9 = this.f4178n0;
            size = i9 > 0 ? Math.min(i9, size) : Math.min(getPreferredWidth(), size);
        } else if (mode == 0) {
            size = this.f4178n0;
            if (size <= 0) {
                size = getPreferredWidth();
            }
        } else if (mode == 1073741824 && (i8 = this.f4178n0) > 0) {
            size = Math.min(i8, size);
        }
        int mode2 = View.MeasureSpec.getMode(i7);
        int size2 = View.MeasureSpec.getSize(i7);
        if (mode2 == Integer.MIN_VALUE) {
            size2 = Math.min(getPreferredHeight(), size2);
        } else if (mode2 == 0) {
            size2 = getPreferredHeight();
        }
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(size, 1073741824), View.MeasureSpec.makeMeasureSpec(size2, 1073741824));
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof f0)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        f0 f0Var = (f0) parcelable;
        super.onRestoreInstanceState(f0Var.r);
        u(f0Var.t);
        requestLayout();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        f0 f0Var = new f0(super.onSaveInstanceState());
        f0Var.t = this.f4172h0;
        return f0Var;
    }

    @Override // android.view.View
    public final void onWindowFocusChanged(boolean z6) {
        super.onWindowFocusChanged(z6);
        post(this.f4185u0);
    }

    public final void p() {
        boolean zIsEmpty = TextUtils.isEmpty(this.f4150G.getText());
        int i6 = (!zIsEmpty || (this.f4171g0 && !this.f4181q0)) ? 0 : 8;
        ImageView imageView = this.f4156M;
        imageView.setVisibility(i6);
        Drawable drawable = imageView.getDrawable();
        if (drawable != null) {
            drawable.setState(!zIsEmpty ? ViewGroup.ENABLED_STATE_SET : ViewGroup.EMPTY_STATE_SET);
        }
    }

    public final void q() {
        int[] iArr = this.f4150G.hasFocus() ? ViewGroup.FOCUSED_STATE_SET : ViewGroup.EMPTY_STATE_SET;
        Drawable background = this.f4152I.getBackground();
        if (background != null) {
            background.setState(iArr);
        }
        Drawable background2 = this.f4153J.getBackground();
        if (background2 != null) {
            background2.setState(iArr);
        }
        invalidate();
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final void r() {
        Drawable drawable;
        CharSequence queryHint = getQueryHint();
        CharSequence charSequence = queryHint;
        if (queryHint == null) {
            charSequence = StringUtils.EMPTY;
        }
        boolean z6 = this.f4171g0;
        SearchAutoComplete searchAutoComplete = this.f4150G;
        CharSequence charSequence2 = charSequence;
        if (z6 && (drawable = this.f4165V) != null) {
            charSequence2 = charSequence;
            int textSize = (int) (((double) searchAutoComplete.getTextSize()) * 1.25d);
            drawable.setBounds(0, 0, textSize, textSize);
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
            spannableStringBuilder.setSpan(new ImageSpan(drawable), 1, 2, 33);
            spannableStringBuilder.append(charSequence);
            charSequence2 = spannableStringBuilder;
        }
        charSequence2 = charSequence;
        searchAutoComplete.setHint(charSequence2);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean requestFocus(int i6, Rect rect) {
        if (this.f4177m0 || !isFocusable()) {
            return false;
        }
        if (this.f4172h0) {
            return super.requestFocus(i6, rect);
        }
        boolean zRequestFocus = this.f4150G.requestFocus(i6, rect);
        if (zRequestFocus) {
            u(false);
        }
        return zRequestFocus;
    }

    public final void s() {
        this.f4153J.setVisibility(((this.f4174j0 || this.f4179o0) && !this.f4172h0 && (this.f4155L.getVisibility() == 0 || this.f4157N.getVisibility() == 0)) ? 0 : 8);
    }

    public void setAppSearchData(Bundle bundle) {
        this.f4184t0 = bundle;
    }

    public void setIconified(boolean z6) {
        if (z6) {
            k();
            return;
        }
        u(false);
        SearchAutoComplete searchAutoComplete = this.f4150G;
        searchAutoComplete.requestFocus();
        searchAutoComplete.setImeVisibility(true);
        View.OnClickListener onClickListener = this.f4170f0;
        if (onClickListener != null) {
            onClickListener.onClick(this);
        }
    }

    public void setIconifiedByDefault(boolean z6) {
        if (this.f4171g0 == z6) {
            return;
        }
        this.f4171g0 = z6;
        u(z6);
        r();
    }

    public void setImeOptions(int i6) {
        this.f4150G.setImeOptions(i6);
    }

    public void setInputType(int i6) {
        this.f4150G.setInputType(i6);
    }

    public void setMaxWidth(int i6) {
        this.f4178n0 = i6;
        requestLayout();
    }

    public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener onFocusChangeListener) {
        this.f4169e0 = onFocusChangeListener;
    }

    public void setOnSearchClickListener(View.OnClickListener onClickListener) {
        this.f4170f0 = onClickListener;
    }

    public void setQueryHint(CharSequence charSequence) {
        this.f4175k0 = charSequence;
        r();
    }

    public void setQueryRefinementEnabled(boolean z6) {
        this.f4176l0 = z6;
        X.b bVar = this.f4173i0;
        if (bVar instanceof i0) {
            ((i0) bVar).f7409H = z6 ? 2 : 1;
        }
    }

    /* JADX WARN: Code duplicated, block: B:34:0x0098  */
    public void setSearchableInfo(SearchableInfo searchableInfo) {
        boolean z6;
        this.f4183s0 = searchableInfo;
        Intent intent = null;
        SearchAutoComplete searchAutoComplete = this.f4150G;
        if (searchableInfo != null) {
            searchAutoComplete.setThreshold(searchableInfo.getSuggestThreshold());
            searchAutoComplete.setImeOptions(this.f4183s0.getImeOptions());
            int inputType = this.f4183s0.getInputType();
            if ((inputType & 15) == 1) {
                inputType &= -65537;
                if (this.f4183s0.getSuggestAuthority() != null) {
                    inputType |= 589824;
                }
            }
            searchAutoComplete.setInputType(inputType);
            X.b bVar = this.f4173i0;
            if (bVar != null) {
                bVar.b(null);
            }
            if (this.f4183s0.getSuggestAuthority() != null) {
                i0 i0Var = new i0(getContext(), this, this.f4183s0, this.f4187w0);
                this.f4173i0 = i0Var;
                searchAutoComplete.setAdapter(i0Var);
                ((i0) this.f4173i0).f7409H = this.f4176l0 ? 2 : 1;
            }
            r();
        }
        SearchableInfo searchableInfo2 = this.f4183s0;
        if (searchableInfo2 != null && searchableInfo2.getVoiceSearchEnabled()) {
            if (this.f4183s0.getVoiceSearchLaunchWebSearch()) {
                intent = this.f4166b0;
            } else if (this.f4183s0.getVoiceSearchLaunchRecognizer()) {
                intent = this.f4167c0;
            }
            z6 = (intent == null || getContext().getPackageManager().resolveActivity(intent, 65536) == null) ? false : true;
        }
        this.f4179o0 = z6;
        if (z6) {
            searchAutoComplete.setPrivateImeOptions("nm");
        }
        u(this.f4172h0);
    }

    public void setSubmitButtonEnabled(boolean z6) {
        this.f4174j0 = z6;
        u(this.f4172h0);
    }

    public void setSuggestionsAdapter(X.b bVar) {
        this.f4173i0 = bVar;
        this.f4150G.setAdapter(bVar);
    }

    public final void t(boolean z6) {
        boolean z7 = this.f4174j0;
        this.f4155L.setVisibility((!z7 || !(z7 || this.f4179o0) || this.f4172h0 || !hasFocus() || (!z6 && this.f4179o0)) ? 8 : 0);
    }

    public final void u(boolean z6) {
        this.f4172h0 = z6;
        int i6 = 8;
        int i7 = z6 ? 0 : 8;
        boolean zIsEmpty = TextUtils.isEmpty(this.f4150G.getText());
        this.f4154K.setVisibility(i7);
        t(!zIsEmpty);
        this.f4151H.setVisibility(z6 ? 8 : 0);
        ImageView imageView = this.f4164U;
        imageView.setVisibility((imageView.getDrawable() == null || this.f4171g0) ? 8 : 0);
        p();
        if (this.f4179o0 && !this.f4172h0 && zIsEmpty) {
            this.f4155L.setVisibility(8);
            i6 = 0;
        }
        this.f4157N.setVisibility(i6);
        s();
    }

    public SearchView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.searchViewStyle);
    }

    public SearchView(Context context, AttributeSet attributeSet, int i6) {
        super(context, attributeSet, i6);
        this.f4160Q = new Rect();
        this.f4161R = new Rect();
        this.f4162S = new int[2];
        this.f4163T = new int[2];
        this.f4185u0 = new W(this, 0);
        this.f4186v0 = new W(this, 1);
        this.f4187w0 = new WeakHashMap();
        a aVar = new a(this);
        b bVar = new b(this);
        Z z6 = new Z(this);
        a0 a0Var = new a0(this);
        I i7 = new I(this, 1);
        V v6 = new V(this);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p041h.a.r, i6, 0);
        C0331c c0331c = new C0331c(context, typedArrayObtainStyledAttributes);
        LayoutInflater.from(context).inflate(typedArrayObtainStyledAttributes.getResourceId(9, R.layout.abc_search_view), (ViewGroup) this, true);
        SearchAutoComplete searchAutoComplete = (SearchAutoComplete) findViewById(R.id.search_src_text);
        this.f4150G = searchAutoComplete;
        searchAutoComplete.setSearchView(this);
        this.f4151H = findViewById(R.id.search_edit_frame);
        View viewFindViewById = findViewById(R.id.search_plate);
        this.f4152I = viewFindViewById;
        View viewFindViewById2 = findViewById(R.id.submit_area);
        this.f4153J = viewFindViewById2;
        ImageView imageView = (ImageView) findViewById(R.id.search_button);
        this.f4154K = imageView;
        ImageView imageView2 = (ImageView) findViewById(R.id.search_go_btn);
        this.f4155L = imageView2;
        ImageView imageView3 = (ImageView) findViewById(R.id.search_close_btn);
        this.f4156M = imageView3;
        ImageView imageView4 = (ImageView) findViewById(R.id.search_voice_btn);
        this.f4157N = imageView4;
        ImageView imageView5 = (ImageView) findViewById(R.id.search_mag_icon);
        this.f4164U = imageView5;
        viewFindViewById.setBackground(c0331c.p(10));
        viewFindViewById2.setBackground(c0331c.p(14));
        imageView.setImageDrawable(c0331c.p(13));
        imageView2.setImageDrawable(c0331c.p(7));
        imageView3.setImageDrawable(c0331c.p(4));
        imageView4.setImageDrawable(c0331c.p(16));
        imageView5.setImageDrawable(c0331c.p(13));
        this.f4165V = c0331c.p(12);
        p000a.a.L(imageView, getResources().getString(R.string.abc_searchview_description_search));
        this.W = typedArrayObtainStyledAttributes.getResourceId(15, R.layout.abc_search_dropdown_item_icons_2line);
        this.a0 = typedArrayObtainStyledAttributes.getResourceId(5, 0);
        imageView.setOnClickListener(aVar);
        imageView3.setOnClickListener(aVar);
        imageView2.setOnClickListener(aVar);
        imageView4.setOnClickListener(aVar);
        searchAutoComplete.setOnClickListener(aVar);
        searchAutoComplete.addTextChangedListener(v6);
        searchAutoComplete.setOnEditorActionListener(z6);
        searchAutoComplete.setOnItemClickListener(a0Var);
        searchAutoComplete.setOnItemSelectedListener(i7);
        searchAutoComplete.setOnKeyListener(bVar);
        searchAutoComplete.setOnFocusChangeListener(new X(this));
        setIconifiedByDefault(typedArrayObtainStyledAttributes.getBoolean(8, true));
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(1, -1);
        if (dimensionPixelSize != -1) {
            setMaxWidth(dimensionPixelSize);
        }
        this.f4168d0 = typedArrayObtainStyledAttributes.getText(6);
        this.f4175k0 = typedArrayObtainStyledAttributes.getText(11);
        int i8 = typedArrayObtainStyledAttributes.getInt(3, -1);
        if (i8 != -1) {
            setImeOptions(i8);
        }
        int i9 = typedArrayObtainStyledAttributes.getInt(2, -1);
        if (i9 != -1) {
            setInputType(i9);
        }
        setFocusable(typedArrayObtainStyledAttributes.getBoolean(0, true));
        c0331c.z();
        Intent intent = new Intent("android.speech.action.WEB_SEARCH");
        this.f4166b0 = intent;
        intent.addFlags(268435456);
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
        Intent intent2 = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        this.f4167c0 = intent2;
        intent2.addFlags(268435456);
        View viewFindViewById3 = findViewById(searchAutoComplete.getDropDownAnchor());
        this.f4158O = viewFindViewById3;
        if (viewFindViewById3 != null) {
            viewFindViewById3.addOnLayoutChangeListener(new Y(this));
        }
        u(this.f4171g0);
        r();
    }

    public void setOnCloseListener(b0 b0Var) {
    }

    public void setOnQueryTextListener(c0 c0Var) {
    }

    public void setOnSuggestionListener(d0 d0Var) {
    }
}
