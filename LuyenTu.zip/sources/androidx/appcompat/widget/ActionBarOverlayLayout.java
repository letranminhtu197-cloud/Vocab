package androidx.appcompat.widget;

import A.d;
import H.AbstractC0040t;
import H.AbstractC0046z;
import H.C;
import H.C0031j;
import H.E;
import H.F;
import H.G;
import H.H;
import H.I;
import H.InterfaceC0029h;
import H.InterfaceC0030i;
import H.J;
import H.K;
import H.W;
import H.Z;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import androidx.core.widget.NestedScrollView;
import com.luyentu.mobile.R;
import java.lang.reflect.Field;
import p068l.A;
import p068l.C0389b;
import p068l.C0392e;
import p068l.InterfaceC0391d;
import p068l.RunnableC0390c;
import p068l.s0;

/* JADX INFO: loaded from: classes.dex */
public class ActionBarOverlayLayout extends ViewGroup implements InterfaceC0029h, InterfaceC0030i {

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public static final int[] f4113P = {R.attr.actionBarSize, android.R.attr.windowContentOverlay};

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public boolean f4114A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public int f4115B;
    public final Rect C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final Rect f4116D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public final Rect f4117E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public Z f4118F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public Z f4119G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public Z f4120H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public Z f4121I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public OverScroller f4122J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public ViewPropertyAnimator f4123K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public final C0389b f4124L;

    /* JADX INFO: renamed from: M, reason: collision with root package name */
    public final RunnableC0390c f4125M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public final RunnableC0390c f4126N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public final C0031j f4127O;
    public int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public ContentFrameLayout f4128s;
    public ActionBarContainer t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public A f4129u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public Drawable f4130v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f4131w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f4132x;
    public boolean y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f4133z;

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.C = new Rect();
        this.f4116D = new Rect();
        this.f4117E = new Rect();
        new Rect();
        new Rect();
        new Rect();
        new Rect();
        Z z6 = Z.f1464b;
        this.f4118F = z6;
        this.f4119G = z6;
        this.f4120H = z6;
        this.f4121I = z6;
        this.f4124L = new C0389b(this);
        this.f4125M = new RunnableC0390c(this, 0);
        this.f4126N = new RunnableC0390c(this, 1);
        i(context);
        this.f4127O = new C0031j();
    }

    public static boolean g(View view, Rect rect, boolean z6) {
        boolean z7;
        C0392e c0392e = (C0392e) view.getLayoutParams();
        int i6 = ((ViewGroup.MarginLayoutParams) c0392e).leftMargin;
        int i7 = rect.left;
        if (i6 != i7) {
            ((ViewGroup.MarginLayoutParams) c0392e).leftMargin = i7;
            z7 = true;
        } else {
            z7 = false;
        }
        int i8 = ((ViewGroup.MarginLayoutParams) c0392e).topMargin;
        int i9 = rect.top;
        if (i8 != i9) {
            ((ViewGroup.MarginLayoutParams) c0392e).topMargin = i9;
            z7 = true;
        }
        int i10 = ((ViewGroup.MarginLayoutParams) c0392e).rightMargin;
        int i11 = rect.right;
        if (i10 != i11) {
            ((ViewGroup.MarginLayoutParams) c0392e).rightMargin = i11;
            z7 = true;
        }
        if (z6) {
            int i12 = ((ViewGroup.MarginLayoutParams) c0392e).bottomMargin;
            int i13 = rect.bottom;
            if (i12 != i13) {
                ((ViewGroup.MarginLayoutParams) c0392e).bottomMargin = i13;
                return true;
            }
        }
        return z7;
    }

    @Override // H.InterfaceC0029h
    public final void a(View view, View view2, int i6, int i7) {
        if (i7 == 0) {
            onNestedScrollAccepted(view, view2, i6);
        }
    }

    @Override // H.InterfaceC0029h
    public final void b(View view, int i6) {
        if (i6 == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // H.InterfaceC0030i
    public final void c(NestedScrollView nestedScrollView, int i6, int i7, int i8, int i9, int i10, int[] iArr) {
        d(nestedScrollView, i6, i7, i8, i9, i10);
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0392e;
    }

    @Override // H.InterfaceC0029h
    public final void d(NestedScrollView nestedScrollView, int i6, int i7, int i8, int i9, int i10) {
        if (i10 == 0) {
            onNestedScroll(nestedScrollView, i6, i7, i8, i9);
        }
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int translationY;
        super.draw(canvas);
        if (this.f4130v == null || this.f4131w) {
            return;
        }
        if (this.t.getVisibility() == 0) {
            translationY = (int) (this.t.getTranslationY() + this.t.getBottom() + 0.5f);
        } else {
            translationY = 0;
        }
        this.f4130v.setBounds(0, translationY, getWidth(), this.f4130v.getIntrinsicHeight() + translationY);
        this.f4130v.draw(canvas);
    }

    @Override // H.InterfaceC0029h
    public final boolean f(View view, View view2, int i6, int i7) {
        return i7 == 0 && onStartNestedScroll(view, view2, i6);
    }

    @Override // android.view.View
    public final boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new C0392e(-1, -1);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0392e(getContext(), attributeSet);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.t;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        C0031j c0031j = this.f4127O;
        return c0031j.f1492b | c0031j.f1491a;
    }

    public CharSequence getTitle() {
        j();
        return ((s0) this.f4129u).f7453a.getTitle();
    }

    public final void h() {
        removeCallbacks(this.f4125M);
        removeCallbacks(this.f4126N);
        ViewPropertyAnimator viewPropertyAnimator = this.f4123K;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public final void i(Context context) {
        TypedArray typedArrayObtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(f4113P);
        this.r = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(1);
        this.f4130v = drawable;
        setWillNotDraw(drawable == null);
        typedArrayObtainStyledAttributes.recycle();
        this.f4131w = context.getApplicationInfo().targetSdkVersion < 19;
        this.f4122J = new OverScroller(context);
    }

    public final void j() {
        A wrapper;
        if (this.f4128s == null) {
            this.f4128s = (ContentFrameLayout) findViewById(R.id.action_bar_activity_content);
            this.t = (ActionBarContainer) findViewById(R.id.action_bar_container);
            KeyEvent.Callback callbackFindViewById = findViewById(R.id.action_bar);
            if (callbackFindViewById instanceof A) {
                wrapper = (A) callbackFindViewById;
            } else {
                if (!(callbackFindViewById instanceof Toolbar)) {
                    throw new IllegalStateException("Can't make a decor toolbar out of ".concat(callbackFindViewById.getClass().getSimpleName()));
                }
                wrapper = ((Toolbar) callbackFindViewById).getWrapper();
            }
            this.f4129u = wrapper;
        }
    }

    @Override // android.view.View
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        j();
        Z zC = Z.c(null, windowInsets);
        W w6 = zC.f1465a;
        boolean zG = g(this.t, new Rect(w6.k().f2a, w6.k().f3b, w6.k().f4c, w6.k().f5d), false);
        Field field = AbstractC0046z.f1508a;
        Rect rect = this.C;
        AbstractC0040t.a(this, zC, rect);
        Z zO = w6.o(rect.left, rect.top, rect.right, rect.bottom);
        this.f4118F = zO;
        boolean z6 = true;
        if (!this.f4119G.equals(zO)) {
            this.f4119G = this.f4118F;
            zG = true;
        }
        Rect rect2 = this.f4116D;
        if (rect2.equals(rect)) {
            z6 = zG;
        } else {
            rect2.set(rect);
        }
        if (z6) {
            requestLayout();
        }
        return w6.a().f1465a.c().f1465a.b().b();
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        i(getContext());
        Field field = AbstractC0046z.f1508a;
        requestApplyInsets();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z6, int i6, int i7, int i8, int i9) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (childAt.getVisibility() != 8) {
                C0392e c0392e = (C0392e) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i11 = ((ViewGroup.MarginLayoutParams) c0392e).leftMargin + paddingLeft;
                int i12 = ((ViewGroup.MarginLayoutParams) c0392e).topMargin + paddingTop;
                childAt.layout(i11, i12, measuredWidth + i11, measuredHeight + i12);
            }
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i6, int i7) {
        int measuredHeight;
        K e6;
        j();
        measureChildWithMargins(this.t, i6, 0, i7, 0);
        C0392e c0392e = (C0392e) this.t.getLayoutParams();
        int iMax = Math.max(0, this.t.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) c0392e).leftMargin + ((ViewGroup.MarginLayoutParams) c0392e).rightMargin);
        int iMax2 = Math.max(0, this.t.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) c0392e).topMargin + ((ViewGroup.MarginLayoutParams) c0392e).bottomMargin);
        int iCombineMeasuredStates = View.combineMeasuredStates(0, this.t.getMeasuredState());
        Field field = AbstractC0046z.f1508a;
        boolean z6 = (getWindowSystemUiVisibility() & 256) != 0;
        if (z6) {
            measuredHeight = this.r;
            if (this.y && this.t.getTabContainer() != null) {
                measuredHeight += this.r;
            }
        } else {
            measuredHeight = this.t.getVisibility() != 8 ? this.t.getMeasuredHeight() : 0;
        }
        Rect rect = this.C;
        Rect rect2 = this.f4117E;
        rect2.set(rect);
        Z z7 = this.f4118F;
        this.f4120H = z7;
        if (this.f4132x || z6) {
            d dVarA = d.a(z7.f1465a.k().f2a, this.f4120H.f1465a.k().f3b + measuredHeight, this.f4120H.f1465a.k().f4c, this.f4120H.f1465a.k().f5d);
            Z z8 = this.f4120H;
            int i8 = Build.VERSION.SDK_INT;
            if (i8 >= 36) {
                e6 = new J(z8);
            } else if (i8 >= 35) {
                e6 = new I(z8);
            } else if (i8 >= 34) {
                e6 = new H(z8);
            } else if (i8 >= 31) {
                e6 = new G(z8);
            } else if (i8 >= 30) {
                e6 = new F(z8);
            } else {
                e6 = i8 >= 29 ? new E(z8) : new C(z8);
            }
            e6.e(dVarA);
            this.f4120H = e6.b();
        } else {
            rect2.top += measuredHeight;
            rect2.bottom = rect2.bottom;
            this.f4120H = z7.f1465a.o(0, measuredHeight, 0, 0);
        }
        g(this.f4128s, rect2, true);
        if (!this.f4121I.equals(this.f4120H)) {
            Z z9 = this.f4120H;
            this.f4121I = z9;
            AbstractC0046z.a(this.f4128s, z9);
        }
        measureChildWithMargins(this.f4128s, i6, 0, i7, 0);
        C0392e c0392e2 = (C0392e) this.f4128s.getLayoutParams();
        int iMax3 = Math.max(iMax, this.f4128s.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) c0392e2).leftMargin + ((ViewGroup.MarginLayoutParams) c0392e2).rightMargin);
        int iMax4 = Math.max(iMax2, this.f4128s.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) c0392e2).topMargin + ((ViewGroup.MarginLayoutParams) c0392e2).bottomMargin);
        int iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.f4128s.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + getPaddingLeft() + iMax3, getSuggestedMinimumWidth()), i6, iCombineMeasuredStates2), View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + iMax4, getSuggestedMinimumHeight()), i7, iCombineMeasuredStates2 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f4, float f7, boolean z6) {
        if (!this.f4133z || !z6) {
            return false;
        }
        this.f4122J.fling(0, 0, 0, (int) f7, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        if (this.f4122J.getFinalY() > this.t.getHeight()) {
            h();
            this.f4126N.run();
        } else {
            h();
            this.f4125M.run();
        }
        this.f4114A = true;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f4, float f7) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i6, int i7, int[] iArr) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i6, int i7, int i8, int i9) {
        int i10 = this.f4115B + i7;
        this.f4115B = i10;
        setActionBarHideOffset(i10);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i6) {
        this.f4127O.f1491a = i6;
        this.f4115B = getActionBarHideOffset();
        h();
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i6) {
        if ((i6 & 2) == 0 || this.t.getVisibility() != 0) {
            return false;
        }
        return this.f4133z;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        if (!this.f4133z || this.f4114A) {
            return;
        }
        if (this.f4115B <= this.t.getHeight()) {
            h();
            postDelayed(this.f4125M, 600L);
        } else {
            h();
            postDelayed(this.f4126N, 600L);
        }
    }

    @Override // android.view.View
    public final void onWindowSystemUiVisibilityChanged(int i6) {
        super.onWindowSystemUiVisibilityChanged(i6);
        j();
    }

    @Override // android.view.View
    public final void onWindowVisibilityChanged(int i6) {
        super.onWindowVisibilityChanged(i6);
    }

    public void setActionBarHideOffset(int i6) {
        h();
        this.t.setTranslationY(-Math.max(0, Math.min(i6, this.t.getHeight())));
    }

    public void setActionBarVisibilityCallback(InterfaceC0391d interfaceC0391d) {
        if (getWindowToken() != null) {
            throw null;
        }
    }

    public void setHasNonEmbeddedTabs(boolean z6) {
        this.y = z6;
    }

    public void setHideOnContentScrollEnabled(boolean z6) {
        if (z6 != this.f4133z) {
            this.f4133z = z6;
            if (z6) {
                return;
            }
            h();
            setActionBarHideOffset(0);
        }
    }

    public void setIcon(int i6) {
        j();
        s0 s0Var = (s0) this.f4129u;
        s0Var.f7456d = i6 != 0 ? p048i.a.a(s0Var.f7453a.getContext(), i6) : null;
        s0Var.c();
    }

    public void setLogo(int i6) {
        j();
        s0 s0Var = (s0) this.f4129u;
        s0Var.f7457e = i6 != 0 ? p048i.a.a(s0Var.f7453a.getContext(), i6) : null;
        s0Var.c();
    }

    public void setOverlayMode(boolean z6) {
        this.f4132x = z6;
        this.f4131w = z6 && getContext().getApplicationInfo().targetSdkVersion < 19;
    }

    public void setShowingForActionMode(boolean z6) {
    }

    public void setUiOptions(int i6) {
    }

    public void setWindowCallback(Window.Callback callback) {
        j();
        ((s0) this.f4129u).f7463k = callback;
    }

    public void setWindowTitle(CharSequence charSequence) {
        j();
        s0 s0Var = (s0) this.f4129u;
        if (s0Var.f7459g) {
            return;
        }
        s0Var.f7460h = charSequence;
        if ((s0Var.f7454b & 8) != 0) {
            s0Var.f7453a.setTitle(charSequence);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new C0392e(layoutParams);
    }

    public void setIcon(Drawable drawable) {
        j();
        s0 s0Var = (s0) this.f4129u;
        s0Var.f7456d = drawable;
        s0Var.c();
    }

    @Override // H.InterfaceC0029h
    public final void e(int i6, int i7, int i8, int[] iArr) {
    }
}
