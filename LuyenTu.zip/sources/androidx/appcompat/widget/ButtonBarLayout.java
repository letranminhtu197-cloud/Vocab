package androidx.appcompat.widget;

import H.AbstractC0046z;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import com.luyentu.mobile.R;
import java.lang.reflect.Field;

/* JADX INFO: loaded from: classes.dex */
public class ButtonBarLayout extends LinearLayout {
    public boolean r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f4143s;

    public ButtonBarLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f4143s = -1;
        int[] iArr = p041h.a.f5953i;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr);
        AbstractC0046z.b(this, context, iArr, attributeSet, typedArrayObtainStyledAttributes, 0);
        this.r = typedArrayObtainStyledAttributes.getBoolean(0, true);
        typedArrayObtainStyledAttributes.recycle();
    }

    private void setStacked(boolean z6) {
        setOrientation(z6 ? 1 : 0);
        setGravity(z6 ? 5 : 80);
        View viewFindViewById = findViewById(R.id.spacer);
        if (viewFindViewById != null) {
            viewFindViewById.setVisibility(z6 ? 8 : 4);
        }
        for (int childCount = getChildCount() - 2; childCount >= 0; childCount--) {
            bringChildToFront(getChildAt(childCount));
        }
    }

    @Override // android.view.View
    public int getMinimumHeight() {
        return Math.max(0, super.getMinimumHeight());
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onMeasure(int i6, int i7) {
        int iMakeMeasureSpec;
        boolean z6;
        int i8;
        int size = View.MeasureSpec.getSize(i6);
        int paddingBottom = 0;
        if (this.r) {
            if (size > this.f4143s && getOrientation() == 1) {
                setStacked(false);
            }
            this.f4143s = size;
        }
        if (getOrientation() != 1 && View.MeasureSpec.getMode(i6) == 1073741824) {
            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(size, Integer.MIN_VALUE);
            z6 = true;
        } else {
            iMakeMeasureSpec = i6;
            z6 = false;
        }
        super.onMeasure(iMakeMeasureSpec, i7);
        if (this.r && getOrientation() != 1 && (getMeasuredWidthAndState() & (-16777216)) == 16777216) {
            setStacked(true);
            z6 = true;
        }
        if (z6) {
            super.onMeasure(i6, i7);
        }
        int childCount = getChildCount();
        int i9 = 0;
        while (true) {
            i8 = -1;
            if (i9 >= childCount) {
                i9 = -1;
                break;
            } else if (getChildAt(i9).getVisibility() == 0) {
                break;
            } else {
                i9++;
            }
        }
        if (i9 >= 0) {
            View childAt = getChildAt(i9);
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight() + getPaddingTop() + layoutParams.topMargin + layoutParams.bottomMargin;
            if ((getOrientation() == 1 ? 1 : 0) != 0) {
                int childCount2 = getChildCount();
                for (int i10 = i9 + 1; i10 < childCount2; i10++) {
                    if (getChildAt(i10).getVisibility() == 0) {
                        i8 = i10;
                        break;
                    }
                }
                paddingBottom = i8 >= 0 ? getChildAt(i8).getPaddingTop() + ((int) (getResources().getDisplayMetrics().density * 16.0f)) + measuredHeight : measuredHeight;
            } else {
                paddingBottom = getPaddingBottom() + measuredHeight;
            }
        }
        Field field = AbstractC0046z.f1508a;
        if (getMinimumHeight() != paddingBottom) {
            setMinimumHeight(paddingBottom);
        }
    }

    public void setAllowStacking(boolean z6) {
        if (this.r != z6) {
            this.r = z6;
            if (!z6 && getOrientation() == 1) {
                setStacked(false);
            }
            requestLayout();
        }
    }
}
