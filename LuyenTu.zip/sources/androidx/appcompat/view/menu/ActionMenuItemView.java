package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import p062k.a;
import p062k.b;
import p062k.h;
import p062k.i;
import p062k.j;
import p062k.p;
import p068l.C0407u;
import p068l.InterfaceC0397j;

/* JADX INFO: loaded from: classes.dex */
public class ActionMenuItemView extends C0407u implements p, View.OnClickListener, InterfaceC0397j {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public b f4077A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public boolean f4078B;
    public boolean C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final int f4079D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public int f4080E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public final int f4081F;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public j f4082v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public CharSequence f4083w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public Drawable f4084x;
    public h y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public a f4085z;

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        Resources resources = context.getResources();
        this.f4078B = d();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p041h.a.f5947c, 0, 0);
        this.f4079D = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        this.f4081F = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.f4080E = -1;
        setSaveEnabled(false);
    }

    @Override // p062k.p
    public final void a(j jVar) {
        this.f4082v = jVar;
        setIcon(jVar.getIcon());
        setTitle(jVar.getTitleCondensed());
        setId(jVar.f7186a);
        setVisibility(jVar.isVisible() ? 0 : 8);
        setEnabled(jVar.isEnabled());
        if (jVar.hasSubMenu() && this.f4085z == null) {
            this.f4085z = new a(this);
        }
    }

    @Override // p068l.InterfaceC0397j
    public final boolean b() {
        return !TextUtils.isEmpty(getText());
    }

    @Override // p068l.InterfaceC0397j
    public final boolean c() {
        return !TextUtils.isEmpty(getText()) && this.f4082v.getIcon() == null;
    }

    public final boolean d() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i6 = configuration.screenWidthDp;
        int i7 = configuration.screenHeightDp;
        if (i6 < 480) {
            return (i6 >= 640 && i7 >= 480) || configuration.orientation == 2;
        }
        return true;
    }

    public final void e() {
        boolean z6 = true;
        boolean z7 = !TextUtils.isEmpty(this.f4083w);
        if (this.f4084x != null && ((this.f4082v.y & 4) != 4 || (!this.f4078B && !this.C))) {
            z6 = false;
        }
        boolean z8 = z7 & z6;
        setText(z8 ? this.f4083w : null);
        CharSequence charSequence = this.f4082v.f7201q;
        if (TextUtils.isEmpty(charSequence)) {
            setContentDescription(z8 ? null : this.f4082v.f7190e);
        } else {
            setContentDescription(charSequence);
        }
        CharSequence charSequence2 = this.f4082v.r;
        if (TextUtils.isEmpty(charSequence2)) {
            p000a.a.L(this, z8 ? null : this.f4082v.f7190e);
        } else {
            p000a.a.L(this, charSequence2);
        }
    }

    @Override // p062k.p
    public j getItemData() {
        return this.f4082v;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        h hVar = this.y;
        if (hVar != null) {
            hVar.a(this.f4082v);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f4078B = d();
        e();
    }

    @Override // p068l.C0407u, android.widget.TextView, android.view.View
    public final void onMeasure(int i6, int i7) {
        int i8;
        boolean zIsEmpty = TextUtils.isEmpty(getText());
        if (!zIsEmpty && (i8 = this.f4080E) >= 0) {
            super.setPadding(i8, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i6, i7);
        int mode = View.MeasureSpec.getMode(i6);
        int size = View.MeasureSpec.getSize(i6);
        int measuredWidth = getMeasuredWidth();
        int i9 = this.f4079D;
        int iMin = mode == Integer.MIN_VALUE ? Math.min(size, i9) : i9;
        if (mode != 1073741824 && i9 > 0 && measuredWidth < iMin) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(iMin, 1073741824), i7);
        }
        if (!zIsEmpty || this.f4084x == null) {
            return;
        }
        super.setPadding((getMeasuredWidth() - this.f4084x.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
    }

    @Override // android.widget.TextView, android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(null);
    }

    @Override // android.widget.TextView, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        a aVar;
        if (this.f4082v.hasSubMenu() && (aVar = this.f4085z) != null && aVar.onTouch(this, motionEvent)) {
            return true;
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setCheckable(boolean z6) {
    }

    public void setChecked(boolean z6) {
    }

    public void setExpandedFormat(boolean z6) {
        if (this.C != z6) {
            this.C = z6;
            j jVar = this.f4082v;
            if (jVar != null) {
                i iVar = jVar.f7199n;
                iVar.f7177k = true;
                iVar.o(true);
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.f4084x = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i6 = this.f4081F;
            if (intrinsicWidth > i6) {
                intrinsicHeight = (int) (intrinsicHeight * (i6 / intrinsicWidth));
                intrinsicWidth = i6;
            }
            if (intrinsicHeight > i6) {
                intrinsicWidth = (int) (intrinsicWidth * (i6 / intrinsicHeight));
            } else {
                i6 = intrinsicHeight;
            }
            drawable.setBounds(0, 0, intrinsicWidth, i6);
        }
        setCompoundDrawables(drawable, null, null, null);
        e();
    }

    public void setItemInvoker(h hVar) {
        this.y = hVar;
    }

    @Override // android.widget.TextView, android.view.View
    public final void setPadding(int i6, int i7, int i8, int i9) {
        this.f4080E = i6;
        super.setPadding(i6, i7, i8, i9);
    }

    public void setPopupCallback(b bVar) {
        this.f4077A = bVar;
    }

    public void setTitle(CharSequence charSequence) {
        this.f4083w = charSequence;
        e();
    }
}
