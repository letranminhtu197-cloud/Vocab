package androidx.appcompat.view.menu;

import H.AbstractC0046z;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import com.luyentu.mobile.R;
import java.lang.reflect.Field;
import org.apache.tika.utils.StringUtils;
import p041h.a;
import p045h3.C0331c;
import p062k.i;
import p062k.j;
import p062k.p;

/* JADX INFO: loaded from: classes.dex */
public class ListMenuItemView extends LinearLayout implements p, AbsListView.SelectionBoundsAdjuster {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final Drawable f4086A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public final int f4087B;
    public final Context C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public boolean f4088D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public final Drawable f4089E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public final boolean f4090F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public LayoutInflater f4091G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public boolean f4092H;
    public j r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public ImageView f4093s;
    public RadioButton t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public TextView f4094u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public CheckBox f4095v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public TextView f4096w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public ImageView f4097x;
    public ImageView y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public LinearLayout f4098z;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        C0331c c0331cW = C0331c.w(getContext(), attributeSet, a.o, R.attr.listMenuViewStyle);
        this.f4086A = c0331cW.p(5);
        TypedArray typedArray = (TypedArray) c0331cW.f6060u;
        this.f4087B = typedArray.getResourceId(1, -1);
        this.f4088D = typedArray.getBoolean(7, false);
        this.C = context;
        this.f4089E = c0331cW.p(8);
        TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{android.R.attr.divider}, R.attr.dropDownListViewStyle, 0);
        this.f4090F = typedArrayObtainStyledAttributes.hasValue(0);
        c0331cW.z();
        typedArrayObtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.f4091G == null) {
            this.f4091G = LayoutInflater.from(getContext());
        }
        return this.f4091G;
    }

    private void setSubMenuArrowVisible(boolean z6) {
        ImageView imageView = this.f4097x;
        if (imageView != null) {
            imageView.setVisibility(z6 ? 0 : 8);
        }
    }

    /* JADX WARN: Code duplicated, block: B:14:0x0037  */
    /* JADX WARN: Code duplicated, block: B:25:0x005a  */
    /* JADX WARN: Code duplicated, block: B:28:0x005e  */
    @Override // p062k.p
    public final void a(j jVar) {
        boolean z6;
        int i6;
        String string;
        boolean z7;
        this.r = jVar;
        setVisibility(jVar.isVisible() ? 0 : 8);
        setTitle(jVar.f7190e);
        setCheckable(jVar.isCheckable());
        if (jVar.f7199n.n()) {
            if ((jVar.f7199n.m() ? jVar.f7195j : jVar.f7193h) != 0) {
                z6 = true;
            } else {
                z6 = false;
            }
        } else {
            z6 = false;
        }
        jVar.f7199n.m();
        if (z6) {
            j jVar2 = this.r;
            if (jVar2.f7199n.n()) {
                if ((jVar2.f7199n.m() ? jVar2.f7195j : jVar2.f7193h) != 0) {
                    z7 = true;
                } else {
                    z7 = false;
                }
            } else {
                z7 = false;
            }
            i6 = z7 ? 0 : 8;
        }
        if (i6 == 0) {
            TextView textView = this.f4096w;
            j jVar3 = this.r;
            i iVar = jVar3.f7199n;
            Context context = iVar.f7167a;
            char c2 = iVar.m() ? jVar3.f7195j : jVar3.f7193h;
            if (c2 == 0) {
                string = StringUtils.EMPTY;
            } else {
                Resources resources = context.getResources();
                StringBuilder sb = new StringBuilder();
                if (ViewConfiguration.get(context).hasPermanentMenuKey()) {
                    sb.append(resources.getString(R.string.abc_prepend_shortcut_label));
                }
                int i7 = iVar.m() ? jVar3.f7196k : jVar3.f7194i;
                j.a(sb, i7, 65536, resources.getString(R.string.abc_menu_meta_shortcut_label));
                j.a(sb, i7, 4096, resources.getString(R.string.abc_menu_ctrl_shortcut_label));
                j.a(sb, i7, 2, resources.getString(R.string.abc_menu_alt_shortcut_label));
                j.a(sb, i7, 1, resources.getString(R.string.abc_menu_shift_shortcut_label));
                j.a(sb, i7, 4, resources.getString(R.string.abc_menu_sym_shortcut_label));
                j.a(sb, i7, 8, resources.getString(R.string.abc_menu_function_shortcut_label));
                if (c2 == '\b') {
                    sb.append(resources.getString(R.string.abc_menu_delete_shortcut_label));
                } else if (c2 == '\n') {
                    sb.append(resources.getString(R.string.abc_menu_enter_shortcut_label));
                } else if (c2 != ' ') {
                    sb.append(c2);
                } else {
                    sb.append(resources.getString(R.string.abc_menu_space_shortcut_label));
                }
                string = sb.toString();
            }
            textView.setText(string);
        }
        if (this.f4096w.getVisibility() != i6) {
            this.f4096w.setVisibility(i6);
        }
        setIcon(jVar.getIcon());
        setEnabled(jVar.isEnabled());
        setSubMenuArrowVisible(jVar.hasSubMenu());
        setContentDescription(jVar.f7201q);
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public final void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.y;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.y.getLayoutParams();
        rect.top = this.y.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
    }

    @Override // p062k.p
    public j getItemData() {
        return this.r;
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        Field field = AbstractC0046z.f1508a;
        setBackground(this.f4086A);
        TextView textView = (TextView) findViewById(R.id.title);
        this.f4094u = textView;
        int i6 = this.f4087B;
        if (i6 != -1) {
            textView.setTextAppearance(this.C, i6);
        }
        this.f4096w = (TextView) findViewById(R.id.shortcut);
        ImageView imageView = (ImageView) findViewById(R.id.submenuarrow);
        this.f4097x = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.f4089E);
        }
        this.y = (ImageView) findViewById(R.id.group_divider);
        this.f4098z = (LinearLayout) findViewById(R.id.content);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onMeasure(int i6, int i7) {
        if (this.f4093s != null && this.f4088D) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f4093s.getLayoutParams();
            int i8 = layoutParams.height;
            if (i8 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i8;
            }
        }
        super.onMeasure(i6, i7);
    }

    public void setCheckable(boolean z6) {
        CompoundButton compoundButton;
        View view;
        if (!z6 && this.t == null && this.f4095v == null) {
            return;
        }
        if ((this.r.f7206x & 4) != 0) {
            if (this.t == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.t = radioButton;
                LinearLayout linearLayout = this.f4098z;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.t;
            view = this.f4095v;
        } else {
            if (this.f4095v == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.f4095v = checkBox;
                LinearLayout linearLayout2 = this.f4098z;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f4095v;
            view = this.t;
        }
        if (z6) {
            compoundButton.setChecked(this.r.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (view == null || view.getVisibility() == 8) {
                return;
            }
            view.setVisibility(8);
            return;
        }
        CheckBox checkBox2 = this.f4095v;
        if (checkBox2 != null) {
            checkBox2.setVisibility(8);
        }
        RadioButton radioButton2 = this.t;
        if (radioButton2 != null) {
            radioButton2.setVisibility(8);
        }
    }

    public void setChecked(boolean z6) {
        CompoundButton compoundButton;
        if ((this.r.f7206x & 4) != 0) {
            if (this.t == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.t = radioButton;
                LinearLayout linearLayout = this.f4098z;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.t;
        } else {
            if (this.f4095v == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.f4095v = checkBox;
                LinearLayout linearLayout2 = this.f4098z;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f4095v;
        }
        compoundButton.setChecked(z6);
    }

    public void setForceShowIcon(boolean z6) {
        this.f4092H = z6;
        this.f4088D = z6;
    }

    public void setGroupDividerEnabled(boolean z6) {
        ImageView imageView = this.y;
        if (imageView != null) {
            imageView.setVisibility((this.f4090F || !z6) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        i iVar = this.r.f7199n;
        boolean z6 = this.f4092H;
        if (z6 || this.f4088D) {
            ImageView imageView = this.f4093s;
            if (imageView == null && drawable == null && !this.f4088D) {
                return;
            }
            if (imageView == null) {
                ImageView imageView2 = (ImageView) getInflater().inflate(R.layout.abc_list_menu_item_icon, (ViewGroup) this, false);
                this.f4093s = imageView2;
                LinearLayout linearLayout = this.f4098z;
                if (linearLayout != null) {
                    linearLayout.addView(imageView2, 0);
                } else {
                    addView(imageView2, 0);
                }
            }
            if (drawable == null && !this.f4088D) {
                this.f4093s.setVisibility(8);
                return;
            }
            ImageView imageView3 = this.f4093s;
            if (!z6) {
                drawable = null;
            }
            imageView3.setImageDrawable(drawable);
            if (this.f4093s.getVisibility() != 0) {
                this.f4093s.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (charSequence == null) {
            if (this.f4094u.getVisibility() != 8) {
                this.f4094u.setVisibility(8);
            }
        } else {
            this.f4094u.setText(charSequence);
            if (this.f4094u.getVisibility() != 0) {
                this.f4094u.setVisibility(0);
            }
        }
    }
}
