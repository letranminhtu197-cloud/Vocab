package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import p045h3.C0331c;
import p062k.h;
import p062k.j;

/* JADX INFO: loaded from: classes.dex */
public final class ExpandedMenuView extends ListView implements h, AdapterView.OnItemClickListener {
    public static final int[] r = {R.attr.background, R.attr.divider};

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        C0331c c0331cW = C0331c.w(context, attributeSet, r, R.attr.listViewStyle);
        TypedArray typedArray = (TypedArray) c0331cW.f6060u;
        if (typedArray.hasValue(0)) {
            setBackgroundDrawable(c0331cW.p(0));
        }
        if (typedArray.hasValue(1)) {
            setDivider(c0331cW.p(1));
        }
        c0331cW.z();
    }

    @Override // p062k.h
    public final boolean a(j jVar) {
        throw null;
    }

    public int getWindowAnimations() {
        return 0;
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i6, long j6) {
        throw null;
    }
}
