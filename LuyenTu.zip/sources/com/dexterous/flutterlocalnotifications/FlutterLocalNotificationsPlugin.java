package com.dexterous.flutterlocalnotifications;

import S4.b;
import W4.n;
import W4.o;
import W4.p;
import W4.q;
import W4.s;
import W4.t;
import W4.u;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationChannelGroup;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.service.notification.StatusBarNotification;
import android.text.Html;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import androidx.core.graphics.drawable.IconCompat;
import com.dexterous.flutterlocalnotifications.isolate.IsolatePreferences;
import com.dexterous.flutterlocalnotifications.models.BitmapSource;
import com.dexterous.flutterlocalnotifications.models.DateTimeComponents;
import com.dexterous.flutterlocalnotifications.models.IconSource;
import com.dexterous.flutterlocalnotifications.models.MessageDetails;
import com.dexterous.flutterlocalnotifications.models.NotificationAction;
import com.dexterous.flutterlocalnotifications.models.NotificationChannelAction;
import com.dexterous.flutterlocalnotifications.models.NotificationChannelDetails;
import com.dexterous.flutterlocalnotifications.models.NotificationChannelGroupDetails;
import com.dexterous.flutterlocalnotifications.models.NotificationDetails;
import com.dexterous.flutterlocalnotifications.models.NotificationStyle;
import com.dexterous.flutterlocalnotifications.models.PersonDetails;
import com.dexterous.flutterlocalnotifications.models.RepeatInterval;
import com.dexterous.flutterlocalnotifications.models.ScheduleMode;
import com.dexterous.flutterlocalnotifications.models.ScheduledNotificationRepeatFrequency;
import com.dexterous.flutterlocalnotifications.models.SoundSource;
import com.dexterous.flutterlocalnotifications.models.styles.BigPictureStyleInformation;
import com.dexterous.flutterlocalnotifications.models.styles.BigTextStyleInformation;
import com.dexterous.flutterlocalnotifications.models.styles.DefaultStyleInformation;
import com.dexterous.flutterlocalnotifications.models.styles.InboxStyleInformation;
import com.dexterous.flutterlocalnotifications.models.styles.MessagingStyleInformation;
import com.dexterous.flutterlocalnotifications.models.styles.StyleInformation;
import com.dexterous.flutterlocalnotifications.utils.BooleanUtils;
import com.dexterous.flutterlocalnotifications.utils.LongUtils;
import com.dexterous.flutterlocalnotifications.utils.StringUtils;
import com.google.crypto.tink.shaded.protobuf.T;
import com.google.gson.reflect.TypeToken;
import h6.h;
import j$.time.LocalDateTime;
import j$.time.ZoneId;
import j$.time.ZonedDateTime;
import j$.time.format.DateTimeFormatter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.parser.external.ExternalParsersConfigReaderMetKeys;
import p068l.v0;
import p094p0.c;
import p119t4.f;
import r4.d;
import w.C0475d;
import w.C0478g;
import w.D;
import w.E;
import w.G;
import w.i;

/* JADX INFO: loaded from: classes.dex */
public class FlutterLocalNotificationsPlugin implements o, t, u, s, b, T4.a {
    static final /* synthetic */ boolean $assertionsDisabled = false;
    private static final String ACTION_ID = "actionId";
    private static final String ARE_NOTIFICATIONS_ENABLED_METHOD = "areNotificationsEnabled";
    private static final String CALLBACK_HANDLE = "callback_handle";
    private static final String CANCEL_ALL_METHOD = "cancelAll";
    private static final String CANCEL_ID = "id";
    private static final String CANCEL_METHOD = "cancel";
    static final String CANCEL_NOTIFICATION = "cancelNotification";
    private static final String CANCEL_TAG = "tag";
    private static final String CAN_SCHEDULE_EXACT_NOTIFICATIONS_METHOD = "canScheduleExactNotifications";
    private static final String CREATE_NOTIFICATION_CHANNEL_GROUP_METHOD = "createNotificationChannelGroup";
    private static final String CREATE_NOTIFICATION_CHANNEL_METHOD = "createNotificationChannel";
    private static final String DEFAULT_ICON = "defaultIcon";
    private static final String DELETE_NOTIFICATION_CHANNEL_GROUP_METHOD = "deleteNotificationChannelGroup";
    private static final String DELETE_NOTIFICATION_CHANNEL_METHOD = "deleteNotificationChannel";
    private static final String DISPATCHER_HANDLE = "dispatcher_handle";
    private static final String DRAWABLE = "drawable";
    private static final String EXACT_ALARMS_PERMISSION_ERROR_CODE = "exact_alarms_not_permitted";
    static final int EXACT_ALARM_PERMISSION_REQUEST_CODE = 2;
    static final int FULL_SCREEN_INTENT_PERMISSION_REQUEST_CODE = 3;
    private static final String GET_ACTIVE_NOTIFICATIONS_ERROR_MESSAGE = "Android version must be 6.0 or newer to use getActiveNotifications";
    private static final String GET_ACTIVE_NOTIFICATIONS_METHOD = "getActiveNotifications";
    private static final String GET_ACTIVE_NOTIFICATION_MESSAGING_STYLE_ERROR_CODE = "getActiveNotificationMessagingStyleError";
    private static final String GET_ACTIVE_NOTIFICATION_MESSAGING_STYLE_METHOD = "getActiveNotificationMessagingStyle";
    private static final String GET_CALLBACK_HANDLE_METHOD = "getCallbackHandle";
    private static final String GET_NOTIFICATION_APP_LAUNCH_DETAILS_METHOD = "getNotificationAppLaunchDetails";
    private static final String GET_NOTIFICATION_CHANNELS_ERROR_CODE = "getNotificationChannelsError";
    private static final String GET_NOTIFICATION_CHANNELS_METHOD = "getNotificationChannels";
    private static final String INITIALIZE_METHOD = "initialize";
    private static final String INPUT = "input";
    private static final String INPUT_RESULT = "FlutterLocalNotificationsPluginInputResult";
    private static final String INVALID_BIG_PICTURE_ERROR_CODE = "invalid_big_picture";
    private static final String INVALID_DRAWABLE_RESOURCE_ERROR_MESSAGE = "The resource %s could not be found. Please make sure it has been added as a drawable resource to your Android head project.";
    private static final String INVALID_ICON_ERROR_CODE = "invalid_icon";
    private static final String INVALID_LARGE_ICON_ERROR_CODE = "invalid_large_icon";
    private static final String INVALID_LED_DETAILS_ERROR_CODE = "invalid_led_details";
    private static final String INVALID_LED_DETAILS_ERROR_MESSAGE = "Must specify both ledOnMs and ledOffMs to configure the blink cycle on older versions of Android before Oreo";
    private static final String INVALID_RAW_RESOURCE_ERROR_MESSAGE = "The resource %s could not be found. Please make sure it has been added as a raw resource to your Android head project.";
    private static final String INVALID_SOUND_ERROR_CODE = "invalid_sound";
    private static final String METHOD_CHANNEL = "dexterous.com/flutter/local_notifications";
    static String NOTIFICATION_DETAILS = "notificationDetails";
    static final String NOTIFICATION_ID = "notificationId";
    private static final String NOTIFICATION_LAUNCHED_APP = "notificationLaunchedApp";
    static final int NOTIFICATION_PERMISSION_REQUEST_CODE = 1;
    private static final String NOTIFICATION_RESPONSE_TYPE = "notificationResponseType";
    static final String NOTIFICATION_TAG = "notificationTag";
    static final String PAYLOAD = "payload";
    private static final String PENDING_NOTIFICATION_REQUESTS_METHOD = "pendingNotificationRequests";
    private static final String PERIODICALLY_SHOW_METHOD = "periodicallyShow";
    private static final String PERIODICALLY_SHOW_WITH_DURATION = "periodicallyShowWithDuration";
    private static final String PERMISSION_REQUEST_IN_PROGRESS_ERROR_CODE = "permissionRequestInProgress";
    private static final String PERMISSION_REQUEST_IN_PROGRESS_ERROR_MESSAGE = "Another permission request is already in progress";
    private static final String REQUEST_EXACT_ALARMS_PERMISSION_METHOD = "requestExactAlarmsPermission";
    private static final String REQUEST_FULL_SCREEN_INTENT_PERMISSION_METHOD = "requestFullScreenIntentPermission";
    private static final String REQUEST_NOTIFICATIONS_PERMISSION_METHOD = "requestNotificationsPermission";
    private static final String SCHEDULED_NOTIFICATIONS = "scheduled_notifications";
    private static final String SELECT_FOREGROUND_NOTIFICATION_ACTION = "SELECT_FOREGROUND_NOTIFICATION";
    private static final String SELECT_NOTIFICATION = "SELECT_NOTIFICATION";
    private static final String SHARED_PREFERENCES_KEY = "notification_plugin_cache";
    private static final String SHOW_METHOD = "show";
    private static final String START_FOREGROUND_SERVICE = "startForegroundService";
    private static final String STOP_FOREGROUND_SERVICE = "stopForegroundService";
    private static final String TAG = "FLTLocalNotifPlugin";
    private static final String UNSUPPORTED_OS_VERSION_ERROR_CODE = "unsupported_os_version";
    private static final String ZONED_SCHEDULE_METHOD = "zonedSchedule";
    static d gson;
    private Context applicationContext;
    private PermissionRequestListener callback;
    private q channel;
    private Activity mainActivity;
    private PermissionRequestProgress permissionRequestProgress = PermissionRequestProgress.None;

    /* JADX INFO: renamed from: com.dexterous.flutterlocalnotifications.FlutterLocalNotificationsPlugin$5, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass5 {
        static final /* synthetic */ int[] $SwitchMap$com$dexterous$flutterlocalnotifications$models$IconSource;
        static final /* synthetic */ int[] $SwitchMap$com$dexterous$flutterlocalnotifications$models$NotificationStyle;
        static final /* synthetic */ int[] $SwitchMap$com$dexterous$flutterlocalnotifications$models$RepeatInterval;

        static {
            int[] iArr = new int[NotificationStyle.values().length];
            $SwitchMap$com$dexterous$flutterlocalnotifications$models$NotificationStyle = iArr;
            try {
                iArr[NotificationStyle.BigPicture.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$dexterous$flutterlocalnotifications$models$NotificationStyle[NotificationStyle.BigText.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$com$dexterous$flutterlocalnotifications$models$NotificationStyle[NotificationStyle.Inbox.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                $SwitchMap$com$dexterous$flutterlocalnotifications$models$NotificationStyle[NotificationStyle.Messaging.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                $SwitchMap$com$dexterous$flutterlocalnotifications$models$NotificationStyle[NotificationStyle.Media.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            int[] iArr2 = new int[IconSource.values().length];
            $SwitchMap$com$dexterous$flutterlocalnotifications$models$IconSource = iArr2;
            try {
                iArr2[IconSource.DrawableResource.ordinal()] = 1;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                $SwitchMap$com$dexterous$flutterlocalnotifications$models$IconSource[IconSource.BitmapFilePath.ordinal()] = 2;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                $SwitchMap$com$dexterous$flutterlocalnotifications$models$IconSource[IconSource.ContentUri.ordinal()] = 3;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                $SwitchMap$com$dexterous$flutterlocalnotifications$models$IconSource[IconSource.FlutterBitmapAsset.ordinal()] = 4;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                $SwitchMap$com$dexterous$flutterlocalnotifications$models$IconSource[IconSource.ByteArray.ordinal()] = 5;
            } catch (NoSuchFieldError unused10) {
            }
            int[] iArr3 = new int[RepeatInterval.values().length];
            $SwitchMap$com$dexterous$flutterlocalnotifications$models$RepeatInterval = iArr3;
            try {
                iArr3[RepeatInterval.EveryMinute.ordinal()] = 1;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                $SwitchMap$com$dexterous$flutterlocalnotifications$models$RepeatInterval[RepeatInterval.Hourly.ordinal()] = 2;
            } catch (NoSuchFieldError unused12) {
            }
            try {
                $SwitchMap$com$dexterous$flutterlocalnotifications$models$RepeatInterval[RepeatInterval.Daily.ordinal()] = 3;
            } catch (NoSuchFieldError unused13) {
            }
            try {
                $SwitchMap$com$dexterous$flutterlocalnotifications$models$RepeatInterval[RepeatInterval.Weekly.ordinal()] = 4;
            } catch (NoSuchFieldError unused14) {
            }
        }
    }

    public static class ExactAlarmPermissionException extends PluginException {
        public ExactAlarmPermissionException() {
            super(FlutterLocalNotificationsPlugin.EXACT_ALARMS_PERMISSION_ERROR_CODE, "Exact alarms are not permitted");
        }
    }

    public enum PermissionRequestProgress {
        None,
        RequestingNotificationPermission,
        RequestingExactAlarmsPermission,
        RequestingFullScreenIntentPermission
    }

    public static class PluginException extends RuntimeException {
        public final String code;

        public PluginException(String str, String str2) {
            super(str2);
            this.code = str;
        }
    }

    private static void applyGrouping(NotificationDetails notificationDetails, i iVar) {
        if (StringUtils.isNullOrEmpty(notificationDetails.groupKey).booleanValue()) {
            return;
        }
        iVar.f9510s = notificationDetails.groupKey;
        if (BooleanUtils.getValue(notificationDetails.setAsGroupSummary)) {
            iVar.t = true;
        }
        iVar.f9489E = notificationDetails.groupAlertBehavior.intValue();
    }

    private void areNotificationsEnabled(p pVar) {
        pVar.a(Boolean.valueOf(getNotificationManager(this.applicationContext).f9449b.areNotificationsEnabled()));
    }

    public static d buildGson() {
        if (gson == null) {
            RuntimeTypeAdapterFactory runtimeTypeAdapterFactoryRegisterSubtype = RuntimeTypeAdapterFactory.of(StyleInformation.class).registerSubtype(DefaultStyleInformation.class).registerSubtype(BigTextStyleInformation.class).registerSubtype(BigPictureStyleInformation.class).registerSubtype(InboxStyleInformation.class).registerSubtype(MessagingStyleInformation.class);
            f fVar = f.t;
            HashMap map = new HashMap();
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            LinkedList linkedList = new LinkedList();
            ScheduleMode.Deserializer deserializer = new ScheduleMode.Deserializer();
            TypeToken<?> typeToken = TypeToken.get((Type) ScheduleMode.class);
            arrayList.add(new u4.t(deserializer, typeToken, typeToken.getType() == typeToken.getRawType() ? true : $assertionsDisabled));
            Objects.requireNonNull(runtimeTypeAdapterFactoryRegisterSubtype);
            arrayList.add(runtimeTypeAdapterFactoryRegisterSubtype);
            ArrayList arrayList3 = new ArrayList(arrayList2.size() + arrayList.size() + 3);
            arrayList3.addAll(arrayList);
            Collections.reverse(arrayList3);
            ArrayList arrayList4 = new ArrayList(arrayList2);
            Collections.reverse(arrayList4);
            arrayList3.addAll(arrayList4);
            boolean z6 = p144x4.b.f10433a;
            HashMap map2 = new HashMap(map);
            new ArrayList(arrayList);
            new ArrayList(arrayList2);
            gson = new d(fVar, map2, arrayList3, new ArrayList(linkedList));
        }
        return gson;
    }

    private static E buildPerson(Context context, PersonDetails personDetails) {
        IconSource iconSource;
        if (personDetails == null) {
            return null;
        }
        boolean value = BooleanUtils.getValue(personDetails.bot);
        Object obj = personDetails.icon;
        IconCompat iconFromSource = (obj == null || (iconSource = personDetails.iconBitmapSource) == null) ? null : getIconFromSource(context, obj, iconSource);
        boolean value2 = BooleanUtils.getValue(personDetails.important);
        String str = personDetails.key;
        if (str == null) {
            str = null;
        }
        String str2 = personDetails.name;
        if (str2 == null) {
            str2 = null;
        }
        String str3 = personDetails.uri;
        String str4 = str3 != null ? str3 : null;
        E e6 = new E();
        e6.f9450a = str2;
        e6.f9451b = iconFromSource;
        e6.f9452c = str4;
        e6.f9453d = str;
        e6.f9454e = value;
        e6.f9455f = value2;
        return e6;
    }

    private static long calculateNextNotificationTrigger(long j6, long j7) {
        while (j6 < System.currentTimeMillis()) {
            j6 += j7;
        }
        return j6;
    }

    private static long calculateRepeatIntervalMilliseconds(NotificationDetails notificationDetails) {
        Integer num = notificationDetails.repeatIntervalMilliseconds;
        if (num != null) {
            return num.intValue();
        }
        int i6 = AnonymousClass5.$SwitchMap$com$dexterous$flutterlocalnotifications$models$RepeatInterval[notificationDetails.repeatInterval.ordinal()];
        if (i6 == 1) {
            return 60000L;
        }
        if (i6 == 2) {
            return 3600000L;
        }
        if (i6 != 3) {
            return i6 != 4 ? 0L : 604800000L;
        }
        return 86400000L;
    }

    private static Boolean canCreateNotificationChannel(Context context, NotificationChannelDetails notificationChannelDetails) {
        NotificationChannelAction notificationChannelAction;
        if (Build.VERSION.SDK_INT < 26) {
            return Boolean.FALSE;
        }
        NotificationChannel notificationChannel = ((NotificationManager) context.getSystemService("notification")).getNotificationChannel(notificationChannelDetails.id);
        return Boolean.valueOf((!(notificationChannel == null && ((notificationChannelAction = notificationChannelDetails.channelAction) == null || notificationChannelAction == NotificationChannelAction.CreateIfNotExists)) && (notificationChannel == null || notificationChannelDetails.channelAction != NotificationChannelAction.Update)) ? $assertionsDisabled : true);
    }

    private void cancel(n nVar, p pVar) {
        Map map = (Map) nVar.f3730b;
        cancelNotification((Integer) map.get(CANCEL_ID), (String) map.get(CANCEL_TAG));
        pVar.a(null);
    }

    private void cancelAllNotifications(p pVar) {
        getNotificationManager(this.applicationContext).f9449b.cancelAll();
        ArrayList<NotificationDetails> arrayListLoadScheduledNotifications = loadScheduledNotifications(this.applicationContext);
        if (arrayListLoadScheduledNotifications == null || arrayListLoadScheduledNotifications.isEmpty()) {
            pVar.a(null);
            return;
        }
        Intent intent = new Intent(this.applicationContext, (Class<?>) ScheduledNotificationReceiver.class);
        int size = arrayListLoadScheduledNotifications.size();
        int i6 = 0;
        while (i6 < size) {
            NotificationDetails notificationDetails = arrayListLoadScheduledNotifications.get(i6);
            i6++;
            getAlarmManager(this.applicationContext).cancel(getBroadcastPendingIntent(this.applicationContext, notificationDetails.id.intValue(), intent));
        }
        saveScheduledNotifications(this.applicationContext, new ArrayList());
        pVar.a(null);
    }

    private void cancelNotification(Integer num, String str) {
        getAlarmManager(this.applicationContext).cancel(getBroadcastPendingIntent(this.applicationContext, num.intValue(), new Intent(this.applicationContext, (Class<?>) ScheduledNotificationReceiver.class)));
        D notificationManager = getNotificationManager(this.applicationContext);
        if (str == null) {
            notificationManager.a(null, num.intValue());
        } else {
            notificationManager.a(str, num.intValue());
        }
        removeNotificationFromCache(this.applicationContext, num);
    }

    private static byte[] castObjectToByteArray(Object obj) {
        if (!(obj instanceof ArrayList)) {
            return (byte[]) obj;
        }
        ArrayList arrayList = (ArrayList) obj;
        byte[] bArr = new byte[arrayList.size()];
        for (int i6 = 0; i6 < arrayList.size(); i6++) {
            bArr[i6] = (byte) ((Double) arrayList.get(i6)).intValue();
        }
        return bArr;
    }

    private static void checkCanScheduleExactAlarms(AlarmManager alarmManager) {
        if (Build.VERSION.SDK_INT >= 31 && !alarmManager.canScheduleExactAlarms()) {
            throw new ExactAlarmPermissionException();
        }
    }

    private static w.s createMessage(Context context, MessageDetails messageDetails) {
        String str;
        w.s sVar = new w.s(messageDetails.text, messageDetails.timestamp.longValue(), buildPerson(context, messageDetails.person));
        String str2 = messageDetails.dataUri;
        if (str2 != null && (str = messageDetails.dataMimeType) != null) {
            Uri uri = Uri.parse(str2);
            sVar.f9530e = str;
            sVar.f9531f = uri;
        }
        return sVar;
    }

    public static Notification createNotification(Context context, NotificationDetails notificationDetails) {
        Intent intent;
        int i6;
        PendingIntent broadcast;
        IconSource iconSource;
        NotificationChannelDetails notificationChannelDetailsFromNotificationDetails = NotificationChannelDetails.fromNotificationDetails(notificationDetails);
        if (canCreateNotificationChannel(context, notificationChannelDetailsFromNotificationDetails).booleanValue()) {
            setupNotificationChannel(context, notificationChannelDetailsFromNotificationDetails);
        }
        Intent launchIntent = getLaunchIntent(context);
        launchIntent.setAction(SELECT_NOTIFICATION);
        launchIntent.putExtra(NOTIFICATION_ID, notificationDetails.id);
        launchIntent.putExtra(PAYLOAD, notificationDetails.payload);
        PendingIntent activity = PendingIntent.getActivity(context, notificationDetails.id.intValue(), launchIntent, 201326592);
        DefaultStyleInformation defaultStyleInformation = (DefaultStyleInformation) notificationDetails.styleInformation;
        i iVar = new i(context, notificationDetails.channelId);
        iVar.f9498e = i.b(defaultStyleInformation.htmlFormatTitle.booleanValue() ? fromHtml(notificationDetails.title) : notificationDetails.title);
        iVar.f9499f = i.b(defaultStyleInformation.htmlFormatBody.booleanValue() ? fromHtml(notificationDetails.body) : notificationDetails.body);
        iVar.f9491G.tickerText = i.b(notificationDetails.ticker);
        iVar.c(16, BooleanUtils.getValue(notificationDetails.autoCancel));
        iVar.f9500g = activity;
        iVar.f9504k = notificationDetails.priority.intValue();
        iVar.c(2, BooleanUtils.getValue(notificationDetails.ongoing));
        iVar.f9492H = BooleanUtils.getValue(notificationDetails.silent);
        iVar.c(8, BooleanUtils.getValue(notificationDetails.onlyAlertOnce));
        if (notificationDetails.actions != null) {
            int iIntValue = notificationDetails.id.intValue() * 16;
            for (NotificationAction notificationAction : notificationDetails.actions) {
                IconCompat iconFromSource = (TextUtils.isEmpty(notificationAction.icon) || (iconSource = notificationAction.iconSource) == null) ? null : getIconFromSource(context, notificationAction.icon, iconSource);
                Boolean bool = notificationAction.showsUserInterface;
                if (bool == null || !bool.booleanValue()) {
                    intent = new Intent(context, (Class<?>) ActionBroadcastReceiver.class);
                    intent.setAction(ActionBroadcastReceiver.ACTION_TAPPED);
                } else {
                    intent = getLaunchIntent(context);
                    intent.setAction(SELECT_FOREGROUND_NOTIFICATION_ACTION);
                }
                intent.putExtra(NOTIFICATION_ID, notificationDetails.id).putExtra(NOTIFICATION_TAG, notificationDetails.tag).putExtra(ACTION_ID, notificationAction.id).putExtra(CANCEL_NOTIFICATION, notificationAction.cancelNotification).putExtra(PAYLOAD, notificationDetails.payload);
                List<NotificationAction.NotificationActionInput> list = notificationAction.actionInputs;
                int i7 = (list == null || list.isEmpty()) ? 201326592 : Build.VERSION.SDK_INT >= 31 ? 167772160 : 134217728;
                Boolean bool2 = notificationAction.showsUserInterface;
                if (bool2 == null || !bool2.booleanValue()) {
                    i6 = iIntValue + 1;
                    broadcast = PendingIntent.getBroadcast(context, iIntValue, intent, i7);
                } else {
                    i6 = iIntValue + 1;
                    broadcast = PendingIntent.getActivity(context, iIntValue, intent, i7);
                }
                SpannableString spannableString = new SpannableString(notificationAction.title);
                if (notificationAction.titleColor != null) {
                    spannableString.setSpan(new ForegroundColorSpan(notificationAction.titleColor.intValue()), 0, spannableString.length(), 0);
                }
                C0475d c0475d = new C0475d(iconFromSource, spannableString, broadcast);
                Boolean bool3 = notificationAction.contextual;
                if (bool3 != null) {
                    c0475d.f9470h = bool3.booleanValue();
                }
                Boolean bool4 = notificationAction.showsUserInterface;
                if (bool4 != null) {
                    c0475d.f9469g = bool4.booleanValue();
                }
                Boolean bool5 = notificationAction.allowGeneratedReplies;
                if (bool5 != null) {
                    c0475d.f9466d = bool5.booleanValue();
                }
                List<NotificationAction.NotificationActionInput> list2 = notificationAction.actionInputs;
                if (list2 != null) {
                    for (NotificationAction.NotificationActionInput notificationActionInput : list2) {
                        HashSet hashSet = new HashSet();
                        Bundle bundle = new Bundle();
                        String str = notificationActionInput.label;
                        Boolean bool6 = notificationActionInput.allowFreeFormInput;
                        boolean zBooleanValue = bool6 != null ? bool6.booleanValue() : true;
                        List<String> list3 = notificationActionInput.allowedMimeTypes;
                        if (list3 != null) {
                            Iterator<String> it = list3.iterator();
                            while (it.hasNext()) {
                                hashSet.add(it.next());
                            }
                        }
                        List<String> list4 = notificationActionInput.choices;
                        G g7 = new G(str, list4 != null ? (CharSequence[]) list4.toArray(new CharSequence[0]) : null, zBooleanValue, bundle, hashSet);
                        if (c0475d.f9468f == null) {
                            c0475d.f9468f = new ArrayList();
                        }
                        c0475d.f9468f.add(g7);
                    }
                }
                iVar.f9495b.add(c0475d.a());
                iIntValue = i6;
            }
        }
        setSmallIcon(context, notificationDetails, iVar);
        iVar.d(getBitmapFromSource(context, notificationDetails.largeIcon, notificationDetails.largeIconBitmapSource));
        Integer num = notificationDetails.color;
        if (num != null) {
            iVar.f9515z = num.intValue();
        }
        Boolean bool7 = notificationDetails.colorized;
        if (bool7 != null) {
            iVar.f9512v = bool7.booleanValue();
            iVar.f9513w = true;
        }
        Boolean bool8 = notificationDetails.showWhen;
        if (bool8 != null) {
            iVar.f9505l = BooleanUtils.getValue(bool8);
        }
        Long l6 = notificationDetails.when;
        if (l6 != null) {
            iVar.f9491G.when = l6.longValue();
        }
        Boolean bool9 = notificationDetails.usesChronometer;
        if (bool9 != null) {
            iVar.f9506m = bool9.booleanValue();
        }
        Boolean bool10 = notificationDetails.chronometerCountDown;
        if (bool10 != null) {
            boolean zBooleanValue2 = bool10.booleanValue();
            if (iVar.y == null) {
                iVar.y = new Bundle();
            }
            iVar.y.putBoolean("android.chronometerCountDown", zBooleanValue2);
        }
        if (BooleanUtils.getValue(notificationDetails.fullScreenIntent)) {
            iVar.f9501h = activity;
            iVar.c(128, true);
        }
        if (!StringUtils.isNullOrEmpty(notificationDetails.shortcutId).booleanValue()) {
            iVar.C = notificationDetails.shortcutId;
        }
        if (!StringUtils.isNullOrEmpty(notificationDetails.subText).booleanValue()) {
            iVar.o = i.b(notificationDetails.subText);
        }
        Integer num2 = notificationDetails.number;
        if (num2 != null) {
            iVar.f9503j = num2.intValue();
        }
        setVisibility(notificationDetails, iVar);
        applyGrouping(notificationDetails, iVar);
        setSound(context, notificationDetails, iVar);
        setVibrationPattern(notificationDetails, iVar);
        setLights(notificationDetails, iVar);
        setStyle(context, notificationDetails, iVar);
        setProgress(notificationDetails, iVar);
        setCategory(notificationDetails, iVar);
        setTimeoutAfter(notificationDetails, iVar);
        Notification notificationA = iVar.a();
        int[] iArr = notificationDetails.additionalFlags;
        if (iArr != null && iArr.length > 0) {
            for (int i8 : iArr) {
                notificationA.flags = i8 | notificationA.flags;
            }
        }
        return notificationA;
    }

    private void createNotificationChannel(n nVar, p pVar) {
        setupNotificationChannel(this.applicationContext, NotificationChannelDetails.from((Map) nVar.f3730b));
        pVar.a(null);
    }

    private void createNotificationChannelGroup(n nVar, p pVar) {
        int i6 = Build.VERSION.SDK_INT;
        if (i6 >= 26) {
            NotificationChannelGroupDetails notificationChannelGroupDetailsFrom = NotificationChannelGroupDetails.from((Map) nVar.f3730b);
            NotificationManager notificationManager = (NotificationManager) this.applicationContext.getSystemService("notification");
            a.y();
            NotificationChannelGroup notificationChannelGroupE = a.e(notificationChannelGroupDetailsFrom.id, notificationChannelGroupDetailsFrom.name);
            if (i6 >= 28) {
                notificationChannelGroupE.setDescription(notificationChannelGroupDetailsFrom.description);
            }
            notificationManager.createNotificationChannelGroup(notificationChannelGroupE);
        }
        pVar.a(null);
    }

    private void deleteNotificationChannel(n nVar, p pVar) {
        if (Build.VERSION.SDK_INT >= 26) {
            ((NotificationManager) this.applicationContext.getSystemService("notification")).deleteNotificationChannel((String) nVar.f3730b);
        }
        pVar.a(null);
    }

    private void deleteNotificationChannelGroup(n nVar, p pVar) {
        if (Build.VERSION.SDK_INT >= 26) {
            ((NotificationManager) this.applicationContext.getSystemService("notification")).deleteNotificationChannelGroup((String) nVar.f3730b);
        }
        pVar.a(null);
    }

    private Map<String, Object> describeIcon(IconCompat iconCompat) {
        IconSource iconSource;
        String resourceEntryName;
        if (iconCompat == null) {
            return null;
        }
        int I6 = iconCompat.f4233a;
        if (I6 == -1) {
            I6 = h.I(iconCompat.f4234b);
        }
        if (I6 == 2) {
            iconSource = IconSource.DrawableResource;
            resourceEntryName = this.applicationContext.getResources().getResourceEntryName(iconCompat.h());
        } else {
            if (I6 != 4) {
                return null;
            }
            iconSource = IconSource.ContentUri;
            resourceEntryName = iconCompat.i().toString();
        }
        HashMap map = new HashMap();
        map.put(ClimateForcast.SOURCE, Integer.valueOf(iconSource.ordinal()));
        map.put("data", resourceEntryName);
        return map;
    }

    private Map<String, Object> describePerson(E e6) {
        if (e6 == null) {
            return null;
        }
        HashMap map = new HashMap();
        map.put(ExternalParsersConfigReaderMetKeys.METADATA_KEY_ATTR, e6.f9453d);
        map.put("name", e6.f9450a);
        map.put("uri", e6.f9452c);
        map.put("bot", Boolean.valueOf(e6.f9454e));
        map.put("important", Boolean.valueOf(e6.f9455f));
        map.put("icon", describeIcon(e6.f9451b));
        return map;
    }

    private NotificationDetails extractNotificationDetails(p pVar, Map<String, Object> map) {
        NotificationDetails notificationDetailsFrom = NotificationDetails.from(map);
        if (hasInvalidIcon(pVar, notificationDetailsFrom.icon) || hasInvalidLargeIcon(pVar, notificationDetailsFrom.largeIcon, notificationDetailsFrom.largeIconBitmapSource) || hasInvalidBigPictureResources(pVar, notificationDetailsFrom) || hasInvalidRawSoundResource(pVar, notificationDetailsFrom) || hasInvalidLedDetails(pVar, notificationDetailsFrom)) {
            return null;
        }
        return notificationDetailsFrom;
    }

    public static Map<String, Object> extractNotificationResponseMap(Intent intent) {
        int intExtra = intent.getIntExtra(NOTIFICATION_ID, 0);
        HashMap map = new HashMap();
        map.put(NOTIFICATION_ID, Integer.valueOf(intExtra));
        map.put(NOTIFICATION_TAG, intent.getStringExtra(NOTIFICATION_TAG));
        map.put(ACTION_ID, intent.getStringExtra(ACTION_ID));
        map.put(PAYLOAD, intent.getStringExtra(PAYLOAD));
        Bundle resultsFromIntent = RemoteInput.getResultsFromIntent(intent);
        if (resultsFromIntent != null) {
            map.put(INPUT, resultsFromIntent.getString(INPUT_RESULT));
        }
        if (SELECT_NOTIFICATION.equals(intent.getAction())) {
            map.put(NOTIFICATION_RESPONSE_TYPE, 0);
        }
        if (SELECT_FOREGROUND_NOTIFICATION_ACTION.equals(intent.getAction())) {
            map.put(NOTIFICATION_RESPONSE_TYPE, 1);
        }
        return map;
    }

    private static Spanned fromHtml(String str) {
        if (str == null) {
            return null;
        }
        return Html.fromHtml(str, 0);
    }

    private void getActiveNotificationMessagingStyle(n nVar, p pVar) {
        Notification notification;
        NotificationManager notificationManager = (NotificationManager) this.applicationContext.getSystemService("notification");
        try {
            Map map = (Map) nVar.f3730b;
            int iIntValue = ((Integer) map.get(CANCEL_ID)).intValue();
            String str = (String) map.get(CANCEL_TAG);
            StatusBarNotification[] activeNotifications = notificationManager.getActiveNotifications();
            int length = activeNotifications.length;
            int i6 = 0;
            int i7 = 0;
            while (true) {
                if (i7 >= length) {
                    notification = null;
                    break;
                }
                StatusBarNotification statusBarNotification = activeNotifications[i7];
                if (statusBarNotification.getId() != iIntValue || (str != null && !str.equals(statusBarNotification.getTag()))) {
                    i7++;
                }
                notification = statusBarNotification.getNotification();
                break;
            }
            if (notification == null) {
                pVar.a(null);
                return;
            }
            w.t tVarE = w.t.e(notification);
            if (tVarE == null) {
                pVar.a(null);
                return;
            }
            HashMap map2 = new HashMap();
            map2.put("groupConversation", Boolean.valueOf(tVarE.f()));
            map2.put("person", describePerson(tVarE.f9534g));
            map2.put("conversationTitle", tVarE.f9535h);
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = tVarE.f9532e;
            int size = arrayList2.size();
            while (i6 < size) {
                Object obj = arrayList2.get(i6);
                i6++;
                w.s sVar = (w.s) obj;
                HashMap map3 = new HashMap();
                map3.put("text", sVar.f9526a);
                map3.put("timestamp", Long.valueOf(sVar.f9527b));
                map3.put("person", describePerson(sVar.f9528c));
                arrayList.add(map3);
            }
            map2.put("messages", arrayList);
            pVar.a(map2);
        } catch (Throwable th) {
            pVar.c(GET_ACTIVE_NOTIFICATION_MESSAGING_STYLE_ERROR_CODE, th.getMessage(), Log.getStackTraceString(th));
        }
    }

    private void getActiveNotifications(p pVar) {
        try {
            StatusBarNotification[] activeNotifications = ((NotificationManager) this.applicationContext.getSystemService("notification")).getActiveNotifications();
            ArrayList arrayList = new ArrayList();
            for (StatusBarNotification statusBarNotification : activeNotifications) {
                HashMap map = new HashMap();
                map.put(CANCEL_ID, Integer.valueOf(statusBarNotification.getId()));
                Notification notification = statusBarNotification.getNotification();
                if (Build.VERSION.SDK_INT >= 26) {
                    map.put("channelId", notification.getChannelId());
                }
                map.put(CANCEL_TAG, statusBarNotification.getTag());
                map.put("groupKey", notification.getGroup());
                map.put("title", notification.extras.getCharSequence("android.title"));
                map.put("body", notification.extras.getCharSequence("android.text"));
                map.put("bigText", notification.extras.getCharSequence("android.bigText"));
                arrayList.add(map);
            }
            pVar.a(arrayList);
        } catch (Throwable th) {
            pVar.c(UNSUPPORTED_OS_VERSION_ERROR_CODE, th.getMessage(), Log.getStackTraceString(th));
        }
    }

    private static AlarmManager getAlarmManager(Context context) {
        return (AlarmManager) context.getSystemService("alarm");
    }

    private static Bitmap getBitmapFromSource(Context context, Object obj, BitmapSource bitmapSource) {
        if (bitmapSource == BitmapSource.DrawableResource) {
            return BitmapFactory.decodeResource(context.getResources(), getDrawableResourceId(context, (String) obj));
        }
        if (bitmapSource == BitmapSource.FilePath) {
            return BitmapFactory.decodeFile((String) obj);
        }
        if (bitmapSource != BitmapSource.ByteArray) {
            return null;
        }
        byte[] bArrCastObjectToByteArray = castObjectToByteArray(obj);
        return BitmapFactory.decodeByteArray(bArrCastObjectToByteArray, 0, bArrCastObjectToByteArray.length);
    }

    private static PendingIntent getBroadcastPendingIntent(Context context, int i6, Intent intent) {
        return PendingIntent.getBroadcast(context, i6, intent, 201326592);
    }

    private void getCallbackHandle(p pVar) {
        pVar.a(new IsolatePreferences(this.applicationContext).getCallbackHandle());
    }

    private static int getDrawableResourceId(Context context, String str) {
        return context.getResources().getIdentifier(str, DRAWABLE, context.getPackageName());
    }

    private static IconCompat getIconFromSource(Context context, Object obj, IconSource iconSource) {
        int i6 = AnonymousClass5.$SwitchMap$com$dexterous$flutterlocalnotifications$models$IconSource[iconSource.ordinal()];
        if (i6 == 1) {
            int drawableResourceId = getDrawableResourceId(context, (String) obj);
            PorterDuff.Mode mode = IconCompat.f4232k;
            context.getClass();
            return IconCompat.g(context.getResources(), context.getPackageName(), drawableResourceId);
        }
        if (i6 == 2) {
            return IconCompat.f(BitmapFactory.decodeFile((String) obj));
        }
        if (i6 == 3) {
            String str = (String) obj;
            PorterDuff.Mode mode2 = IconCompat.f4232k;
            str.getClass();
            IconCompat iconCompat = new IconCompat(4);
            iconCompat.f4234b = str;
            return iconCompat;
        }
        if (i6 != 4) {
            if (i6 != 5) {
                return null;
            }
            byte[] bArrCastObjectToByteArray = castObjectToByteArray(obj);
            int length = bArrCastObjectToByteArray.length;
            IconCompat iconCompat2 = new IconCompat(3);
            iconCompat2.f4234b = bArrCastObjectToByteArray;
            iconCompat2.f4237e = 0;
            iconCompat2.f4238f = length;
            return iconCompat2;
        }
        try {
            Q4.d dVar = (Q4.d) A4.d.L().f176s;
            AssetFileDescriptor assetFileDescriptorOpenFd = context.getAssets().openFd(((String) dVar.f3251e.f1488c) + File.separator + ((String) obj));
            FileInputStream fileInputStreamCreateInputStream = assetFileDescriptorOpenFd.createInputStream();
            IconCompat iconCompatF = IconCompat.f(BitmapFactory.decodeStream(fileInputStreamCreateInputStream));
            fileInputStreamCreateInputStream.close();
            assetFileDescriptorOpenFd.close();
            return iconCompatF;
        } catch (IOException e6) {
            throw new RuntimeException(e6);
        }
    }

    private static Intent getLaunchIntent(Context context) {
        return context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
    }

    private HashMap<String, Object> getMappedNotificationChannel(NotificationChannel notificationChannel) {
        HashMap<String, Object> map = new HashMap<>();
        if (Build.VERSION.SDK_INT >= 26) {
            map.put(CANCEL_ID, notificationChannel.getId());
            map.put("name", notificationChannel.getName());
            map.put("description", notificationChannel.getDescription());
            map.put("groupId", notificationChannel.getGroup());
            map.put("showBadge", Boolean.valueOf(notificationChannel.canShowBadge()));
            map.put("importance", Integer.valueOf(notificationChannel.getImportance()));
            Uri sound = notificationChannel.getSound();
            if (sound == null) {
                map.put("sound", null);
                map.put("playSound", Boolean.FALSE);
            } else {
                map.put("playSound", Boolean.TRUE);
                List listAsList = Arrays.asList(SoundSource.values());
                if (sound.getScheme().equals("android.resource")) {
                    String[] strArrSplit = sound.toString().split("/");
                    String str = strArrSplit[strArrSplit.length - 1];
                    Integer numTryParseInt = tryParseInt(str);
                    if (numTryParseInt == null) {
                        map.put("soundSource", Integer.valueOf(listAsList.indexOf(SoundSource.RawResource)));
                        map.put("sound", str);
                    } else {
                        try {
                            String resourceEntryName = this.applicationContext.getResources().getResourceEntryName(numTryParseInt.intValue());
                            if (resourceEntryName != null) {
                                map.put("soundSource", Integer.valueOf(listAsList.indexOf(SoundSource.RawResource)));
                                map.put("sound", resourceEntryName);
                            }
                        } catch (Exception unused) {
                            map.put("sound", null);
                            map.put("playSound", Boolean.FALSE);
                        }
                    }
                } else {
                    map.put("soundSource", Integer.valueOf(listAsList.indexOf(SoundSource.Uri)));
                    map.put("sound", sound.toString());
                }
            }
            map.put("enableVibration", Boolean.valueOf(notificationChannel.shouldVibrate()));
            map.put("vibrationPattern", notificationChannel.getVibrationPattern());
            map.put("enableLights", Boolean.valueOf(notificationChannel.shouldShowLights()));
            map.put("ledColor", Integer.valueOf(notificationChannel.getLightColor()));
            AudioAttributes audioAttributes = notificationChannel.getAudioAttributes();
            map.put("audioAttributesUsage", Integer.valueOf(audioAttributes == null ? 5 : audioAttributes.getUsage()));
        }
        return map;
    }

    private static String getNextFireDate(NotificationDetails notificationDetails) {
        ScheduledNotificationRepeatFrequency scheduledNotificationRepeatFrequency = notificationDetails.scheduledNotificationRepeatFrequency;
        if (scheduledNotificationRepeatFrequency == ScheduledNotificationRepeatFrequency.Daily) {
            return DateTimeFormatter.ISO_LOCAL_DATE_TIME.format(LocalDateTime.parse(notificationDetails.scheduledDateTime).plusDays(1L));
        }
        if (scheduledNotificationRepeatFrequency != ScheduledNotificationRepeatFrequency.Weekly) {
            return null;
        }
        return DateTimeFormatter.ISO_LOCAL_DATE_TIME.format(LocalDateTime.parse(notificationDetails.scheduledDateTime).plusWeeks(1L));
    }

    private static String getNextFireDateMatchingDateTimeComponents(NotificationDetails notificationDetails) {
        ZoneId zoneIdOf = ZoneId.of(notificationDetails.timeZoneName);
        ZonedDateTime zonedDateTimeOf = ZonedDateTime.of(LocalDateTime.parse(notificationDetails.scheduledDateTime), zoneIdOf);
        ZonedDateTime zonedDateTimeNow = ZonedDateTime.now(zoneIdOf);
        ZonedDateTime zonedDateTimeOf2 = ZonedDateTime.of(zonedDateTimeNow.getYear(), zonedDateTimeNow.getMonthValue(), zonedDateTimeNow.getDayOfMonth(), zonedDateTimeOf.getHour(), zonedDateTimeOf.getMinute(), zonedDateTimeOf.getSecond(), zonedDateTimeOf.getNano(), zoneIdOf);
        while (zonedDateTimeOf2.isBefore(zonedDateTimeNow)) {
            zonedDateTimeOf2 = zonedDateTimeOf2.plusDays(1L);
        }
        DateTimeComponents dateTimeComponents = notificationDetails.matchDateTimeComponents;
        if (dateTimeComponents == DateTimeComponents.Time) {
            return DateTimeFormatter.ISO_LOCAL_DATE_TIME.format(zonedDateTimeOf2);
        }
        if (dateTimeComponents == DateTimeComponents.DayOfWeekAndTime) {
            while (zonedDateTimeOf2.getDayOfWeek() != zonedDateTimeOf.getDayOfWeek()) {
                zonedDateTimeOf2 = zonedDateTimeOf2.plusDays(1L);
            }
            return DateTimeFormatter.ISO_LOCAL_DATE_TIME.format(zonedDateTimeOf2);
        }
        if (dateTimeComponents == DateTimeComponents.DayOfMonthAndTime) {
            while (zonedDateTimeOf2.getDayOfMonth() != zonedDateTimeOf.getDayOfMonth()) {
                zonedDateTimeOf2 = zonedDateTimeOf2.plusDays(1L);
            }
            return DateTimeFormatter.ISO_LOCAL_DATE_TIME.format(zonedDateTimeOf2);
        }
        if (dateTimeComponents != DateTimeComponents.DateAndTime) {
            return null;
        }
        while (true) {
            if (zonedDateTimeOf2.getMonthValue() == zonedDateTimeOf.getMonthValue() && zonedDateTimeOf2.getDayOfMonth() == zonedDateTimeOf.getDayOfMonth()) {
                return DateTimeFormatter.ISO_LOCAL_DATE_TIME.format(zonedDateTimeOf2);
            }
            zonedDateTimeOf2 = zonedDateTimeOf2.plusDays(1L);
        }
    }

    private void getNotificationAppLaunchDetails(p pVar) {
        HashMap map = new HashMap();
        Boolean bool = Boolean.FALSE;
        Activity activity = this.mainActivity;
        if (activity != null) {
            Intent intent = activity.getIntent();
            boolean z6 = (intent == null || !(SELECT_NOTIFICATION.equals(intent.getAction()) || SELECT_FOREGROUND_NOTIFICATION_ACTION.equals(intent.getAction())) || launchedActivityFromHistory(intent)) ? $assertionsDisabled : true;
            Boolean boolValueOf = Boolean.valueOf(z6);
            if (z6) {
                map.put("notificationResponse", extractNotificationResponseMap(intent));
            }
            bool = boolValueOf;
        }
        map.put(NOTIFICATION_LAUNCHED_APP, bool);
        pVar.a(map);
    }

    private void getNotificationChannels(p pVar) {
        List listC;
        try {
            D notificationManager = getNotificationManager(this.applicationContext);
            if (Build.VERSION.SDK_INT >= 26) {
                listC = B.a.c(notificationManager.f9449b);
            } else {
                notificationManager.getClass();
                listC = Collections.EMPTY_LIST;
            }
            ArrayList arrayList = new ArrayList();
            Iterator it = listC.iterator();
            while (it.hasNext()) {
                arrayList.add(getMappedNotificationChannel(a.c(it.next())));
            }
            pVar.a(arrayList);
        } catch (Throwable th) {
            pVar.c(GET_NOTIFICATION_CHANNELS_ERROR_CODE, th.getMessage(), Log.getStackTraceString(th));
        }
    }

    private static D getNotificationManager(Context context) {
        return new D(context);
    }

    private boolean hasInvalidBigPictureResources(p pVar, NotificationDetails notificationDetails) {
        if (notificationDetails.style == NotificationStyle.BigPicture) {
            BigPictureStyleInformation bigPictureStyleInformation = (BigPictureStyleInformation) notificationDetails.styleInformation;
            if (hasInvalidLargeIcon(pVar, bigPictureStyleInformation.largeIcon, bigPictureStyleInformation.largeIconBitmapSource)) {
                return true;
            }
            BitmapSource bitmapSource = bigPictureStyleInformation.bigPictureBitmapSource;
            if (bitmapSource == BitmapSource.DrawableResource) {
                String str = (String) bigPictureStyleInformation.bigPicture;
                if (!StringUtils.isNullOrEmpty(str).booleanValue() || isValidDrawableResource(this.applicationContext, str, pVar, INVALID_BIG_PICTURE_ERROR_CODE)) {
                    return $assertionsDisabled;
                }
                return true;
            }
            if (bitmapSource == BitmapSource.FilePath) {
                return StringUtils.isNullOrEmpty((String) bigPictureStyleInformation.bigPicture).booleanValue();
            }
            if (bitmapSource == BitmapSource.ByteArray) {
                byte[] bArr = (byte[]) bigPictureStyleInformation.bigPicture;
                if (bArr == null || bArr.length == 0) {
                    return true;
                }
                return $assertionsDisabled;
            }
        }
        return $assertionsDisabled;
    }

    private boolean hasInvalidIcon(p pVar, String str) {
        if (StringUtils.isNullOrEmpty(str).booleanValue() || isValidDrawableResource(this.applicationContext, str, pVar, INVALID_ICON_ERROR_CODE)) {
            return $assertionsDisabled;
        }
        return true;
    }

    private boolean hasInvalidLargeIcon(p pVar, Object obj, BitmapSource bitmapSource) {
        BitmapSource bitmapSource2 = BitmapSource.DrawableResource;
        if (bitmapSource != bitmapSource2 && bitmapSource != BitmapSource.FilePath) {
            if (bitmapSource == BitmapSource.ByteArray && ((byte[]) obj).length == 0) {
                return true;
            }
            return $assertionsDisabled;
        }
        String str = (String) obj;
        if (StringUtils.isNullOrEmpty(str).booleanValue() || bitmapSource != bitmapSource2 || isValidDrawableResource(this.applicationContext, str, pVar, INVALID_LARGE_ICON_ERROR_CODE)) {
            return $assertionsDisabled;
        }
        return true;
    }

    private boolean hasInvalidLedDetails(p pVar, NotificationDetails notificationDetails) {
        if (notificationDetails.ledColor == null) {
            return $assertionsDisabled;
        }
        if (notificationDetails.ledOnMs != null && notificationDetails.ledOffMs != null) {
            return $assertionsDisabled;
        }
        pVar.c(INVALID_LED_DETAILS_ERROR_CODE, INVALID_LED_DETAILS_ERROR_MESSAGE, null);
        return true;
    }

    private boolean hasInvalidRawSoundResource(p pVar, NotificationDetails notificationDetails) {
        if (StringUtils.isNullOrEmpty(notificationDetails.sound).booleanValue()) {
            return $assertionsDisabled;
        }
        SoundSource soundSource = notificationDetails.soundSource;
        if ((soundSource != null && soundSource != SoundSource.RawResource) || this.applicationContext.getResources().getIdentifier(notificationDetails.sound, "raw", this.applicationContext.getPackageName()) != 0) {
            return $assertionsDisabled;
        }
        pVar.c(INVALID_SOUND_ERROR_CODE, T.j("The resource ", notificationDetails.sound, " could not be found. Please make sure it has been added as a raw resource to your Android head project."), null);
        return true;
    }

    private void initialize(n nVar, p pVar) {
        String str = (String) ((Map) nVar.f3730b).get(DEFAULT_ICON);
        if (isValidDrawableResource(this.applicationContext, str, pVar, INVALID_ICON_ERROR_CODE)) {
            Long l6 = LongUtils.parseLong(nVar.a(DISPATCHER_HANDLE));
            Long l7 = LongUtils.parseLong(nVar.a(CALLBACK_HANDLE));
            if (l6 != null && l7 != null) {
                new IsolatePreferences(this.applicationContext).saveCallbackKeys(l6, l7);
            }
            this.applicationContext.getSharedPreferences(SHARED_PREFERENCES_KEY, 0).edit().putString(DEFAULT_ICON, str).apply();
            pVar.a(Boolean.TRUE);
        }
    }

    private static boolean isValidDrawableResource(Context context, String str, p pVar, String str2) {
        if (context.getResources().getIdentifier(str, DRAWABLE, context.getPackageName()) != 0) {
            return true;
        }
        pVar.c(str2, T.j("The resource ", str, " could not be found. Please make sure it has been added as a drawable resource to your Android head project."), null);
        return $assertionsDisabled;
    }

    private static boolean launchedActivityFromHistory(Intent intent) {
        if (intent == null || (intent.getFlags() & 1048576) != 1048576) {
            return $assertionsDisabled;
        }
        return true;
    }

    private static ArrayList<NotificationDetails> loadScheduledNotifications(Context context) {
        ArrayList<NotificationDetails> arrayList = new ArrayList<>();
        String string = context.getSharedPreferences(SCHEDULED_NOTIFICATIONS, 0).getString(SCHEDULED_NOTIFICATIONS, null);
        return string != null ? (ArrayList) buildGson().b(string, new TypeToken<ArrayList<NotificationDetails>>() { // from class: com.dexterous.flutterlocalnotifications.FlutterLocalNotificationsPlugin.1
        }.getType()) : arrayList;
    }

    private void pendingNotificationRequests(p pVar) {
        ArrayList<NotificationDetails> arrayListLoadScheduledNotifications = loadScheduledNotifications(this.applicationContext);
        ArrayList arrayList = new ArrayList();
        int size = arrayListLoadScheduledNotifications.size();
        int i6 = 0;
        while (i6 < size) {
            NotificationDetails notificationDetails = arrayListLoadScheduledNotifications.get(i6);
            i6++;
            NotificationDetails notificationDetails2 = notificationDetails;
            HashMap map = new HashMap();
            map.put(CANCEL_ID, notificationDetails2.id);
            map.put("title", notificationDetails2.title);
            map.put("body", notificationDetails2.body);
            map.put(PAYLOAD, notificationDetails2.payload);
            arrayList.add(map);
        }
        pVar.a(arrayList);
    }

    private void processForegroundNotificationAction(Intent intent, Map<String, Object> map) {
        if (intent.getBooleanExtra(CANCEL_NOTIFICATION, $assertionsDisabled)) {
            new D(this.applicationContext).a(null, ((Integer) map.get(NOTIFICATION_ID)).intValue());
        }
    }

    public static void removeNotificationFromCache(Context context, Integer num) {
        ArrayList<NotificationDetails> arrayListLoadScheduledNotifications = loadScheduledNotifications(context);
        Iterator<NotificationDetails> it = arrayListLoadScheduledNotifications.iterator();
        while (it.hasNext()) {
            if (it.next().id.equals(num)) {
                it.remove();
                break;
            }
        }
        saveScheduledNotifications(context, arrayListLoadScheduledNotifications);
    }

    private void repeat(n nVar, p pVar) {
        NotificationDetails notificationDetailsExtractNotificationDetails = extractNotificationDetails(pVar, (Map) nVar.f3730b);
        if (notificationDetailsExtractNotificationDetails != null) {
            try {
                repeatNotification(this.applicationContext, notificationDetailsExtractNotificationDetails, Boolean.TRUE);
                pVar.a(null);
            } catch (PluginException e6) {
                pVar.c(e6.code, e6.getMessage(), null);
            }
        }
    }

    private static void repeatNotification(Context context, NotificationDetails notificationDetails, Boolean bool) {
        long jCalculateRepeatIntervalMilliseconds = calculateRepeatIntervalMilliseconds(notificationDetails);
        long jLongValue = notificationDetails.calledAt.longValue();
        if (notificationDetails.repeatTime != null) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(System.currentTimeMillis());
            calendar.set(11, notificationDetails.repeatTime.hour.intValue());
            calendar.set(12, notificationDetails.repeatTime.minute.intValue());
            calendar.set(13, notificationDetails.repeatTime.second.intValue());
            Integer num = notificationDetails.day;
            if (num != null) {
                calendar.set(7, num.intValue());
            }
            jLongValue = calendar.getTimeInMillis();
        }
        long jCalculateNextNotificationTrigger = calculateNextNotificationTrigger(jLongValue, jCalculateRepeatIntervalMilliseconds);
        String strF = buildGson().f(notificationDetails);
        Intent intent = new Intent(context, (Class<?>) ScheduledNotificationReceiver.class);
        intent.putExtra(NOTIFICATION_DETAILS, strF);
        PendingIntent broadcastPendingIntent = getBroadcastPendingIntent(context, notificationDetails.id.intValue(), intent);
        AlarmManager alarmManager = getAlarmManager(context);
        if (notificationDetails.scheduleMode == null) {
            notificationDetails.scheduleMode = ScheduleMode.inexact;
        }
        if (notificationDetails.scheduleMode.useAllowWhileIdle()) {
            setupAllowWhileIdleAlarm(notificationDetails, alarmManager, jCalculateNextNotificationTrigger, broadcastPendingIntent);
        } else {
            alarmManager.setInexactRepeating(0, jCalculateNextNotificationTrigger, jCalculateRepeatIntervalMilliseconds, broadcastPendingIntent);
        }
        if (bool.booleanValue()) {
            saveScheduledNotification(context, notificationDetails);
        }
    }

    public static void rescheduleNotifications(Context context) {
        ArrayList<NotificationDetails> arrayListLoadScheduledNotifications = loadScheduledNotifications(context);
        int size = arrayListLoadScheduledNotifications.size();
        int i6 = 0;
        while (i6 < size) {
            NotificationDetails notificationDetails = arrayListLoadScheduledNotifications.get(i6);
            i6++;
            NotificationDetails notificationDetails2 = notificationDetails;
            try {
                if (notificationDetails2.repeatInterval != null || notificationDetails2.repeatIntervalMilliseconds != null) {
                    repeatNotification(context, notificationDetails2, Boolean.FALSE);
                } else if (notificationDetails2.timeZoneName != null) {
                    zonedScheduleNotification(context, notificationDetails2, Boolean.FALSE);
                } else {
                    scheduleNotification(context, notificationDetails2, Boolean.FALSE);
                }
            } catch (ExactAlarmPermissionException e6) {
                Log.e(TAG, e6.getMessage());
                removeNotificationFromCache(context, notificationDetails2.id);
            }
        }
    }

    private static Uri retrieveSoundResourceUri(Context context, String str, SoundSource soundSource) {
        if (StringUtils.isNullOrEmpty(str).booleanValue()) {
            return RingtoneManager.getDefaultUri(2);
        }
        if (soundSource != null && soundSource != SoundSource.RawResource) {
            if (soundSource == SoundSource.Uri) {
                return Uri.parse(str);
            }
            return null;
        }
        return Uri.parse("android.resource://" + context.getPackageName() + "/raw/" + str);
    }

    private static void saveScheduledNotification(Context context, NotificationDetails notificationDetails) {
        ArrayList<NotificationDetails> arrayListLoadScheduledNotifications = loadScheduledNotifications(context);
        ArrayList arrayList = new ArrayList();
        int size = arrayListLoadScheduledNotifications.size();
        int i6 = 0;
        while (i6 < size) {
            NotificationDetails notificationDetails2 = arrayListLoadScheduledNotifications.get(i6);
            i6++;
            NotificationDetails notificationDetails3 = notificationDetails2;
            if (!notificationDetails3.id.equals(notificationDetails.id)) {
                arrayList.add(notificationDetails3);
            }
        }
        arrayList.add(notificationDetails);
        saveScheduledNotifications(context, arrayList);
    }

    private static void saveScheduledNotifications(Context context, ArrayList<NotificationDetails> arrayList) {
        context.getSharedPreferences(SCHEDULED_NOTIFICATIONS, 0).edit().putString(SCHEDULED_NOTIFICATIONS, buildGson().f(arrayList)).apply();
    }

    public static void scheduleNextNotification(Context context, NotificationDetails notificationDetails) {
        try {
            if (notificationDetails.scheduledNotificationRepeatFrequency != null) {
                zonedScheduleNextNotification(context, notificationDetails);
                return;
            }
            if (notificationDetails.matchDateTimeComponents != null) {
                zonedScheduleNextNotificationMatchingDateComponents(context, notificationDetails);
                return;
            }
            if (notificationDetails.repeatInterval == null && notificationDetails.repeatIntervalMilliseconds == null) {
                removeNotificationFromCache(context, notificationDetails.id);
                return;
            }
            scheduleNextRepeatingNotification(context, notificationDetails);
        } catch (ExactAlarmPermissionException e6) {
            Log.e(TAG, e6.getMessage());
            removeNotificationFromCache(context, notificationDetails.id);
        }
    }

    private static void scheduleNextRepeatingNotification(Context context, NotificationDetails notificationDetails) {
        long jCalculateNextNotificationTrigger = calculateNextNotificationTrigger(notificationDetails.calledAt.longValue(), calculateRepeatIntervalMilliseconds(notificationDetails));
        String strF = buildGson().f(notificationDetails);
        Intent intent = new Intent(context, (Class<?>) ScheduledNotificationReceiver.class);
        intent.putExtra(NOTIFICATION_DETAILS, strF);
        PendingIntent broadcastPendingIntent = getBroadcastPendingIntent(context, notificationDetails.id.intValue(), intent);
        AlarmManager alarmManager = getAlarmManager(context);
        if (notificationDetails.scheduleMode == null) {
            notificationDetails.scheduleMode = ScheduleMode.exactAllowWhileIdle;
        }
        setupAllowWhileIdleAlarm(notificationDetails, alarmManager, jCalculateNextNotificationTrigger, broadcastPendingIntent);
        saveScheduledNotification(context, notificationDetails);
    }

    private static void scheduleNotification(Context context, NotificationDetails notificationDetails, Boolean bool) {
        String strF = buildGson().f(notificationDetails);
        Intent intent = new Intent(context, (Class<?>) ScheduledNotificationReceiver.class);
        intent.putExtra(NOTIFICATION_DETAILS, strF);
        setupAlarm(notificationDetails, getAlarmManager(context), notificationDetails.millisecondsSinceEpoch.longValue(), getBroadcastPendingIntent(context, notificationDetails.id.intValue(), intent));
        if (bool.booleanValue()) {
            saveScheduledNotification(context, notificationDetails);
        }
    }

    private Boolean sendNotificationPayloadMessage(Intent intent) {
        if (!SELECT_NOTIFICATION.equals(intent.getAction()) && !SELECT_FOREGROUND_NOTIFICATION_ACTION.equals(intent.getAction())) {
            return Boolean.FALSE;
        }
        Map<String, Object> mapExtractNotificationResponseMap = extractNotificationResponseMap(intent);
        if (SELECT_FOREGROUND_NOTIFICATION_ACTION.equals(intent.getAction())) {
            processForegroundNotificationAction(intent, mapExtractNotificationResponseMap);
        }
        this.channel.a("didReceiveNotificationResponse", mapExtractNotificationResponseMap, null);
        return Boolean.TRUE;
    }

    private void setActivity(Activity activity) {
        this.mainActivity = activity;
    }

    private static void setBigPictureStyle(Context context, NotificationDetails notificationDetails, i iVar) {
        BigPictureStyleInformation bigPictureStyleInformation = (BigPictureStyleInformation) notificationDetails.styleInformation;
        C0478g c0478g = new C0478g();
        if (bigPictureStyleInformation.contentTitle != null) {
            c0478g.f9552b = i.b(bigPictureStyleInformation.htmlFormatContentTitle.booleanValue() ? fromHtml(bigPictureStyleInformation.contentTitle) : bigPictureStyleInformation.contentTitle);
        }
        if (bigPictureStyleInformation.summaryText != null) {
            c0478g.f9553c = i.b(bigPictureStyleInformation.htmlFormatSummaryText.booleanValue() ? fromHtml(bigPictureStyleInformation.summaryText) : bigPictureStyleInformation.summaryText);
            c0478g.f9554d = true;
        }
        if (bigPictureStyleInformation.hideExpandedLargeIcon.booleanValue()) {
            c0478g.f9481f = null;
            c0478g.f9482g = true;
        } else {
            Object obj = bigPictureStyleInformation.largeIcon;
            if (obj != null) {
                Bitmap bitmapFromSource = getBitmapFromSource(context, obj, bigPictureStyleInformation.largeIconBitmapSource);
                c0478g.f9481f = bitmapFromSource == null ? null : IconCompat.f(bitmapFromSource);
                c0478g.f9482g = true;
            }
        }
        Bitmap bitmapFromSource2 = getBitmapFromSource(context, bigPictureStyleInformation.bigPicture, bigPictureStyleInformation.bigPictureBitmapSource);
        c0478g.f9480e = bitmapFromSource2 != null ? IconCompat.f(bitmapFromSource2) : null;
        iVar.f(c0478g);
    }

    private static void setBigTextStyle(NotificationDetails notificationDetails, i iVar) {
        BigTextStyleInformation bigTextStyleInformation = (BigTextStyleInformation) notificationDetails.styleInformation;
        w.h hVar = new w.h(0);
        if (bigTextStyleInformation.bigText != null) {
            hVar.f9485f = i.b(bigTextStyleInformation.htmlFormatBigText.booleanValue() ? fromHtml(bigTextStyleInformation.bigText) : bigTextStyleInformation.bigText);
        }
        if (bigTextStyleInformation.contentTitle != null) {
            hVar.f9552b = i.b(bigTextStyleInformation.htmlFormatContentTitle.booleanValue() ? fromHtml(bigTextStyleInformation.contentTitle) : bigTextStyleInformation.contentTitle);
        }
        if (bigTextStyleInformation.summaryText != null) {
            hVar.f9553c = i.b(bigTextStyleInformation.htmlFormatSummaryText.booleanValue() ? fromHtml(bigTextStyleInformation.summaryText) : bigTextStyleInformation.summaryText);
            hVar.f9554d = true;
        }
        iVar.f(hVar);
    }

    private void setCanScheduleExactNotifications(p pVar) {
        if (Build.VERSION.SDK_INT < 31) {
            pVar.a(Boolean.TRUE);
        } else {
            pVar.a(Boolean.valueOf(getAlarmManager(this.applicationContext).canScheduleExactAlarms()));
        }
    }

    private static void setCategory(NotificationDetails notificationDetails, i iVar) {
        String str = notificationDetails.category;
        if (str == null) {
            return;
        }
        iVar.f9514x = str;
    }

    private static void setInboxStyle(NotificationDetails notificationDetails, i iVar) {
        CharSequence charSequenceFromHtml;
        InboxStyleInformation inboxStyleInformation = (InboxStyleInformation) notificationDetails.styleInformation;
        w.h hVar = new w.h(1);
        if (inboxStyleInformation.contentTitle != null) {
            hVar.f9552b = i.b(inboxStyleInformation.htmlFormatContentTitle.booleanValue() ? fromHtml(inboxStyleInformation.contentTitle) : inboxStyleInformation.contentTitle);
        }
        if (inboxStyleInformation.summaryText != null) {
            hVar.f9553c = i.b(inboxStyleInformation.htmlFormatSummaryText.booleanValue() ? fromHtml(inboxStyleInformation.summaryText) : inboxStyleInformation.summaryText);
            hVar.f9554d = true;
        }
        ArrayList<String> arrayList = inboxStyleInformation.lines;
        if (arrayList != null) {
            int size = arrayList.size();
            int i6 = 0;
            while (i6 < size) {
                String str = arrayList.get(i6);
                i6++;
                String str2 = str;
                if (inboxStyleInformation.htmlFormatLines.booleanValue()) {
                    charSequenceFromHtml = str2;
                    charSequenceFromHtml = fromHtml(str2);
                }
                if (charSequenceFromHtml != null) {
                    ((ArrayList) hVar.f9485f).add(i.b(charSequenceFromHtml));
                }
            }
        }
        iVar.f(hVar);
    }

    private static void setLights(NotificationDetails notificationDetails, i iVar) {
        if (!BooleanUtils.getValue(notificationDetails.enableLights) || notificationDetails.ledOnMs == null || notificationDetails.ledOffMs == null) {
            return;
        }
        int iIntValue = notificationDetails.ledColor.intValue();
        int iIntValue2 = notificationDetails.ledOnMs.intValue();
        int iIntValue3 = notificationDetails.ledOffMs.intValue();
        Notification notification = iVar.f9491G;
        notification.ledARGB = iIntValue;
        notification.ledOnMS = iIntValue2;
        notification.ledOffMS = iIntValue3;
        notification.flags = ((iIntValue2 == 0 || iIntValue3 == 0) ? 0 : 1) | (notification.flags & (-2));
    }

    private static void setMediaStyle(i iVar) {
        iVar.f(new c(0));
    }

    private static void setMessagingStyle(Context context, NotificationDetails notificationDetails, i iVar) {
        MessagingStyleInformation messagingStyleInformation = (MessagingStyleInformation) notificationDetails.styleInformation;
        w.t tVar = new w.t(buildPerson(context, messagingStyleInformation.person));
        tVar.f9536i = Boolean.valueOf(BooleanUtils.getValue(messagingStyleInformation.groupConversation));
        String str = messagingStyleInformation.conversationTitle;
        if (str != null) {
            tVar.f9535h = str;
        }
        ArrayList<MessageDetails> arrayList = messagingStyleInformation.messages;
        if (arrayList != null && !arrayList.isEmpty()) {
            ArrayList<MessageDetails> arrayList2 = messagingStyleInformation.messages;
            int size = arrayList2.size();
            int i6 = 0;
            while (i6 < size) {
                MessageDetails messageDetails = arrayList2.get(i6);
                i6++;
                w.s sVarCreateMessage = createMessage(context, messageDetails);
                if (sVarCreateMessage != null) {
                    ArrayList arrayList3 = tVar.f9532e;
                    arrayList3.add(sVarCreateMessage);
                    if (arrayList3.size() > 25) {
                        arrayList3.remove(0);
                    }
                }
            }
        }
        iVar.f(tVar);
    }

    private static void setProgress(NotificationDetails notificationDetails, i iVar) {
        if (BooleanUtils.getValue(notificationDetails.showProgress)) {
            int iIntValue = notificationDetails.maxProgress.intValue();
            int iIntValue2 = notificationDetails.progress.intValue();
            boolean zBooleanValue = notificationDetails.indeterminate.booleanValue();
            iVar.f9508p = iIntValue;
            iVar.f9509q = iIntValue2;
            iVar.r = zBooleanValue;
        }
    }

    private static void setSmallIcon(Context context, NotificationDetails notificationDetails, i iVar) {
        if (!StringUtils.isNullOrEmpty(notificationDetails.icon).booleanValue()) {
            iVar.f9491G.icon = getDrawableResourceId(context, notificationDetails.icon);
            return;
        }
        String string = context.getSharedPreferences(SHARED_PREFERENCES_KEY, 0).getString(DEFAULT_ICON, null);
        if (StringUtils.isNullOrEmpty(string).booleanValue()) {
            iVar.f9491G.icon = notificationDetails.iconResourceId.intValue();
        } else {
            iVar.f9491G.icon = getDrawableResourceId(context, string);
        }
    }

    private static void setSound(Context context, NotificationDetails notificationDetails, i iVar) {
        if (BooleanUtils.getValue(notificationDetails.playSound)) {
            iVar.e(retrieveSoundResourceUri(context, notificationDetails.sound, notificationDetails.soundSource));
        } else {
            iVar.e(null);
        }
    }

    private static void setStyle(Context context, NotificationDetails notificationDetails, i iVar) {
        int i6 = AnonymousClass5.$SwitchMap$com$dexterous$flutterlocalnotifications$models$NotificationStyle[notificationDetails.style.ordinal()];
        if (i6 == 1) {
            setBigPictureStyle(context, notificationDetails, iVar);
            return;
        }
        if (i6 == 2) {
            setBigTextStyle(notificationDetails, iVar);
            return;
        }
        if (i6 == 3) {
            setInboxStyle(notificationDetails, iVar);
        } else if (i6 == 4) {
            setMessagingStyle(context, notificationDetails, iVar);
        } else {
            if (i6 != 5) {
                return;
            }
            setMediaStyle(iVar);
        }
    }

    private static void setTimeoutAfter(NotificationDetails notificationDetails, i iVar) {
        Long l6 = notificationDetails.timeoutAfter;
        if (l6 == null) {
            return;
        }
        iVar.f9488D = l6.longValue();
    }

    private static void setVibrationPattern(NotificationDetails notificationDetails, i iVar) {
        if (!BooleanUtils.getValue(notificationDetails.enableVibration)) {
            iVar.f9491G.vibrate = new long[]{0};
            return;
        }
        long[] jArr = notificationDetails.vibrationPattern;
        if (jArr == null || jArr.length <= 0) {
            return;
        }
        iVar.f9491G.vibrate = jArr;
    }

    private static void setVisibility(NotificationDetails notificationDetails, i iVar) {
        int i6;
        Integer num = notificationDetails.visibility;
        if (num == null) {
            return;
        }
        int iIntValue = num.intValue();
        if (iIntValue != 0) {
            i6 = 1;
            if (iIntValue != 1) {
                if (iIntValue != 2) {
                    throw new IllegalArgumentException("Unknown index: " + notificationDetails.visibility);
                }
                i6 = -1;
            }
        } else {
            i6 = 0;
        }
        iVar.f9486A = i6;
    }

    private static void setupAlarm(NotificationDetails notificationDetails, AlarmManager alarmManager, long j6, PendingIntent pendingIntent) {
        if (notificationDetails.scheduleMode == null) {
            notificationDetails.scheduleMode = ScheduleMode.exact;
        }
        if (notificationDetails.scheduleMode.useAllowWhileIdle()) {
            setupAllowWhileIdleAlarm(notificationDetails, alarmManager, j6, pendingIntent);
            return;
        }
        if (notificationDetails.scheduleMode.useExactAlarm()) {
            checkCanScheduleExactAlarms(alarmManager);
            alarmManager.setExact(0, j6, pendingIntent);
        } else if (!notificationDetails.scheduleMode.useAlarmClock()) {
            alarmManager.set(0, j6, pendingIntent);
        } else {
            checkCanScheduleExactAlarms(alarmManager);
            alarmManager.setAlarmClock(new AlarmManager.AlarmClockInfo(j6, pendingIntent), pendingIntent);
        }
    }

    private static void setupAllowWhileIdleAlarm(NotificationDetails notificationDetails, AlarmManager alarmManager, long j6, PendingIntent pendingIntent) {
        if (notificationDetails.scheduleMode.useExactAlarm()) {
            checkCanScheduleExactAlarms(alarmManager);
            alarmManager.setExactAndAllowWhileIdle(0, j6, pendingIntent);
        } else if (!notificationDetails.scheduleMode.useAlarmClock()) {
            alarmManager.setAndAllowWhileIdle(0, j6, pendingIntent);
        } else {
            checkCanScheduleExactAlarms(alarmManager);
            alarmManager.setAlarmClock(new AlarmManager.AlarmClockInfo(j6, pendingIntent), pendingIntent);
        }
    }

    private static void setupNotificationChannel(Context context, NotificationChannelDetails notificationChannelDetails) {
        Integer num;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
            a.m();
            NotificationChannel notificationChannelD = a.d(notificationChannelDetails.id, notificationChannelDetails.name, notificationChannelDetails.importance.intValue());
            notificationChannelD.setDescription(notificationChannelDetails.description);
            notificationChannelD.setGroup(notificationChannelDetails.groupId);
            if (notificationChannelDetails.playSound.booleanValue()) {
                Integer num2 = notificationChannelDetails.audioAttributesUsage;
                notificationChannelD.setSound(retrieveSoundResourceUri(context, notificationChannelDetails.sound, notificationChannelDetails.soundSource), new AudioAttributes.Builder().setUsage(num2 != null ? num2.intValue() : 5).build());
            } else {
                notificationChannelD.setSound(null, null);
            }
            notificationChannelD.enableVibration(BooleanUtils.getValue(notificationChannelDetails.enableVibration));
            long[] jArr = notificationChannelDetails.vibrationPattern;
            if (jArr != null && jArr.length > 0) {
                notificationChannelD.setVibrationPattern(jArr);
            }
            boolean value = BooleanUtils.getValue(notificationChannelDetails.enableLights);
            notificationChannelD.enableLights(value);
            if (value && (num = notificationChannelDetails.ledColor) != null) {
                notificationChannelD.setLightColor(num.intValue());
            }
            notificationChannelD.setShowBadge(BooleanUtils.getValue(notificationChannelDetails.showBadge));
            notificationManager.createNotificationChannel(notificationChannelD);
        }
    }

    private void show(n nVar, p pVar) {
        NotificationDetails notificationDetailsExtractNotificationDetails = extractNotificationDetails(pVar, (Map) nVar.f3730b);
        if (notificationDetailsExtractNotificationDetails != null) {
            showNotification(this.applicationContext, notificationDetailsExtractNotificationDetails);
            pVar.a(null);
        }
    }

    public static void showNotification(Context context, NotificationDetails notificationDetails) {
        Notification notificationCreateNotification = createNotification(context, notificationDetails);
        D notificationManager = getNotificationManager(context);
        String str = notificationDetails.tag;
        if (str != null) {
            notificationManager.b(str, notificationDetails.id.intValue(), notificationCreateNotification);
        } else {
            notificationManager.b(null, notificationDetails.id.intValue(), notificationCreateNotification);
        }
    }

    private void startForegroundService(n nVar, p pVar) {
        Map<String, Object> map = (Map) nVar.a("notificationData");
        Integer num = (Integer) nVar.a("startType");
        ArrayList arrayList = (ArrayList) nVar.a("foregroundServiceTypes");
        if (arrayList != null && arrayList.size() == 0) {
            pVar.c("ARGUMENT_ERROR", "If foregroundServiceTypes is non-null it must not be empty!", null);
            return;
        }
        if (map == null || num == null) {
            pVar.c("ARGUMENT_ERROR", "An argument passed to startForegroundService was null!", null);
            return;
        }
        NotificationDetails notificationDetailsExtractNotificationDetails = extractNotificationDetails(pVar, map);
        if (notificationDetailsExtractNotificationDetails != null) {
            if (notificationDetailsExtractNotificationDetails.id.intValue() == 0) {
                pVar.c("ARGUMENT_ERROR", "The id of the notification for a foreground service must not be 0!", null);
                return;
            }
            ForegroundServiceStartParameter foregroundServiceStartParameter = new ForegroundServiceStartParameter(notificationDetailsExtractNotificationDetails, num.intValue(), arrayList);
            Intent intent = new Intent(this.applicationContext, (Class<?>) ForegroundService.class);
            intent.putExtra(ForegroundServiceStartParameter.EXTRA, foregroundServiceStartParameter);
            Context context = this.applicationContext;
            if (Build.VERSION.SDK_INT >= 26) {
                B.a.s(context, intent);
            } else {
                context.startService(intent);
            }
            pVar.a(null);
        }
    }

    private void stopForegroundService(p pVar) {
        this.applicationContext.stopService(new Intent(this.applicationContext, (Class<?>) ForegroundService.class));
        pVar.a(null);
    }

    private Integer tryParseInt(String str) {
        try {
            return Integer.valueOf(Integer.parseInt(str));
        } catch (NumberFormatException unused) {
            return null;
        }
    }

    private void zonedSchedule(n nVar, p pVar) {
        NotificationDetails notificationDetailsExtractNotificationDetails = extractNotificationDetails(pVar, (Map) nVar.f3730b);
        if (notificationDetailsExtractNotificationDetails != null) {
            if (notificationDetailsExtractNotificationDetails.matchDateTimeComponents != null) {
                notificationDetailsExtractNotificationDetails.scheduledDateTime = getNextFireDateMatchingDateTimeComponents(notificationDetailsExtractNotificationDetails);
            }
            try {
                zonedScheduleNotification(this.applicationContext, notificationDetailsExtractNotificationDetails, Boolean.TRUE);
                pVar.a(null);
            } catch (PluginException e6) {
                pVar.c(e6.code, e6.getMessage(), null);
            }
        }
    }

    private static void zonedScheduleNextNotification(Context context, NotificationDetails notificationDetails) {
        String nextFireDate = getNextFireDate(notificationDetails);
        if (nextFireDate == null) {
            return;
        }
        notificationDetails.scheduledDateTime = nextFireDate;
        zonedScheduleNotification(context, notificationDetails, Boolean.TRUE);
    }

    private static void zonedScheduleNextNotificationMatchingDateComponents(Context context, NotificationDetails notificationDetails) {
        String nextFireDateMatchingDateTimeComponents = getNextFireDateMatchingDateTimeComponents(notificationDetails);
        if (nextFireDateMatchingDateTimeComponents == null) {
            return;
        }
        notificationDetails.scheduledDateTime = nextFireDateMatchingDateTimeComponents;
        zonedScheduleNotification(context, notificationDetails, Boolean.TRUE);
    }

    private static void zonedScheduleNotification(Context context, NotificationDetails notificationDetails, Boolean bool) {
        String strF = buildGson().f(notificationDetails);
        Intent intent = new Intent(context, (Class<?>) ScheduledNotificationReceiver.class);
        intent.putExtra(NOTIFICATION_DETAILS, strF);
        setupAlarm(notificationDetails, getAlarmManager(context), ZonedDateTime.of(LocalDateTime.parse(notificationDetails.scheduledDateTime), ZoneId.of(notificationDetails.timeZoneName)).toInstant().toEpochMilli(), getBroadcastPendingIntent(context, notificationDetails.id.intValue(), intent));
        if (bool.booleanValue()) {
            saveScheduledNotification(context, notificationDetails);
        }
    }

    @Override // W4.s
    public boolean onActivityResult(int i6, int i7, Intent intent) {
        if (i6 != 1 && i6 != 2 && i6 != 3) {
            return $assertionsDisabled;
        }
        if (this.permissionRequestProgress == PermissionRequestProgress.RequestingExactAlarmsPermission && i6 == 2 && Build.VERSION.SDK_INT >= 31) {
            this.callback.complete(getAlarmManager(this.applicationContext).canScheduleExactAlarms());
            this.permissionRequestProgress = PermissionRequestProgress.None;
        }
        if (this.permissionRequestProgress == PermissionRequestProgress.RequestingFullScreenIntentPermission && i6 == 3 && Build.VERSION.SDK_INT >= 34) {
            this.callback.complete(((NotificationManager) this.applicationContext.getSystemService("notification")).canUseFullScreenIntent());
            this.permissionRequestProgress = PermissionRequestProgress.None;
        }
        return true;
    }

    @Override // T4.a
    public void onAttachedToActivity(T4.b bVar) {
        v0 v0Var = (v0) bVar;
        v0Var.b(this);
        ((HashSet) v0Var.t).add(this);
        v0Var.a(this);
        Activity activity = (Activity) v0Var.r;
        this.mainActivity = activity;
        Intent intent = activity.getIntent();
        if (launchedActivityFromHistory(intent) || !SELECT_FOREGROUND_NOTIFICATION_ACTION.equals(intent.getAction())) {
            return;
        }
        processForegroundNotificationAction(intent, extractNotificationResponseMap(intent));
    }

    @Override // S4.b
    public void onAttachedToEngine(S4.a aVar) {
        this.applicationContext = aVar.f3496a;
        q qVar = new q(aVar.f3498c, METHOD_CHANNEL);
        this.channel = qVar;
        qVar.b(this);
    }

    @Override // T4.a
    public void onDetachedFromActivity() {
        this.mainActivity = null;
    }

    @Override // T4.a
    public void onDetachedFromActivityForConfigChanges() {
        this.mainActivity = null;
    }

    @Override // S4.b
    public void onDetachedFromEngine(S4.a aVar) {
        this.channel.b(null);
        this.channel = null;
        this.applicationContext = null;
    }

    @Override // W4.o
    public void onMethodCall(n nVar, final p pVar) {
        String str = nVar.f3729a;
        str.getClass();
        switch (str) {
            case "stopForegroundService":
                stopForegroundService(pVar);
                break;
            case "getNotificationChannels":
                getNotificationChannels(pVar);
                break;
            case "deleteNotificationChannelGroup":
                deleteNotificationChannelGroup(nVar, pVar);
                break;
            case "requestNotificationsPermission":
                requestNotificationsPermission(new PermissionRequestListener() { // from class: com.dexterous.flutterlocalnotifications.FlutterLocalNotificationsPlugin.2
                    @Override // com.dexterous.flutterlocalnotifications.PermissionRequestListener
                    public void complete(boolean z6) {
                        pVar.a(Boolean.valueOf(z6));
                    }

                    @Override // com.dexterous.flutterlocalnotifications.PermissionRequestListener
                    public void fail(String str2) {
                        pVar.c(FlutterLocalNotificationsPlugin.PERMISSION_REQUEST_IN_PROGRESS_ERROR_CODE, str2, null);
                    }
                });
                break;
            case "cancel":
                cancel(nVar, pVar);
                break;
            case "requestExactAlarmsPermission":
                requestExactAlarmsPermission(new PermissionRequestListener() { // from class: com.dexterous.flutterlocalnotifications.FlutterLocalNotificationsPlugin.3
                    @Override // com.dexterous.flutterlocalnotifications.PermissionRequestListener
                    public void complete(boolean z6) {
                        pVar.a(Boolean.valueOf(z6));
                    }

                    @Override // com.dexterous.flutterlocalnotifications.PermissionRequestListener
                    public void fail(String str2) {
                        pVar.c(FlutterLocalNotificationsPlugin.PERMISSION_REQUEST_IN_PROGRESS_ERROR_CODE, str2, null);
                    }
                });
                break;
            case "requestFullScreenIntentPermission":
                requestFullScreenIntentPermission(new PermissionRequestListener() { // from class: com.dexterous.flutterlocalnotifications.FlutterLocalNotificationsPlugin.4
                    @Override // com.dexterous.flutterlocalnotifications.PermissionRequestListener
                    public void complete(boolean z6) {
                        pVar.a(Boolean.valueOf(z6));
                    }

                    @Override // com.dexterous.flutterlocalnotifications.PermissionRequestListener
                    public void fail(String str2) {
                        pVar.c(FlutterLocalNotificationsPlugin.PERMISSION_REQUEST_IN_PROGRESS_ERROR_CODE, str2, null);
                    }
                });
                break;
            case "pendingNotificationRequests":
                pendingNotificationRequests(pVar);
                break;
            case "getNotificationAppLaunchDetails":
                getNotificationAppLaunchDetails(pVar);
                break;
            case "show":
                show(nVar, pVar);
                break;
            case "periodicallyShow":
                repeat(nVar, pVar);
                break;
            case "getActiveNotificationMessagingStyle":
                getActiveNotificationMessagingStyle(nVar, pVar);
                break;
            case "cancelAll":
                cancelAllNotifications(pVar);
                break;
            case "zonedSchedule":
                zonedSchedule(nVar, pVar);
                break;
            case "createNotificationChannelGroup":
                createNotificationChannelGroup(nVar, pVar);
                break;
            case "getCallbackHandle":
                getCallbackHandle(pVar);
                break;
            case "initialize":
                initialize(nVar, pVar);
                break;
            case "areNotificationsEnabled":
                areNotificationsEnabled(pVar);
                break;
            case "canScheduleExactNotifications":
                setCanScheduleExactNotifications(pVar);
                break;
            case "deleteNotificationChannel":
                deleteNotificationChannel(nVar, pVar);
                break;
            case "startForegroundService":
                startForegroundService(nVar, pVar);
                break;
            case "getActiveNotifications":
                getActiveNotifications(pVar);
                break;
            case "createNotificationChannel":
                createNotificationChannel(nVar, pVar);
                break;
            case "periodicallyShowWithDuration":
                repeat(nVar, pVar);
                break;
            default:
                pVar.b();
                break;
        }
    }

    @Override // W4.t
    public boolean onNewIntent(Intent intent) {
        Activity activity;
        boolean zBooleanValue = sendNotificationPayloadMessage(intent).booleanValue();
        if (zBooleanValue && (activity = this.mainActivity) != null) {
            activity.setIntent(intent);
        }
        return zBooleanValue;
    }

    @Override // T4.a
    public void onReattachedToActivityForConfigChanges(T4.b bVar) {
        v0 v0Var = (v0) bVar;
        v0Var.b(this);
        ((HashSet) v0Var.t).add(this);
        v0Var.a(this);
        this.mainActivity = (Activity) v0Var.r;
    }

    @Override // W4.u
    public boolean onRequestPermissionsResult(int i6, String[] strArr, int[] iArr) {
        PermissionRequestProgress permissionRequestProgress = this.permissionRequestProgress;
        PermissionRequestProgress permissionRequestProgress2 = PermissionRequestProgress.RequestingNotificationPermission;
        boolean z6 = $assertionsDisabled;
        if (permissionRequestProgress == permissionRequestProgress2 && i6 == 1) {
            if (iArr.length > 0 && iArr[0] == 0) {
                z6 = true;
            }
            this.callback.complete(z6);
            this.permissionRequestProgress = PermissionRequestProgress.None;
        }
        return z6;
    }

    public void requestExactAlarmsPermission(PermissionRequestListener permissionRequestListener) {
        PermissionRequestProgress permissionRequestProgress = this.permissionRequestProgress;
        PermissionRequestProgress permissionRequestProgress2 = PermissionRequestProgress.None;
        if (permissionRequestProgress != permissionRequestProgress2) {
            permissionRequestListener.fail(PERMISSION_REQUEST_IN_PROGRESS_ERROR_MESSAGE);
            return;
        }
        this.callback = permissionRequestListener;
        if (Build.VERSION.SDK_INT < 31) {
            permissionRequestListener.complete(true);
            return;
        }
        if (getAlarmManager(this.applicationContext).canScheduleExactAlarms()) {
            this.callback.complete(true);
            this.permissionRequestProgress = permissionRequestProgress2;
            return;
        }
        this.permissionRequestProgress = PermissionRequestProgress.RequestingExactAlarmsPermission;
        this.mainActivity.startActivityForResult(new Intent("android.settings.REQUEST_SCHEDULE_EXACT_ALARM", Uri.parse("package:" + this.applicationContext.getPackageName())), 2);
    }

    public void requestFullScreenIntentPermission(PermissionRequestListener permissionRequestListener) {
        PermissionRequestProgress permissionRequestProgress = this.permissionRequestProgress;
        PermissionRequestProgress permissionRequestProgress2 = PermissionRequestProgress.None;
        if (permissionRequestProgress != permissionRequestProgress2) {
            permissionRequestListener.fail(PERMISSION_REQUEST_IN_PROGRESS_ERROR_MESSAGE);
            return;
        }
        this.callback = permissionRequestListener;
        if (Build.VERSION.SDK_INT < 34) {
            permissionRequestListener.complete(true);
            return;
        }
        NotificationManager notificationManager = (NotificationManager) this.applicationContext.getSystemService("notification");
        getAlarmManager(this.applicationContext);
        if (notificationManager.canUseFullScreenIntent()) {
            this.callback.complete(true);
            this.permissionRequestProgress = permissionRequestProgress2;
            return;
        }
        this.permissionRequestProgress = PermissionRequestProgress.RequestingFullScreenIntentPermission;
        this.mainActivity.startActivityForResult(new Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT", Uri.parse("package:" + this.applicationContext.getPackageName())), 3);
    }

    public void requestNotificationsPermission(PermissionRequestListener permissionRequestListener) {
        PermissionRequestProgress permissionRequestProgress = this.permissionRequestProgress;
        PermissionRequestProgress permissionRequestProgress2 = PermissionRequestProgress.None;
        if (permissionRequestProgress != permissionRequestProgress2) {
            permissionRequestListener.fail(PERMISSION_REQUEST_IN_PROGRESS_ERROR_MESSAGE);
            return;
        }
        this.callback = permissionRequestListener;
        if (Build.VERSION.SDK_INT < 33) {
            this.callback.complete(new D(this.mainActivity).f9449b.areNotificationsEnabled());
        } else if (h.m(this.mainActivity, "android.permission.POST_NOTIFICATIONS") == 0) {
            this.callback.complete(true);
            this.permissionRequestProgress = permissionRequestProgress2;
        } else {
            this.permissionRequestProgress = PermissionRequestProgress.RequestingNotificationPermission;
            h.W(this.mainActivity, new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
    }
}
