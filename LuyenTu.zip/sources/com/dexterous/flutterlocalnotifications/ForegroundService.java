package com.dexterous.flutterlocalnotifications;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public class ForegroundService extends Service {
    private static int orCombineFlags(ArrayList<Integer> arrayList) {
        int iIntValue = arrayList.get(0).intValue();
        for (int i6 = 1; i6 < arrayList.size(); i6++) {
            iIntValue |= arrayList.get(i6).intValue();
        }
        return iIntValue;
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i6, int i7) {
        int i8 = Build.VERSION.SDK_INT;
        ForegroundServiceStartParameter foregroundServiceStartParameter = i8 >= 33 ? (ForegroundServiceStartParameter) intent.getSerializableExtra(ForegroundServiceStartParameter.EXTRA, ForegroundServiceStartParameter.class) : (ForegroundServiceStartParameter) intent.getSerializableExtra(ForegroundServiceStartParameter.EXTRA);
        Notification notificationCreateNotification = FlutterLocalNotificationsPlugin.createNotification(this, foregroundServiceStartParameter.notificationData);
        if (foregroundServiceStartParameter.foregroundServiceTypes == null || i8 < 29) {
            startForeground(foregroundServiceStartParameter.notificationData.id.intValue(), notificationCreateNotification);
        } else {
            startForeground(foregroundServiceStartParameter.notificationData.id.intValue(), notificationCreateNotification, orCombineFlags(foregroundServiceStartParameter.foregroundServiceTypes));
        }
        return foregroundServiceStartParameter.startMode;
    }
}
