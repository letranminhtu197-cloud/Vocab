package com.dexterous.flutterlocalnotifications;

import A4.d;
import M4.b;
import W4.g;
import W4.i;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.dexterous.flutterlocalnotifications.isolate.IsolatePreferences;
import io.flutter.view.FlutterCallbackInformation;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import w.D;

/* JADX INFO: loaded from: classes.dex */
public class ActionBroadcastReceiver extends BroadcastReceiver {
    public static final String ACTION_TAPPED = "com.dexterous.flutterlocalnotifications.ActionBroadcastReceiver.ACTION_TAPPED";
    private static final String TAG = "ActionBroadcastReceiver";
    private static ActionEventSink actionEventSink;
    private static b engine;
    IsolatePreferences preferences;

    public static class ActionEventSink implements i {
        final List<Map<String, Object>> cache;
        private g eventSink;

        private ActionEventSink() {
            this.cache = new ArrayList();
        }

        public void addItem(Map<String, Object> map) {
            g gVar = this.eventSink;
            if (gVar != null) {
                gVar.a(map);
            } else {
                this.cache.add(map);
            }
        }

        @Override // W4.i
        public void onCancel(Object obj) {
            this.eventSink = null;
        }

        @Override // W4.i
        public void onListen(Object obj, g gVar) {
            Iterator<Map<String, Object>> it = this.cache.iterator();
            while (it.hasNext()) {
                gVar.a(it.next());
            }
            this.cache.clear();
            this.eventSink = gVar;
        }
    }

    public ActionBroadcastReceiver(IsolatePreferences isolatePreferences) {
        this.preferences = isolatePreferences;
    }

    private void initializeEventChannel(N4.b bVar) {
        new d(bVar.f2685v, "dexterous.com/flutter/local_notifications/actions").R(actionEventSink);
    }

    private void startEngine(Context context) {
        if (engine != null) {
            Log.e(TAG, "Engine is already initialised");
            return;
        }
        Q4.d dVar = (Q4.d) d.L().f176s;
        dVar.d(context);
        dVar.a(context, null);
        engine = new b(context, null);
        FlutterCallbackInformation flutterCallbackInformationLookupDispatcherHandle = this.preferences.lookupDispatcherHandle();
        if (flutterCallbackInformationLookupDispatcherHandle == null) {
            Log.w(TAG, "Callback information could not be retrieved");
            return;
        }
        N4.b bVar = engine.f2463c;
        initializeEventChannel(bVar);
        bVar.a(new d(context.getAssets(), (String) dVar.f3251e.f1488c, flutterCallbackInformationLookupDispatcherHandle, 16));
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        if (ACTION_TAPPED.equalsIgnoreCase(intent.getAction())) {
            IsolatePreferences isolatePreferences = this.preferences;
            if (isolatePreferences == null) {
                isolatePreferences = new IsolatePreferences(context);
            }
            this.preferences = isolatePreferences;
            Map<String, Object> mapExtractNotificationResponseMap = FlutterLocalNotificationsPlugin.extractNotificationResponseMap(intent);
            if (intent.getBooleanExtra("cancelNotification", false)) {
                int iIntValue = ((Integer) mapExtractNotificationResponseMap.get("notificationId")).intValue();
                Object obj = mapExtractNotificationResponseMap.get("notificationTag");
                if (obj instanceof String) {
                    new D(context).a((String) obj, iIntValue);
                } else {
                    new D(context).a(null, iIntValue);
                }
            }
            if (actionEventSink == null) {
                actionEventSink = new ActionEventSink();
            }
            actionEventSink.addItem(mapExtractNotificationResponseMap);
            startEngine(context);
        }
    }

    public ActionBroadcastReceiver() {
    }
}
