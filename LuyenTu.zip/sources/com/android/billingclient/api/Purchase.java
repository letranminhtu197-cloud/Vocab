package com.android.billingclient.api;

import android.text.TextUtils;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes.dex */
public final class Purchase {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f4661a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f4662b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final JSONObject f4663c;

    public Purchase(String str, String str2) {
        this.f4661a = str;
        this.f4662b = str2;
        this.f4663c = new JSONObject(str);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Purchase)) {
            return false;
        }
        Purchase purchase = (Purchase) obj;
        return TextUtils.equals(this.f4661a, purchase.f4661a) && TextUtils.equals(this.f4662b, purchase.f4662b);
    }

    public final int hashCode() {
        return this.f4661a.hashCode();
    }

    public final String toString() {
        return "Purchase. Json: ".concat(String.valueOf(this.f4661a));
    }
}
