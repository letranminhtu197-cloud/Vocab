package com.android.billingclient.api;

import A5.h;
import android.app.PendingIntent;
import android.content.IntentSender;
import android.os.Bundle;
import android.os.ResultReceiver;
import com.google.android.gms.internal.play_billing.AbstractC0255w;
import io.flutter.plugin.editing.j;
import p015d.l;
import p029f.f;
import p030f0.C;
import p068l.m0;
import p101q0.G;

/* JADX INFO: loaded from: classes.dex */
public class ProxyBillingActivityV2 extends l {

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public f f4655K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public f f4656L;

    /* JADX INFO: renamed from: M, reason: collision with root package name */
    public f f4657M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public ResultReceiver f4658N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public ResultReceiver f4659O;

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public ResultReceiver f4660P;

    @Override // p015d.l, w.AbstractActivityC0473b, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f4655K = j(new C(4), new G(this));
        this.f4656L = j(new C(4), new j(this));
        this.f4657M = j(new C(4), new m0(this));
        if (bundle != null) {
            if (bundle.containsKey("alternative_billing_only_dialog_result_receiver")) {
                this.f4658N = (ResultReceiver) bundle.getParcelable("alternative_billing_only_dialog_result_receiver");
            }
            if (bundle.containsKey("external_payment_dialog_result_receiver")) {
                this.f4659O = (ResultReceiver) bundle.getParcelable("external_payment_dialog_result_receiver");
            }
            if (bundle.containsKey("external_offer_flow_result_receiver")) {
                this.f4660P = (ResultReceiver) bundle.getParcelable("external_offer_flow_result_receiver");
                return;
            }
            return;
        }
        AbstractC0255w.g("ProxyBillingActivityV2", "Launching Play Store billing dialog");
        if (getIntent().hasExtra("ALTERNATIVE_BILLING_ONLY_DIALOG_INTENT")) {
            PendingIntent pendingIntent = (PendingIntent) getIntent().getParcelableExtra("ALTERNATIVE_BILLING_ONLY_DIALOG_INTENT");
            this.f4658N = (ResultReceiver) getIntent().getParcelableExtra("alternative_billing_only_dialog_result_receiver");
            f fVar = this.f4655K;
            h.e(pendingIntent, "pendingIntent");
            IntentSender intentSender = pendingIntent.getIntentSender();
            h.d(intentSender, "getIntentSender(...)");
            fVar.K(new p029f.h(intentSender, null, 0, 0));
            return;
        }
        if (getIntent().hasExtra("external_payment_dialog_pending_intent")) {
            PendingIntent pendingIntent2 = (PendingIntent) getIntent().getParcelableExtra("external_payment_dialog_pending_intent");
            this.f4659O = (ResultReceiver) getIntent().getParcelableExtra("external_payment_dialog_result_receiver");
            f fVar2 = this.f4656L;
            h.e(pendingIntent2, "pendingIntent");
            IntentSender intentSender2 = pendingIntent2.getIntentSender();
            h.d(intentSender2, "getIntentSender(...)");
            fVar2.K(new p029f.h(intentSender2, null, 0, 0));
            return;
        }
        if (getIntent().hasExtra("external_offer_flow_pending_intent")) {
            PendingIntent pendingIntent3 = (PendingIntent) getIntent().getParcelableExtra("external_offer_flow_pending_intent");
            this.f4660P = (ResultReceiver) getIntent().getParcelableExtra("external_offer_flow_result_receiver");
            f fVar3 = this.f4657M;
            h.e(pendingIntent3, "pendingIntent");
            IntentSender intentSender3 = pendingIntent3.getIntentSender();
            h.d(intentSender3, "getIntentSender(...)");
            fVar3.K(new p029f.h(intentSender3, null, 0, 0));
        }
    }

    @Override // p015d.l, w.AbstractActivityC0473b, android.app.Activity
    public final void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        ResultReceiver resultReceiver = this.f4658N;
        if (resultReceiver != null) {
            bundle.putParcelable("alternative_billing_only_dialog_result_receiver", resultReceiver);
        }
        ResultReceiver resultReceiver2 = this.f4659O;
        if (resultReceiver2 != null) {
            bundle.putParcelable("external_payment_dialog_result_receiver", resultReceiver2);
        }
        ResultReceiver resultReceiver3 = this.f4660P;
        if (resultReceiver3 != null) {
            bundle.putParcelable("external_offer_flow_result_receiver", resultReceiver3);
        }
    }
}
