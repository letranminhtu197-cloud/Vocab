package com.android.billingclient.api;

import R0.C0135a;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.os.ResultReceiver;
import com.google.android.gms.internal.play_billing.AbstractC0255w;
import com.google.android.gms.internal.play_billing.m1;
import p103q2.C0442f;
import p103q2.z;

/* JADX INFO: loaded from: classes.dex */
public class ProxyBillingActivity extends Activity {
    public ResultReceiver r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f4651s;
    public boolean t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f4652u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public long f4653v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f4654w;

    public final Intent a(long j6, int i6) {
        Intent intentB = b();
        intentB.putExtra("RESPONSE_CODE", 6);
        intentB.putExtra("DEBUG_MESSAGE", "An internal error occurred.");
        C0135a c0135aA = C0442f.a();
        c0135aA.f3287b = 6;
        c0135aA.f3286a = "An internal error occurred.";
        C0442f c0442fA = c0135aA.a();
        int i7 = z.f8660a;
        intentB.putExtra("FAILURE_LOGGING_PAYLOAD", z.b(i6, 2, c0442fA, null, m1.f4896s).a());
        intentB.putExtra("INTENT_SOURCE", "LAUNCH_BILLING_FLOW");
        intentB.putExtra("billingClientTransactionId", j6);
        intentB.putExtra("wasServiceAutoReconnected", this.f4654w);
        return intentB;
    }

    public final Intent b() {
        Intent intent = new Intent("com.android.vending.billing.LOCAL_BROADCAST_PURCHASES_UPDATED");
        intent.setPackage(getApplicationContext().getPackageName());
        return intent;
    }

    /* JADX WARN: Code duplicated, block: B:17:0x0034 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:18:0x0036  */
    /* JADX WARN: Code duplicated, block: B:19:0x0038  */
    @Override // android.app.Activity
    public final void onActivityResult(int i6, int i7, Intent intent) {
        int i8;
        Intent intentA;
        int i9;
        ResultReceiver resultReceiver;
        Bundle extras;
        super.onActivityResult(i6, i7, intent);
        if (i6 == 100 || i6 == 110) {
            int i10 = AbstractC0255w.e(intent, "ProxyBillingActivity").f8596a;
            if (i7 != -1) {
                AbstractC0255w.h("ProxyBillingActivity", "Activity finished with resultCode " + i7 + " and billing's responseCode: " + i10);
            } else if (i10 != 0) {
                i7 = -1;
                AbstractC0255w.h("ProxyBillingActivity", "Activity finished with resultCode " + i7 + " and billing's responseCode: " + i10);
            } else {
                i7 = -1;
            }
            if (intent == null) {
                AbstractC0255w.h("ProxyBillingActivity", "Got null data with resultCode " + i7 + "!");
                if (i7 == -1) {
                    i8 = 113;
                } else if (i7 == 0) {
                    i8 = 114;
                } else if (i7 == 3) {
                    i8 = 115;
                } else if (i7 != 4) {
                    i8 = i7 != 5 ? 117 : 118;
                } else {
                    i8 = 116;
                }
                intentA = a(this.f4653v, i8);
            } else if (intent.getExtras() != null) {
                String string = intent.getExtras().getString("ALTERNATIVE_BILLING_USER_CHOICE_DATA");
                if (string != null) {
                    intentA = new Intent("com.android.vending.billing.ALTERNATIVE_BILLING");
                    intentA.setPackage(getApplicationContext().getPackageName());
                    intentA.putExtra("ALTERNATIVE_BILLING_USER_CHOICE_DATA", string);
                    intentA.putExtra("INTENT_SOURCE", "LAUNCH_BILLING_FLOW");
                } else {
                    Intent intentB = b();
                    intentB.putExtras(intent.getExtras());
                    intentB.putExtra("INTENT_SOURCE", "LAUNCH_BILLING_FLOW");
                    intentA = intentB;
                }
                intentA.putExtra("billingClientTransactionId", this.f4653v);
                intentA.putExtra("wasServiceAutoReconnected", this.f4654w);
            } else {
                AbstractC0255w.h("ProxyBillingActivity", "Got null bundle!");
                intentA = a(this.f4653v, 22);
            }
            if (i6 == 110) {
                intentA.putExtra("IS_FIRST_PARTY_PURCHASE", true);
            }
            sendBroadcast(intentA);
        } else if (i6 == 101) {
            if (intent == null) {
                AbstractC0255w.h("ProxyBillingActivity", "Got null intent!");
            } else {
                int i11 = AbstractC0255w.f4934a;
                Bundle extras2 = intent.getExtras();
                if (extras2 == null) {
                    AbstractC0255w.h("ProxyBillingActivity", "Unexpected null bundle received!");
                } else {
                    i9 = extras2.getInt("IN_APP_MESSAGE_RESPONSE_CODE", 0);
                }
                resultReceiver = this.r;
                if (resultReceiver != null) {
                    if (intent == null) {
                        extras = null;
                    } else {
                        extras = intent.getExtras();
                    }
                    resultReceiver.send(i9, extras);
                }
            }
            i9 = 0;
            resultReceiver = this.r;
            if (resultReceiver != null) {
                if (intent == null) {
                    extras = null;
                } else {
                    extras = intent.getExtras();
                }
                resultReceiver.send(i9, extras);
            }
        } else {
            AbstractC0255w.h("ProxyBillingActivity", "Got onActivityResult with wrong requestCode: " + i6 + "; skipping...");
        }
        this.f4651s = false;
        finish();
    }

    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        PendingIntent pendingIntent;
        super.onCreate(bundle);
        if (bundle != null) {
            AbstractC0255w.g("ProxyBillingActivity", "Launching Play Store billing flow from savedInstanceState");
            this.f4651s = bundle.getBoolean("send_cancelled_broadcast_if_finished", false);
            if (bundle.containsKey("in_app_message_result_receiver")) {
                this.r = (ResultReceiver) bundle.getParcelable("in_app_message_result_receiver");
            }
            this.t = bundle.getBoolean("IS_FLOW_FROM_FIRST_PARTY_CLIENT", false);
            this.f4652u = bundle.getInt("activity_code", 100);
            if (bundle.containsKey("billingClientTransactionId")) {
                this.f4653v = bundle.getLong("billingClientTransactionId");
            }
            if (bundle.containsKey("wasServiceAutoReconnected")) {
                this.f4654w = bundle.getBoolean("wasServiceAutoReconnected");
                return;
            }
            return;
        }
        AbstractC0255w.g("ProxyBillingActivity", "Launching Play Store billing flow");
        this.f4652u = 100;
        if (getIntent().hasExtra("BUY_INTENT")) {
            pendingIntent = (PendingIntent) getIntent().getParcelableExtra("BUY_INTENT");
            if (getIntent().hasExtra("IS_FLOW_FROM_FIRST_PARTY_CLIENT") && getIntent().getBooleanExtra("IS_FLOW_FROM_FIRST_PARTY_CLIENT", false)) {
                this.t = true;
                this.f4652u = 110;
            }
        } else if (getIntent().hasExtra("IN_APP_MESSAGE_INTENT")) {
            pendingIntent = (PendingIntent) getIntent().getParcelableExtra("IN_APP_MESSAGE_INTENT");
            this.r = (ResultReceiver) getIntent().getParcelableExtra("in_app_message_result_receiver");
            this.f4652u = 101;
        } else {
            pendingIntent = null;
        }
        if (getIntent().hasExtra("billingClientTransactionId")) {
            this.f4653v = getIntent().getLongExtra("billingClientTransactionId", 0L);
        }
        if (getIntent().hasExtra("wasServiceAutoReconnected")) {
            this.f4654w = getIntent().getBooleanExtra("wasServiceAutoReconnected", false);
        }
        try {
            this.f4651s = true;
            startIntentSenderForResult(pendingIntent.getIntentSender(), this.f4652u, new Intent(), 0, 0, 0);
        } catch (IntentSender.SendIntentException e6) {
            AbstractC0255w.i("ProxyBillingActivity", "Got exception while trying to start a purchase flow.", e6);
            ResultReceiver resultReceiver = this.r;
            if (resultReceiver != null) {
                resultReceiver.send(0, null);
            } else {
                Intent intentA = a(this.f4653v, 137);
                if (this.t) {
                    intentA.putExtra("IS_FIRST_PARTY_PURCHASE", true);
                }
                sendBroadcast(intentA);
            }
            this.f4651s = false;
            finish();
        }
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        super.onDestroy();
        if (isFinishing() && this.f4651s) {
            Intent intentB = b();
            intentB.putExtra("RESPONSE_CODE", 1);
            intentB.putExtra("DEBUG_MESSAGE", "Billing dialog closed.");
            if (this.t) {
                intentB.putExtra("IS_FIRST_PARTY_PURCHASE", true);
            }
            int i6 = this.f4652u;
            if (i6 == 110 || i6 == 100) {
                intentB.putExtra("INTENT_SOURCE", "LAUNCH_BILLING_FLOW");
                intentB.putExtra("billingClientTransactionId", this.f4653v);
            }
            sendBroadcast(intentB);
        }
    }

    @Override // android.app.Activity
    public final void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        ResultReceiver resultReceiver = this.r;
        if (resultReceiver != null) {
            bundle.putParcelable("in_app_message_result_receiver", resultReceiver);
        }
        bundle.putBoolean("send_cancelled_broadcast_if_finished", this.f4651s);
        bundle.putBoolean("IS_FLOW_FROM_FIRST_PARTY_CLIENT", this.t);
        bundle.putInt("activity_code", this.f4652u);
        bundle.putLong("billingClientTransactionId", this.f4653v);
        bundle.putBoolean("wasServiceAutoReconnected", this.f4654w);
    }
}
