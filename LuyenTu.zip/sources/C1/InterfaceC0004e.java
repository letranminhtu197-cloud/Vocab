package C1;

import android.os.IInterface;

/* JADX INFO: renamed from: C1.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0004e extends IInterface {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final String f483b = "androidx$room$IMultiInstanceInvalidationService".replace('$', '.');

    void j(int i6, String[] strArr);
}
