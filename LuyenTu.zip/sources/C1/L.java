package C1;

/* JADX INFO: loaded from: classes.dex */
public final class L extends p116s5.h implements p154z5.e {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f411v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public /* synthetic */ Object f412w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final /* synthetic */ U f413x;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public L(U u6, q5.c cVar) {
        super(2, cVar);
        this.f413x = u6;
    }

    @Override // p154z5.e
    public final Object g(Object obj, Object obj2) {
        return ((L) j((E1.p) obj, (q5.c) obj2)).l(p074l5.l.f7746a);
    }

    @Override // p116s5.a
    public final q5.c j(Object obj, q5.c cVar) {
        L l6 = new L(this.f413x, cVar);
        l6.f412w = obj;
        return l6;
    }

    @Override // p116s5.a
    public final Object l(Object obj) {
        int i6 = this.f411v;
        if (i6 != 0) {
            if (i6 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            X2.a.O(obj);
            return obj;
        }
        X2.a.O(obj);
        E1.p pVar = (E1.p) this.f412w;
        this.f411v = 1;
        Object objA = U.a(this.f413x, pVar, this);
        p109r5.a aVar = p109r5.a.r;
        return objA == aVar ? aVar : objA;
    }
}
