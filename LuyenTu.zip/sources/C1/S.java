package C1;

/* JADX INFO: loaded from: classes.dex */
public final class S extends p116s5.h implements p154z5.e {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public int f439A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public int f440B;
    public final /* synthetic */ EnumC0011l[] C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final /* synthetic */ U f441D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public final /* synthetic */ E f442E;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public EnumC0011l[] f443v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public U f444w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public E f445x;
    public int y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public int f446z;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public S(EnumC0011l[] enumC0011lArr, U u6, E e6, q5.c cVar) {
        super(2, cVar);
        this.C = enumC0011lArr;
        this.f441D = u6;
        this.f442E = e6;
    }

    @Override // p154z5.e
    public final Object g(Object obj, Object obj2) {
        return ((S) j((E1.p) obj, (q5.c) obj2)).l(p074l5.l.f7746a);
    }

    @Override // p116s5.a
    public final q5.c j(Object obj, q5.c cVar) {
        return new S(this.C, this.f441D, this.f442E, cVar);
    }

    /* JADX WARN: Code duplicated, block: B:11:0x0032  */
    /* JADX WARN: Code duplicated, block: B:13:0x003c  */
    /* JADX WARN: Code duplicated, block: B:15:0x0040 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:16:0x0042  */
    /* JADX WARN: Code duplicated, block: B:19:0x0057  */
    /* JADX WARN: Code duplicated, block: B:21:0x005a  */
    /* JADX WARN: Code duplicated, block: B:23:0x0060  */
    /* JADX WARN: Code duplicated, block: B:26:0x0075  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:26:0x0075 -> B:27:0x0076). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    @Override // p116s5.a
    public final java.lang.Object l(java.lang.Object r11) {
        /*
            r10 = this;
            int r0 = r10.f440B
            r1 = 2
            r2 = 1
            if (r0 == 0) goto L22
            if (r0 == r2) goto La
            if (r0 != r1) goto L1a
        La:
            int r0 = r10.f439A
            int r3 = r10.f446z
            int r4 = r10.y
            C1.E r5 = r10.f445x
            C1.U r6 = r10.f444w
            C1.l[] r7 = r10.f443v
            X2.a.O(r11)
            goto L58
        L1a:
            java.lang.IllegalStateException r11 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r11.<init>(r0)
            throw r11
        L22:
            X2.a.O(r11)
            C1.l[] r11 = r10.C
            int r0 = r11.length
            r3 = 0
            C1.U r4 = r10.f441D
            C1.E r5 = r10.f442E
            r7 = r11
            r11 = r3
            r6 = r4
        L30:
            if (r3 >= r0) goto L78
            r4 = r7[r3]
            int r8 = r11 + 1
            int r4 = r4.ordinal()
            if (r4 == 0) goto L75
            r5.a r9 = p109r5.a.r
            if (r4 == r2) goto L60
            if (r4 != r1) goto L5a
            r10.f443v = r7
            r10.f444w = r6
            r10.f445x = r5
            r10.y = r8
            r10.f446z = r3
            r10.f439A = r0
            r10.f440B = r1
            java.lang.Object r11 = C1.U.d(r6, r5, r11, r10)
            if (r11 != r9) goto L57
            goto L74
        L57:
            r4 = r8
        L58:
            r11 = r4
            goto L76
        L5a:
            D3.u r11 = new D3.u
            r11.<init>()
            throw r11
        L60:
            r10.f443v = r7
            r10.f444w = r6
            r10.f445x = r5
            r10.y = r8
            r10.f446z = r3
            r10.f439A = r0
            r10.f440B = r2
            java.lang.Object r11 = C1.U.c(r6, r5, r11, r10)
            if (r11 != r9) goto L57
        L74:
            return r9
        L75:
            r11 = r8
        L76:
            int r3 = r3 + r2
            goto L30
        L78:
            l5.l r11 = p074l5.l.f7746a
            return r11
        */
        throw new UnsupportedOperationException("Method not decompiled: C1.S.l(java.lang.Object):java.lang.Object");
    }
}
