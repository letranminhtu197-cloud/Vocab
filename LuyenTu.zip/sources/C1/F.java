package C1;

/* JADX INFO: loaded from: classes.dex */
public final class F extends p116s5.c {

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public Object f391u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public /* synthetic */ Object f392v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ U f393w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f394x;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public F(U u6, p116s5.c cVar) {
        super(cVar);
        this.f393w = u6;
    }

    @Override // p116s5.a
    public final Object l(Object obj) {
        this.f392v = obj;
        this.f394x |= Integer.MIN_VALUE;
        return U.a(this.f393w, null, this);
    }
}
