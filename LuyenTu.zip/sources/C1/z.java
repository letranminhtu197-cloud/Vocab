package C1;

/* JADX INFO: loaded from: classes.dex */
public abstract class z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f546a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f547b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f548c;

    public z(String str, int i6, String str2) {
        this.f546a = i6;
        this.f547b = str;
        this.f548c = str2;
    }

    public abstract void a(L1.a aVar);

    public abstract void b(L1.a aVar);

    public abstract void c(L1.a aVar);

    public abstract void d(L1.a aVar);

    public abstract void e(L1.a aVar);

    public abstract void f(L1.a aVar);

    public abstract y g(L1.a aVar);
}
