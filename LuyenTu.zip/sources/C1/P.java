package C1;

/* JADX INFO: loaded from: classes.dex */
public final class P extends p116s5.c {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final /* synthetic */ U f428A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public int f429B;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public InterfaceC0015p f430u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public String f431v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public String[] f432w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f433x;
    public int y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public /* synthetic */ Object f434z;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public P(U u6, p116s5.c cVar) {
        super(cVar);
        this.f428A = u6;
    }

    @Override // p116s5.a
    public final Object l(Object obj) {
        this.f434z = obj;
        this.f429B |= Integer.MIN_VALUE;
        return U.d(this.f428A, null, 0, this);
    }
}
