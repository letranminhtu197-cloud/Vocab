package C1;

import K5.InterfaceC0117v;

/* JADX INFO: loaded from: classes.dex */
public final class G extends p116s5.h implements p154z5.e {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f395v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ U f396w;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public G(U u6, q5.c cVar) {
        super(2, cVar);
        this.f396w = u6;
    }

    @Override // p154z5.e
    public final Object g(Object obj, Object obj2) {
        return ((G) j((InterfaceC0117v) obj, (q5.c) obj2)).l(p074l5.l.f7746a);
    }

    @Override // p116s5.a
    public final q5.c j(Object obj, q5.c cVar) {
        return new G(this.f396w, cVar);
    }

    @Override // p116s5.a
    public final Object l(Object obj) throws Throwable {
        int i6 = this.f395v;
        if (i6 == 0) {
            X2.a.O(obj);
            this.f395v = 1;
            Object objF = this.f396w.f(this);
            p109r5.a aVar = p109r5.a.r;
            if (objF == aVar) {
                return aVar;
            }
        } else {
            if (i6 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            X2.a.O(obj);
        }
        return p074l5.l.f7746a;
    }
}
