package C1;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class D {
    public static final D r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final D f390s;
    public static final /* synthetic */ D[] t;

    static {
        D d6 = new D("DEFERRED", 0);
        r = d6;
        D d7 = new D("IMMEDIATE", 1);
        f390s = d7;
        t = new D[]{d6, d7, new D("EXCLUSIVE", 2)};
    }

    public static D valueOf(String str) {
        return (D) Enum.valueOf(D.class, str);
    }

    public static D[] values() {
        return (D[]) t.clone();
    }
}
