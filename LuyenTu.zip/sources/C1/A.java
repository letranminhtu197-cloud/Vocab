package C1;

/* JADX INFO: loaded from: classes.dex */
public abstract class A implements q5.f {
    public static final Z3.e r = new Z3.e(7);
}
