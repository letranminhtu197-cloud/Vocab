package C1;

/* JADX INFO: loaded from: classes.dex */
public final class H extends p116s5.c {

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public I f397u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int[] f398v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public /* synthetic */ Object f399w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final /* synthetic */ I f400x;
    public int y;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public H(I i6, q5.c cVar) {
        super(cVar);
        this.f400x = i6;
    }

    @Override // p116s5.a
    public final Object l(Object obj) {
        this.f399w = obj;
        this.y |= Integer.MIN_VALUE;
        return this.f400x.h(null, this);
    }
}
