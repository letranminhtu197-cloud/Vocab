package C1;

import android.content.Context;
import androidx.work.impl.WorkDatabase;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.concurrent.Executor;

/* JADX INFO: renamed from: C1.u, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0019u {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Context f516b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f517c;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Executor f520f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Executor f521g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public p025e2.n f522h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f523i;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f530q;
    public boolean r;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ArrayList f518d = new ArrayList();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final ArrayList f519e = new ArrayList();

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final v f524j = v.r;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final long f525k = -1;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final p066k4.c f526l = new p066k4.c(3);

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final LinkedHashSet f527m = new LinkedHashSet();

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final LinkedHashSet f528n = new LinkedHashSet();
    public final ArrayList o = new ArrayList();

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f529p = true;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final boolean f531s = true;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final A5.e f515a = A5.o.a(WorkDatabase.class);

    public C0019u(Context context, String str) {
        this.f516b = context;
        this.f517c = str;
    }

    public final void a(G1.a... aVarArr) {
        for (G1.a aVar : aVarArr) {
            Integer numValueOf = Integer.valueOf(aVar.f1417a);
            LinkedHashSet linkedHashSet = this.f528n;
            linkedHashSet.add(numValueOf);
            linkedHashSet.add(Integer.valueOf(aVar.f1418b));
        }
        G1.a[] aVarArr2 = (G1.a[]) Arrays.copyOf(aVarArr, aVarArr.length);
        p066k4.c cVar = this.f526l;
        cVar.getClass();
        A5.h.e(aVarArr2, "migrations");
        for (G1.a aVar2 : aVarArr2) {
            cVar.G(aVar2);
        }
    }
}
