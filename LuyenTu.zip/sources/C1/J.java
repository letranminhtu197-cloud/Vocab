package C1;

/* JADX INFO: loaded from: classes.dex */
public final class J extends p116s5.h implements p154z5.e {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f403v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public /* synthetic */ Object f404w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final /* synthetic */ U f405x;
    public final /* synthetic */ int[] y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final /* synthetic */ String[] f406z;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public J(U u6, int[] iArr, String[] strArr, q5.c cVar) {
        super(2, cVar);
        this.f405x = u6;
        this.y = iArr;
        this.f406z = strArr;
    }

    @Override // p154z5.e
    public final Object g(Object obj, Object obj2) {
        ((J) j((N5.h) obj, (q5.c) obj2)).l(p074l5.l.f7746a);
        return p109r5.a.r;
    }

    @Override // p116s5.a
    public final q5.c j(Object obj, q5.c cVar) {
        J j6 = new J(this.f405x, this.y, this.f406z, cVar);
        j6.f404w = obj;
        return j6;
    }

    /* JADX WARN: Code restructure failed: missing block: B:31:0x0098, code lost:
    
        if (K5.AbstractC0120y.x((q5.h) r6, r20, r9) == r8) goto L32;
     */
    @Override // p116s5.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object l(java.lang.Object r21) {
        /*
            Method dump skipped, instruction units count: 237
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: C1.J.l(java.lang.Object):java.lang.Object");
    }
}
