package C1;

/* JADX INFO: renamed from: C1.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0015p {
    Object b(String str, p154z5.c cVar, p116s5.c cVar2);
}
