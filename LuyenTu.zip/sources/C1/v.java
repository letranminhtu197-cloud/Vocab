package C1;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public final class v {
    public static final v r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final v f532s;
    public static final v t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final /* synthetic */ v[] f533u;

    static {
        v vVar = new v("AUTOMATIC", 0);
        r = vVar;
        v vVar2 = new v("TRUNCATE", 1);
        f532s = vVar2;
        v vVar3 = new v("WRITE_AHEAD_LOGGING", 2);
        t = vVar3;
        f533u = new v[]{vVar, vVar2, vVar3};
    }

    public static v valueOf(String str) {
        return (v) Enum.valueOf(v.class, str);
    }

    public static v[] values() {
        return (v[]) f533u.clone();
    }
}
