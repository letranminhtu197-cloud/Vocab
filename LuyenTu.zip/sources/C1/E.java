package C1;

/* JADX INFO: loaded from: classes.dex */
public interface E extends InterfaceC0015p {
    Object a(D d6, p154z5.e eVar, p116s5.h hVar);

    Object d(p116s5.h hVar);
}
