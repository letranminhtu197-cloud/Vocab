package C1;

/* JADX INFO: renamed from: C1.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0001b {
    M1.d a();
}
