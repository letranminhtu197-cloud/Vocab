package C1;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;
import androidx.room.MultiInstanceInvalidationService;

/* JADX INFO: renamed from: C1.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class BinderC0009j extends Binder implements InterfaceC0004e {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ MultiInstanceInvalidationService f494e;

    public BinderC0009j(MultiInstanceInvalidationService multiInstanceInvalidationService) {
        this.f494e = multiInstanceInvalidationService;
        attachInterface(this, InterfaceC0004e.f483b);
    }

    @Override // C1.InterfaceC0004e
    public final void j(int i6, String[] strArr) {
        A5.h.e(strArr, "tables");
        MultiInstanceInvalidationService multiInstanceInvalidationService = this.f494e;
        synchronized (multiInstanceInvalidationService.t) {
            try {
                String str = (String) multiInstanceInvalidationService.f4505s.get(Integer.valueOf(i6));
                if (str == null) {
                    Log.w("ROOM", "Remote invalidation client ID not registered");
                    return;
                }
                int iBeginBroadcast = multiInstanceInvalidationService.t.beginBroadcast();
                for (int i7 = 0; i7 < iBeginBroadcast; i7++) {
                    try {
                        Object broadcastCookie = multiInstanceInvalidationService.t.getBroadcastCookie(i7);
                        A5.h.c(broadcastCookie, "null cannot be cast to non-null type kotlin.Int");
                        Integer num = (Integer) broadcastCookie;
                        int iIntValue = num.intValue();
                        String str2 = (String) multiInstanceInvalidationService.f4505s.get(num);
                        if (i6 != iIntValue && str.equals(str2)) {
                            try {
                                ((InterfaceC0003d) multiInstanceInvalidationService.t.getBroadcastItem(i7)).d(strArr);
                            } catch (RemoteException e6) {
                                Log.w("ROOM", "Error invoking a remote callback", e6);
                            }
                        }
                    } catch (Throwable th) {
                        multiInstanceInvalidationService.t.finishBroadcast();
                        throw th;
                    }
                }
                multiInstanceInvalidationService.t.finishBroadcast();
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    @Override // android.os.Binder
    public final boolean onTransact(int i6, Parcel parcel, Parcel parcel2, int i7) {
        String str = InterfaceC0004e.f483b;
        if (i6 >= 1 && i6 <= 16777215) {
            parcel.enforceInterface(str);
        }
        if (i6 == 1598968902) {
            parcel2.writeString(str);
            return true;
        }
        InterfaceC0003d interfaceC0003d = null;
        InterfaceC0003d interfaceC0003d2 = null;
        if (i6 != 1) {
            if (i6 != 2) {
                if (i6 != 3) {
                    return super.onTransact(i6, parcel, parcel2, i7);
                }
                j(parcel.readInt(), parcel.createStringArray());
                return true;
            }
            IBinder strongBinder = parcel.readStrongBinder();
            if (strongBinder != null) {
                IInterface iInterfaceQueryLocalInterface = strongBinder.queryLocalInterface(InterfaceC0003d.f482a);
                if (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof InterfaceC0003d)) {
                    C0002c c0002c = new C0002c();
                    c0002c.f481e = strongBinder;
                    interfaceC0003d2 = c0002c;
                } else {
                    interfaceC0003d2 = (InterfaceC0003d) iInterfaceQueryLocalInterface;
                }
            }
            int i8 = parcel.readInt();
            A5.h.e(interfaceC0003d2, "callback");
            MultiInstanceInvalidationService multiInstanceInvalidationService = this.f494e;
            synchronized (multiInstanceInvalidationService.t) {
                multiInstanceInvalidationService.t.unregister(interfaceC0003d2);
            }
            parcel2.writeNoException();
            return true;
        }
        IBinder strongBinder2 = parcel.readStrongBinder();
        if (strongBinder2 != null) {
            IInterface iInterfaceQueryLocalInterface2 = strongBinder2.queryLocalInterface(InterfaceC0003d.f482a);
            if (iInterfaceQueryLocalInterface2 == null || !(iInterfaceQueryLocalInterface2 instanceof InterfaceC0003d)) {
                C0002c c0002c2 = new C0002c();
                c0002c2.f481e = strongBinder2;
                interfaceC0003d = c0002c2;
            } else {
                interfaceC0003d = (InterfaceC0003d) iInterfaceQueryLocalInterface2;
            }
        }
        String string = parcel.readString();
        A5.h.e(interfaceC0003d, "callback");
        int i9 = 0;
        if (string != null) {
            MultiInstanceInvalidationService multiInstanceInvalidationService2 = this.f494e;
            synchronized (multiInstanceInvalidationService2.t) {
                try {
                    int i10 = multiInstanceInvalidationService2.r + 1;
                    multiInstanceInvalidationService2.r = i10;
                    if (multiInstanceInvalidationService2.t.register(interfaceC0003d, Integer.valueOf(i10))) {
                        multiInstanceInvalidationService2.f4505s.put(Integer.valueOf(i10), string);
                        i9 = i10;
                    } else {
                        multiInstanceInvalidationService2.r--;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        parcel2.writeNoException();
        parcel2.writeInt(i9);
        return true;
    }

    @Override // android.os.IInterface
    public final IBinder asBinder() {
        return this;
    }
}
