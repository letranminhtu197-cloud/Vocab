package C1;

/* JADX INFO: loaded from: classes.dex */
public final class I implements N5.h {
    public final /* synthetic */ A5.n r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ N5.h f401s;
    public final /* synthetic */ String[] t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ int[] f402u;

    public I(A5.n nVar, N5.h hVar, String[] strArr, int[] iArr) {
        this.r = nVar;
        this.f401s = hVar;
        this.t = strArr;
        this.f402u = iArr;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0052, code lost:
    
        if (r5.h(r15, r0) == r6) goto L35;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0096, code lost:
    
        if (r5.h(r15, r0) == r6) goto L35;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x0098, code lost:
    
        return r6;
     */
    @Override // N5.h
    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object h(int[] r14, q5.c r15) {
        /*
            r13 = this;
            boolean r0 = r15 instanceof C1.H
            if (r0 == 0) goto L13
            r0 = r15
            C1.H r0 = (C1.H) r0
            int r1 = r0.y
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.y = r1
            goto L18
        L13:
            C1.H r0 = new C1.H
            r0.<init>(r13, r15)
        L18:
            java.lang.Object r15 = r0.f399w
            int r1 = r0.y
            r2 = 2
            r3 = 1
            if (r1 == 0) goto L35
            if (r1 == r3) goto L2d
            if (r1 != r2) goto L25
            goto L2d
        L25:
            java.lang.IllegalStateException r14 = new java.lang.IllegalStateException
            java.lang.String r15 = "call to 'resume' before 'invoke' with coroutine"
            r14.<init>(r15)
            throw r14
        L2d:
            int[] r14 = r0.f398v
            C1.I r0 = r0.f397u
            X2.a.O(r15)
            goto L9a
        L35:
            X2.a.O(r15)
            A5.n r15 = r13.r
            java.lang.Object r1 = r15.r
            java.lang.String[] r4 = r13.t
            N5.h r5 = r13.f401s
            r5.a r6 = p109r5.a.r
            if (r1 != 0) goto L55
            java.util.Set r15 = p081m5.e.U(r4)
            r0.f397u = r13
            r0.f398v = r14
            r0.y = r3
            java.lang.Object r15 = r5.h(r15, r0)
            if (r15 != r6) goto L99
            goto L98
        L55:
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            int r3 = r4.length
            r7 = 0
            r8 = r7
        L5d:
            if (r7 >= r3) goto L82
            r9 = r4[r7]
            int r10 = r8 + 1
            java.lang.Object r11 = r15.r
            if (r11 == 0) goto L7a
            int[] r11 = (int[]) r11
            int[] r12 = r13.f402u
            r8 = r12[r8]
            r11 = r11[r8]
            r8 = r14[r8]
            if (r11 == r8) goto L76
            r1.add(r9)
        L76:
            int r7 = r7 + 1
            r8 = r10
            goto L5d
        L7a:
            java.lang.IllegalStateException r14 = new java.lang.IllegalStateException
            java.lang.String r15 = "Required value was null."
            r14.<init>(r15)
            throw r14
        L82:
            boolean r15 = r1.isEmpty()
            if (r15 != 0) goto L99
            java.util.Set r15 = p081m5.f.P0(r1)
            r0.f397u = r13
            r0.f398v = r14
            r0.y = r2
            java.lang.Object r15 = r5.h(r15, r0)
            if (r15 != r6) goto L99
        L98:
            return r6
        L99:
            r0 = r13
        L9a:
            A5.n r15 = r0.r
            r15.r = r14
            l5.l r14 = p074l5.l.f7746a
            return r14
        */
        throw new UnsupportedOperationException("Method not decompiled: C1.I.h(int[], q5.c):java.lang.Object");
    }
}
