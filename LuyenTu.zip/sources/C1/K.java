package C1;

/* JADX INFO: loaded from: classes.dex */
public final class K extends p116s5.c {

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public U f407u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public A4.b f408v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public /* synthetic */ Object f409w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final /* synthetic */ U f410x;
    public int y;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public K(U u6, p116s5.c cVar) {
        super(cVar);
        this.f410x = u6;
    }

    @Override // p116s5.a
    public final Object l(Object obj) {
        this.f409w = obj;
        this.y |= Integer.MIN_VALUE;
        return U.b(this.f410x, this);
    }
}
