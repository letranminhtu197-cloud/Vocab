package C1;

import java.util.ArrayDeque;
import java.util.concurrent.Executor;
import org.apache.tika.parser.external.ExternalParsersConfigReaderMetKeys;

/* JADX INFO: loaded from: classes.dex */
public final class C implements Executor {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final ArrayDeque f387s;
    public final Executor t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public Runnable f388u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final Object f389v;

    public C(Executor executor, int i6) {
        this.r = i6;
        switch (i6) {
            case 1:
                this.t = executor;
                this.f387s = new ArrayDeque();
                this.f389v = new Object();
                break;
            default:
                A5.h.e(executor, "executor");
                this.t = executor;
                this.f387s = new ArrayDeque();
                this.f389v = new Object();
                break;
        }
    }

    public final void a() {
        switch (this.r) {
            case 0:
                synchronized (this.f389v) {
                    Object objPoll = this.f387s.poll();
                    Runnable runnable = (Runnable) objPoll;
                    this.f388u = runnable;
                    if (objPoll != null) {
                        this.t.execute(runnable);
                    }
                    break;
                }
                return;
            default:
                Runnable runnable2 = (Runnable) this.f387s.poll();
                this.f388u = runnable2;
                if (runnable2 != null) {
                    this.t.execute(runnable2);
                    return;
                }
                return;
        }
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        switch (this.r) {
            case 0:
                A5.h.e(runnable, ExternalParsersConfigReaderMetKeys.COMMAND_TAG);
                synchronized (this.f389v) {
                    this.f387s.offer(new B(runnable, this, 0));
                    if (this.f388u == null) {
                        a();
                    }
                    break;
                }
                return;
            default:
                synchronized (this.f389v) {
                    try {
                        this.f387s.add(new E.a(this, runnable, 12));
                        if (this.f388u == null) {
                            a();
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                    break;
                }
                return;
        }
    }
}
