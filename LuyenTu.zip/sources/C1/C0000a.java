package C1;

import android.content.Context;
import android.content.Intent;
import java.io.File;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;

/* JADX INFO: renamed from: C1.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0000a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f462a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f463b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final M1.c f464c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final p066k4.c f465d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final List f466e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f467f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final v f468g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final Executor f469h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final Executor f470i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Intent f471j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final boolean f472k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final boolean f473l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final Set f474m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final String f475n;
    public final File o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final Callable f476p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final List f477q;
    public final List r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final boolean f478s;
    public final L1.b t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final q5.h f479u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f480v;

    public C0000a(Context context, String str, M1.c cVar, p066k4.c cVar2, List list, boolean z6, v vVar, Executor executor, Executor executor2, Intent intent, boolean z7, boolean z8, Set set, String str2, File file, Callable callable, List list2, List list3, boolean z9, L1.b bVar, q5.h hVar) {
        A5.h.e(context, "context");
        A5.h.e(cVar2, "migrationContainer");
        A5.h.e(executor, "queryExecutor");
        A5.h.e(executor2, "transactionExecutor");
        A5.h.e(list2, "typeConverters");
        A5.h.e(list3, "autoMigrationSpecs");
        this.f462a = context;
        this.f463b = str;
        this.f464c = cVar;
        this.f465d = cVar2;
        this.f466e = list;
        this.f467f = z6;
        this.f468g = vVar;
        this.f469h = executor;
        this.f470i = executor2;
        this.f471j = intent;
        this.f472k = z7;
        this.f473l = z8;
        this.f474m = set;
        this.f475n = str2;
        this.o = file;
        this.f476p = callable;
        this.f477q = list2;
        this.r = list3;
        this.f478s = z9;
        this.t = bVar;
        this.f479u = hVar;
        this.f480v = true;
    }
}
