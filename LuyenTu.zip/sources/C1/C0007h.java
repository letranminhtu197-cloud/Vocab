package C1;

import K5.InterfaceC0117v;

/* JADX INFO: renamed from: C1.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0007h extends p116s5.h implements p154z5.e {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f485v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ C0008i f486w;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0007h(C0008i c0008i, q5.c cVar) {
        super(2, cVar);
        this.f486w = c0008i;
    }

    @Override // p154z5.e
    public final Object g(Object obj, Object obj2) {
        return ((C0007h) j((InterfaceC0117v) obj, (q5.c) obj2)).l(p074l5.l.f7746a);
    }

    @Override // p116s5.a
    public final q5.c j(Object obj, q5.c cVar) {
        return new C0007h(this.f486w, cVar);
    }

    @Override // p116s5.a
    public final Object l(Object obj) {
        int i6 = this.f485v;
        if (i6 == 0) {
            X2.a.O(obj);
            this.f485v = 1;
            Object objA = this.f486w.a(this);
            p109r5.a aVar = p109r5.a.r;
            if (objA == aVar) {
                return aVar;
            }
        } else {
            if (i6 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            X2.a.O(obj);
        }
        return p074l5.l.f7746a;
    }
}
