package C1;

import K5.AbstractC0120y;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class w extends A5.g implements p154z5.a {
    @Override // p154z5.a
    public final Object b() throws Exception {
        x xVar = (x) this.f181s;
        P5.d dVar = xVar.f534a;
        if (dVar == null) {
            A5.h.j("coroutineScope");
            throw null;
        }
        AbstractC0120y.e(dVar, null);
        xVar.g();
        C0018t c0018t = xVar.f537d;
        if (c0018t != null) {
            c0018t.f513f.close();
            return p074l5.l.f7746a;
        }
        A5.h.j("connectionManager");
        throw null;
    }
}
