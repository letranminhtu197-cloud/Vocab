package C1;

import K5.C0104h;
import android.app.job.JobParameters;
import android.net.Uri;
import android.os.Process;
import android.os.StrictMode;
import androidx.credentials.playservices.CredentialProviderPlayServicesImpl;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.JobInfoSchedulerService;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.Callable;
import org.apache.tika.embedder.ExternalEmbedder;
import org.apache.tika.fork.ContentHandlerProxy;
import org.apache.tika.pipes.PipesServer;
import org.apache.tika.utils.XMLReaderUtils;
import p101q0.Y;
import p140x0.C0484f;
import p140x0.C0499v;
import p140x0.SurfaceHolderCallbackC0500w;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class B implements Runnable {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ Object f386s;
    public final /* synthetic */ Object t;

    public /* synthetic */ B(R3.a aVar, Runnable runnable) {
        this.r = 17;
        this.t = aVar;
        this.f386s = runnable;
    }

    @Override // java.lang.Runnable
    public final void run() throws IllegalAccessException, InvocationTargetException {
        p066k4.c cVar;
        A0.c cVar2;
        boolean z6 = false;
        switch (this.r) {
            case 0:
                Runnable runnable = (Runnable) this.f386s;
                C c2 = (C) this.t;
                try {
                    runnable.run();
                    return;
                } finally {
                    c2.a();
                }
            case 1:
                JobInfoSchedulerService jobInfoSchedulerService = (JobInfoSchedulerService) this.f386s;
                JobParameters jobParameters = (JobParameters) this.t;
                int i6 = JobInfoSchedulerService.r;
                jobInfoSchedulerService.jobFinished(jobParameters, false);
                return;
            case 2:
                ((C4.i) this.f386s).f614b.a(this.t);
                return;
            case 3:
                ((E0.b) ((D0.m) ((D0.s) this.f386s).t.f7289s).f697s.f915u.get(((D0.l) this.t).f661D)).c(true);
                return;
            case 4:
                E0.b bVar = (E0.b) this.f386s;
                Uri uri = (Uri) this.t;
                bVar.f908z = false;
                bVar.d(uri);
                return;
            case 5:
                F4.g gVar = (F4.g) this.f386s;
                F4.f fVar = (F4.f) this.t;
                gVar.getClass();
                fVar.f1254b.run();
                gVar.f1260f = fVar;
                gVar.f1259e.run();
                return;
            case 6:
                F4.i iVar = (F4.i) this.f386s;
                F4.g gVar2 = (F4.g) this.t;
                synchronized (iVar) {
                    try {
                        HashSet hashSet = new HashSet((HashSet) iVar.f1261s);
                        ((HashSet) iVar.t).remove(gVar2);
                        ((HashSet) iVar.f1261s).add(gVar2);
                        F4.f fVar2 = gVar2.f1260f;
                        if (fVar2 == null || (cVar = fVar2.f1253a) == null || !((F4.e) cVar.f7289s).k()) {
                            F4.f fVar3 = gVar2.f1260f;
                            if ((fVar3 != null ? fVar3.a() : null) != null) {
                                HashMap map = (HashMap) iVar.f1265x;
                                F4.f fVar4 = gVar2.f1260f;
                                map.remove(fVar4 != null ? fVar4.a() : null);
                            }
                        }
                        iVar.g(gVar2);
                        Iterator it = hashSet.iterator();
                        while (it.hasNext()) {
                            iVar.g((F4.g) it.next());
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                    break;
                }
                return;
            case 7:
                J0.P p6 = (J0.P) this.f386s;
                R0.A a5 = (R0.A) this.t;
                p6.f1713R = p6.f1705J == null ? a5 : new R0.t(-9223372036854775807L);
                p6.f1714S = a5.j();
                if (!p6.f1719Y && a5.j() == -9223372036854775807L) {
                    z6 = true;
                }
                p6.f1715T = z6;
                p6.f1716U = z6 ? 7 : 1;
                if (p6.f1709N) {
                    p6.f1729x.u(p6.f1714S, a5.g(), p6.f1715T);
                    return;
                } else {
                    p6.x();
                    return;
                }
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                ((C0104h) this.f386s).C((L5.e) this.t);
                return;
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                P0.x xVar = (P0.x) this.f386s;
                Y y = (Y) this.t;
                SurfaceHolderCallbackC0500w surfaceHolderCallbackC0500w = xVar.f2978b;
                int i7 = p117t0.s.f9002a;
                surfaceHolderCallbackC0500w.f9979a.f10018l.e(25, new C0499v(y));
                return;
            case 10:
                P0.x xVar2 = (P0.x) this.f386s;
                C0484f c0484f = (C0484f) this.t;
                synchronized (c0484f) {
                }
                SurfaceHolderCallbackC0500w surfaceHolderCallbackC0500w2 = xVar2.f2978b;
                int i8 = p117t0.s.f9002a;
                y0.d dVar = surfaceHolderCallbackC0500w2.f9979a.f10022q;
                y0.a aVarH = dVar.H((J0.E) dVar.f10448u.f838f);
                dVar.L(aVarH, 1020, new p053i4.E(aVarH, c0484f, 17));
                return;
            case 11:
                CredentialProviderPlayServicesImpl.runFallbackClearCredFlow$lambda$2$0$0$0((L.d) this.f386s, (Exception) this.t);
                return;
            case 12:
                CredentialProviderPlayServicesImpl.onClearCredential$lambda$3$0$0((L.d) this.f386s, (A5.n) this.t);
                return;
            case 13:
                Q3.p pVar = (Q3.p) this.f386s;
                p009b4.a aVar = (p009b4.a) this.t;
                if (pVar.f3236b != Q3.p.f3234d) {
                    throw new IllegalStateException("provide() can be called only once.");
                }
                synchronized (pVar) {
                    cVar2 = pVar.f3235a;
                    pVar.f3235a = null;
                    pVar.f3236b = aVar;
                    break;
                }
                cVar2.getClass();
                return;
            case 14:
                Q3.o oVar = (Q3.o) this.f386s;
                p009b4.a aVar2 = (p009b4.a) this.t;
                synchronized (oVar) {
                    try {
                        if (oVar.f3232b == null) {
                            oVar.f3231a.add(aVar2);
                        } else {
                            oVar.f3232b.add(aVar2.get());
                        }
                    } catch (Throwable th2) {
                        throw th2;
                    }
                }
                return;
            case 15:
                ((L.d) this.f386s).i(this.t);
                return;
            case 16:
                ((L.d) this.f386s).onResult((L.l) this.t);
                return;
            case PipesServer.TIMEOUT_EXIT_CODE /* 17 */:
                R3.a aVar3 = (R3.a) this.t;
                Runnable runnable2 = (Runnable) this.f386s;
                Process.setThreadPriority(aVar3.f3407c);
                StrictMode.ThreadPolicy threadPolicy = aVar3.f3408d;
                if (threadPolicy != null) {
                    StrictMode.setThreadPolicy(threadPolicy);
                }
                runnable2.run();
                return;
            case 18:
                Callable callable = (Callable) this.f386s;
                R3.h hVar = (R3.h) ((A0.i) this.t).f64s;
                try {
                    hVar.k(callable.call());
                    return;
                } catch (Exception e6) {
                    hVar.l(e6);
                    return;
                }
            case 19:
                ((S.c) this.f386s).c().i((M.d) this.t);
                return;
            case XMLReaderUtils.DEFAULT_MAX_ENTITY_EXPANSIONS /* 20 */:
                ((S.c) this.f386s).c().onResult((L.l) this.t);
                return;
            case 21:
                ((S.c) this.f386s).c().i(((A5.n) this.t).r);
                return;
            case 22:
                ((U.b) this.f386s).d().i((M.d) this.t);
                return;
            case 23:
                ((U.b) this.f386s).d().i(((A5.n) this.t).r);
                return;
            case 24:
                ((U.b) this.f386s).d().onResult((L.l) this.t);
                return;
            case 25:
                ((U.b) this.f386s).d().i((M.h) this.t);
                return;
            case 26:
                ExternalEmbedder.lambda$multiThreadedStreamCopy$2((InputStream) this.f386s, (OutputStream) this.t);
                return;
            case 27:
                String str = (String) this.f386s;
                p091o3.j jVar = (p091o3.j) this.t;
                HashMap map2 = p010b5.d.t;
                try {
                    try {
                        L3.g.f(str).b();
                        break;
                    } catch (IllegalStateException unused) {
                    }
                    jVar.b(null);
                    return;
                } catch (Exception e7) {
                    jVar.a(e7);
                    return;
                }
            case 28:
                c5.f fVar5 = (c5.f) this.f386s;
                p091o3.j jVar2 = (p091o3.j) this.t;
                try {
                    fVar5.e();
                    jVar2.b(null);
                    return;
                } catch (Exception e8) {
                    jVar2.a(e8);
                    return;
                }
            default:
                ((W4.h) this.f386s).a((ArrayList) this.t);
                return;
        }
    }

    public /* synthetic */ B(Object obj, Object obj2, int i6) {
        this.r = i6;
        this.f386s = obj;
        this.t = obj2;
    }
}
