package C1;

/* JADX INFO: loaded from: classes.dex */
public final class Q extends p116s5.c {

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public A4.b f435u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public /* synthetic */ Object f436v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ U f437w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f438x;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Q(U u6, p116s5.c cVar) {
        super(cVar);
        this.f437w = u6;
    }

    @Override // p116s5.a
    public final Object l(Object obj) {
        this.f436v = obj;
        this.f438x |= Integer.MIN_VALUE;
        return this.f437w.f(this);
    }
}
