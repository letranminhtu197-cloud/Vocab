package C1;

import android.os.IInterface;
import android.os.RemoteCallbackList;
import androidx.room.MultiInstanceInvalidationService;

/* JADX INFO: renamed from: C1.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class RemoteCallbackListC0010k extends RemoteCallbackList {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ MultiInstanceInvalidationService f495a;

    public RemoteCallbackListC0010k(MultiInstanceInvalidationService multiInstanceInvalidationService) {
        this.f495a = multiInstanceInvalidationService;
    }

    @Override // android.os.RemoteCallbackList
    public final void onCallbackDied(IInterface iInterface, Object obj) {
        A5.h.e((InterfaceC0003d) iInterface, "callback");
        A5.h.e(obj, "cookie");
        this.f495a.f4505s.remove((Integer) obj);
    }
}
