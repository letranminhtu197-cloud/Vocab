package C1;

import android.os.IBinder;
import android.os.Parcel;

/* JADX INFO: renamed from: C1.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0002c implements InterfaceC0003d {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public IBinder f481e;

    @Override // android.os.IInterface
    public final IBinder asBinder() {
        return this.f481e;
    }

    @Override // C1.InterfaceC0003d
    public final void d(String[] strArr) {
        Parcel parcelObtain = Parcel.obtain();
        try {
            parcelObtain.writeInterfaceToken(InterfaceC0003d.f482a);
            parcelObtain.writeStringArray(strArr);
            this.f481e.transact(1, parcelObtain, null, 1);
        } finally {
            parcelObtain.recycle();
        }
    }
}
