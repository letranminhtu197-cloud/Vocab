package C1;

/* JADX INFO: loaded from: classes.dex */
public final class r extends z {
    @Override // C1.z
    public final void a(L1.a aVar) {
        A5.h.e(aVar, "connection");
        throw new IllegalStateException("NOP delegate should never be called");
    }

    @Override // C1.z
    public final void b(L1.a aVar) {
        A5.h.e(aVar, "connection");
        throw new IllegalStateException("NOP delegate should never be called");
    }

    @Override // C1.z
    public final void c(L1.a aVar) {
        A5.h.e(aVar, "connection");
        throw new IllegalStateException("NOP delegate should never be called");
    }

    @Override // C1.z
    public final void d(L1.a aVar) {
        A5.h.e(aVar, "connection");
        throw new IllegalStateException("NOP delegate should never be called");
    }

    @Override // C1.z
    public final void e(L1.a aVar) {
        A5.h.e(aVar, "connection");
        throw new IllegalStateException("NOP delegate should never be called");
    }

    @Override // C1.z
    public final void f(L1.a aVar) {
        A5.h.e(aVar, "connection");
        throw new IllegalStateException("NOP delegate should never be called");
    }

    @Override // C1.z
    public final y g(L1.a aVar) {
        A5.h.e(aVar, "connection");
        throw new IllegalStateException("NOP delegate should never be called");
    }
}
