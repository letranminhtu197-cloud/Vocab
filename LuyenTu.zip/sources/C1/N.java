package C1;

import K5.InterfaceC0117v;

/* JADX INFO: loaded from: classes.dex */
public final class N extends p116s5.h implements p154z5.e {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f417v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ U f418w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final /* synthetic */ p154z5.a f419x;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public N(U u6, p154z5.a aVar, q5.c cVar) {
        super(2, cVar);
        this.f418w = u6;
        this.f419x = aVar;
    }

    @Override // p154z5.e
    public final Object g(Object obj, Object obj2) {
        return ((N) j((InterfaceC0117v) obj, (q5.c) obj2)).l(p074l5.l.f7746a);
    }

    @Override // p116s5.a
    public final q5.c j(Object obj, q5.c cVar) {
        return new N(this.f418w, this.f419x, cVar);
    }

    @Override // p116s5.a
    public final Object l(Object obj) {
        int i6 = this.f417v;
        p154z5.a aVar = this.f419x;
        try {
            if (i6 == 0) {
                X2.a.O(obj);
                U u6 = this.f418w;
                this.f417v = 1;
                obj = U.b(u6, this);
                p109r5.a aVar2 = p109r5.a.r;
                if (obj == aVar2) {
                    return aVar2;
                }
            } else {
                if (i6 != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                X2.a.O(obj);
            }
            aVar.b();
            return p074l5.l.f7746a;
        } catch (Throwable th) {
            aVar.b();
            throw th;
        }
    }
}
