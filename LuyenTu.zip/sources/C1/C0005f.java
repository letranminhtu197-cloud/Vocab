package C1;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteTransactionListener;
import android.os.CancellationSignal;
import java.lang.reflect.Method;
import org.apache.tika.fork.ContentHandlerProxy;

/* JADX INFO: renamed from: C1.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0005f implements p154z5.a {
    public final /* synthetic */ int r;

    public /* synthetic */ C0005f(int i6) {
        this.r = i6;
    }

    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Object, l5.d] */
    @Override // p154z5.a
    public final Object b() {
        Class<?> returnType;
        int i6 = 1;
        int i7 = 3;
        switch (this.r) {
            case 0:
                return p074l5.l.f7746a;
            case 1:
                return Boolean.TRUE;
            case 2:
                return 33554432;
            case 3:
                try {
                    Method declaredMethod = SQLiteDatabase.class.getDeclaredMethod("getThreadSession", null);
                    declaredMethod.setAccessible(true);
                    return declaredMethod;
                } catch (Throwable unused) {
                    return null;
                }
            case 4:
                try {
                    Method method = (Method) N1.b.f2625u.getValue();
                    if (method == null || (returnType = method.getReturnType()) == null) {
                        return null;
                    }
                    Class cls = Integer.TYPE;
                    return returnType.getDeclaredMethod("beginTransaction", cls, SQLiteTransactionListener.class, cls, CancellationSignal.class);
                } catch (Throwable unused2) {
                    return null;
                }
            case 5:
                return new c5.h(0);
            case 6:
                D5.a aVar = D5.e.r;
                return Integer.valueOf(D5.e.r.a().nextInt(2147418112) + 65536);
            case 7:
                return new c5.h(i6);
            case ContentHandlerProxy.IGNORABLE_WHITESPACE /* 8 */:
                return new c5.h(2);
            case ContentHandlerProxy.PROCESSING_INSTRUCTION /* 9 */:
                return new c5.h(i7);
            case 10:
                return new c5.h(i7);
            default:
                return new c5.h(4);
        }
    }
}
