package C1;

/* JADX INFO: loaded from: classes.dex */
public final class O extends p116s5.c {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public int f420A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public /* synthetic */ Object f421B;
    public final /* synthetic */ U C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public int f422D;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public U f423u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public InterfaceC0015p f424v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public String f425w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public String[] f426x;
    public int y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public int f427z;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public O(U u6, p116s5.c cVar) {
        super(cVar);
        this.C = u6;
    }

    @Override // p116s5.a
    public final Object l(Object obj) {
        this.f421B = obj;
        this.f422D |= Integer.MIN_VALUE;
        return U.c(this.C, null, 0, this);
    }
}
