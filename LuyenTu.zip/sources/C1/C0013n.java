package C1;

/* JADX INFO: renamed from: C1.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0013n extends p116s5.c {

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public /* synthetic */ Object f502u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ A0.i f503v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f504w;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0013n(A0.i iVar, p116s5.c cVar) {
        super(cVar);
        this.f503v = iVar;
    }

    @Override // p116s5.a
    public final Object l(Object obj) {
        this.f502u = obj;
        this.f504w |= Integer.MIN_VALUE;
        this.f503v.o(null, this);
        return p109r5.a.r;
    }
}
