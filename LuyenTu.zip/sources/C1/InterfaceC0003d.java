package C1;

import android.os.IInterface;

/* JADX INFO: renamed from: C1.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0003d extends IInterface {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final String f482a = "androidx$room$IMultiInstanceInvalidationCallback".replace('$', '.');

    void d(String[] strArr);
}
