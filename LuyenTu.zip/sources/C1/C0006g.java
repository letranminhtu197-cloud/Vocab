package C1;

import K5.b0;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

/* JADX INFO: renamed from: C1.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0006g extends A5.g implements p154z5.c {

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final /* synthetic */ int f484z;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0006g(int i6, Object obj, Class cls, String str, String str2, int i7, int i8, int i9) {
        super(i6, obj, cls, str, str2, i7, i8);
        this.f484z = i9;
    }

    @Override // p154z5.c
    public final Object a(Object obj) {
        switch (this.f484z) {
            case 0:
                A5.h.e((Set) obj, "p0");
                C0008i c0008i = (C0008i) this.f181s;
                ReentrantLock reentrantLock = c0008i.f490d;
                reentrantLock.lock();
                try {
                    List listL0 = p081m5.f.L0(c0008i.f489c.values());
                    reentrantLock.unlock();
                    Iterator it = listL0.iterator();
                    if (!it.hasNext()) {
                        return p074l5.l.f7746a;
                    }
                    ((AbstractC0014o) it.next()).getClass();
                    throw null;
                } catch (Throwable th) {
                    reentrantLock.unlock();
                    throw th;
                }
            default:
                ((b0) this.f181s).l((Throwable) obj);
                return p074l5.l.f7746a;
        }
    }
}
