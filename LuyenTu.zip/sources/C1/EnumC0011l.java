package C1;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: C1.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC0011l {
    public static final EnumC0011l r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final EnumC0011l f496s;
    public static final EnumC0011l t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final /* synthetic */ EnumC0011l[] f497u;

    static {
        EnumC0011l enumC0011l = new EnumC0011l("NO_OP", 0);
        r = enumC0011l;
        EnumC0011l enumC0011l2 = new EnumC0011l("ADD", 1);
        f496s = enumC0011l2;
        EnumC0011l enumC0011l3 = new EnumC0011l("REMOVE", 2);
        t = enumC0011l3;
        f497u = new EnumC0011l[]{enumC0011l, enumC0011l2, enumC0011l3};
    }

    public static EnumC0011l valueOf(String str) {
        return (EnumC0011l) Enum.valueOf(EnumC0011l.class, str);
    }

    public static EnumC0011l[] values() {
        return (EnumC0011l[]) f497u.clone();
    }
}
