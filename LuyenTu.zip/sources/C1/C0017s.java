package C1;

/* JADX INFO: renamed from: C1.s, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0017s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f506a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f507b;

    public C0017s(C0016q c0016q) {
        this.f507b = c0016q;
    }

    public C0017s(p018d2.l lVar) {
        A5.h.e(lVar, "clock");
        this.f507b = lVar;
    }
}
