package C1;

import androidx.work.impl.WorkDatabase_Impl;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.concurrent.locks.ReentrantLock;

/* JADX INFO: renamed from: C1.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0008i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final WorkDatabase_Impl f487a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final U f488b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final LinkedHashMap f489c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ReentrantLock f490d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final C0005f f491e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final C0005f f492f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Object f493g;

    public C0008i(WorkDatabase_Impl workDatabase_Impl, LinkedHashMap linkedHashMap, LinkedHashMap linkedHashMap2, String... strArr) {
        this.f487a = workDatabase_Impl;
        U u6 = new U(workDatabase_Impl, linkedHashMap, linkedHashMap2, strArr, workDatabase_Impl.f543j, new C0006g(1, this, C0008i.class, "notifyInvalidatedObservers", "notifyInvalidatedObservers(Ljava/util/Set;)V", 0, 0, 0));
        this.f488b = u6;
        this.f489c = new LinkedHashMap();
        this.f490d = new ReentrantLock();
        this.f491e = new C0005f(this);
        this.f492f = new C0005f(this);
        A5.h.d(Collections.newSetFromMap(new IdentityHashMap()), "newSetFromMap(...)");
        this.f493g = new Object();
        u6.f461k = new B4.o(this, 1);
    }

    public final Object a(p116s5.h hVar) {
        Object objF;
        WorkDatabase_Impl workDatabase_Impl = this.f487a;
        return ((!workDatabase_Impl.k() || workDatabase_Impl.m()) && (objF = this.f488b.f(hVar)) == p109r5.a.r) ? objF : p074l5.l.f7746a;
    }
}
