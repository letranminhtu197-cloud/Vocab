package C1;

import android.os.Looper;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
public abstract class x {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public P5.d f534a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Executor f535b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public C f536c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public C0018t f537d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public C0008i f538e;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f540g;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final A4.b f539f = new A4.b(new w(0, this, x.class, "onClosed", "onClosed()V", 0, 0));

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final ThreadLocal f541h = new ThreadLocal();

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final LinkedHashMap f542i = new LinkedHashMap();

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f543j = true;

    public final void a() {
        if (this.f540g) {
            return;
        }
        if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
            throw new IllegalStateException("Cannot access database on the main thread since it may potentially lock the UI for a long period of time.");
        }
    }

    public final void b() {
        a();
        a();
        M1.a aVarH = h().H();
        if (!aVarH.u()) {
            p000a.a.J(new C0007h(g(), null));
        }
        if (aVarH.y()) {
            aVarH.C();
        } else {
            aVarH.i();
        }
    }

    public List c(LinkedHashMap linkedHashMap) {
        LinkedHashMap linkedHashMap2 = new LinkedHashMap(p081m5.r.Y(linkedHashMap.size()));
        for (Map.Entry entry : linkedHashMap.entrySet()) {
            linkedHashMap2.put(X2.a.B((G5.b) entry.getKey()), entry.getValue());
        }
        return p081m5.m.r;
    }

    public abstract C0008i d();

    public z e() {
        throw new p074l5.f(0);
    }

    public final void f() {
        h().H().h();
        if (l()) {
            return;
        }
        C0008i c0008iG = g();
        c0008iG.f488b.e(c0008iG.f491e, c0008iG.f492f);
    }

    public final C0008i g() {
        C0008i c0008i = this.f538e;
        if (c0008i != null) {
            return c0008i;
        }
        A5.h.j("internalTracker");
        throw null;
    }

    public final M1.d h() {
        C0018t c0018t = this.f537d;
        if (c0018t == null) {
            A5.h.j("connectionManager");
            throw null;
        }
        M1.d dVarC = c0018t.c();
        if (dVarC != null) {
            return dVarC;
        }
        throw new IllegalStateException("Cannot return a SupportSQLiteOpenHelper since no SupportSQLiteOpenHelper.Factory was configured with Room.");
    }

    public Set i() {
        return p081m5.f.P0(new ArrayList(p081m5.g.x0(p081m5.o.r)));
    }

    public LinkedHashMap j() {
        int iY = p081m5.r.Y(p081m5.g.x0(p081m5.o.r));
        if (iY < 16) {
            iY = 16;
        }
        return new LinkedHashMap(iY);
    }

    public final boolean k() {
        C0018t c0018t = this.f537d;
        if (c0018t != null) {
            return c0018t.c() != null;
        }
        A5.h.j("connectionManager");
        throw null;
    }

    public final boolean l() {
        return m() && h().H().u();
    }

    public final boolean m() {
        C0018t c0018t = this.f537d;
        if (c0018t == null) {
            A5.h.j("connectionManager");
            throw null;
        }
        M1.a aVar = c0018t.f514g;
        if (aVar != null) {
            return aVar.isOpen();
        }
        return false;
    }

    public final Object n(Callable callable) {
        b();
        try {
            Object objCall = callable.call();
            o();
            return objCall;
        } finally {
            f();
        }
    }

    public final void o() {
        h().H().B();
    }

    public final Object p(boolean z6, p154z5.e eVar, p116s5.c cVar) {
        C0018t c0018t = this.f537d;
        if (c0018t != null) {
            return c0018t.f513f.k(z6, eVar, cVar);
        }
        A5.h.j("connectionManager");
        throw null;
    }
}
