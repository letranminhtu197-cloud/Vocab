package C1;

import H.AbstractC0037p;
import android.app.ActivityOptions;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.Spatializer;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.locks.ReentrantLock;
import p101q0.C0417e;
import p101q0.C0427o;

/* JADX INFO: renamed from: C1.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0012m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f498a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f499b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f500c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f501d;

    public C0012m(int i6, boolean z6) {
        switch (i6) {
            case 3:
                this.f499b = new Intent("android.intent.action.VIEW");
                this.f500c = new p033f5.f(23);
                this.f498a = true;
                break;
            default:
                this.f499b = new ArrayList();
                this.f498a = false;
                this.f500c = new CopyOnWriteArrayList();
                break;
        }
    }

    public p086n4.a a() {
        Intent intent = (Intent) this.f499b;
        if (!intent.hasExtra("android.support.customtabs.extra.SESSION")) {
            Bundle bundle = new Bundle();
            bundle.putBinder("android.support.customtabs.extra.SESSION", null);
            intent.putExtras(bundle);
        }
        intent.putExtra("android.support.customtabs.extra.EXTRA_ENABLE_INSTANT_APPS", this.f498a);
        ((p033f5.f) this.f500c).getClass();
        intent.putExtras(new Bundle());
        intent.putExtra("androidx.browser.customtabs.extra.SHARE_STATE", 0);
        int i6 = Build.VERSION.SDK_INT;
        LocaleList adjustedDefault = LocaleList.getAdjustedDefault();
        String languageTag = adjustedDefault.size() > 0 ? adjustedDefault.get(0).toLanguageTag() : null;
        if (!TextUtils.isEmpty(languageTag)) {
            Bundle bundleExtra = intent.hasExtra("com.android.browser.headers") ? intent.getBundleExtra("com.android.browser.headers") : new Bundle();
            if (!bundleExtra.containsKey("Accept-Language")) {
                bundleExtra.putString("Accept-Language", languageTag);
                intent.putExtra("com.android.browser.headers", bundleExtra);
            }
        }
        if (i6 >= 34) {
            if (((ActivityOptions) this.f501d) == null) {
                this.f501d = ActivityOptions.makeBasic();
            }
            AbstractC0037p.j((ActivityOptions) this.f501d);
        }
        if (i6 >= 36) {
            if (((ActivityOptions) this.f501d) == null) {
                this.f501d = ActivityOptions.makeBasic();
            }
            I.d.e((ActivityOptions) this.f501d, !intent.getBooleanExtra("androidx.browser.customtabs.extra.DISABLE_BACKGROUND_INTERACTION", false));
        }
        ActivityOptions activityOptions = (ActivityOptions) this.f501d;
        return new p086n4.a(intent, activityOptions != null ? activityOptions.toBundle() : null, 1);
    }

    public boolean b(C0417e c0417e, C0427o c0427o) {
        String str = c0427o.f8396m;
        int i6 = c0427o.f8374A;
        if ("audio/eac3-joc".equals(str) && i6 == 16) {
            i6 = 12;
        }
        int iQ = p117t0.s.q(i6);
        if (iQ == 0) {
            return false;
        }
        AudioFormat.Builder channelMask = new AudioFormat.Builder().setEncoding(2).setChannelMask(iQ);
        int i7 = c0427o.f8375B;
        if (i7 != -1) {
            channelMask.setSampleRate(i7);
        }
        return ((Spatializer) this.f499b).canBeSpatialized((AudioAttributes) c0417e.a().f64s, channelMask.build());
    }

    public void c(boolean z6) {
        this.f498a = z6;
        ArrayList arrayList = (ArrayList) this.f499b;
        int size = arrayList.size();
        int i6 = 0;
        while (i6 < size) {
            Object obj = arrayList.get(i6);
            i6++;
            p015d.p pVar = (p015d.p) obj;
            pVar.c(pVar.f5142e && z6);
        }
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public C0012m(p030f0.H h7) {
        this(2, false);
        this.f501d = h7;
    }

    public C0012m(int i6) {
        this.f499b = new ReentrantLock();
        this.f500c = new long[i6];
        this.f501d = new boolean[i6];
    }

    public C0012m(Spatializer spatializer) {
        this.f499b = spatializer;
        this.f498a = spatializer.getImmersiveAudioLevel() != 0;
    }
}
