package C1;

/* JADX INFO: loaded from: classes.dex */
public final class y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f544a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f545b;

    public y(String str, boolean z6) {
        this.f544a = str;
        this.f545b = z6;
    }

    public y(boolean z6, String str) {
        this.f545b = z6;
        this.f544a = str;
    }
}
