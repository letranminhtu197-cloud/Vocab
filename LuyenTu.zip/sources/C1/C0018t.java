package C1;

import android.content.Context;
import android.content.Intent;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: renamed from: C1.t, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0018t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f508a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f509b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final C0000a f510c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final z f511d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final List f512e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final E1.b f513f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public M1.a f514g;

    public C0018t(C0000a c0000a, B4.j jVar) throws Exception {
        this.f510c = c0000a;
        this.f511d = new r(StringUtils.EMPTY, -1, StringUtils.EMPTY);
        List list = c0000a.f466e;
        p081m5.m mVar = p081m5.m.r;
        this.f512e = list == null ? mVar : list;
        C0016q c0016q = new C0016q(this, 0);
        list = list == null ? mVar : list;
        C0017s c0017s = new C0017s(c0016q);
        A5.h.e(list, "<this>");
        ArrayList arrayList = new ArrayList(list.size() + 1);
        arrayList.addAll(list);
        arrayList.add(c0017s);
        Context context = c0000a.f462a;
        String str = c0000a.f463b;
        M1.c cVar = c0000a.f464c;
        p066k4.c cVar2 = c0000a.f465d;
        boolean z6 = c0000a.f467f;
        v vVar = c0000a.f468g;
        Executor executor = c0000a.f469h;
        Executor executor2 = c0000a.f470i;
        Intent intent = c0000a.f471j;
        boolean z7 = c0000a.f472k;
        boolean z8 = c0000a.f473l;
        Set set = c0000a.f474m;
        String str2 = c0000a.f475n;
        File file = c0000a.o;
        Callable callable = c0000a.f476p;
        List list2 = c0000a.f477q;
        List list3 = c0000a.r;
        boolean z9 = c0000a.f478s;
        L1.b bVar = c0000a.t;
        q5.h hVar = c0000a.f479u;
        A5.h.e(context, "context");
        A5.h.e(cVar2, "migrationContainer");
        A5.h.e(executor, "queryExecutor");
        A5.h.e(executor2, "transactionExecutor");
        A5.h.e(list2, "typeConverters");
        A5.h.e(list3, "autoMigrationSpecs");
        jVar.a(new C0000a(context, str, cVar, cVar2, arrayList, z6, vVar, executor, executor2, intent, z7, z8, set, str2, file, callable, list2, list3, z9, bVar, hVar));
        throw null;
    }

    public static final void a(C0018t c0018t, L1.a aVar) throws Exception {
        Object objM;
        z zVar = c0018t.f511d;
        C0000a c0000a = c0018t.f510c;
        v vVar = c0000a.f468g;
        v vVar2 = v.t;
        if (vVar == vVar2) {
            p018d2.G.v(aVar, "PRAGMA journal_mode = WAL");
        } else {
            p018d2.G.v(aVar, "PRAGMA journal_mode = TRUNCATE");
        }
        if (c0000a.f468g == vVar2) {
            p018d2.G.v(aVar, "PRAGMA synchronous = NORMAL");
        } else {
            p018d2.G.v(aVar, "PRAGMA synchronous = FULL");
        }
        b(aVar);
        L1.c cVarI = aVar.I("PRAGMA user_version");
        try {
            cVarI.E();
            int i6 = (int) cVarI.getLong(0);
            p018d2.G.h(cVarI, null);
            int i7 = zVar.f546a;
            if (i6 != i7) {
                p018d2.G.v(aVar, "BEGIN EXCLUSIVE TRANSACTION");
                try {
                    if (i6 == 0) {
                        c0018t.d(aVar);
                    } else {
                        c0018t.e(aVar, i6, i7);
                    }
                    p018d2.G.v(aVar, "PRAGMA user_version = " + i7);
                    objM = p074l5.l.f7746a;
                } catch (Throwable th) {
                    objM = X2.a.m(th);
                }
                if (!(objM instanceof p074l5.h)) {
                    p018d2.G.v(aVar, "END TRANSACTION");
                }
                Throwable thA = p074l5.i.a(objM);
                if (thA != null) {
                    p018d2.G.v(aVar, "ROLLBACK TRANSACTION");
                    throw thA;
                }
            }
            c0018t.f(aVar);
        } catch (Throwable th2) {
            try {
                throw th2;
            } catch (Throwable th3) {
                p018d2.G.h(cVarI, th2);
                throw th3;
            }
        }
    }

    public static void b(L1.a aVar) throws Exception {
        L1.c cVarI = aVar.I("PRAGMA busy_timeout");
        try {
            cVarI.E();
            long j6 = cVarI.getLong(0);
            p018d2.G.h(cVarI, null);
            if (j6 < 3000) {
                p018d2.G.v(aVar, "PRAGMA busy_timeout = 3000");
            }
        } catch (Throwable th) {
            try {
                throw th;
            } catch (Throwable th2) {
                p018d2.G.h(cVarI, th);
                throw th2;
            }
        }
    }

    public final M1.d c() {
        M4.i iVar;
        E1.b bVar = this.f513f;
        F1.b bVar2 = bVar instanceof F1.b ? (F1.b) bVar : null;
        if (bVar2 == null || (iVar = bVar2.r) == null) {
            return null;
        }
        return (M1.d) iVar.f2508s;
    }

    public final void d(L1.a aVar) throws Exception {
        A5.h.e(aVar, "connection");
        L1.c cVarI = aVar.I("SELECT count(*) FROM sqlite_master WHERE name != 'android_metadata'");
        try {
            boolean z6 = false;
            if (cVarI.E() && cVarI.getLong(0) == 0) {
                z6 = true;
            }
            p018d2.G.h(cVarI, null);
            z zVar = this.f511d;
            zVar.a(aVar);
            if (!z6) {
                y yVarG = zVar.g(aVar);
                if (!yVarG.f545b) {
                    throw new IllegalStateException(("Pre-packaged database has an invalid schema: " + yVarG.f544a).toString());
                }
            }
            g(aVar);
            zVar.c(aVar);
            Iterator it = this.f512e.iterator();
            while (it.hasNext()) {
                ((C0017s) it.next()).getClass();
                if (aVar instanceof F1.a) {
                    A5.h.e(((F1.a) aVar).r, "db");
                }
            }
        } catch (Throwable th) {
            try {
                throw th;
            } catch (Throwable th2) {
                p018d2.G.h(cVarI, th);
                throw th2;
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:127:0x009d A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:128:0x009d A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:131:? A[LOOP:4: B:9:0x0026->B:131:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:132:0x009a A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:133:0x0085 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:137:0x007e A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:13:0x002d A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:14:0x002f  */
    /* JADX WARN: Code duplicated, block: B:16:0x003b  */
    /* JADX WARN: Code duplicated, block: B:17:0x003d  */
    /* JADX WARN: Code duplicated, block: B:18:0x0047  */
    /* JADX WARN: Code duplicated, block: B:21:0x0054  */
    /* JADX WARN: Code duplicated, block: B:24:0x0060  */
    /* JADX WARN: Code duplicated, block: B:27:0x0072  */
    public final void e(L1.a aVar, int i6, int i7) {
        Iterable iterable;
        TreeMap treeMap;
        p074l5.g gVar;
        Iterator it;
        boolean z6;
        int iIntValue;
        TreeMap treeMap2;
        A5.h.e(aVar, "connection");
        C0000a c0000a = this.f510c;
        p066k4.c cVar = c0000a.f465d;
        A5.h.e(cVar, "<this>");
        LinkedHashMap linkedHashMap = (LinkedHashMap) cVar.f7289s;
        if (i6 == i7) {
            iterable = p081m5.m.r;
        } else {
            boolean z7 = i7 > i6;
            ArrayList arrayList = new ArrayList();
            int i8 = i6;
            while (true) {
                if (z7) {
                    if (i8 < i7) {
                        if (z7) {
                            treeMap2 = (TreeMap) linkedHashMap.get(Integer.valueOf(i8));
                            if (treeMap2 == null) {
                                gVar = null;
                            } else {
                                gVar = new p074l5.g(treeMap2, treeMap2.descendingKeySet());
                            }
                        } else {
                            treeMap = (TreeMap) linkedHashMap.get(Integer.valueOf(i8));
                            if (treeMap == null) {
                                gVar = null;
                            } else {
                                gVar = new p074l5.g(treeMap, treeMap.keySet());
                            }
                        }
                        if (gVar == null) {
                            Map map = (Map) gVar.r;
                            it = ((Iterable) gVar.f7743s).iterator();
                            while (true) {
                                if (it.hasNext()) {
                                    z6 = false;
                                    break;
                                }
                                iIntValue = ((Number) it.next()).intValue();
                                if (!z7) {
                                    if (i7 <= iIntValue && iIntValue < i8) {
                                        Object obj = map.get(Integer.valueOf(iIntValue));
                                        A5.h.b(obj);
                                        arrayList.add(obj);
                                        z6 = true;
                                        i8 = iIntValue;
                                        break;
                                        break;
                                    }
                                } else if (i8 + 1 <= iIntValue && iIntValue <= i7) {
                                    Object obj2 = map.get(Integer.valueOf(iIntValue));
                                    A5.h.b(obj2);
                                    arrayList.add(obj2);
                                    z6 = true;
                                    i8 = iIntValue;
                                    break;
                                }
                            }
                            if (!z6) {
                            }
                        }
                        iterable = null;
                    } else {
                        iterable = arrayList;
                    }
                } else if (i8 > i7) {
                    if (z7) {
                        treeMap2 = (TreeMap) linkedHashMap.get(Integer.valueOf(i8));
                        if (treeMap2 == null) {
                            gVar = null;
                        } else {
                            gVar = new p074l5.g(treeMap2, treeMap2.descendingKeySet());
                        }
                    } else {
                        treeMap = (TreeMap) linkedHashMap.get(Integer.valueOf(i8));
                        if (treeMap == null) {
                            gVar = null;
                        } else {
                            gVar = new p074l5.g(treeMap, treeMap.keySet());
                        }
                    }
                    if (gVar == null) {
                        Map map2 = (Map) gVar.r;
                        it = ((Iterable) gVar.f7743s).iterator();
                        while (true) {
                            if (it.hasNext()) {
                                z6 = false;
                                break;
                                break;
                            }
                            iIntValue = ((Number) it.next()).intValue();
                            if (!z7) {
                                if (i8 + 1 <= iIntValue) {
                                    continue;
                                }
                            } else if (i7 <= iIntValue) {
                                continue;
                            }
                        }
                        if (!z6) {
                        }
                    }
                    iterable = null;
                } else {
                    iterable = arrayList;
                }
            }
        }
        z zVar = this.f511d;
        if (iterable != null) {
            zVar.f(aVar);
            Iterator it2 = iterable.iterator();
            while (it2.hasNext()) {
                ((G1.a) it2.next()).a(aVar);
            }
            y yVarG = zVar.g(aVar);
            if (yVarG.f545b) {
                zVar.e(aVar);
                g(aVar);
                return;
            } else {
                throw new IllegalStateException(("Migration didn't properly handle: " + yVarG.f544a).toString());
            }
        }
        A5.h.e(c0000a, "<this>");
        boolean z8 = false;
        if (i6 <= i7 || !c0000a.f473l) {
            Set set = c0000a.f474m;
            if (c0000a.f472k && (set == null || !set.contains(Integer.valueOf(i6)))) {
                z8 = true;
            }
        }
        if (z8) {
            throw new IllegalStateException(("A migration from " + i6 + " to " + i7 + " was required but not found. Please provide the necessary Migration path via RoomDatabase.Builder.addMigration(...) or allow for destructive migrations via one of the RoomDatabase.Builder.fallbackToDestructiveMigration* functions.").toString());
        }
        if (c0000a.f478s) {
            L1.c cVarI = aVar.I("SELECT name, type FROM sqlite_master WHERE type = 'table' OR type = 'view'");
            try {
                p087n5.c cVarM = p018d2.G.m();
                while (cVarI.E()) {
                    String strM = cVarI.m(0);
                    if (!I5.l.v0(strM, "sqlite_") && !strM.equals("android_metadata")) {
                        cVarM.add(new p074l5.g(strM, Boolean.valueOf(A5.h.a(cVarI.m(1), "view"))));
                    }
                }
                p087n5.c cVarB = p018d2.G.b(cVarM);
                p018d2.G.h(cVarI, null);
                ListIterator listIterator = cVarB.listIterator(0);
                while (true) {
                    p087n5.a aVar2 = (p087n5.a) listIterator;
                    if (!aVar2.hasNext()) {
                        break;
                    }
                    p074l5.g gVar2 = (p074l5.g) aVar2.next();
                    String str = (String) gVar2.r;
                    if (((Boolean) gVar2.f7743s).booleanValue()) {
                        p018d2.G.v(aVar, "DROP VIEW IF EXISTS " + str);
                    } else {
                        p018d2.G.v(aVar, "DROP TABLE IF EXISTS " + str);
                    }
                }
            } catch (Throwable th) {
                try {
                    throw th;
                } catch (Throwable th2) {
                    p018d2.G.h(cVarI, th);
                    throw th2;
                }
            }
        } else {
            zVar.b(aVar);
        }
        Iterator it3 = this.f512e.iterator();
        while (it3.hasNext()) {
            ((C0017s) it3.next()).getClass();
            if (aVar instanceof F1.a) {
                A5.h.e(((F1.a) aVar).r, "db");
            }
        }
        zVar.a(aVar);
    }

    public final void f(L1.a aVar) throws Exception {
        Object objM;
        A5.h.e(aVar, "connection");
        L1.c cVarI = aVar.I("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'room_master_table'");
        try {
            boolean z6 = cVarI.E() && cVarI.getLong(0) != 0;
            p018d2.G.h(cVarI, null);
            z zVar = this.f511d;
            if (z6) {
                L1.c cVarI2 = aVar.I("SELECT identity_hash FROM room_master_table WHERE id = 42 LIMIT 1");
                try {
                    String strM = cVarI2.E() ? cVarI2.m(0) : null;
                    p018d2.G.h(cVarI2, null);
                    if (!zVar.f547b.equals(strM) && !zVar.f548c.equals(strM)) {
                        throw new IllegalStateException(("Room cannot verify the data integrity. Looks like you've changed schema but forgot to update the version number. You can simply fix this by increasing the version number. Expected identity hash: " + zVar.f547b + ", found: " + strM).toString());
                    }
                } catch (Throwable th) {
                    try {
                        throw th;
                    } catch (Throwable th2) {
                        p018d2.G.h(cVarI2, th);
                        throw th2;
                    }
                }
            } else {
                p018d2.G.v(aVar, "BEGIN EXCLUSIVE TRANSACTION");
                try {
                    y yVarG = zVar.g(aVar);
                    if (!yVarG.f545b) {
                        throw new IllegalStateException(("Pre-packaged database has an invalid schema: " + yVarG.f544a).toString());
                    }
                    zVar.e(aVar);
                    g(aVar);
                    objM = p074l5.l.f7746a;
                    if (!(objM instanceof p074l5.h)) {
                        p018d2.G.v(aVar, "END TRANSACTION");
                    }
                    Throwable thA = p074l5.i.a(objM);
                    if (thA != null) {
                        p018d2.G.v(aVar, "ROLLBACK TRANSACTION");
                        throw thA;
                    }
                } catch (Throwable th3) {
                    objM = X2.a.m(th3);
                }
            }
            zVar.d(aVar);
            for (C0017s c0017s : this.f512e) {
                c0017s.getClass();
                if (aVar instanceof F1.a) {
                    M1.a aVar2 = ((F1.a) aVar).r;
                    switch (c0017s.f506a) {
                        case 0:
                            A5.h.e(aVar2, "db");
                            ((C0016q) c0017s.f507b).a(aVar2);
                            break;
                        default:
                            A5.h.e(aVar2, "db");
                            aVar2.i();
                            try {
                                StringBuilder sb = new StringBuilder("DELETE FROM workspec WHERE state IN (2, 3, 5) AND (last_enqueue_time + minimum_retention_duration) < ");
                                ((p018d2.l) c0017s.f507b).getClass();
                                sb.append(System.currentTimeMillis() - p025e2.o.f5468a);
                                sb.append(" AND (SELECT COUNT(*)=0 FROM dependency WHERE     prerequisite_id=id AND     work_spec_id NOT IN         (SELECT id FROM workspec WHERE state IN (2, 3, 5)))");
                                aVar2.n(sb.toString());
                                aVar2.B();
                                aVar2.h();
                            } catch (Throwable th4) {
                                aVar2.h();
                                throw th4;
                            }
                            break;
                    }
                }
            }
            this.f508a = true;
        } catch (Throwable th5) {
            try {
                throw th5;
            } catch (Throwable th6) {
                p018d2.G.h(cVarI, th5);
                throw th6;
            }
        }
    }

    public final void g(L1.a aVar) throws Exception {
        p018d2.G.v(aVar, "CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
        String str = this.f511d.f547b;
        A5.h.e(str, "hash");
        p018d2.G.v(aVar, "INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '" + str + "')");
    }

    public C0018t(C0000a c0000a, z zVar) {
        int i6;
        E1.h hVar;
        v vVar = c0000a.f468g;
        M1.c cVar = c0000a.f464c;
        String str = c0000a.f463b;
        this.f510c = c0000a;
        this.f511d = zVar;
        List list = c0000a.f466e;
        this.f512e = list == null ? p081m5.m.r : list;
        L1.b bVar = c0000a.t;
        if (bVar != null) {
            if (str == null) {
                hVar = new E1.h(new A4.b(this, bVar));
            } else {
                A4.b bVar2 = new A4.b(this, bVar);
                int iOrdinal = vVar.ordinal();
                if (iOrdinal == 1) {
                    i6 = 1;
                } else {
                    if (iOrdinal != 2) {
                        throw new IllegalStateException(("Can't get max number of reader for journal mode '" + vVar + '\'').toString());
                    }
                    i6 = 4;
                }
                int iOrdinal2 = vVar.ordinal();
                if (iOrdinal2 != 1 && iOrdinal2 != 2) {
                    throw new IllegalStateException(("Can't get max number of writers for journal mode '" + vVar + '\'').toString());
                }
                hVar = new E1.h(bVar2, str, i6);
            }
            this.f513f = hVar;
        } else if (cVar != null) {
            Context context = c0000a.f462a;
            A5.h.e(context, "context");
            this.f513f = new F1.b(new M4.i(cVar.a(new M1.b(context, str, new p103q2.v(this, zVar.f546a), false, false))));
        } else {
            throw new IllegalArgumentException("SQLiteManager was constructed with both null driver and open helper factory!");
        }
        boolean z6 = vVar == v.t;
        M1.d dVarC = c();
        if (dVarC != null) {
            dVarC.setWriteAheadLoggingEnabled(z6);
        }
    }
}
