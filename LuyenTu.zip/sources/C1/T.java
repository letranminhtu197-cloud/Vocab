package C1;

import java.util.concurrent.locks.ReentrantLock;

/* JADX INFO: loaded from: classes.dex */
public final class T extends p116s5.h implements p154z5.e {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f447v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public /* synthetic */ Object f448w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final /* synthetic */ U f449x;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public T(U u6, q5.c cVar) {
        super(2, cVar);
        this.f449x = u6;
    }

    @Override // p154z5.e
    public final Object g(Object obj, Object obj2) {
        return ((T) j((E) obj, (q5.c) obj2)).l(p074l5.l.f7746a);
    }

    @Override // p116s5.a
    public final q5.c j(Object obj, q5.c cVar) {
        T t = new T(this.f449x, cVar);
        t.f448w = obj;
        return t;
    }

    @Override // p116s5.a
    public final Object l(Object obj) {
        E e6;
        Object objD;
        EnumC0011l[] enumC0011lArr;
        EnumC0011l enumC0011l;
        int i6 = this.f447v;
        p074l5.l lVar = p074l5.l.f7746a;
        boolean z6 = true;
        p109r5.a aVar = p109r5.a.r;
        if (i6 == 0) {
            X2.a.O(obj);
            e6 = (E) this.f448w;
            this.f448w = e6;
            this.f447v = 1;
            objD = e6.d(this);
            if (objD != aVar) {
            }
            return aVar;
        }
        if (i6 != 1) {
            if (i6 != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            X2.a.O(obj);
            return lVar;
        }
        e6 = (E) this.f448w;
        X2.a.O(obj);
        objD = obj;
        if (!((Boolean) objD).booleanValue()) {
            U u6 = this.f449x;
            C0012m c0012m = u6.f458h;
            long[] jArr = (long[]) c0012m.f500c;
            ReentrantLock reentrantLock = (ReentrantLock) c0012m.f499b;
            reentrantLock.lock();
            try {
                if (c0012m.f498a) {
                    boolean z7 = false;
                    c0012m.f498a = false;
                    int length = jArr.length;
                    enumC0011lArr = new EnumC0011l[length];
                    int i7 = 0;
                    boolean z8 = false;
                    while (i7 < length) {
                        if (jArr[i7] <= 0) {
                            z6 = z7;
                        }
                        boolean[] zArr = (boolean[]) c0012m.f501d;
                        if (z6 != zArr[i7]) {
                            zArr[i7] = z6;
                            enumC0011l = z6 ? EnumC0011l.f496s : EnumC0011l.t;
                            z8 = true;
                        } else {
                            enumC0011l = EnumC0011l.r;
                        }
                        enumC0011lArr[i7] = enumC0011l;
                        i7++;
                        z6 = true;
                        z7 = false;
                    }
                    if (!z8) {
                        enumC0011lArr = null;
                    }
                    reentrantLock.unlock();
                } else {
                    reentrantLock.unlock();
                    enumC0011lArr = null;
                }
                if (enumC0011lArr != null) {
                    S s6 = new S(enumC0011lArr, u6, e6, null);
                    this.f448w = null;
                    this.f447v = 2;
                    if (e6.a(D.f390s, s6, this) == aVar) {
                        return aVar;
                    }
                }
            } catch (Throwable th) {
                reentrantLock.unlock();
                throw th;
            }
        }
        return lVar;
    }
}
