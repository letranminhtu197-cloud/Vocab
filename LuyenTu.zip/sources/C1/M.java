package C1;

/* JADX INFO: loaded from: classes.dex */
public final class M extends p116s5.h implements p154z5.e {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f414v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public /* synthetic */ Object f415w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final /* synthetic */ U f416x;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public M(U u6, q5.c cVar) {
        super(2, cVar);
        this.f416x = u6;
    }

    @Override // p154z5.e
    public final Object g(Object obj, Object obj2) {
        return ((M) j((E) obj, (q5.c) obj2)).l(p074l5.l.f7746a);
    }

    @Override // p116s5.a
    public final q5.c j(Object obj, q5.c cVar) {
        M m6 = new M(this.f416x, cVar);
        m6.f415w = obj;
        return m6;
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x004e, code lost:
    
        if (r7 == r3) goto L19;
     */
    @Override // p116s5.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object l(java.lang.Object r7) {
        /*
            r6 = this;
            int r0 = r6.f414v
            r1 = 2
            r2 = 1
            r5.a r3 = p109r5.a.r
            if (r0 == 0) goto L20
            if (r0 == r2) goto L18
            if (r0 != r1) goto L10
            X2.a.O(r7)     // Catch: android.database.SQLException -> L54
            goto L51
        L10:
            java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r7.<init>(r0)
            throw r7
        L18:
            java.lang.Object r0 = r6.f415w
            C1.E r0 = (C1.E) r0
            X2.a.O(r7)
            goto L33
        L20:
            X2.a.O(r7)
            java.lang.Object r7 = r6.f415w
            r0 = r7
            C1.E r0 = (C1.E) r0
            r6.f415w = r0
            r6.f414v = r2
            java.lang.Object r7 = r0.d(r6)
            if (r7 != r3) goto L33
            goto L50
        L33:
            java.lang.Boolean r7 = (java.lang.Boolean) r7
            boolean r7 = r7.booleanValue()
            if (r7 == 0) goto L3c
            goto L54
        L3c:
            C1.D r7 = C1.D.f390s     // Catch: android.database.SQLException -> L54
            C1.L r2 = new C1.L     // Catch: android.database.SQLException -> L54
            C1.U r4 = r6.f416x     // Catch: android.database.SQLException -> L54
            r5 = 0
            r2.<init>(r4, r5)     // Catch: android.database.SQLException -> L54
            r6.f415w = r5     // Catch: android.database.SQLException -> L54
            r6.f414v = r1     // Catch: android.database.SQLException -> L54
            java.lang.Object r7 = r0.a(r7, r2, r6)     // Catch: android.database.SQLException -> L54
            if (r7 != r3) goto L51
        L50:
            return r3
        L51:
            java.util.Set r7 = (java.util.Set) r7     // Catch: android.database.SQLException -> L54
            return r7
        L54:
            m5.o r7 = p081m5.o.r
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: C1.M.l(java.lang.Object):java.lang.Object");
    }
}
