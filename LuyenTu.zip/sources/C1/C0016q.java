package C1;

/* JADX INFO: renamed from: C1.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class C0016q implements p154z5.c {
    public final /* synthetic */ int r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ Object f505s;

    public /* synthetic */ C0016q(S5.c cVar, S5.b bVar) {
        this.r = 3;
        this.f505s = cVar;
    }

    @Override // p154z5.c
    public final Object a(Object obj) {
        switch (this.r) {
            case 0:
                C0018t c0018t = (C0018t) this.f505s;
                M1.a aVar = (M1.a) obj;
                A5.h.e(aVar, "db");
                c0018t.f514g = aVar;
                return p074l5.l.f7746a;
            case 1:
                C0005f c0005f = (C0005f) this.f505s;
                A5.h.e(obj, "it");
                return c0005f.b();
            case 2:
                S.c cVar = (S.c) this.f505s;
                M.e eVar = (M.e) obj;
                A5.h.e(eVar, "e");
                cVar.d().execute(new S.a(cVar, eVar, 1));
                return p074l5.l.f7746a;
            case 3:
                ((S5.c) this.f505s).a(null);
                return p074l5.l.f7746a;
            case 4:
                U.b bVar = (U.b) this.f505s;
                M.e eVar2 = (M.e) obj;
                A5.h.e(eVar2, "e");
                bVar.e().execute(new U.a(bVar, eVar2, 0));
                return p074l5.l.f7746a;
            default:
                ((p154z5.c) this.f505s).a(new p047h5.N(((p074l5.i) obj).r));
                return p074l5.l.f7746a;
        }
    }

    public /* synthetic */ C0016q(Object obj, int i6) {
        this.r = i6;
        this.f505s = obj;
    }
}
