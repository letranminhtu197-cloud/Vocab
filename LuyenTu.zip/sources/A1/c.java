package A1;

import com.google.crypto.tink.shaded.protobuf.T;
import java.util.List;
import p018d2.G;

/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final List f141a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f142b;

    public c(int i6, List list) {
        this.f141a = list;
        this.f142b = i6;
        if (list.isEmpty() && i6 == -1) {
            return;
        }
        if (!list.isEmpty()) {
            int size = list.size();
            if (i6 >= 0 && i6 < size) {
                return;
            }
        }
        StringBuilder sbN = T.n("Invalid 'NavigationEventHistory' state:  'currentIndex' must be within the bounds of 'mergedHistory' (or -1 if empty). Received: currentIndex = '", i6, "', bounds = '");
        sbN.append(G.w(list));
        sbN.append("'.");
        throw new IllegalArgumentException(sbN.toString().toString());
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || c.class != obj.getClass()) {
            return false;
        }
        c cVar = (c) obj;
        return this.f142b == cVar.f142b && A5.h.a(this.f141a, cVar.f141a);
    }

    public final int hashCode() {
        return this.f141a.hashCode() + (this.f142b * 31);
    }

    public final String toString() {
        return "NavigationEventHistory(currentIndex=" + this.f142b + ", mergedHistory=" + this.f141a + ')';
    }

    public c() {
        this(-1, p081m5.m.r);
    }
}
