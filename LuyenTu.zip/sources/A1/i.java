package A1;

import android.app.Notification;

/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class i {
    public static /* bridge */ /* synthetic */ Class d() {
        return Notification.ProgressStyle.class;
    }
}
