package A1;

/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f136a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f137b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f138c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final float f139d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f140e;

    public b(int i6, float f4, float f7, float f8, long j6) {
        this.f136a = i6;
        this.f137b = f4;
        this.f138c = f7;
        this.f139d = f8;
        this.f140e = j6;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && b.class == obj.getClass()) {
            b bVar = (b) obj;
            return this.f138c == bVar.f138c && this.f139d == bVar.f139d && this.f137b == bVar.f137b && this.f136a == bVar.f136a && this.f140e == bVar.f140e;
        }
        return false;
    }

    public final int hashCode() {
        return Long.hashCode(this.f140e) + ((Integer.hashCode(this.f136a) + ((Float.hashCode(this.f137b) + ((Float.hashCode(this.f139d) + (Float.hashCode(this.f138c) * 31)) * 31)) * 31)) * 31);
    }

    public final String toString() {
        return "NavigationEvent(touchX=" + this.f138c + ", touchY=" + this.f139d + ", progress=" + this.f137b + ", swipeEdge=" + this.f136a + ", frameTimeMillis=" + this.f140e + ')';
    }
}
