package A1;

import N5.t;
import N5.x;
import N5.y;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import org.apache.tika.metadata.ClimateForcast;
import p015d.p;
import p015d.q;
import p018d2.G;
import p053i4.v;

/* JADX INFO: loaded from: classes.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final x f145a = y.a(f.f159a);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final x f146b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final t f147c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final p081m5.d f148d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final p081m5.d f149e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public p f150f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f151g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public d f152h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final LinkedHashSet f153i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final LinkedHashSet f154j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final LinkedHashSet f155k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f156l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f157m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f158n;

    public e() {
        x xVarA = y.a(new c());
        this.f146b = xVarA;
        this.f147c = new t(xVarA);
        this.f148d = new p081m5.d();
        this.f149e = new p081m5.d();
        this.f153i = new LinkedHashSet();
        this.f154j = new LinkedHashSet();
        this.f155k = new LinkedHashSet();
    }

    public final void a(v vVar, d dVar, int i6) {
        LinkedHashSet linkedHashSet;
        boolean z6;
        A5.h.e(vVar, "dispatcher");
        if (dVar.f143a != null) {
            throw new IllegalArgumentException(("Input '" + dVar + "' is already added to dispatcher " + dVar.f143a + '.').toString());
        }
        if (i6 != 0) {
            linkedHashSet = i6 != 1 ? this.f153i : this.f154j;
        } else {
            linkedHashSet = this.f155k;
        }
        linkedHashSet.add(dVar);
        dVar.f143a = vVar;
        A5.h.e((c) this.f147c.r.e(), ClimateForcast.HISTORY);
        if (i6 != 0) {
            z6 = i6 != 1 ? this.f158n : this.f156l;
        } else {
            z6 = this.f157m;
        }
        dVar.b(z6);
    }

    public final void b() {
        boolean z6;
        boolean z7;
        c cVar;
        p081m5.d dVar = this.f148d;
        if (dVar != null && dVar.isEmpty()) {
            z6 = false;
            break;
        }
        Iterator it = dVar.iterator();
        while (true) {
            if (!it.hasNext()) {
                z6 = false;
                break;
            } else if (((p) it.next()).f5139b) {
                z6 = true;
                break;
            }
        }
        p081m5.d dVar2 = this.f149e;
        if (dVar2 != null && dVar2.isEmpty()) {
            z7 = false;
            break;
        }
        Iterator it2 = dVar2.iterator();
        while (true) {
            if (!it2.hasNext()) {
                z7 = false;
                break;
            } else if (((p) it2.next()).f5139b) {
                z7 = true;
                break;
            }
        }
        boolean z8 = z6 || z7;
        boolean z9 = this.f157m != z6;
        boolean z10 = this.f156l != z7;
        boolean z11 = this.f158n != z8;
        LinkedHashSet linkedHashSet = this.f155k;
        if (z9) {
            Iterator it3 = linkedHashSet.iterator();
            while (it3.hasNext()) {
                ((d) it3.next()).b(z6);
            }
        }
        LinkedHashSet linkedHashSet2 = this.f154j;
        if (z10) {
            Iterator it4 = linkedHashSet2.iterator();
            while (it4.hasNext()) {
                ((d) it4.next()).b(z7);
            }
        }
        LinkedHashSet linkedHashSet3 = this.f153i;
        if (z11) {
            Iterator it5 = linkedHashSet3.iterator();
            while (it5.hasNext()) {
                ((d) it5.next()).b(z8);
            }
        }
        this.f157m = z6;
        this.f156l = z7;
        this.f158n = z8;
        p pVarC = this.f150f;
        if (pVarC == null) {
            pVarC = c(0);
        }
        p pVarC2 = this.f150f;
        if (pVarC2 == null) {
            pVarC2 = c(0);
        }
        if (A5.h.a(pVarC2, pVarC)) {
            if (pVarC2 == null) {
                cVar = new c();
            } else {
                ArrayList arrayList = new ArrayList();
                Iterator<E> it6 = dVar.iterator();
                while (it6.hasNext()) {
                    ((p) it6.next()).getClass();
                }
                Iterator<E> it7 = dVar2.iterator();
                while (it7.hasNext()) {
                    ((p) it7.next()).getClass();
                }
                q qVar = pVarC2.f5138a;
                p087n5.c cVarM = G.m();
                p081m5.k.y0(cVarM, arrayList);
                cVarM.add(qVar);
                p081m5.k.y0(cVarM, p081m5.m.r);
                cVar = new c(arrayList.size(), G.b(cVarM));
            }
            x xVar = this.f146b;
            if (A5.h.a((c) xVar.e(), cVar)) {
                return;
            }
            xVar.g(null, cVar);
            Iterator it8 = linkedHashSet.iterator();
            while (it8.hasNext()) {
                ((d) it8.next()).getClass();
            }
            Iterator it9 = linkedHashSet2.iterator();
            while (it9.hasNext()) {
                ((d) it9.next()).getClass();
            }
            Iterator it10 = linkedHashSet3.iterator();
            while (it10.hasNext()) {
                ((d) it10.next()).getClass();
            }
        }
    }

    public final p c(int i6) {
        Object next;
        Object next2;
        p081m5.d dVar = this.f149e;
        p081m5.d dVar2 = this.f148d;
        Object obj = null;
        if (i6 == -1) {
            Iterator it = dVar2.iterator();
            do {
                if (!it.hasNext()) {
                    next = null;
                    break;
                }
                next = it.next();
            } while (!((p) next).f5139b);
            p pVar = (p) next;
            if (pVar != null) {
                return pVar;
            }
            for (Object obj2 : dVar) {
                if (((p) obj2).f5139b) {
                    obj = obj2;
                    break;
                }
            }
            return (p) obj;
        }
        if (i6 != 0) {
            if (i6 != 1) {
                throw new IllegalStateException(("Unsupported direction: '" + i6 + "'.").toString());
            }
            Iterator it2 = dVar2.iterator();
            while (it2.hasNext()) {
                ((p) it2.next()).getClass();
            }
            Iterator it3 = dVar.iterator();
            while (it3.hasNext()) {
                ((p) it3.next()).getClass();
            }
            return null;
        }
        Iterator it4 = dVar2.iterator();
        do {
            if (!it4.hasNext()) {
                next2 = null;
                break;
            }
            next2 = it4.next();
        } while (!((p) next2).f5139b);
        p pVar2 = (p) next2;
        if (pVar2 != null) {
            return pVar2;
        }
        for (Object obj3 : dVar) {
            if (((p) obj3).f5139b) {
                obj = obj3;
                break;
            }
        }
        return (p) obj;
    }
}
