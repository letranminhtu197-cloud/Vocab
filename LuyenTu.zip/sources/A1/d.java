package A1;

import C1.C0012m;
import N5.x;
import android.util.Log;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import p015d.p;
import p015d.t;
import p030f0.AbstractComponentCallbacksC0325s;
import p030f0.C0319l;
import p030f0.H;
import p030f0.O;
import p030f0.S;
import p030f0.T;
import p053i4.v;

/* JADX INFO: loaded from: classes.dex */
public abstract class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public v f143a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f144b;

    public final void a() {
        v vVar = this.f143a;
        if (vVar == null) {
            throw new IllegalStateException("This input is not added to any dispatcher.");
        }
        if (!this.f144b) {
            vVar.p(this, null);
        }
        e eVar = (e) vVar.f6368s;
        B4.b bVar = (B4.b) vVar.r;
        eVar.getClass();
        if (equals(eVar.f152h) && -1 == eVar.f151g) {
            p pVarC = eVar.f150f;
            if (pVarC == null) {
                pVarC = eVar.c(-1);
            }
            eVar.f150f = null;
            eVar.f151g = 0;
            eVar.f152h = null;
            if (pVarC == null) {
                ((t) bVar.f349s).f5148a.run();
            } else {
                H h7 = (H) pVarC.f5141d.f501d;
                int i6 = 3;
                if (H.J(3)) {
                    Log.d("FragmentManager", "handleOnBackPressed. PREDICTIVE_BACK = true fragment manager " + h7);
                }
                C0012m c0012m = h7.f5566i;
                ArrayList arrayList = h7.f5570m;
                h7.A(true);
                if (h7.f5565h != null) {
                    if (!arrayList.isEmpty()) {
                        LinkedHashSet linkedHashSet = new LinkedHashSet(H.E(h7.f5565h));
                        int size = arrayList.size();
                        int i7 = 0;
                        while (i7 < size) {
                            Object obj = arrayList.get(i7);
                            i7++;
                            if (obj != null) {
                                throw new ClassCastException();
                            }
                            Iterator it = linkedHashSet.iterator();
                            if (it.hasNext()) {
                                throw null;
                            }
                        }
                    }
                    ArrayList arrayList2 = h7.f5565h.f5622a;
                    int size2 = arrayList2.size();
                    int i8 = 0;
                    while (i8 < size2) {
                        Object obj2 = arrayList2.get(i8);
                        i8++;
                        AbstractComponentCallbacksC0325s abstractComponentCallbacksC0325s = ((O) obj2).f5609b;
                        if (abstractComponentCallbacksC0325s != null) {
                            abstractComponentCallbacksC0325s.f5697D = false;
                        }
                    }
                    for (C0319l c0319l : h7.f(new ArrayList(Collections.singletonList(h7.f5565h)), 0, 1)) {
                        ArrayList arrayList3 = c0319l.f5664c;
                        if (H.J(i6)) {
                            Log.d("FragmentManager", "SpecialEffectsController: Completing Back ");
                        }
                        c0319l.e(arrayList3);
                        c0319l.getClass();
                        A5.h.e(arrayList3, "operations");
                        ArrayList arrayList4 = new ArrayList();
                        Iterator it2 = arrayList3.iterator();
                        while (it2.hasNext()) {
                            ((T) it2.next()).getClass();
                            p081m5.k.y0(arrayList4, null);
                        }
                        List listL0 = p081m5.f.L0(p081m5.f.P0(arrayList4));
                        int size3 = listL0.size();
                        int i9 = 0;
                        while (i9 < size3) {
                            ((S) listL0.get(i9)).a(c0319l.f5662a);
                            i9++;
                            i6 = i6;
                        }
                        int i10 = i6;
                        int size4 = arrayList3.size();
                        for (int i11 = 0; i11 < size4; i11++) {
                            c0319l.a((T) arrayList3.get(i11));
                        }
                        List listL1 = p081m5.f.L0(arrayList3);
                        if (listL1.size() > 0) {
                            ((T) listL1.get(0)).getClass();
                            throw null;
                        }
                        i6 = i10;
                    }
                    h7.f5565h = null;
                    h7.e0();
                    if (H.J(i6)) {
                        Log.d("FragmentManager", "Op is being set to null");
                        Log.d("FragmentManager", "OnBackPressedCallback enabled=" + c0012m.f498a + " for  FragmentManager " + h7);
                    }
                } else if (c0012m.f498a) {
                    if (H.J(3)) {
                        Log.d("FragmentManager", "Calling popBackStackImmediate via onBackPressed callback");
                    }
                    h7.Q();
                } else {
                    if (H.J(3)) {
                        Log.d("FragmentManager", "Calling onBackPressed via onBackPressed callback");
                    }
                    h7.f5564g.a().a();
                }
            }
            x xVar = eVar.f145a;
            xVar.getClass();
            xVar.g(null, f.f159a);
        }
        this.f144b = false;
    }

    public void b(boolean z6) {
    }
}
