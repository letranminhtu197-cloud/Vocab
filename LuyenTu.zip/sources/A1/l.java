package A1;

import L4.AbstractActivityC0123b;
import android.window.OnBackInvokedCallback;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class l implements OnBackInvokedCallback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f165a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f166b;

    public /* synthetic */ l(Object obj, int i6) {
        this.f165a = i6;
        this.f166b = obj;
    }

    public final void onBackInvoked() {
        switch (this.f165a) {
            case 0:
                ((j) this.f166b).a();
                break;
            default:
                ((AbstractActivityC0123b) this.f166b).onBackPressed();
                break;
        }
    }
}
