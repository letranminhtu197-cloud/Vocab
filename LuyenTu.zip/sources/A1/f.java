package A1;

import com.google.android.gms.internal.play_billing.AbstractC0252u0;

/* JADX INFO: loaded from: classes.dex */
public final class f extends AbstractC0252u0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final f f159a = new f();

    public final String toString() {
        return "Idle()";
    }
}
