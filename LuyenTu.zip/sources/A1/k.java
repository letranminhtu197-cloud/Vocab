package A1;

import android.media.ImageReader;

/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class k {
    public static /* synthetic */ ImageReader.Builder h(int i6, int i7) {
        return new ImageReader.Builder(i6, i7);
    }

    public static /* synthetic */ void r() {
    }
}
