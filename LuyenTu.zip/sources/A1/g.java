package A1;

import com.google.android.gms.internal.play_billing.AbstractC0252u0;

/* JADX INFO: loaded from: classes.dex */
public final class g extends AbstractC0252u0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final b f160a;

    public g(b bVar) {
        A5.h.e(bVar, "latestEvent");
        this.f160a = bVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return obj != null && g.class == obj.getClass() && A5.h.a(this.f160a, ((g) obj).f160a);
    }

    public final int hashCode() {
        return this.f160a.hashCode() - 31;
    }

    public final String toString() {
        return "InProgress(latestEvent=" + this.f160a + ", direction=-1)";
    }
}
