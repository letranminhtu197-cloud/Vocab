package A1;

import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

/* JADX INFO: loaded from: classes.dex */
public final class j extends d {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final OnBackInvokedDispatcher f161c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f162d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final OnBackInvokedCallback f163e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f164f;

    public j(OnBackInvokedDispatcher onBackInvokedDispatcher, int i6) {
        this.f161c = onBackInvokedDispatcher;
        this.f162d = i6;
        this.f163e = Build.VERSION.SDK_INT == 33 ? new l(this, 0) : new m(this, 0);
    }

    @Override // A1.d
    public final void b(boolean z6) {
        if (z6 && !this.f164f) {
            this.f161c.registerOnBackInvokedCallback(this.f162d, this.f163e);
            this.f164f = true;
        } else {
            if (z6 || !this.f164f) {
                return;
            }
            this.f161c.unregisterOnBackInvokedCallback(this.f163e);
            this.f164f = false;
        }
    }
}
