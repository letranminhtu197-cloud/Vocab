package A1;

import C1.C0012m;
import L4.AbstractActivityC0123b;
import L4.C0127f;
import N5.x;
import W4.q;
import android.util.Log;
import android.window.BackEvent;
import android.window.OnBackAnimationCallback;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import p015d.p;
import p018d2.G;
import p030f0.C0319l;
import p030f0.H;
import p030f0.S;
import p030f0.T;
import p053i4.v;

/* JADX INFO: loaded from: classes.dex */
public final class m implements OnBackAnimationCallback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f167a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f168b;

    public /* synthetic */ m(Object obj, int i6) {
        this.f167a = i6;
        this.f168b = obj;
    }

    public final void onBackCancelled() {
        switch (this.f167a) {
            case 0:
                j jVar = (j) this.f168b;
                v vVar = jVar.f143a;
                if (vVar == null) {
                    throw new IllegalStateException("This input is not added to any dispatcher.");
                }
                if (!jVar.f144b) {
                    vVar.p(jVar, null);
                }
                e eVar = (e) vVar.f6368s;
                eVar.getClass();
                if (jVar.equals(eVar.f152h) && -1 == eVar.f151g) {
                    p pVarC = eVar.f150f;
                    if (pVarC == null) {
                        pVarC = eVar.c(-1);
                    }
                    eVar.f150f = null;
                    eVar.f151g = 0;
                    eVar.f152h = null;
                    if (pVarC != null) {
                        pVarC.a();
                    }
                    x xVar = eVar.f145a;
                    xVar.getClass();
                    xVar.g(null, f.f159a);
                }
                jVar.f144b = false;
                return;
            default:
                AbstractActivityC0123b abstractActivityC0123b = (AbstractActivityC0123b) this.f168b;
                if (abstractActivityC0123b.m("cancelBackGesture")) {
                    C0127f c0127f = abstractActivityC0123b.f2236s;
                    c0127f.c();
                    M4.b bVar = c0127f.f2242b;
                    if (bVar != null) {
                        ((q) bVar.f2470j.f7289s).a("cancelBackGesture", null, null);
                        return;
                    } else {
                        Log.w("FlutterActivityAndFragmentDelegate", "Invoked cancelBackGesture() before FlutterFragment was attached to an Activity.");
                        return;
                    }
                }
                return;
        }
    }

    public final void onBackInvoked() {
        switch (this.f167a) {
            case 0:
                ((j) this.f168b).a();
                break;
            default:
                AbstractActivityC0123b abstractActivityC0123b = (AbstractActivityC0123b) this.f168b;
                if (abstractActivityC0123b.m("commitBackGesture")) {
                    C0127f c0127f = abstractActivityC0123b.f2236s;
                    c0127f.c();
                    M4.b bVar = c0127f.f2242b;
                    if (bVar == null) {
                        Log.w("FlutterActivityAndFragmentDelegate", "Invoked commitBackGesture() before FlutterFragment was attached to an Activity.");
                    } else {
                        ((q) bVar.f2470j.f7289s).a("commitBackGesture", null, null);
                    }
                }
                break;
        }
    }

    public final void onBackProgressed(BackEvent backEvent) {
        switch (this.f167a) {
            case 0:
                A5.h.e(backEvent, "backEvent");
                j jVar = (j) this.f168b;
                b bVarA = G.a(backEvent);
                v vVar = jVar.f143a;
                if (vVar == null) {
                    throw new IllegalStateException("This input is not added to any dispatcher.");
                }
                if (jVar.f144b) {
                    e eVar = (e) vVar.f6368s;
                    eVar.getClass();
                    if (jVar.equals(eVar.f152h) && -1 == eVar.f151g) {
                        p pVarC = eVar.f150f;
                        if (pVarC == null) {
                            pVarC = eVar.c(-1);
                        }
                        if (pVarC != null) {
                            C0012m c0012m = pVarC.f5141d;
                            p015d.a aVar = new p015d.a(bVarA);
                            H h7 = (H) c0012m.f501d;
                            if (H.J(2)) {
                                Log.v("FragmentManager", "handleOnBackProgressed. PREDICTIVE_BACK = true fragment manager " + h7);
                            }
                            if (h7.f5565h != null) {
                                for (C0319l c0319l : h7.f(new ArrayList(Collections.singletonList(h7.f5565h)), 0, 1)) {
                                    c0319l.getClass();
                                    if (H.J(2)) {
                                        Log.v("FragmentManager", "SpecialEffectsController: Processing Progress " + aVar.f5093c);
                                    }
                                    ArrayList arrayList = c0319l.f5664c;
                                    ArrayList arrayList2 = new ArrayList();
                                    int size = arrayList.size();
                                    int i6 = 0;
                                    while (i6 < size) {
                                        Object obj = arrayList.get(i6);
                                        i6++;
                                        ((T) obj).getClass();
                                        p081m5.k.y0(arrayList2, null);
                                    }
                                    List listL0 = p081m5.f.L0(p081m5.f.P0(arrayList2));
                                    int size2 = listL0.size();
                                    for (int i7 = 0; i7 < size2; i7++) {
                                        ((S) listL0.get(i7)).b(aVar, c0319l.f5662a);
                                    }
                                }
                                Iterator it = h7.f5570m.iterator();
                                if (it.hasNext()) {
                                    it.next().getClass();
                                    throw new ClassCastException();
                                }
                            }
                        }
                        x xVar = eVar.f145a;
                        g gVar = new g(bVarA);
                        xVar.getClass();
                        xVar.g(null, gVar);
                        return;
                    }
                    return;
                }
                return;
            default:
                AbstractActivityC0123b abstractActivityC0123b = (AbstractActivityC0123b) this.f168b;
                if (abstractActivityC0123b.m("updateBackGestureProgress")) {
                    C0127f c0127f = abstractActivityC0123b.f2236s;
                    c0127f.c();
                    M4.b bVar = c0127f.f2242b;
                    if (bVar != null) {
                        ((q) bVar.f2470j.f7289s).a("updateBackGestureProgress", p066k4.c.H(backEvent), null);
                        return;
                    } else {
                        Log.w("FlutterActivityAndFragmentDelegate", "Invoked updateBackGestureProgress() before FlutterFragment was attached to an Activity.");
                        return;
                    }
                }
                return;
        }
    }

    public final void onBackStarted(BackEvent backEvent) {
        switch (this.f167a) {
            case 0:
                A5.h.e(backEvent, "backEvent");
                j jVar = (j) this.f168b;
                b bVarA = G.a(backEvent);
                v vVar = jVar.f143a;
                if (vVar == null) {
                    throw new IllegalStateException("This input is not added to any dispatcher.");
                }
                if (jVar.f144b) {
                    return;
                }
                vVar.p(jVar, bVarA);
                jVar.f144b = true;
                return;
            default:
                AbstractActivityC0123b abstractActivityC0123b = (AbstractActivityC0123b) this.f168b;
                if (abstractActivityC0123b.m("startBackGesture")) {
                    C0127f c0127f = abstractActivityC0123b.f2236s;
                    c0127f.c();
                    M4.b bVar = c0127f.f2242b;
                    if (bVar != null) {
                        ((q) bVar.f2470j.f7289s).a("startBackGesture", p066k4.c.H(backEvent), null);
                        return;
                    } else {
                        Log.w("FlutterActivityAndFragmentDelegate", "Invoked startBackGesture() before FlutterFragment was attached to an Activity.");
                        return;
                    }
                }
                return;
        }
    }
}
